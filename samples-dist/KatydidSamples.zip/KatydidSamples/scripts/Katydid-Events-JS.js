if (typeof kotlin === 'undefined') {
  throw new Error("Error loading module 'Katydid-Events-JS'. Its dependency 'kotlin' was not found. Please, check whether 'kotlin' is loaded prior to 'Katydid-Events-JS'.");
}
this['Katydid-Events-JS'] = function (_, Kotlin) {
  'use strict';
  var throwCCE = Kotlin.throwCCE;
  var Kind_OBJECT = Kotlin.Kind.OBJECT;
  var Kind_CLASS = Kotlin.Kind.CLASS;
  var Kind_INTERFACE = Kotlin.Kind.INTERFACE;
  var Enum = Kotlin.kotlin.Enum;
  var throwISE = Kotlin.throwISE;
  var Any = Object;
  var listOf = Kotlin.kotlin.collections.listOf_i5x0yv$;
  KatydidWheelEvent$DeltaMode.prototype = Object.create(Enum.prototype);
  KatydidWheelEvent$DeltaMode.prototype.constructor = KatydidWheelEvent$DeltaMode;
  KatydidUiEventImpl.prototype = Object.create(KatydidEventImpl.prototype);
  KatydidUiEventImpl.prototype.constructor = KatydidUiEventImpl;
  KatydidFocusEventImpl.prototype = Object.create(KatydidUiEventImpl.prototype);
  KatydidFocusEventImpl.prototype.constructor = KatydidFocusEventImpl;
  KatydidInputEventImpl.prototype = Object.create(KatydidUiEventImpl.prototype);
  KatydidInputEventImpl.prototype.constructor = KatydidInputEventImpl;
  KatydidMouseEventImpl.prototype = Object.create(KatydidUiEventImpl.prototype);
  KatydidMouseEventImpl.prototype.constructor = KatydidMouseEventImpl;
  KatydidWheelEventImpl.prototype = Object.create(KatydidMouseEventImpl.prototype);
  KatydidWheelEventImpl.prototype.constructor = KatydidWheelEventImpl;
  function EventPool() {
    EventPool$Companion_getInstance();
  }
  function EventPool$Companion() {
    EventPool$Companion_instance = this;
  }
  EventPool$Companion.prototype.makeEvent_9ojx7i$ = function (event) {
    return new KatydidEventImpl(event);
  };
  EventPool$Companion.prototype.makeFocusEvent_9ojx7i$ = function (event) {
    var tmp$;
    return new KatydidFocusEventImpl(Kotlin.isType(tmp$ = event, FocusEvent) ? tmp$ : throwCCE());
  };
  EventPool$Companion.prototype.makeInputEvent_9ojx7i$ = function (event) {
    var tmp$;
    return new KatydidInputEventImpl(Kotlin.isType(tmp$ = event, InputEvent) ? tmp$ : throwCCE());
  };
  EventPool$Companion.prototype.makeMouseEvent_9ojx7i$ = function (event) {
    var tmp$;
    return new KatydidMouseEventImpl(Kotlin.isType(tmp$ = event, MouseEvent) ? tmp$ : throwCCE());
  };
  EventPool$Companion.prototype.makeWheelEvent_9ojx7i$ = function (event) {
    var tmp$;
    return new KatydidWheelEventImpl(Kotlin.isType(tmp$ = event, WheelEvent) ? tmp$ : throwCCE());
  };
  EventPool$Companion.$metadata$ = {
    kind: Kind_OBJECT,
    simpleName: 'Companion',
    interfaces: []
  };
  var EventPool$Companion_instance = null;
  function EventPool$Companion_getInstance() {
    if (EventPool$Companion_instance === null) {
      new EventPool$Companion();
    }
    return EventPool$Companion_instance;
  }
  EventPool.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'EventPool',
    interfaces: []
  };
  function onblur$lambda(closure$handler) {
    return function (event) {
      return closure$handler(EventPool$Companion_getInstance().makeFocusEvent_9ojx7i$(event));
    };
  }
  function onblur($receiver, handler) {
    $receiver.onEvent_ahb438$('blur', onblur$lambda(handler));
  }
  function onfocus$lambda(closure$handler) {
    return function (event) {
      return closure$handler(EventPool$Companion_getInstance().makeFocusEvent_9ojx7i$(event));
    };
  }
  function onfocus($receiver, handler) {
    $receiver.onEvent_ahb438$('focus', onfocus$lambda(handler));
  }
  function onbeforeinput$lambda(closure$handler) {
    return function (event) {
      return closure$handler(EventPool$Companion_getInstance().makeInputEvent_9ojx7i$(event));
    };
  }
  function onbeforeinput($receiver, handler) {
    $receiver.onEvent_ahb438$('beforeinput', onbeforeinput$lambda(handler));
  }
  function onchange$lambda(closure$handler) {
    return function (event) {
      return closure$handler(EventPool$Companion_getInstance().makeEvent_9ojx7i$(event));
    };
  }
  function onchange($receiver, handler) {
    $receiver.onEvent_ahb438$('change', onchange$lambda(handler));
  }
  function oninput$lambda(closure$handler) {
    return function (event) {
      return closure$handler(EventPool$Companion_getInstance().makeInputEvent_9ojx7i$(event));
    };
  }
  function oninput($receiver, handler) {
    $receiver.onEvent_ahb438$('input', oninput$lambda(handler));
  }
  function onkeydown$lambda(closure$handler) {
    return function (event) {
      var tmp$;
      return closure$handler(Kotlin.isType(tmp$ = event, KeyboardEvent) ? tmp$ : throwCCE());
    };
  }
  function onkeydown($receiver, handler) {
    $receiver.onEvent_ahb438$('keydown', onkeydown$lambda(handler));
  }
  function onkeyup$lambda(closure$handler) {
    return function (event) {
      var tmp$;
      return closure$handler(Kotlin.isType(tmp$ = event, KeyboardEvent) ? tmp$ : throwCCE());
    };
  }
  function onkeyup($receiver, handler) {
    $receiver.onEvent_ahb438$('keyup', onkeyup$lambda(handler));
  }
  function onclick$lambda(closure$handler) {
    return function (event) {
      return closure$handler(EventPool$Companion_getInstance().makeMouseEvent_9ojx7i$(event));
    };
  }
  function onclick($receiver, handler) {
    $receiver.onEvent_ahb438$('click', onclick$lambda(handler));
  }
  function ondblclick$lambda(closure$handler) {
    return function (event) {
      return closure$handler(EventPool$Companion_getInstance().makeMouseEvent_9ojx7i$(event));
    };
  }
  function ondblclick($receiver, handler) {
    $receiver.onEvent_ahb438$('dblclick', ondblclick$lambda(handler));
  }
  function onmousedown$lambda(closure$handler) {
    return function (event) {
      return closure$handler(EventPool$Companion_getInstance().makeMouseEvent_9ojx7i$(event));
    };
  }
  function onmousedown($receiver, handler) {
    $receiver.onEvent_ahb438$('mousedown', onmousedown$lambda(handler));
  }
  function onmouseenter$lambda(closure$handler) {
    return function (event) {
      return closure$handler(EventPool$Companion_getInstance().makeMouseEvent_9ojx7i$(event));
    };
  }
  function onmouseenter($receiver, handler) {
    $receiver.onEvent_ahb438$('mouseenter', onmouseenter$lambda(handler));
  }
  function onmouseleave$lambda(closure$handler) {
    return function (event) {
      return closure$handler(EventPool$Companion_getInstance().makeMouseEvent_9ojx7i$(event));
    };
  }
  function onmouseleave($receiver, handler) {
    $receiver.onEvent_ahb438$('mouseleave', onmouseleave$lambda(handler));
  }
  function onmousemove$lambda(closure$handler) {
    return function (event) {
      return closure$handler(EventPool$Companion_getInstance().makeMouseEvent_9ojx7i$(event));
    };
  }
  function onmousemove($receiver, handler) {
    $receiver.onEvent_ahb438$('mousemove', onmousemove$lambda(handler));
  }
  function onmouseout$lambda(closure$handler) {
    return function (event) {
      return closure$handler(EventPool$Companion_getInstance().makeMouseEvent_9ojx7i$(event));
    };
  }
  function onmouseout($receiver, handler) {
    $receiver.onEvent_ahb438$('mouseout', onmouseout$lambda(handler));
  }
  function onmouseover$lambda(closure$handler) {
    return function (event) {
      return closure$handler(EventPool$Companion_getInstance().makeMouseEvent_9ojx7i$(event));
    };
  }
  function onmouseover($receiver, handler) {
    $receiver.onEvent_ahb438$('mouseover', onmouseover$lambda(handler));
  }
  function onmouseup$lambda(closure$handler) {
    return function (event) {
      return closure$handler(EventPool$Companion_getInstance().makeMouseEvent_9ojx7i$(event));
    };
  }
  function onmouseup($receiver, handler) {
    $receiver.onEvent_ahb438$('mouseup', onmouseup$lambda(handler));
  }
  function onwheel$lambda(closure$handler) {
    return function (event) {
      return closure$handler(EventPool$Companion_getInstance().makeWheelEvent_9ojx7i$(event));
    };
  }
  function onwheel($receiver, handler) {
    $receiver.onEvent_ahb438$('wheel', onwheel$lambda(handler));
  }
  function KatydidEvent() {
  }
  KatydidEvent.$metadata$ = {
    kind: Kind_INTERFACE,
    simpleName: 'KatydidEvent',
    interfaces: []
  };
  function KatydidFocusEvent() {
  }
  KatydidFocusEvent.$metadata$ = {
    kind: Kind_INTERFACE,
    simpleName: 'KatydidFocusEvent',
    interfaces: [KatydidUiEvent]
  };
  function KatydidInputEvent() {
  }
  KatydidInputEvent.$metadata$ = {
    kind: Kind_INTERFACE,
    simpleName: 'KatydidInputEvent',
    interfaces: [KatydidUiEvent]
  };
  function KatydidMouseEvent() {
  }
  KatydidMouseEvent.$metadata$ = {
    kind: Kind_INTERFACE,
    simpleName: 'KatydidMouseEvent',
    interfaces: [KatydidUiEvent]
  };
  function KatydidUiEvent() {
  }
  KatydidUiEvent.$metadata$ = {
    kind: Kind_INTERFACE,
    simpleName: 'KatydidUiEvent',
    interfaces: [KatydidEvent]
  };
  function KatydidWheelEvent() {
  }
  function KatydidWheelEvent$DeltaMode(name, ordinal) {
    Enum.call(this);
    this.name$ = name;
    this.ordinal$ = ordinal;
  }
  function KatydidWheelEvent$DeltaMode_initFields() {
    KatydidWheelEvent$DeltaMode_initFields = function () {
    };
    KatydidWheelEvent$DeltaMode$DELTA_PIXEL_instance = new KatydidWheelEvent$DeltaMode('DELTA_PIXEL', 0);
    KatydidWheelEvent$DeltaMode$DELTA_LINE_instance = new KatydidWheelEvent$DeltaMode('DELTA_LINE', 1);
    KatydidWheelEvent$DeltaMode$DELTA_PAGE_instance = new KatydidWheelEvent$DeltaMode('DELTA_PAGE', 2);
  }
  var KatydidWheelEvent$DeltaMode$DELTA_PIXEL_instance;
  function KatydidWheelEvent$DeltaMode$DELTA_PIXEL_getInstance() {
    KatydidWheelEvent$DeltaMode_initFields();
    return KatydidWheelEvent$DeltaMode$DELTA_PIXEL_instance;
  }
  var KatydidWheelEvent$DeltaMode$DELTA_LINE_instance;
  function KatydidWheelEvent$DeltaMode$DELTA_LINE_getInstance() {
    KatydidWheelEvent$DeltaMode_initFields();
    return KatydidWheelEvent$DeltaMode$DELTA_LINE_instance;
  }
  var KatydidWheelEvent$DeltaMode$DELTA_PAGE_instance;
  function KatydidWheelEvent$DeltaMode$DELTA_PAGE_getInstance() {
    KatydidWheelEvent$DeltaMode_initFields();
    return KatydidWheelEvent$DeltaMode$DELTA_PAGE_instance;
  }
  KatydidWheelEvent$DeltaMode.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'DeltaMode',
    interfaces: [Enum]
  };
  function KatydidWheelEvent$DeltaMode$values() {
    return [KatydidWheelEvent$DeltaMode$DELTA_PIXEL_getInstance(), KatydidWheelEvent$DeltaMode$DELTA_LINE_getInstance(), KatydidWheelEvent$DeltaMode$DELTA_PAGE_getInstance()];
  }
  KatydidWheelEvent$DeltaMode.values = KatydidWheelEvent$DeltaMode$values;
  function KatydidWheelEvent$DeltaMode$valueOf(name) {
    switch (name) {
      case 'DELTA_PIXEL':
        return KatydidWheelEvent$DeltaMode$DELTA_PIXEL_getInstance();
      case 'DELTA_LINE':
        return KatydidWheelEvent$DeltaMode$DELTA_LINE_getInstance();
      case 'DELTA_PAGE':
        return KatydidWheelEvent$DeltaMode$DELTA_PAGE_getInstance();
      default:throwISE('No enum constant o.katydid.events.types.KatydidWheelEvent.DeltaMode.' + name);
    }
  }
  KatydidWheelEvent$DeltaMode.valueOf_61zpoe$ = KatydidWheelEvent$DeltaMode$valueOf;
  KatydidWheelEvent.$metadata$ = {
    kind: Kind_INTERFACE,
    simpleName: 'KatydidWheelEvent',
    interfaces: [KatydidMouseEvent]
  };
  function KatydidEventImpl(event) {
    this.event_q6bh6a$_0 = event;
  }
  Object.defineProperty(KatydidEventImpl.prototype, 'isDefaultPrevented', {
    get: function () {
      return this.event_q6bh6a$_0.defaultPrevented;
    }
  });
  Object.defineProperty(KatydidEventImpl.prototype, 'isPropagationStopped', {
    get: function () {
      return false;
    }
  });
  KatydidEventImpl.prototype.getTargetAttribute_ytbaoo$ = function (attrName) {
    var tmp$;
    return (tmp$ = this.event_q6bh6a$_0.target[attrName]) == null || Kotlin.isType(tmp$, Any) ? tmp$ : throwCCE();
  };
  KatydidEventImpl.prototype.preventDefault = function () {
    this.event_q6bh6a$_0.preventDefault();
  };
  KatydidEventImpl.prototype.stopPropagation = function () {
    this.event_q6bh6a$_0.stopPropagation();
  };
  KatydidEventImpl.prototype.setTargetAttribute_umlfku$ = function (attrName, value) {
    this.event_q6bh6a$_0.target[attrName] = value;
  };
  KatydidEventImpl.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidEventImpl',
    interfaces: [KatydidEvent]
  };
  function KatydidFocusEventImpl(event) {
    KatydidUiEventImpl.call(this, event);
    this.event_0 = event;
  }
  KatydidFocusEventImpl.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidFocusEventImpl',
    interfaces: [KatydidFocusEvent, KatydidUiEventImpl]
  };
  function KatydidInputEventImpl(event) {
    KatydidUiEventImpl.call(this, event);
    this.event_0 = event;
  }
  KatydidInputEventImpl.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidInputEventImpl',
    interfaces: [KatydidInputEvent, KatydidUiEventImpl]
  };
  function KatydidMouseEventImpl(event) {
    KatydidUiEventImpl.call(this, event);
    this.event_2cldi7$_0 = event;
  }
  Object.defineProperty(KatydidMouseEventImpl.prototype, 'altKey', {
    get: function () {
      return this.event_2cldi7$_0.altKey;
    }
  });
  Object.defineProperty(KatydidMouseEventImpl.prototype, 'button', {
    get: function () {
      return this.event_2cldi7$_0.button;
    }
  });
  Object.defineProperty(KatydidMouseEventImpl.prototype, 'buttons', {
    get: function () {
      return this.event_2cldi7$_0.buttons;
    }
  });
  Object.defineProperty(KatydidMouseEventImpl.prototype, 'clientX', {
    get: function () {
      return this.event_2cldi7$_0.clientX;
    }
  });
  Object.defineProperty(KatydidMouseEventImpl.prototype, 'clientY', {
    get: function () {
      return this.event_2cldi7$_0.clientY;
    }
  });
  Object.defineProperty(KatydidMouseEventImpl.prototype, 'ctrlKey', {
    get: function () {
      return this.event_2cldi7$_0.ctrlKey;
    }
  });
  Object.defineProperty(KatydidMouseEventImpl.prototype, 'metaKey', {
    get: function () {
      return this.event_2cldi7$_0.metaKey;
    }
  });
  Object.defineProperty(KatydidMouseEventImpl.prototype, 'offsetX', {
    get: function () {
      return this.event_2cldi7$_0.offsetX;
    }
  });
  Object.defineProperty(KatydidMouseEventImpl.prototype, 'offsetY', {
    get: function () {
      return this.event_2cldi7$_0.offsetY;
    }
  });
  Object.defineProperty(KatydidMouseEventImpl.prototype, 'pageX', {
    get: function () {
      return this.event_2cldi7$_0.pageX;
    }
  });
  Object.defineProperty(KatydidMouseEventImpl.prototype, 'pageY', {
    get: function () {
      return this.event_2cldi7$_0.pageY;
    }
  });
  Object.defineProperty(KatydidMouseEventImpl.prototype, 'screenX', {
    get: function () {
      return this.event_2cldi7$_0.screenX;
    }
  });
  Object.defineProperty(KatydidMouseEventImpl.prototype, 'screenY', {
    get: function () {
      return this.event_2cldi7$_0.screenY;
    }
  });
  Object.defineProperty(KatydidMouseEventImpl.prototype, 'shiftKey', {
    get: function () {
      return this.event_2cldi7$_0.shiftKey;
    }
  });
  KatydidMouseEventImpl.prototype.getModifierState_61zpoe$ = function (key) {
    return this.event_2cldi7$_0.getModifierState(key);
  };
  KatydidMouseEventImpl.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidMouseEventImpl',
    interfaces: [KatydidMouseEvent, KatydidUiEventImpl]
  };
  function KatydidUiEventImpl(event) {
    KatydidEventImpl.call(this, event);
    this.event_ubew72$_0 = event;
  }
  KatydidUiEventImpl.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidUiEventImpl',
    interfaces: [KatydidUiEvent, KatydidEventImpl]
  };
  function KatydidWheelEventImpl(event) {
    KatydidWheelEventImpl$Companion_getInstance();
    KatydidMouseEventImpl.call(this, event);
    this.event_0 = event;
  }
  Object.defineProperty(KatydidWheelEventImpl.prototype, 'deltaMode', {
    get: function () {
      return KatydidWheelEventImpl$Companion_getInstance().deltaModes.get_za3lpa$(this.event_0.deltaMode);
    }
  });
  Object.defineProperty(KatydidWheelEventImpl.prototype, 'deltaX', {
    get: function () {
      return this.event_0.deltaX;
    }
  });
  Object.defineProperty(KatydidWheelEventImpl.prototype, 'deltaY', {
    get: function () {
      return this.event_0.deltaY;
    }
  });
  Object.defineProperty(KatydidWheelEventImpl.prototype, 'deltaZ', {
    get: function () {
      return this.event_0.deltaZ;
    }
  });
  function KatydidWheelEventImpl$Companion() {
    KatydidWheelEventImpl$Companion_instance = this;
    this.deltaModes = listOf([KatydidWheelEvent$DeltaMode$DELTA_PIXEL_getInstance(), KatydidWheelEvent$DeltaMode$DELTA_LINE_getInstance(), KatydidWheelEvent$DeltaMode$DELTA_PAGE_getInstance()]);
  }
  KatydidWheelEventImpl$Companion.$metadata$ = {
    kind: Kind_OBJECT,
    simpleName: 'Companion',
    interfaces: []
  };
  var KatydidWheelEventImpl$Companion_instance = null;
  function KatydidWheelEventImpl$Companion_getInstance() {
    if (KatydidWheelEventImpl$Companion_instance === null) {
      new KatydidWheelEventImpl$Companion();
    }
    return KatydidWheelEventImpl$Companion_instance;
  }
  KatydidWheelEventImpl.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidWheelEventImpl',
    interfaces: [KatydidWheelEvent, KatydidMouseEventImpl]
  };
  Object.defineProperty(EventPool, 'Companion', {
    get: EventPool$Companion_getInstance
  });
  var package$i = _.i || (_.i = {});
  var package$katydid = package$i.katydid || (package$i.katydid = {});
  var package$events = package$katydid.events || (package$katydid.events = {});
  var package$pool = package$events.pool || (package$events.pool = {});
  package$pool.EventPool = EventPool;
  var package$o = _.o || (_.o = {});
  var package$katydid_0 = package$o.katydid || (package$o.katydid = {});
  var package$events_0 = package$katydid_0.events || (package$katydid_0.events = {});
  var package$eventhandling = package$events_0.eventhandling || (package$events_0.eventhandling = {});
  package$eventhandling.onblur_gtueds$ = onblur;
  package$eventhandling.onfocus_gtueds$ = onfocus;
  package$eventhandling.onbeforeinput_i6t1xa$ = onbeforeinput;
  package$eventhandling.onchange_94yeqk$ = onchange;
  package$eventhandling.oninput_i6t1xa$ = oninput;
  package$eventhandling.onkeydown_6l7vgm$ = onkeydown;
  package$eventhandling.onkeyup_6l7vgm$ = onkeyup;
  package$eventhandling.onclick_qkbymb$ = onclick;
  package$eventhandling.ondblclick_qkbymb$ = ondblclick;
  package$eventhandling.onmousedown_qkbymb$ = onmousedown;
  package$eventhandling.onmouseenter_qkbymb$ = onmouseenter;
  package$eventhandling.onmouseleave_qkbymb$ = onmouseleave;
  package$eventhandling.onmousemove_qkbymb$ = onmousemove;
  package$eventhandling.onmouseout_qkbymb$ = onmouseout;
  package$eventhandling.onmouseover_qkbymb$ = onmouseover;
  package$eventhandling.onmouseup_qkbymb$ = onmouseup;
  package$eventhandling.onwheel_9uas4z$ = onwheel;
  var package$types = package$events_0.types || (package$events_0.types = {});
  package$types.KatydidEvent = KatydidEvent;
  package$types.KatydidFocusEvent = KatydidFocusEvent;
  package$types.KatydidInputEvent = KatydidInputEvent;
  package$types.KatydidMouseEvent = KatydidMouseEvent;
  package$types.KatydidUiEvent = KatydidUiEvent;
  Object.defineProperty(KatydidWheelEvent$DeltaMode, 'DELTA_PIXEL', {
    get: KatydidWheelEvent$DeltaMode$DELTA_PIXEL_getInstance
  });
  Object.defineProperty(KatydidWheelEvent$DeltaMode, 'DELTA_LINE', {
    get: KatydidWheelEvent$DeltaMode$DELTA_LINE_getInstance
  });
  Object.defineProperty(KatydidWheelEvent$DeltaMode, 'DELTA_PAGE', {
    get: KatydidWheelEvent$DeltaMode$DELTA_PAGE_getInstance
  });
  KatydidWheelEvent.DeltaMode = KatydidWheelEvent$DeltaMode;
  package$types.KatydidWheelEvent = KatydidWheelEvent;
  var package$x = _.x || (_.x = {});
  var package$katydid_1 = package$x.katydid || (package$x.katydid = {});
  var package$events_1 = package$katydid_1.events || (package$katydid_1.events = {});
  var package$types_0 = package$events_1.types || (package$events_1.types = {});
  package$types_0.KatydidEventImpl = KatydidEventImpl;
  package$types_0.KatydidFocusEventImpl = KatydidFocusEventImpl;
  package$types_0.KatydidInputEventImpl = KatydidInputEventImpl;
  package$types_0.KatydidMouseEventImpl = KatydidMouseEventImpl;
  package$types_0.KatydidUiEventImpl = KatydidUiEventImpl;
  Object.defineProperty(KatydidWheelEventImpl, 'Companion', {
    get: KatydidWheelEventImpl$Companion_getInstance
  });
  package$types_0.KatydidWheelEventImpl = KatydidWheelEventImpl;
  Kotlin.defineModule('Katydid-Events-JS', _);
  return _;
}(typeof this['Katydid-Events-JS'] === 'undefined' ? {} : this['Katydid-Events-JS'], kotlin);

//# sourceMappingURL=Katydid-Events-JS.js.map
