if (typeof kotlin === 'undefined') {
  throw new Error("Error loading module 'Katydid-VDOM-JS'. Its dependency 'kotlin' was not found. Please, check whether 'kotlin' is loaded prior to 'Katydid-VDOM-JS'.");
}
this['Katydid-VDOM-JS'] = function (_, Kotlin) {
  'use strict';
  var Kind_CLASS = Kotlin.Kind.CLASS;
  var IllegalStateException_init = Kotlin.kotlin.IllegalStateException_init_pdl1vj$;
  var startsWith = Kotlin.kotlin.text.startsWith_7epoxm$;
  var Unit = Kotlin.kotlin.Unit;
  var ArrayList_init = Kotlin.kotlin.collections.ArrayList_init_287e2$;
  var collectionSizeOrDefault = Kotlin.kotlin.collections.collectionSizeOrDefault_ba2ldo$;
  var ArrayList_init_0 = Kotlin.kotlin.collections.ArrayList_init_ww73n8$;
  var IllegalArgumentException_init = Kotlin.kotlin.IllegalArgumentException_init_pdl1vj$;
  var joinToString = Kotlin.kotlin.collections.joinToString_fmv235$;
  var Kind_OBJECT = Kotlin.Kind.OBJECT;
  var addAll = Kotlin.kotlin.collections.addAll_ipc267$;
  var toString = Kotlin.toString;
  var split = Kotlin.kotlin.text.split_ip8yn$;
  var sorted = Kotlin.kotlin.collections.sorted_exjks8$;
  var equals = Kotlin.equals;
  var LinkedHashMap_init = Kotlin.kotlin.collections.LinkedHashMap_init_q3lmfv$;
  var LinkedHashSet_init = Kotlin.kotlin.collections.LinkedHashSet_init_287e2$;
  var Map = Kotlin.kotlin.collections.Map;
  var throwCCE = Kotlin.throwCCE;
  var Enum = Kotlin.kotlin.Enum;
  var throwISE = Kotlin.throwISE;
  var ensureNotNull = Kotlin.ensureNotNull;
  var HashMap_init = Kotlin.kotlin.collections.HashMap_init_q3lmfv$;
  var getCallableRef = Kotlin.getCallableRef;
  var UnsupportedOperationException_init = Kotlin.kotlin.UnsupportedOperationException_init_pdl1vj$;
  var MutableMap = Kotlin.kotlin.collections.MutableMap;
  var MutableSet = Kotlin.kotlin.collections.MutableSet;
  var Kind_INTERFACE = Kotlin.Kind.INTERFACE;
  var emptyList = Kotlin.kotlin.collections.emptyList_287e2$;
  var Annotation = Kotlin.kotlin.Annotation;
  var RuntimeException_init = Kotlin.kotlin.RuntimeException_init;
  var RuntimeException = Kotlin.kotlin.RuntimeException;
  var emptyMap = Kotlin.kotlin.collections.emptyMap_q3lmfv$;
  KatydidEmbeddedContentBuilderImpl.prototype = Object.create(KatydidAttributesContentBuilderImpl.prototype);
  KatydidEmbeddedContentBuilderImpl.prototype.constructor = KatydidEmbeddedContentBuilderImpl;
  KatydidPhrasingContentBuilderImpl.prototype = Object.create(KatydidEmbeddedContentBuilderImpl.prototype);
  KatydidPhrasingContentBuilderImpl.prototype.constructor = KatydidPhrasingContentBuilderImpl;
  KatydidFlowContentBuilderImpl.prototype = Object.create(KatydidPhrasingContentBuilderImpl.prototype);
  KatydidFlowContentBuilderImpl.prototype.constructor = KatydidFlowContentBuilderImpl;
  KatydidDetailsFlowContentBuilderImpl.prototype = Object.create(KatydidFlowContentBuilderImpl.prototype);
  KatydidDetailsFlowContentBuilderImpl.prototype.constructor = KatydidDetailsFlowContentBuilderImpl;
  KatydidOrderedListContentBuilderImpl.prototype = Object.create(KatydidAttributesContentBuilderImpl.prototype);
  KatydidOrderedListContentBuilderImpl.prototype.constructor = KatydidOrderedListContentBuilderImpl;
  KatydidUnorderedListContentBuilderImpl.prototype = Object.create(KatydidAttributesContentBuilderImpl.prototype);
  KatydidUnorderedListContentBuilderImpl.prototype.constructor = KatydidUnorderedListContentBuilderImpl;
  KatydidMediaEmbeddedContentBuilderImpl.prototype = Object.create(KatydidEmbeddedContentBuilderImpl.prototype);
  KatydidMediaEmbeddedContentBuilderImpl.prototype.constructor = KatydidMediaEmbeddedContentBuilderImpl;
  KatydidMediaFlowContentBuilderImpl.prototype = Object.create(KatydidFlowContentBuilderImpl.prototype);
  KatydidMediaFlowContentBuilderImpl.prototype.constructor = KatydidMediaFlowContentBuilderImpl;
  KatydidMediaPhrasingContentBuilderImpl.prototype = Object.create(KatydidPhrasingContentBuilderImpl.prototype);
  KatydidMediaPhrasingContentBuilderImpl.prototype.constructor = KatydidMediaPhrasingContentBuilderImpl;
  KatydidPictureContentBuilderImpl.prototype = Object.create(KatydidAttributesContentBuilderImpl.prototype);
  KatydidPictureContentBuilderImpl.prototype.constructor = KatydidPictureContentBuilderImpl;
  KatydidDescriptionListContentBuilderImpl.prototype = Object.create(KatydidAttributesContentBuilderImpl.prototype);
  KatydidDescriptionListContentBuilderImpl.prototype.constructor = KatydidDescriptionListContentBuilderImpl;
  KatydidOptGroupContentBuilderImpl.prototype = Object.create(KatydidAttributesContentBuilderImpl.prototype);
  KatydidOptGroupContentBuilderImpl.prototype.constructor = KatydidOptGroupContentBuilderImpl;
  KatydidSelectContentBuilderImpl.prototype = Object.create(KatydidOptGroupContentBuilderImpl.prototype);
  KatydidSelectContentBuilderImpl.prototype.constructor = KatydidSelectContentBuilderImpl;
  KatydidTextContentBuilderImpl.prototype = Object.create(KatydidAttributesContentBuilderImpl.prototype);
  KatydidTextContentBuilderImpl.prototype.constructor = KatydidTextContentBuilderImpl;
  KatydidObjectEmbeddedContentBuilderImpl.prototype = Object.create(KatydidEmbeddedContentBuilderImpl.prototype);
  KatydidObjectEmbeddedContentBuilderImpl.prototype.constructor = KatydidObjectEmbeddedContentBuilderImpl;
  KatydidObjectFlowContentBuilderImpl.prototype = Object.create(KatydidFlowContentBuilderImpl.prototype);
  KatydidObjectFlowContentBuilderImpl.prototype.constructor = KatydidObjectFlowContentBuilderImpl;
  KatydidObjectPhrasingContentBuilderImpl.prototype = Object.create(KatydidPhrasingContentBuilderImpl.prototype);
  KatydidObjectPhrasingContentBuilderImpl.prototype.constructor = KatydidObjectPhrasingContentBuilderImpl;
  KatydidRubyContentBuilderImpl.prototype = Object.create(KatydidPhrasingContentBuilderImpl.prototype);
  KatydidRubyContentBuilderImpl.prototype.constructor = KatydidRubyContentBuilderImpl;
  KatydidColGroupContentBuilderImpl.prototype = Object.create(KatydidAttributesContentBuilderImpl.prototype);
  KatydidColGroupContentBuilderImpl.prototype.constructor = KatydidColGroupContentBuilderImpl;
  KatydidTableBodyContentBuilderImpl.prototype = Object.create(KatydidAttributesContentBuilderImpl.prototype);
  KatydidTableBodyContentBuilderImpl.prototype.constructor = KatydidTableBodyContentBuilderImpl;
  KatydidTableContentBuilderImpl.prototype = Object.create(KatydidAttributesContentBuilderImpl.prototype);
  KatydidTableContentBuilderImpl.prototype.constructor = KatydidTableContentBuilderImpl;
  KatydidTableRowContentBuilderImpl.prototype = Object.create(KatydidAttributesContentBuilderImpl.prototype);
  KatydidTableRowContentBuilderImpl.prototype.constructor = KatydidTableRowContentBuilderImpl;
  KatydidElementImpl.prototype = Object.create(KatydidNodeImpl.prototype);
  KatydidElementImpl.prototype.constructor = KatydidElementImpl;
  KatydidHtmlElementImpl.prototype = Object.create(KatydidElementImpl.prototype);
  KatydidHtmlElementImpl.prototype.constructor = KatydidHtmlElementImpl;
  KatydidAppPseudoNode.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidAppPseudoNode.prototype.constructor = KatydidAppPseudoNode;
  KatydidDel.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidDel.prototype.constructor = KatydidDel;
  KatydidIns.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidIns.prototype.constructor = KatydidIns;
  KatydidArea.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidArea.prototype.constructor = KatydidArea;
  KatydidAudio.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidAudio.prototype.constructor = KatydidAudio;
  KatydidEmbed.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidEmbed.prototype.constructor = KatydidEmbed;
  KatydidIframe.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidIframe.prototype.constructor = KatydidIframe;
  KatydidImg.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidImg.prototype.constructor = KatydidImg;
  KatydidMap.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidMap.prototype.constructor = KatydidMap;
  KatydidObject.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidObject.prototype.constructor = KatydidObject;
  KatydidParam.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidParam.prototype.constructor = KatydidParam;
  KatydidPicture.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidPicture.prototype.constructor = KatydidPicture;
  KatydidSource.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidSource.prototype.constructor = KatydidSource;
  KatydidTrack.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidTrack.prototype.constructor = KatydidTrack;
  KatydidVideo.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidVideo.prototype.constructor = KatydidVideo;
  KatydidButton.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidButton.prototype.constructor = KatydidButton;
  KatydidDataList.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidDataList.prototype.constructor = KatydidDataList;
  KatydidFieldSet.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidFieldSet.prototype.constructor = KatydidFieldSet;
  KatydidForm.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidForm.prototype.constructor = KatydidForm;
  KatydidInputButton.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidInputButton.prototype.constructor = KatydidInputButton;
  KatydidInputCheckbox.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidInputCheckbox.prototype.constructor = KatydidInputCheckbox;
  KatydidInputColor.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidInputColor.prototype.constructor = KatydidInputColor;
  KatydidInputDate.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidInputDate.prototype.constructor = KatydidInputDate;
  KatydidInputDateTimeLocal.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidInputDateTimeLocal.prototype.constructor = KatydidInputDateTimeLocal;
  KatydidInputEmail.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidInputEmail.prototype.constructor = KatydidInputEmail;
  KatydidInputFile.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidInputFile.prototype.constructor = KatydidInputFile;
  KatydidInputHidden.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidInputHidden.prototype.constructor = KatydidInputHidden;
  KatydidInputImageButton.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidInputImageButton.prototype.constructor = KatydidInputImageButton;
  KatydidInputMonth.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidInputMonth.prototype.constructor = KatydidInputMonth;
  KatydidInputNumber.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidInputNumber.prototype.constructor = KatydidInputNumber;
  KatydidInputPassword.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidInputPassword.prototype.constructor = KatydidInputPassword;
  KatydidInputRadioButton.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidInputRadioButton.prototype.constructor = KatydidInputRadioButton;
  KatydidInputRange.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidInputRange.prototype.constructor = KatydidInputRange;
  KatydidInputResetButton.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidInputResetButton.prototype.constructor = KatydidInputResetButton;
  KatydidInputSearch.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidInputSearch.prototype.constructor = KatydidInputSearch;
  KatydidInputSubmitButton.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidInputSubmitButton.prototype.constructor = KatydidInputSubmitButton;
  KatydidInputTelephone.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidInputTelephone.prototype.constructor = KatydidInputTelephone;
  KatydidInputText.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidInputText.prototype.constructor = KatydidInputText;
  KatydidInputTime.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidInputTime.prototype.constructor = KatydidInputTime;
  KatydidInputUrl.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidInputUrl.prototype.constructor = KatydidInputUrl;
  KatydidInputWeek.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidInputWeek.prototype.constructor = KatydidInputWeek;
  KatydidLabel.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidLabel.prototype.constructor = KatydidLabel;
  KatydidLegend.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidLegend.prototype.constructor = KatydidLegend;
  KatydidMeter.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidMeter.prototype.constructor = KatydidMeter;
  KatydidOptGroup.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidOptGroup.prototype.constructor = KatydidOptGroup;
  KatydidOption.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidOption.prototype.constructor = KatydidOption;
  KatydidOutput.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidOutput.prototype.constructor = KatydidOutput;
  KatydidProgress.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidProgress.prototype.constructor = KatydidProgress;
  KatydidSelect.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidSelect.prototype.constructor = KatydidSelect;
  KatydidTextArea.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidTextArea.prototype.constructor = KatydidTextArea;
  KatydidAddress.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidAddress.prototype.constructor = KatydidAddress;
  KatydidBlockQuote.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidBlockQuote.prototype.constructor = KatydidBlockQuote;
  KatydidDd.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidDd.prototype.constructor = KatydidDd;
  KatydidDiv.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidDiv.prototype.constructor = KatydidDiv;
  KatydidDl.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidDl.prototype.constructor = KatydidDl;
  KatydidDt.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidDt.prototype.constructor = KatydidDt;
  KatydidFigCaption.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidFigCaption.prototype.constructor = KatydidFigCaption;
  KatydidFigure.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidFigure.prototype.constructor = KatydidFigure;
  KatydidHr.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidHr.prototype.constructor = KatydidHr;
  KatydidLi.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidLi.prototype.constructor = KatydidLi;
  KatydidMain.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidMain.prototype.constructor = KatydidMain;
  KatydidOl.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidOl.prototype.constructor = KatydidOl;
  KatydidP.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidP.prototype.constructor = KatydidP;
  KatydidPre.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidPre.prototype.constructor = KatydidPre;
  KatydidUl.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidUl.prototype.constructor = KatydidUl;
  KatydidDetails.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidDetails.prototype.constructor = KatydidDetails;
  KatydidDialog.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidDialog.prototype.constructor = KatydidDialog;
  KatydidSummary.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidSummary.prototype.constructor = KatydidSummary;
  KatydidNodeImpl$EState.prototype = Object.create(Enum.prototype);
  KatydidNodeImpl$EState.prototype.constructor = KatydidNodeImpl$EState;
  KatydidRb.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidRb.prototype.constructor = KatydidRb;
  KatydidRp.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidRp.prototype.constructor = KatydidRp;
  KatydidRt.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidRt.prototype.constructor = KatydidRt;
  KatydidRtc.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidRtc.prototype.constructor = KatydidRtc;
  KatydidRuby.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidRuby.prototype.constructor = KatydidRuby;
  KatydidCanvas.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidCanvas.prototype.constructor = KatydidCanvas;
  KatydidArticle.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidArticle.prototype.constructor = KatydidArticle;
  KatydidAside.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidAside.prototype.constructor = KatydidAside;
  KatydidFooter.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidFooter.prototype.constructor = KatydidFooter;
  KatydidH1.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidH1.prototype.constructor = KatydidH1;
  KatydidH2.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidH2.prototype.constructor = KatydidH2;
  KatydidH3.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidH3.prototype.constructor = KatydidH3;
  KatydidH4.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidH4.prototype.constructor = KatydidH4;
  KatydidH5.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidH5.prototype.constructor = KatydidH5;
  KatydidH6.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidH6.prototype.constructor = KatydidH6;
  KatydidHeader.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidHeader.prototype.constructor = KatydidHeader;
  KatydidNav.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidNav.prototype.constructor = KatydidNav;
  KatydidSection.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidSection.prototype.constructor = KatydidSection;
  KatydidCaption.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidCaption.prototype.constructor = KatydidCaption;
  KatydidCol.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidCol.prototype.constructor = KatydidCol;
  KatydidColGroup.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidColGroup.prototype.constructor = KatydidColGroup;
  KatydidTable.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidTable.prototype.constructor = KatydidTable;
  KatydidTBody.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidTBody.prototype.constructor = KatydidTBody;
  KatydidTd.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidTd.prototype.constructor = KatydidTd;
  KatydidTFoot.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidTFoot.prototype.constructor = KatydidTFoot;
  KatydidTh.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidTh.prototype.constructor = KatydidTh;
  KatydidTHead.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidTHead.prototype.constructor = KatydidTHead;
  KatydidTr.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidTr.prototype.constructor = KatydidTr;
  KatydidA.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidA.prototype.constructor = KatydidA;
  KatydidAbbr.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidAbbr.prototype.constructor = KatydidAbbr;
  KatydidB.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidB.prototype.constructor = KatydidB;
  KatydidBdi.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidBdi.prototype.constructor = KatydidBdi;
  KatydidBdo.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidBdo.prototype.constructor = KatydidBdo;
  KatydidBr.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidBr.prototype.constructor = KatydidBr;
  KatydidCite.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidCite.prototype.constructor = KatydidCite;
  KatydidCode.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidCode.prototype.constructor = KatydidCode;
  KatydidComment.prototype = Object.create(KatydidNodeImpl.prototype);
  KatydidComment.prototype.constructor = KatydidComment;
  KatydidData.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidData.prototype.constructor = KatydidData;
  KatydidDfn.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidDfn.prototype.constructor = KatydidDfn;
  KatydidEm.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidEm.prototype.constructor = KatydidEm;
  KatydidI.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidI.prototype.constructor = KatydidI;
  KatydidKbd.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidKbd.prototype.constructor = KatydidKbd;
  KatydidMark.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidMark.prototype.constructor = KatydidMark;
  KatydidQ.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidQ.prototype.constructor = KatydidQ;
  KatydidS.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidS.prototype.constructor = KatydidS;
  KatydidSamp.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidSamp.prototype.constructor = KatydidSamp;
  KatydidSmall.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidSmall.prototype.constructor = KatydidSmall;
  KatydidSpan.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidSpan.prototype.constructor = KatydidSpan;
  KatydidStrong.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidStrong.prototype.constructor = KatydidStrong;
  KatydidSub.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidSub.prototype.constructor = KatydidSub;
  KatydidSup.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidSup.prototype.constructor = KatydidSup;
  KatydidText.prototype = Object.create(KatydidNodeImpl.prototype);
  KatydidText.prototype.constructor = KatydidText;
  KatydidTime.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidTime.prototype.constructor = KatydidTime;
  KatydidU.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidU.prototype.constructor = KatydidU;
  KatydidVar.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidVar.prototype.constructor = KatydidVar;
  KatydidWbr.prototype = Object.create(KatydidHtmlElementImpl.prototype);
  KatydidWbr.prototype.constructor = KatydidWbr;
  EmbeddedContent.prototype = Object.create(ContentType.prototype);
  EmbeddedContent.prototype.constructor = EmbeddedContent;
  FlowContent.prototype = Object.create(ContentType.prototype);
  FlowContent.prototype.constructor = FlowContent;
  PhrasingContent.prototype = Object.create(ContentType.prototype);
  PhrasingContent.prototype.constructor = PhrasingContent;
  EAnchorHtmlLinkType.prototype = Object.create(Enum.prototype);
  EAnchorHtmlLinkType.prototype.constructor = EAnchorHtmlLinkType;
  EAreaShape.prototype = Object.create(Enum.prototype);
  EAreaShape.prototype.constructor = EAreaShape;
  EButtonType.prototype = Object.create(Enum.prototype);
  EButtonType.prototype.constructor = EButtonType;
  ECorsSetting.prototype = Object.create(Enum.prototype);
  ECorsSetting.prototype.constructor = ECorsSetting;
  EDirection.prototype = Object.create(Enum.prototype);
  EDirection.prototype.constructor = EDirection;
  EFormEncodingType.prototype = Object.create(Enum.prototype);
  EFormEncodingType.prototype.constructor = EFormEncodingType;
  EFormSubmissionMethod.prototype = Object.create(Enum.prototype);
  EFormSubmissionMethod.prototype.constructor = EFormSubmissionMethod;
  EHeadingScope.prototype = Object.create(Enum.prototype);
  EHeadingScope.prototype.constructor = EHeadingScope;
  EOrderedListType.prototype = Object.create(Enum.prototype);
  EOrderedListType.prototype.constructor = EOrderedListType;
  EPreloadHint.prototype = Object.create(Enum.prototype);
  EPreloadHint.prototype.constructor = EPreloadHint;
  EReferrerPolicy.prototype = Object.create(Enum.prototype);
  EReferrerPolicy.prototype.constructor = EReferrerPolicy;
  ESandboxOption.prototype = Object.create(Enum.prototype);
  ESandboxOption.prototype.constructor = ESandboxOption;
  ETrackKind.prototype = Object.create(Enum.prototype);
  ETrackKind.prototype.constructor = ETrackKind;
  EWrapType.prototype = Object.create(Enum.prototype);
  EWrapType.prototype.constructor = EWrapType;
  EventCancellationException.prototype = Object.create(RuntimeException.prototype);
  EventCancellationException.prototype.constructor = EventCancellationException;
  function KatydidDetailsContentRestrictions() {
    this.summaryAllowed_0 = true;
  }
  KatydidDetailsContentRestrictions.prototype.confirmSummaryAllowedThenDisallow = function () {
    if (!this.summaryAllowed_0) {
      var message = 'Element type <summary> not allowed here';
      throw IllegalStateException_init(message.toString());
    }
    this.summaryAllowed_0 = false;
  };
  KatydidDetailsContentRestrictions.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidDetailsContentRestrictions',
    interfaces: []
  };
  function KatydidDetailsFlowContentBuilderImpl(itsElement, itsContentRestrictions, itsDispatchMessages) {
    if (itsContentRestrictions === void 0)
      itsContentRestrictions = KatydidContentRestrictions_init();
    KatydidFlowContentBuilderImpl.call(this, itsElement, itsContentRestrictions, itsDispatchMessages);
    this.detailsContentRestrictions = new KatydidDetailsContentRestrictions();
  }
  KatydidDetailsFlowContentBuilderImpl.prototype.summary_qckjfy$$default = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    this.element_0.addChildNode_x5x0wf$(KatydidSummary_init(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent));
  };
  KatydidDetailsFlowContentBuilderImpl.prototype.summaryHeading_8h2c3u$$default = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    this.element_0.addChildNode_x5x0wf$(KatydidSummary_init_0(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, true, defineContent));
  };
  KatydidDetailsFlowContentBuilderImpl.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidDetailsFlowContentBuilderImpl',
    interfaces: [KatydidDetailsFlowContentBuilder, KatydidFlowContentBuilderImpl]
  };
  function KatydidAttributesContentBuilderImpl(itsElement, itsDispatchMessages) {
    this.dispatchMessages_0 = itsDispatchMessages;
    this.element_0 = itsElement;
  }
  KatydidAttributesContentBuilderImpl.prototype.attribute_puj7f4$ = function (name, value) {
    if (startsWith(name, 'data-')) {
      this.element_0.setData_puj7f4$(name.substring(5), value);
    }
    this.element_0.setAttribute_jyasbz$(name, value);
  };
  KatydidAttributesContentBuilderImpl.prototype.attributes_8bsfpn$ = function (pairs) {
    var tmp$;
    for (tmp$ = 0; tmp$ !== pairs.length; ++tmp$) {
      var element = pairs[tmp$];
      this.attribute_puj7f4$(element.first, element.second.toString());
    }
  };
  KatydidAttributesContentBuilderImpl.prototype.classes_n2nruh$ = function (pairs) {
    var destination = ArrayList_init();
    var tmp$;
    for (tmp$ = 0; tmp$ !== pairs.length; ++tmp$) {
      var element = pairs[tmp$];
      if (element.second)
        destination.add_11rb$(element);
    }
    var destination_0 = ArrayList_init_0(collectionSizeOrDefault(destination, 10));
    var tmp$_0;
    tmp$_0 = destination.iterator();
    while (tmp$_0.hasNext()) {
      var item = tmp$_0.next();
      destination_0.add_11rb$(item.first);
    }
    var classList = destination_0;
    this.element_0.addClasses_upaayv$(classList);
  };
  KatydidAttributesContentBuilderImpl.prototype.data_puj7f4$ = function (name, value) {
    if (startsWith(name, 'data-')) {
      this.element_0.setData_puj7f4$(name.substring(5), value);
    }
     else {
      this.element_0.setData_puj7f4$(name, value);
    }
  };
  KatydidAttributesContentBuilderImpl.prototype.dataset_9ih0sy$ = function (pairs) {
    var tmp$;
    for (tmp$ = 0; tmp$ !== pairs.length; ++tmp$) {
      var element = pairs[tmp$];
      this.data_puj7f4$(element.first, element.second);
    }
  };
  function KatydidAttributesContentBuilderImpl$onEvent$lambda(this$KatydidAttributesContentBuilderImpl, closure$handler) {
    return function (e) {
      this$KatydidAttributesContentBuilderImpl.dispatchMessages_0(closure$handler(e));
      return Unit;
    };
  }
  KatydidAttributesContentBuilderImpl.prototype.onEvent_ahb438$ = function (eventName, handler) {
    this.element_0.addEventHandler_8s0k5j$(eventName, KatydidAttributesContentBuilderImpl$onEvent$lambda(this, handler));
  };
  KatydidAttributesContentBuilderImpl.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidAttributesContentBuilderImpl',
    interfaces: [KatydidAttributesContentBuilder]
  };
  function KatydidContentRestrictions(addressAllowed, anchorAllowed, areaProhibited, dfnAllowed, figCaptionProhibited, footerAllowed, formAllowed, headerAllowed, headingsAllowed, interactiveContentAllowed, labelAllowed, legendProhibited, mainAllowed, mediaElementAllowed, meterAllowed, paramProhibited, progressAllowed, sectioningAllowed, tableAllowed) {
    this.addressAllowed_0 = addressAllowed;
    this.anchorAllowed_0 = anchorAllowed;
    this.areaProhibited_0 = areaProhibited;
    this.dfnAllowed_0 = dfnAllowed;
    this.figCaptionProhibited_0 = figCaptionProhibited;
    this.footerAllowed_0 = footerAllowed;
    this.formAllowed_0 = formAllowed;
    this.headerAllowed_0 = headerAllowed;
    this.headingsAllowed_0 = headingsAllowed;
    this.interactiveContentAllowed_0 = interactiveContentAllowed;
    this.labelAllowed_0 = labelAllowed;
    this.legendProhibited_0 = legendProhibited;
    this.mainAllowed_0 = mainAllowed;
    this.mediaElementAllowed_0 = mediaElementAllowed;
    this.meterAllowed_0 = meterAllowed;
    this.paramProhibited_0 = paramProhibited;
    this.progressAllowed_0 = progressAllowed;
    this.sectioningAllowed_0 = sectioningAllowed;
    this.tableAllowed_0 = tableAllowed;
  }
  KatydidContentRestrictions.prototype.confirmAddressAllowed = function () {
    if (!this.addressAllowed_0) {
      var message = 'Element type <address> not allowed here';
      throw IllegalStateException_init(message.toString());
    }
  };
  KatydidContentRestrictions.prototype.confirmAnchorAllowed = function () {
    if (!this.anchorAllowed_0) {
      var message = 'Element type <a> not allowed here';
      throw IllegalStateException_init(message.toString());
    }
  };
  KatydidContentRestrictions.prototype.confirmAreaAllowed = function () {
    if (!!this.areaProhibited_0) {
      var message = 'Element type <area> not allowed here';
      throw IllegalStateException_init(message.toString());
    }
  };
  KatydidContentRestrictions.prototype.confirmDfnAllowed = function () {
    if (!this.dfnAllowed_0) {
      var message = 'Element type <dfn> not allowed here.';
      throw IllegalStateException_init(message.toString());
    }
  };
  KatydidContentRestrictions.prototype.confirmFigCaptionAllowedThenDisallow = function () {
    if (!!this.figCaptionProhibited_0) {
      var message = 'Element type <figcaption> not allowed here.';
      throw IllegalStateException_init(message.toString());
    }
    this.figCaptionProhibited_0 = true;
  };
  KatydidContentRestrictions.prototype.confirmFooterAllowed = function () {
    if (!this.footerAllowed_0) {
      var message = 'Element type <footer> not allowed here.';
      throw IllegalStateException_init(message.toString());
    }
  };
  KatydidContentRestrictions.prototype.confirmFormAllowed = function () {
    if (!this.formAllowed_0) {
      var message = 'Element type <form> not allowed here. (Form elements cannot be nested.)';
      throw IllegalStateException_init(message.toString());
    }
  };
  KatydidContentRestrictions.prototype.confirmHeaderAllowed = function () {
    if (!this.headerAllowed_0) {
      var message = 'Element type <header> not allowed here.';
      throw IllegalStateException_init(message.toString());
    }
  };
  KatydidContentRestrictions.prototype.confirmHeadingsAllowed = function () {
    if (!this.headingsAllowed_0) {
      var message = 'Element types <h1> to <h6> not allowed here.';
      throw IllegalStateException_init(message.toString());
    }
  };
  KatydidContentRestrictions.prototype.confirmInteractiveContentAllowed = function () {
    if (!this.interactiveContentAllowed_0) {
      var message = 'Interactive content not allowed here.';
      throw IllegalStateException_init(message.toString());
    }
  };
  KatydidContentRestrictions.prototype.confirmLabelAllowed = function () {
    if (!this.labelAllowed_0) {
      var message = 'Element type <label> not allowed here.';
      throw IllegalStateException_init(message.toString());
    }
  };
  KatydidContentRestrictions.prototype.confirmLegendAllowedThenDisallow = function () {
    if (!!this.legendProhibited_0) {
      var message = 'Element type <legend> not allowed here.';
      throw IllegalStateException_init(message.toString());
    }
    this.legendProhibited_0 = true;
  };
  KatydidContentRestrictions.prototype.confirmMainAllowed = function () {
    if (!this.mainAllowed_0) {
      var message = 'Element type <main> not allowed here.';
      throw IllegalStateException_init(message.toString());
    }
  };
  KatydidContentRestrictions.prototype.confirmMediaElementAllowed = function () {
    if (!this.mediaElementAllowed_0) {
      var message = 'Media element not allowed here.';
      throw IllegalStateException_init(message.toString());
    }
  };
  KatydidContentRestrictions.prototype.confirmMeterAllowed = function () {
    if (!this.meterAllowed_0) {
      var message = 'Element type <meter> not allowed here.';
      throw IllegalStateException_init(message.toString());
    }
  };
  KatydidContentRestrictions.prototype.confirmParamAllowed = function () {
    if (!!this.paramProhibited_0) {
      var message = 'Element type <param> not allowed here.';
      throw IllegalStateException_init(message.toString());
    }
  };
  KatydidContentRestrictions.prototype.confirmProgressAllowed = function () {
    if (!this.progressAllowed_0) {
      var message = 'Element type <progress> not allowed here.';
      throw IllegalStateException_init(message.toString());
    }
  };
  KatydidContentRestrictions.prototype.confirmSectioningAllowed = function () {
    if (!this.sectioningAllowed_0) {
      var message = 'Sectioning content not allowed here.';
      throw IllegalStateException_init(message.toString());
    }
  };
  KatydidContentRestrictions.prototype.confirmTableAllowed = function () {
    if (!this.tableAllowed_0) {
      var message = 'Element type <table> not allowed here.';
      throw IllegalStateException_init(message.toString());
    }
  };
  KatydidContentRestrictions.prototype.prohibitParam = function () {
    this.paramProhibited_0 = true;
  };
  KatydidContentRestrictions.prototype.withAnchorInteractiveContentNotAllowed = function () {
    return KatydidContentRestrictions_init_0(this, void 0, false, void 0, void 0, void 0, void 0, void 0, void 0, void 0, false);
  };
  KatydidContentRestrictions.prototype.withAreaAllowed = function () {
    return KatydidContentRestrictions_init_0(this, void 0, void 0, false);
  };
  KatydidContentRestrictions.prototype.withDfnNotAllowed = function () {
    return KatydidContentRestrictions_init_0(this, void 0, void 0, void 0, false);
  };
  KatydidContentRestrictions.prototype.withFigCaptionAllowed = function () {
    return KatydidContentRestrictions_init_0(this, void 0, void 0, void 0, void 0, false);
  };
  KatydidContentRestrictions.prototype.withFooterHeaderAddressNotAllowed = function () {
    return KatydidContentRestrictions_init_0(this, false, void 0, void 0, void 0, void 0, false, void 0, false, false, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, false);
  };
  KatydidContentRestrictions.prototype.withFooterHeaderMainNotAllowed = function () {
    return KatydidContentRestrictions_init_0(this, void 0, void 0, void 0, void 0, void 0, false, void 0, false, void 0, void 0, void 0, void 0, false);
  };
  KatydidContentRestrictions.prototype.withFormNotAllowed = function () {
    return KatydidContentRestrictions_init_0(this, void 0, void 0, void 0, void 0, void 0, void 0, false);
  };
  KatydidContentRestrictions.prototype.withInteractiveContentNotAllowed = function () {
    return KatydidContentRestrictions_init_0(this, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, false);
  };
  KatydidContentRestrictions.prototype.withLabelNotAllowed = function () {
    return KatydidContentRestrictions_init_0(this, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, false);
  };
  KatydidContentRestrictions.prototype.withLegendAllowed = function () {
    return KatydidContentRestrictions_init_0(this, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, false);
  };
  KatydidContentRestrictions.prototype.withMainNotAllowed = function () {
    return KatydidContentRestrictions_init_0(this, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, false);
  };
  KatydidContentRestrictions.prototype.withMediaElementNotAllowed = function () {
    return KatydidContentRestrictions_init_0(this, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, false);
  };
  KatydidContentRestrictions.prototype.withMeterNotAllowed = function () {
    return KatydidContentRestrictions_init_0(this, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, false);
  };
  KatydidContentRestrictions.prototype.withParamAllowed = function () {
    return KatydidContentRestrictions_init_0(this, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, false);
  };
  KatydidContentRestrictions.prototype.withProgressNotAllowed = function () {
    return KatydidContentRestrictions_init_0(this, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, false);
  };
  KatydidContentRestrictions.prototype.withTableNotAllowed = function () {
    return KatydidContentRestrictions_init_0(this, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, false);
  };
  KatydidContentRestrictions.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidContentRestrictions',
    interfaces: []
  };
  function KatydidContentRestrictions_init($this) {
    $this = $this || Object.create(KatydidContentRestrictions.prototype);
    KatydidContentRestrictions.call($this, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, false, true, true, true);
    return $this;
  }
  function KatydidContentRestrictions_init_0(original, addressAllowed, anchorAllowed, areaProhibited, dfnAllowed, figCaptionProhibited, footerAllowed, formAllowed, headerAllowed, headingsAllowed, interactiveContentAllowed, labelAllowed, legendProhibited, mainAllowed, mediaElementAllowed, meterAllowed, paramProhibited, progressAllowed, sectioningAllowed, tableAllowed, $this) {
    if (addressAllowed === void 0)
      addressAllowed = true;
    if (anchorAllowed === void 0)
      anchorAllowed = true;
    if (areaProhibited === void 0)
      areaProhibited = true;
    if (dfnAllowed === void 0)
      dfnAllowed = true;
    if (figCaptionProhibited === void 0)
      figCaptionProhibited = true;
    if (footerAllowed === void 0)
      footerAllowed = true;
    if (formAllowed === void 0)
      formAllowed = true;
    if (headerAllowed === void 0)
      headerAllowed = true;
    if (headingsAllowed === void 0)
      headingsAllowed = true;
    if (interactiveContentAllowed === void 0)
      interactiveContentAllowed = true;
    if (labelAllowed === void 0)
      labelAllowed = true;
    if (legendProhibited === void 0)
      legendProhibited = false;
    if (mainAllowed === void 0)
      mainAllowed = true;
    if (mediaElementAllowed === void 0)
      mediaElementAllowed = true;
    if (meterAllowed === void 0)
      meterAllowed = true;
    if (paramProhibited === void 0)
      paramProhibited = true;
    if (progressAllowed === void 0)
      progressAllowed = true;
    if (sectioningAllowed === void 0)
      sectioningAllowed = true;
    if (tableAllowed === void 0)
      tableAllowed = true;
    $this = $this || Object.create(KatydidContentRestrictions.prototype);
    KatydidContentRestrictions.call($this, original.addressAllowed_0 && addressAllowed, original.anchorAllowed_0 && anchorAllowed, original.areaProhibited_0 && areaProhibited, original.dfnAllowed_0 && dfnAllowed, original.figCaptionProhibited_0 && figCaptionProhibited, original.footerAllowed_0 && footerAllowed, original.formAllowed_0 && formAllowed, original.headerAllowed_0 && headerAllowed, original.headingsAllowed_0 && headingsAllowed, original.interactiveContentAllowed_0 && interactiveContentAllowed, original.labelAllowed_0 && labelAllowed, original.legendProhibited_0 && legendProhibited, original.mainAllowed_0 && mainAllowed, original.mediaElementAllowed_0 && mediaElementAllowed, original.meterAllowed_0 && meterAllowed, original.paramProhibited_0 && paramProhibited, original.progressAllowed_0 && progressAllowed, original.sectioningAllowed_0 && sectioningAllowed, original.tableAllowed_0 && tableAllowed);
    return $this;
  }
  function KatydidEmbeddedContentBuilderImpl(itsElement, itsContentRestrictions, itsDispatchMessages) {
    KatydidAttributesContentBuilderImpl.call(this, itsElement, itsDispatchMessages);
    this.contentRestrictions = itsContentRestrictions;
  }
  KatydidEmbeddedContentBuilderImpl.prototype.attributesContent_bflrjy$ = function (element) {
    this.contentRestrictions.prohibitParam();
    return new KatydidAttributesContentBuilderImpl(element, this.dispatchMessages_0);
  };
  KatydidEmbeddedContentBuilderImpl.prototype.audio_if4zjc$$default = function (selector, key, accesskey, autoplay, contenteditable, controls, crossorigin, dir, draggable, hidden, lang, loop, muted, preload, spellcheck, src, style, tabindex, title, translate, defineContent) {
    this.element_0.addChildNode_x5x0wf$(KatydidAudio_init(this, selector, key, accesskey, autoplay, contenteditable, controls, crossorigin, dir, draggable, hidden, lang, loop, muted, preload, spellcheck, src, style, tabindex, title, translate, defineContent));
  };
  KatydidEmbeddedContentBuilderImpl.prototype.canvas_ablpy6$$default = function (selector, key, accesskey, contenteditable, dir, draggable, height, hidden, lang, spellcheck, style, tabindex, title, translate, width, defineContent) {
    this.element_0.addChildNode_x5x0wf$(KatydidCanvas_init(this, selector, key, accesskey, contenteditable, dir, draggable, height, hidden, lang, spellcheck, style, tabindex, title, translate, width, defineContent));
  };
  KatydidEmbeddedContentBuilderImpl.prototype.comment_4w9ihe$ = function (nodeValue, key) {
    this.element_0.addChildNode_x5x0wf$(new KatydidComment(nodeValue, key));
  };
  KatydidEmbeddedContentBuilderImpl.prototype.detailsFlowContent_98eimz$ = function (element) {
    this.contentRestrictions.prohibitParam();
    return new KatydidDetailsFlowContentBuilderImpl(element, this.contentRestrictions, this.dispatchMessages_0);
  };
  KatydidEmbeddedContentBuilderImpl.prototype.embed_nx0pss$$default = function (selector, key, accesskey, contenteditable, dir, draggable, height, hidden, lang, spellcheck, src, style, tabindex, title, translate, type, width, defineContent) {
    this.element_0.addChildNode_x5x0wf$(new KatydidEmbed(this, selector, key, accesskey, contenteditable, dir, draggable, height, hidden, lang, spellcheck, src, style, tabindex, title, translate, type, width, defineContent));
  };
  KatydidEmbeddedContentBuilderImpl.prototype.iframe_6rhnbj$$default = function (selector, key, accesskey, allowfullscreen, allowpaymentrequest, contenteditable, dir, draggable, height, hidden, lang, name, referrerpolicy, sandbox, spellcheck, src, srcdoc, style, tabindex, title, translate, width, defineContent) {
    this.element_0.addChildNode_x5x0wf$(new KatydidIframe(this, selector, key, accesskey, allowfullscreen, allowpaymentrequest, contenteditable, dir, draggable, height, hidden, lang, name, referrerpolicy, sandbox, spellcheck, src, srcdoc, style, tabindex, title, translate, width, defineContent));
  };
  KatydidEmbeddedContentBuilderImpl.prototype.img_fdnnaq$$default = function (selector, key, accesskey, alt, contenteditable, crossorigin, dir, draggable, height, hidden, ismap, lang, referrerpolicy, sizes, spellcheck, src, srcset, style, tabindex, title, translate, usemap, width, defineAttributes) {
    this.element_0.addChildNode_x5x0wf$(KatydidImg_init(this, selector, key, accesskey, alt, contenteditable, crossorigin, dir, draggable, height, hidden, ismap, lang, referrerpolicy, sizes, spellcheck, src, srcset, style, tabindex, title, translate, usemap, width, defineAttributes));
  };
  KatydidEmbeddedContentBuilderImpl.prototype.mediaEmbeddedContent_wzqe2t$ = function (element, sourceAllowed) {
    this.contentRestrictions.prohibitParam();
    return new KatydidMediaEmbeddedContentBuilderImpl(element, this.contentRestrictions.withMediaElementNotAllowed(), new KatydidMediaContentRestrictions(sourceAllowed), this.dispatchMessages_0);
  };
  KatydidEmbeddedContentBuilderImpl.prototype.object_ggcu0x$$default = function (selector, key, accesskey, contenteditable, data, dir, draggable, form, height, hidden, lang, name, spellcheck, style, tabindex, title, translate, type, typemustmatch, width, defineContent) {
    this.element_0.addChildNode_x5x0wf$(KatydidObject_init(this, selector, key, accesskey, contenteditable, data, dir, draggable, form, height, hidden, lang, name, spellcheck, style, tabindex, title, translate, type, typemustmatch, width, defineContent));
  };
  KatydidEmbeddedContentBuilderImpl.prototype.objectEmbeddedContent_5czpdc$ = function (element) {
    this.contentRestrictions.prohibitParam();
    return new KatydidObjectEmbeddedContentBuilderImpl(element, this.contentRestrictions.withParamAllowed(), this.dispatchMessages_0);
  };
  KatydidEmbeddedContentBuilderImpl.prototype.pictureContent_rc0r53$ = function (element) {
    this.contentRestrictions.prohibitParam();
    return new KatydidPictureContentBuilderImpl(element, new KatydidPictureContentRestrictions(), this.dispatchMessages_0);
  };
  KatydidEmbeddedContentBuilderImpl.prototype.picture_r7gn0k$$default = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    this.element_0.addChildNode_x5x0wf$(new KatydidPicture(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent));
  };
  KatydidEmbeddedContentBuilderImpl.prototype.textContent_bflrjy$ = function (element) {
    return new KatydidTextContentBuilderImpl(element, this.dispatchMessages_0);
  };
  KatydidEmbeddedContentBuilderImpl.prototype.video_n6slad$$default = function (selector, key, accesskey, autoplay, contenteditable, controls, crossorigin, dir, draggable, height, hidden, lang, loop, muted, poster, preload, spellcheck, src, style, tabindex, title, translate, width, defineContent) {
    this.element_0.addChildNode_x5x0wf$(KatydidVideo_init(this, selector, key, accesskey, autoplay, contenteditable, controls, crossorigin, dir, draggable, height, hidden, lang, loop, muted, poster, preload, spellcheck, src, style, tabindex, title, translate, width, defineContent));
  };
  KatydidEmbeddedContentBuilderImpl.prototype.withNoAddedRestrictions_bflrjy$ = function (element) {
    this.contentRestrictions.prohibitParam();
    return new KatydidEmbeddedContentBuilderImpl(element, this.contentRestrictions, this.dispatchMessages_0);
  };
  KatydidEmbeddedContentBuilderImpl.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidEmbeddedContentBuilderImpl',
    interfaces: [KatydidEmbeddedContentBuilder, KatydidAttributesContentBuilderImpl]
  };
  function KatydidFlowContentBuilderImpl(itsElement, itsContentRestrictions, itsDispatchMessages) {
    KatydidPhrasingContentBuilderImpl.call(this, itsElement, itsContentRestrictions, itsDispatchMessages);
  }
  KatydidFlowContentBuilderImpl.prototype.a_3jwxqy$$default = function (selector, key, accesskey, contenteditable, dir, download, draggable, hidden, href, hreflang, lang, rel, rev, spellcheck, style, tabindex, target, title, translate, type, contentType, defineContent) {
    this.element_0.addChildNode_x5x0wf$(KatydidA_init_0(this, selector, key, accesskey, contenteditable, dir, download, draggable, hidden, href, hreflang, lang, rel, rev, spellcheck, style, tabindex, target, title, translate, type, defineContent));
  };
  KatydidFlowContentBuilderImpl.prototype.address_6zr3om$$default = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    this.element_0.addChildNode_x5x0wf$(new KatydidAddress(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent));
  };
  KatydidFlowContentBuilderImpl.prototype.article_6zr3om$$default = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    this.element_0.addChildNode_x5x0wf$(new KatydidArticle(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent));
  };
  KatydidFlowContentBuilderImpl.prototype.aside_6zr3om$$default = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    this.element_0.addChildNode_x5x0wf$(new KatydidAside(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent));
  };
  KatydidFlowContentBuilderImpl.prototype.audio_tp0mfx$$default = function (selector, key, accesskey, autoplay, contenteditable, controls, crossorigin, dir, draggable, hidden, lang, loop, muted, preload, spellcheck, src, style, tabindex, title, translate, contentType, defineContent) {
    this.element_0.addChildNode_x5x0wf$(KatydidAudio_init_0(this, selector, key, accesskey, autoplay, contenteditable, controls, crossorigin, dir, draggable, hidden, lang, loop, muted, preload, spellcheck, src, style, tabindex, title, translate, defineContent));
  };
  KatydidFlowContentBuilderImpl.prototype.blockquote_rfnrw3$$default = function (selector, key, accesskey, cite, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    this.element_0.addChildNode_x5x0wf$(new KatydidBlockQuote(this, selector, key, accesskey, cite, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent));
  };
  KatydidFlowContentBuilderImpl.prototype.canvas_p01gpz$$default = function (selector, key, accesskey, contenteditable, dir, draggable, height, hidden, lang, spellcheck, style, tabindex, title, translate, width, contentType, defineContent) {
    this.element_0.addChildNode_x5x0wf$(KatydidCanvas_init_0(this, selector, key, accesskey, contenteditable, dir, draggable, height, hidden, lang, spellcheck, style, tabindex, title, translate, width, defineContent));
  };
  KatydidFlowContentBuilderImpl.prototype.del_pat60j$$default = function (selector, key, accesskey, cite, contenteditable, datetime, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, contentType, defineContent) {
    this.element_0.addChildNode_x5x0wf$(KatydidDel_init_0(this, selector, key, accesskey, cite, contenteditable, datetime, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, contentType, defineContent));
  };
  KatydidFlowContentBuilderImpl.prototype.descriptionListContent_orwckh$ = function (element) {
    this.contentRestrictions.prohibitParam();
    return new KatydidDescriptionListContentBuilderImpl(element, this.contentRestrictions, this.dispatchMessages_0);
  };
  KatydidFlowContentBuilderImpl.prototype.descriptionListContent_wcji1e$ = function (element) {
    this.contentRestrictions.prohibitParam();
    return new KatydidDescriptionListContentBuilderImpl(element, this.contentRestrictions, this.dispatchMessages_0);
  };
  KatydidFlowContentBuilderImpl.prototype.details_k8gqqw$$default = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, open, spellcheck, style, tabindex, title, translate, defineContent) {
    this.element_0.addChildNode_x5x0wf$(new KatydidDetails(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, open, spellcheck, style, tabindex, title, translate, defineContent));
  };
  KatydidFlowContentBuilderImpl.prototype.dialog_rmrn7i$$default = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, open, spellcheck, style, tabindex, title, translate, defineContent) {
    this.element_0.addChildNode_x5x0wf$(new KatydidDialog(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, open, spellcheck, style, tabindex, title, translate, defineContent));
  };
  KatydidFlowContentBuilderImpl.prototype.div_6zr3om$$default = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    this.element_0.addChildNode_x5x0wf$(KatydidDiv_init(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent));
  };
  KatydidFlowContentBuilderImpl.prototype.dl_a7rbte$$default = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    this.element_0.addChildNode_x5x0wf$(new KatydidDl(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent));
  };
  KatydidFlowContentBuilderImpl.prototype.fieldset_wkcbaa$$default = function (selector, key, accesskey, contenteditable, dir, disabled, draggable, form, hidden, lang, name, spellcheck, style, tabindex, title, translate, defineContent) {
    this.element_0.addChildNode_x5x0wf$(new KatydidFieldSet(this, selector, key, accesskey, contenteditable, dir, disabled, draggable, form, hidden, lang, name, spellcheck, style, tabindex, title, translate, defineContent));
  };
  KatydidFlowContentBuilderImpl.prototype.figCaption_6zr3om$$default = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    this.element_0.addChildNode_x5x0wf$(new KatydidFigCaption(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent));
  };
  KatydidFlowContentBuilderImpl.prototype.figure_6zr3om$$default = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    this.element_0.addChildNode_x5x0wf$(new KatydidFigure(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent));
  };
  KatydidFlowContentBuilderImpl.prototype.footer_6zr3om$$default = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    this.element_0.addChildNode_x5x0wf$(new KatydidFooter(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent));
  };
  KatydidFlowContentBuilderImpl.prototype.form_roosm5$$default = function (selector, key, acceptCharset, accesskey, action, autocomplete, contenteditable, dir, draggable, enctype, hidden, lang, method, name, novalidate, spellcheck, style, tabindex, target, title, translate, defineContent) {
    this.element_0.addChildNode_x5x0wf$(new KatydidForm(this, selector, key, acceptCharset, accesskey, action, autocomplete, contenteditable, dir, draggable, enctype, hidden, lang, method, name, novalidate, spellcheck, style, tabindex, title, target, translate, defineContent));
  };
  KatydidFlowContentBuilderImpl.prototype.h1_qckjfy$$default = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    this.element_0.addChildNode_x5x0wf$(new KatydidH1(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent));
  };
  KatydidFlowContentBuilderImpl.prototype.h2_qckjfy$$default = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    this.element_0.addChildNode_x5x0wf$(new KatydidH2(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent));
  };
  KatydidFlowContentBuilderImpl.prototype.h3_qckjfy$$default = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    this.element_0.addChildNode_x5x0wf$(new KatydidH3(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent));
  };
  KatydidFlowContentBuilderImpl.prototype.h4_qckjfy$$default = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    this.element_0.addChildNode_x5x0wf$(new KatydidH4(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent));
  };
  KatydidFlowContentBuilderImpl.prototype.h5_qckjfy$$default = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    this.element_0.addChildNode_x5x0wf$(new KatydidH5(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent));
  };
  KatydidFlowContentBuilderImpl.prototype.h6_qckjfy$$default = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    this.element_0.addChildNode_x5x0wf$(new KatydidH6(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent));
  };
  KatydidFlowContentBuilderImpl.prototype.header_6zr3om$$default = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    this.element_0.addChildNode_x5x0wf$(new KatydidHeader(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent));
  };
  KatydidFlowContentBuilderImpl.prototype.hr_9mj9vz$$default = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineAttributes) {
    this.element_0.addChildNode_x5x0wf$(new KatydidHr(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineAttributes));
  };
  KatydidFlowContentBuilderImpl.prototype.ins_pat60j$$default = function (selector, key, accesskey, cite, contenteditable, datetime, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, contentType, defineContent) {
    this.element_0.addChildNode_x5x0wf$(KatydidIns_init_0(this, selector, key, accesskey, cite, contenteditable, datetime, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, contentType, defineContent));
  };
  KatydidFlowContentBuilderImpl.prototype.legend_qckjfy$$default = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    this.element_0.addChildNode_x5x0wf$(new KatydidLegend(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent));
  };
  KatydidFlowContentBuilderImpl.prototype.listContent_cyehjb$ = function (element) {
    this.contentRestrictions.prohibitParam();
    return new KatydidOrderedListContentBuilderImpl(this, element, this.dispatchMessages_0);
  };
  KatydidFlowContentBuilderImpl.prototype.listContent_42v5tr$ = function (element) {
    this.contentRestrictions.prohibitParam();
    return new KatydidUnorderedListContentBuilderImpl(this, element, this.dispatchMessages_0);
  };
  KatydidFlowContentBuilderImpl.prototype.main_6zr3om$$default = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    this.element_0.addChildNode_x5x0wf$(new KatydidMain(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent));
  };
  KatydidFlowContentBuilderImpl.prototype.map_io1brw$$default = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, name, spellcheck, style, tabindex, title, translate, contentType, defineContent) {
    this.element_0.addChildNode_x5x0wf$(KatydidMap_init_0(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, name, spellcheck, style, tabindex, title, translate, contentType, defineContent));
  };
  KatydidFlowContentBuilderImpl.prototype.mediaFlowContent_wzqe2t$ = function (element, sourceAllowed) {
    this.contentRestrictions.prohibitParam();
    return new KatydidMediaFlowContentBuilderImpl(element, this.contentRestrictions.withMediaElementNotAllowed(), new KatydidMediaContentRestrictions(sourceAllowed), this.dispatchMessages_0);
  };
  KatydidFlowContentBuilderImpl.prototype.nav_6zr3om$$default = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    this.element_0.addChildNode_x5x0wf$(new KatydidNav(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent));
  };
  KatydidFlowContentBuilderImpl.prototype.object_649euk$$default = function (selector, key, accesskey, contenteditable, data, dir, draggable, form, height, hidden, lang, name, spellcheck, style, tabindex, title, translate, type, typemustmatch, width, contentType, defineContent) {
    this.element_0.addChildNode_x5x0wf$(KatydidObject_init_0(this, selector, key, accesskey, contenteditable, data, dir, draggable, form, height, hidden, lang, name, spellcheck, style, tabindex, title, translate, type, typemustmatch, width, defineContent));
  };
  KatydidFlowContentBuilderImpl.prototype.objectFlowContent_5czpdc$ = function (element) {
    this.contentRestrictions.prohibitParam();
    return new KatydidObjectFlowContentBuilderImpl(element, this.contentRestrictions.withParamAllowed(), this.dispatchMessages_0);
  };
  KatydidFlowContentBuilderImpl.prototype.ol_5bxxpo$$default = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, reversed, spellcheck, start, style, tabindex, title, translate, type, defineContent) {
    this.element_0.addChildNode_x5x0wf$(new KatydidOl(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, reversed, spellcheck, start, style, tabindex, title, translate, type, defineContent));
  };
  KatydidFlowContentBuilderImpl.prototype.p_qckjfy$$default = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    this.element_0.addChildNode_x5x0wf$(new KatydidP(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent));
  };
  KatydidFlowContentBuilderImpl.prototype.phrasingContent_bflrjy$ = function (element) {
    this.contentRestrictions.prohibitParam();
    return new KatydidPhrasingContentBuilderImpl(element, this.contentRestrictions, this.dispatchMessages_0);
  };
  KatydidFlowContentBuilderImpl.prototype.pre_qckjfy$$default = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    this.element_0.addChildNode_x5x0wf$(new KatydidPre(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent));
  };
  KatydidFlowContentBuilderImpl.prototype.section_6zr3om$$default = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    this.element_0.addChildNode_x5x0wf$(new KatydidSection(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent));
  };
  KatydidFlowContentBuilderImpl.prototype.table_55vzb3$$default = function (selector, key, accesskey, border, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    this.element_0.addChildNode_x5x0wf$(new KatydidTable(this, selector, key, accesskey, border, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent));
  };
  KatydidFlowContentBuilderImpl.prototype.tableContent_th3er0$ = function (element) {
    return new KatydidTableContentBuilderImpl(element, this.contentRestrictions, this.dispatchMessages_0);
  };
  KatydidFlowContentBuilderImpl.prototype.ul_hxau5b$$default = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    this.element_0.addChildNode_x5x0wf$(new KatydidUl(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent));
  };
  KatydidFlowContentBuilderImpl.prototype.video_hpee3a$$default = function (selector, key, accesskey, autoplay, contenteditable, controls, crossorigin, dir, draggable, height, hidden, lang, loop, muted, poster, preload, spellcheck, src, style, tabindex, title, translate, width, contentType, defineContent) {
    this.element_0.addChildNode_x5x0wf$(KatydidVideo_init_0(this, selector, key, accesskey, autoplay, contenteditable, controls, crossorigin, dir, draggable, height, hidden, lang, loop, muted, poster, preload, spellcheck, src, style, tabindex, title, translate, width, defineContent));
  };
  KatydidFlowContentBuilderImpl.prototype.withFigCaptionAllowed_bflrjy$ = function (element) {
    this.contentRestrictions.prohibitParam();
    return new KatydidFlowContentBuilderImpl(element, this.contentRestrictions.withFigCaptionAllowed(), this.dispatchMessages_0);
  };
  KatydidFlowContentBuilderImpl.prototype.withFooterHeaderAddressNotAllowed_bflrjy$ = function (element) {
    this.contentRestrictions.prohibitParam();
    return new KatydidFlowContentBuilderImpl(element, this.contentRestrictions.withFooterHeaderAddressNotAllowed(), this.dispatchMessages_0);
  };
  KatydidFlowContentBuilderImpl.prototype.withFooterHeaderMainNotAllowed_bflrjy$ = function (element) {
    this.contentRestrictions.prohibitParam();
    return new KatydidFlowContentBuilderImpl(element, this.contentRestrictions.withFooterHeaderMainNotAllowed(), this.dispatchMessages_0);
  };
  KatydidFlowContentBuilderImpl.prototype.withFormNotAllowed_bflrjy$ = function (element) {
    this.contentRestrictions.prohibitParam();
    return new KatydidFlowContentBuilderImpl(element, this.contentRestrictions.withFormNotAllowed(), this.dispatchMessages_0);
  };
  KatydidFlowContentBuilderImpl.prototype.withInteractiveContentNotAllowed_bflrjy$ = function (element) {
    this.contentRestrictions.prohibitParam();
    return new KatydidFlowContentBuilderImpl(element, this.contentRestrictions.withInteractiveContentNotAllowed(), this.dispatchMessages_0);
  };
  KatydidFlowContentBuilderImpl.prototype.withLegendAllowed_bflrjy$ = function (element) {
    this.contentRestrictions.prohibitParam();
    return new KatydidFlowContentBuilderImpl(element, this.contentRestrictions.withLegendAllowed(), this.dispatchMessages_0);
  };
  KatydidFlowContentBuilderImpl.prototype.withMainNotAllowed_bflrjy$ = function (element) {
    this.contentRestrictions.prohibitParam();
    return new KatydidFlowContentBuilderImpl(element, this.contentRestrictions.withMainNotAllowed(), this.dispatchMessages_0);
  };
  KatydidFlowContentBuilderImpl.prototype.withNoAddedRestrictions_bflrjy$ = function (element) {
    this.contentRestrictions.prohibitParam();
    return new KatydidFlowContentBuilderImpl(element, this.contentRestrictions, this.dispatchMessages_0);
  };
  KatydidFlowContentBuilderImpl.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidFlowContentBuilderImpl',
    interfaces: [KatydidFlowContentBuilder, KatydidPhrasingContentBuilderImpl]
  };
  function KatydidPhrasingContentBuilderImpl(itsElement, itsContentRestrictions, itsDispatchMessages) {
    KatydidEmbeddedContentBuilderImpl.call(this, itsElement, itsContentRestrictions, itsDispatchMessages);
  }
  KatydidPhrasingContentBuilderImpl.prototype.a_ncyfe7$$default = function (selector, key, accesskey, contenteditable, dir, download, draggable, hidden, href, hreflang, lang, rel, rev, spellcheck, style, tabindex, target, title, translate, type, defineContent) {
    this.element_0.addChildNode_x5x0wf$(KatydidA_init(this, selector, key, accesskey, contenteditable, dir, download, draggable, hidden, href, hreflang, lang, rel, rev, spellcheck, style, tabindex, target, title, translate, type, defineContent));
  };
  KatydidPhrasingContentBuilderImpl.prototype.abbr_qckjfy$$default = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    this.element_0.addChildNode_x5x0wf$(new KatydidAbbr(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent));
  };
  KatydidPhrasingContentBuilderImpl.prototype.area_ys14xf$$default = function (selector, key, accesskey, alt, contenteditable, coords, dir, download, draggable, hidden, href, hreflang, lang, referrerpolicy, rel, spellcheck, shape, style, tabindex, target, title, translate, type, defineAttributes) {
    this.element_0.addChildNode_x5x0wf$(new KatydidArea(this, selector, key, accesskey, alt, contenteditable, coords, dir, download, draggable, hidden, href, hreflang, lang, referrerpolicy, rel, spellcheck, shape, style, tabindex, target, title, translate, type, defineAttributes));
  };
  KatydidPhrasingContentBuilderImpl.prototype.audio_z5y2od$$default = function (selector, key, accesskey, autoplay, contenteditable, controls, crossorigin, dir, draggable, hidden, lang, loop, muted, preload, spellcheck, src, style, tabindex, title, translate, contentType, defineContent) {
    this.element_0.addChildNode_x5x0wf$(KatydidAudio_init_1(this, selector, key, accesskey, autoplay, contenteditable, controls, crossorigin, dir, draggable, hidden, lang, loop, muted, preload, spellcheck, src, style, tabindex, title, translate, defineContent));
  };
  KatydidPhrasingContentBuilderImpl.prototype.b_qckjfy$$default = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    this.element_0.addChildNode_x5x0wf$(new KatydidB(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent));
  };
  KatydidPhrasingContentBuilderImpl.prototype.bdi_g2kg67$$default = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    this.element_0.addChildNode_x5x0wf$(new KatydidBdi(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent));
  };
  KatydidPhrasingContentBuilderImpl.prototype.bdo_g2kg67$$default = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    this.element_0.addChildNode_x5x0wf$(new KatydidBdo(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent));
  };
  KatydidPhrasingContentBuilderImpl.prototype.br_9mj9vz$$default = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineAttributes) {
    this.element_0.addChildNode_x5x0wf$(new KatydidBr(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineAttributes));
  };
  KatydidPhrasingContentBuilderImpl.prototype.button_2lxa1r$$default = function (selector, key, accesskey, autofocus, contenteditable, dir, disabled, draggable, form, formaction, formenctype, formmethod, formnovalidate, formtarget, hidden, lang, name, spellcheck, style, tabindex, title, translate, type, value, defineContent) {
    this.element_0.addChildNode_x5x0wf$(new KatydidButton(this, selector, key, accesskey, autofocus, contenteditable, dir, disabled, draggable, form, formaction, formenctype, formmethod, formnovalidate, formtarget, hidden, lang, name, spellcheck, style, tabindex, title, translate, type, value, defineContent));
  };
  KatydidPhrasingContentBuilderImpl.prototype.canvas_zeuq1z$$default = function (selector, key, accesskey, contenteditable, dir, draggable, height, hidden, lang, spellcheck, style, tabindex, title, translate, width, contentType, defineContent) {
    this.element_0.addChildNode_x5x0wf$(KatydidCanvas_init_1(this, selector, key, accesskey, contenteditable, dir, draggable, height, hidden, lang, spellcheck, style, tabindex, title, translate, width, defineContent));
  };
  KatydidPhrasingContentBuilderImpl.prototype.cite_qckjfy$$default = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    this.element_0.addChildNode_x5x0wf$(new KatydidCite(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent));
  };
  KatydidPhrasingContentBuilderImpl.prototype.code_qckjfy$$default = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    this.element_0.addChildNode_x5x0wf$(new KatydidCode(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent));
  };
  KatydidPhrasingContentBuilderImpl.prototype.data_cn0i2o$$default = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, value, defineContent) {
    this.element_0.addChildNode_x5x0wf$(new KatydidData(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, value, defineContent));
  };
  KatydidPhrasingContentBuilderImpl.prototype.datalist_csvf3w$$default = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    this.element_0.addChildNode_x5x0wf$(KatydidDataList_init(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent));
  };
  KatydidPhrasingContentBuilderImpl.prototype.datalist_zf5udj$$default = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, contentType, defineContent) {
    this.element_0.addChildNode_x5x0wf$(KatydidDataList_init_0(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, contentType, defineContent));
  };
  KatydidPhrasingContentBuilderImpl.prototype.del_smchxe$$default = function (selector, key, accesskey, cite, contenteditable, datetime, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    this.element_0.addChildNode_x5x0wf$(KatydidDel_init(this, selector, key, accesskey, cite, contenteditable, datetime, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent));
  };
  KatydidPhrasingContentBuilderImpl.prototype.dfn_qckjfy$$default = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    this.element_0.addChildNode_x5x0wf$(new KatydidDfn(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent));
  };
  KatydidPhrasingContentBuilderImpl.prototype.em_qckjfy$$default = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    this.element_0.addChildNode_x5x0wf$(new KatydidEm(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent));
  };
  KatydidPhrasingContentBuilderImpl.prototype.i_qckjfy$$default = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    this.element_0.addChildNode_x5x0wf$(new KatydidI(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent));
  };
  KatydidPhrasingContentBuilderImpl.prototype.inputButton_kk2d6s$$default = function (selector, key, accesskey, contenteditable, dir, disabled, draggable, form, hidden, lang, name, spellcheck, style, tabindex, title, translate, value, defineAttributes) {
    this.element_0.addChildNode_x5x0wf$(new KatydidInputButton(this, selector, key, accesskey, contenteditable, dir, disabled, draggable, form, hidden, lang, name, spellcheck, style, tabindex, title, translate, value, defineAttributes));
  };
  KatydidPhrasingContentBuilderImpl.prototype.inputCheckbox_5idhkk$$default = function (selector, key, accesskey, autofocus, checked, contenteditable, dir, disabled, draggable, form, hidden, lang, name, required, spellcheck, style, tabindex, title, translate, value, defineAttributes) {
    this.element_0.addChildNode_x5x0wf$(new KatydidInputCheckbox(this, selector, key, accesskey, autofocus, checked, contenteditable, dir, disabled, draggable, form, hidden, lang, name, required, spellcheck, style, tabindex, title, translate, value, defineAttributes));
  };
  KatydidPhrasingContentBuilderImpl.prototype.inputColor_9zybug$$default = function (selector, key, accesskey, autocomplete, autofocus, contenteditable, dir, disabled, draggable, form, hidden, lang, list, name, spellcheck, style, tabindex, title, translate, value, defineAttributes) {
    this.element_0.addChildNode_x5x0wf$(new KatydidInputColor(this, selector, key, accesskey, autocomplete, autofocus, contenteditable, dir, disabled, draggable, form, hidden, lang, list, name, spellcheck, style, tabindex, title, translate, value, defineAttributes));
  };
  KatydidPhrasingContentBuilderImpl.prototype.inputDate_3kgd4t$$default = function (selector, key, accesskey, autocomplete, autofocus, contenteditable, dir, disabled, draggable, form, hidden, lang, list, max, min, name, readonly, required, spellcheck, step, style, tabindex, title, translate, value, defineAttributes) {
    this.element_0.addChildNode_x5x0wf$(new KatydidInputDate(this, selector, key, accesskey, autocomplete, autofocus, contenteditable, dir, disabled, draggable, form, hidden, lang, list, max, min, name, readonly, required, spellcheck, step, style, tabindex, title, translate, value, defineAttributes));
  };
  KatydidPhrasingContentBuilderImpl.prototype.inputDateTimeLocal_3kgd4t$$default = function (selector, key, accesskey, autocomplete, autofocus, contenteditable, dir, disabled, draggable, form, hidden, lang, list, max, min, name, readonly, required, spellcheck, step, style, tabindex, title, translate, value, defineAttributes) {
    this.element_0.addChildNode_x5x0wf$(new KatydidInputDateTimeLocal(this, selector, key, accesskey, autocomplete, autofocus, contenteditable, dir, disabled, draggable, form, hidden, lang, list, max, min, name, readonly, required, spellcheck, step, style, tabindex, title, translate, value, defineAttributes));
  };
  KatydidPhrasingContentBuilderImpl.prototype.inputEmail_44r9ep$$default = function (selector, key, accesskey, autocomplete, autofocus, contenteditable, dir, disabled, draggable, form, hidden, lang, list, maxlength, minlength, multiple, name, pattern, placeholder, readonly, required, size, spellcheck, style, tabindex, title, translate, value, defineAttributes) {
    this.element_0.addChildNode_x5x0wf$(new KatydidInputEmail(this, selector, key, accesskey, autocomplete, autofocus, contenteditable, dir, disabled, draggable, form, hidden, lang, list, maxlength, minlength, multiple, name, pattern, placeholder, readonly, required, size, spellcheck, style, tabindex, title, translate, value, defineAttributes));
  };
  KatydidPhrasingContentBuilderImpl.prototype.inputFile_8v4l2x$$default = function (selector, key, accept, accesskey, autofocus, contenteditable, dir, disabled, draggable, form, hidden, lang, multiple, name, required, spellcheck, style, tabindex, title, translate, value, defineAttributes) {
    this.element_0.addChildNode_x5x0wf$(new KatydidInputFile(this, selector, key, accept, accesskey, autofocus, contenteditable, dir, disabled, draggable, form, hidden, lang, multiple, name, required, spellcheck, style, tabindex, title, translate, value, defineAttributes));
  };
  KatydidPhrasingContentBuilderImpl.prototype.inputHidden_kk2d6s$$default = function (selector, key, accesskey, contenteditable, dir, disabled, draggable, form, hidden, lang, name, spellcheck, style, tabindex, title, translate, value, defineAttributes) {
    this.element_0.addChildNode_x5x0wf$(new KatydidInputHidden(this, selector, key, accesskey, contenteditable, dir, disabled, draggable, form, hidden, lang, name, spellcheck, style, tabindex, title, translate, value, defineAttributes));
  };
  KatydidPhrasingContentBuilderImpl.prototype.inputImageButton_ojhf04$$default = function (selector, key, accesskey, alt, contenteditable, dir, disabled, draggable, form, formaction, formenctype, formmethod, formnovalidate, formtarget, height, hidden, lang, name, spellcheck, src, style, tabindex, title, translate, width, defineAttributes) {
    this.element_0.addChildNode_x5x0wf$(new KatydidInputImageButton(this, selector, key, accesskey, alt, contenteditable, dir, disabled, draggable, form, formaction, formenctype, formmethod, formnovalidate, formtarget, height, hidden, lang, name, spellcheck, src, style, tabindex, title, translate, width, defineAttributes));
  };
  KatydidPhrasingContentBuilderImpl.prototype.inputMonth_3kgd4t$$default = function (selector, key, accesskey, autocomplete, autofocus, contenteditable, dir, disabled, draggable, form, hidden, lang, list, max, min, name, readonly, required, spellcheck, step, style, tabindex, title, translate, value, defineAttributes) {
    this.element_0.addChildNode_x5x0wf$(new KatydidInputMonth(this, selector, key, accesskey, autocomplete, autofocus, contenteditable, dir, disabled, draggable, form, hidden, lang, list, max, min, name, readonly, required, spellcheck, step, style, tabindex, title, translate, value, defineAttributes));
  };
  KatydidPhrasingContentBuilderImpl.prototype.inputNumber_xtj0dk$$default = function (selector, key, accesskey, autocomplete, autofocus, contenteditable, dir, disabled, draggable, form, hidden, lang, list, max, min, name, placeholder, readonly, required, spellcheck, step, style, tabindex, title, translate, value, defineAttributes) {
    this.element_0.addChildNode_x5x0wf$(KatydidInputNumber_init(this, selector, key, accesskey, autocomplete, autofocus, contenteditable, dir, disabled, draggable, form, hidden, lang, list, max, min, name, placeholder, readonly, required, spellcheck, step, style, tabindex, title, translate, value, defineAttributes));
  };
  KatydidPhrasingContentBuilderImpl.prototype.inputNumber_25std2$$default = function (selector, key, accesskey, autocomplete, autofocus, contenteditable, dir, disabled, draggable, form, hidden, lang, list, max, min, name, placeholder, readonly, required, spellcheck, step, style, tabindex, title, translate, value, defineAttributes) {
    this.element_0.addChildNode_x5x0wf$(KatydidInputNumber_init_0(this, selector, key, accesskey, autocomplete, autofocus, contenteditable, dir, disabled, draggable, form, hidden, lang, list, max, min, name, placeholder, readonly, required, spellcheck, step, style, tabindex, title, translate, value, defineAttributes));
  };
  KatydidPhrasingContentBuilderImpl.prototype.inputPassword_98xs2q$$default = function (selector, key, accesskey, autocomplete, autofocus, contenteditable, dir, disabled, draggable, form, hidden, lang, maxlength, minlength, name, pattern, placeholder, readonly, required, size, spellcheck, style, tabindex, title, translate, value, defineAttributes) {
    this.element_0.addChildNode_x5x0wf$(new KatydidInputPassword(this, selector, key, accesskey, autocomplete, autofocus, contenteditable, dir, disabled, draggable, form, hidden, lang, maxlength, minlength, name, pattern, placeholder, readonly, required, size, spellcheck, style, tabindex, title, translate, value, defineAttributes));
  };
  KatydidPhrasingContentBuilderImpl.prototype.inputRadioButton_5idhkk$$default = function (selector, key, accesskey, autofocus, checked, contenteditable, dir, disabled, draggable, form, hidden, lang, name, required, spellcheck, style, tabindex, title, translate, value, defineAttributes) {
    this.element_0.addChildNode_x5x0wf$(new KatydidInputRadioButton(this, selector, key, accesskey, autofocus, checked, contenteditable, dir, disabled, draggable, form, hidden, lang, name, required, spellcheck, style, tabindex, title, translate, value, defineAttributes));
  };
  KatydidPhrasingContentBuilderImpl.prototype.inputRange_er1tee$$default = function (selector, key, accesskey, autocomplete, autofocus, contenteditable, dir, disabled, draggable, form, hidden, lang, list, max, min, name, spellcheck, step, style, tabindex, title, translate, value, defineAttributes) {
    this.element_0.addChildNode_x5x0wf$(new KatydidInputRange(this, selector, key, accesskey, autocomplete, autofocus, contenteditable, dir, disabled, draggable, form, hidden, lang, list, max, min, name, spellcheck, step, style, tabindex, title, translate, value, defineAttributes));
  };
  KatydidPhrasingContentBuilderImpl.prototype.inputResetButton_kk2d6s$$default = function (selector, key, accesskey, contenteditable, dir, disabled, draggable, form, hidden, lang, name, spellcheck, style, tabindex, title, translate, value, defineAttributes) {
    this.element_0.addChildNode_x5x0wf$(new KatydidInputResetButton(this, selector, key, accesskey, contenteditable, dir, disabled, draggable, form, hidden, lang, name, spellcheck, style, tabindex, title, translate, value, defineAttributes));
  };
  KatydidPhrasingContentBuilderImpl.prototype.inputSearch_y74p72$$default = function (selector, key, accesskey, autocomplete, autofocus, contenteditable, dir, dirname, disabled, draggable, form, hidden, lang, list, maxlength, minlength, name, pattern, placeholder, readonly, required, size, spellcheck, style, tabindex, title, translate, value, defineAttributes) {
    this.element_0.addChildNode_x5x0wf$(new KatydidInputSearch(this, selector, key, accesskey, autocomplete, autofocus, contenteditable, dir, dirname, disabled, draggable, form, hidden, lang, list, maxlength, minlength, name, pattern, placeholder, readonly, required, size, spellcheck, style, tabindex, title, translate, value, defineAttributes));
  };
  KatydidPhrasingContentBuilderImpl.prototype.inputSubmitButton_xi657a$$default = function (selector, key, accesskey, contenteditable, dir, disabled, draggable, form, formaction, formenctype, formmethod, formnovalidate, formtarget, hidden, lang, name, spellcheck, style, tabindex, title, translate, value, defineAttributes) {
    this.element_0.addChildNode_x5x0wf$(new KatydidInputSubmitButton(this, selector, key, accesskey, contenteditable, dir, disabled, draggable, form, formaction, formenctype, formmethod, formnovalidate, formtarget, hidden, lang, name, spellcheck, style, tabindex, title, translate, value, defineAttributes));
  };
  KatydidPhrasingContentBuilderImpl.prototype.inputTelephone_m3bg53$$default = function (selector, key, accesskey, autocomplete, autofocus, contenteditable, dir, disabled, draggable, form, hidden, lang, list, maxlength, minlength, name, pattern, placeholder, readonly, required, size, spellcheck, style, tabindex, title, translate, value, defineAttributes) {
    this.element_0.addChildNode_x5x0wf$(new KatydidInputTelephone(this, selector, key, accesskey, autocomplete, autofocus, contenteditable, dir, disabled, draggable, form, hidden, lang, list, maxlength, minlength, name, pattern, placeholder, readonly, required, size, spellcheck, style, tabindex, title, translate, value, defineAttributes));
  };
  KatydidPhrasingContentBuilderImpl.prototype.inputText_y74p72$$default = function (selector, key, accesskey, autocomplete, autofocus, contenteditable, dir, dirname, disabled, draggable, form, hidden, lang, list, maxlength, minlength, name, pattern, placeholder, readonly, required, size, spellcheck, style, tabindex, title, translate, value, defineAttributes) {
    this.element_0.addChildNode_x5x0wf$(new KatydidInputText(this, selector, key, accesskey, autocomplete, autofocus, contenteditable, dir, dirname, disabled, draggable, form, hidden, lang, list, maxlength, minlength, name, pattern, placeholder, readonly, required, size, spellcheck, style, tabindex, title, translate, value, defineAttributes));
  };
  KatydidPhrasingContentBuilderImpl.prototype.inputTime_629f1$$default = function (selector, key, accesskey, autocomplete, autofocus, contenteditable, dir, disabled, draggable, form, hidden, lang, list, max, min, name, readonly, required, spellcheck, step, style, tabindex, title, translate, value, defineAttributes) {
    this.element_0.addChildNode_x5x0wf$(new KatydidInputTime(this, selector, key, accesskey, autocomplete, autofocus, contenteditable, dir, disabled, draggable, form, hidden, lang, list, max, min, name, readonly, required, spellcheck, step, style, tabindex, title, translate, value, defineAttributes));
  };
  KatydidPhrasingContentBuilderImpl.prototype.inputUrl_m3bg53$$default = function (selector, key, accesskey, autocomplete, autofocus, contenteditable, dir, disabled, draggable, form, hidden, lang, list, maxlength, minlength, name, pattern, placeholder, readonly, required, size, spellcheck, style, tabindex, title, translate, value, defineAttributes) {
    this.element_0.addChildNode_x5x0wf$(new KatydidInputUrl(this, selector, key, accesskey, autocomplete, autofocus, contenteditable, dir, disabled, draggable, form, hidden, lang, list, maxlength, minlength, name, pattern, placeholder, readonly, required, size, spellcheck, style, tabindex, title, translate, value, defineAttributes));
  };
  KatydidPhrasingContentBuilderImpl.prototype.inputWeek_3kgd4t$$default = function (selector, key, accesskey, autocomplete, autofocus, contenteditable, dir, disabled, draggable, form, hidden, lang, list, max, min, name, readonly, required, spellcheck, step, style, tabindex, title, translate, value, defineAttributes) {
    this.element_0.addChildNode_x5x0wf$(new KatydidInputWeek(this, selector, key, accesskey, autocomplete, autofocus, contenteditable, dir, disabled, draggable, form, hidden, lang, list, max, min, name, readonly, required, spellcheck, step, style, tabindex, title, translate, value, defineAttributes));
  };
  KatydidPhrasingContentBuilderImpl.prototype.ins_smchxe$$default = function (selector, key, accesskey, cite, contenteditable, datetime, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    this.element_0.addChildNode_x5x0wf$(KatydidIns_init(this, selector, key, accesskey, cite, contenteditable, datetime, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent));
  };
  KatydidPhrasingContentBuilderImpl.prototype.kbd_qckjfy$$default = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    this.element_0.addChildNode_x5x0wf$(new KatydidKbd(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent));
  };
  KatydidPhrasingContentBuilderImpl.prototype.label_va30u7$$default = function (selector, key, accesskey, contenteditable, dir, draggable, for_0, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    this.element_0.addChildNode_x5x0wf$(new KatydidLabel(this, selector, key, accesskey, contenteditable, dir, draggable, for_0, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent));
  };
  KatydidPhrasingContentBuilderImpl.prototype.map_z0i53j$$default = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, name, spellcheck, style, tabindex, title, translate, defineContent) {
    this.element_0.addChildNode_x5x0wf$(KatydidMap_init(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, name, spellcheck, style, tabindex, title, translate, defineContent));
  };
  KatydidPhrasingContentBuilderImpl.prototype.mark_qckjfy$$default = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    this.element_0.addChildNode_x5x0wf$(new KatydidMark(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent));
  };
  KatydidPhrasingContentBuilderImpl.prototype.mediaPhrasingContent_wzqe2t$ = function (element, sourceAllowed) {
    this.contentRestrictions.prohibitParam();
    return new KatydidMediaPhrasingContentBuilderImpl(element, this.contentRestrictions.withMediaElementNotAllowed(), new KatydidMediaContentRestrictions(sourceAllowed), this.dispatchMessages_0);
  };
  KatydidPhrasingContentBuilderImpl.prototype.meter_6c4h8d$$default = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, high, lang, low, max, min, optimum, spellcheck, style, tabindex, title, translate, value, defineContent) {
    this.element_0.addChildNode_x5x0wf$(KatydidMeter_init(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, high, lang, low, max, min, optimum, spellcheck, style, tabindex, title, translate, value, defineContent));
  };
  KatydidPhrasingContentBuilderImpl.prototype.meter_ujjlce$$default = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, high, lang, low, max, min, optimum, spellcheck, style, tabindex, title, translate, value, defineContent) {
    this.element_0.addChildNode_x5x0wf$(KatydidMeter_init_0(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, high, lang, low, max, min, optimum, spellcheck, style, tabindex, title, translate, value, defineContent));
  };
  KatydidPhrasingContentBuilderImpl.prototype.object_8mhd8$$default = function (selector, key, accesskey, contenteditable, data, dir, draggable, form, height, hidden, lang, name, spellcheck, style, tabindex, title, translate, type, typemustmatch, width, contentType, defineContent) {
    this.element_0.addChildNode_x5x0wf$(KatydidObject_init_1(this, selector, key, accesskey, contenteditable, data, dir, draggable, form, height, hidden, lang, name, spellcheck, style, tabindex, title, translate, type, typemustmatch, width, defineContent));
  };
  KatydidPhrasingContentBuilderImpl.prototype.objectPhrasingContent_5czpdc$ = function (element) {
    this.contentRestrictions.prohibitParam();
    return new KatydidObjectPhrasingContentBuilderImpl(element, this.contentRestrictions.withParamAllowed(), this.dispatchMessages_0);
  };
  KatydidPhrasingContentBuilderImpl.prototype.optGroupContent_gwhh62$ = function (element) {
    this.contentRestrictions.prohibitParam();
    return new KatydidOptGroupContentBuilderImpl(element, this.contentRestrictions, this.dispatchMessages_0);
  };
  KatydidPhrasingContentBuilderImpl.prototype.output_7nyrc9$$default = function (selector, key, accesskey, contenteditable, dir, disabled, draggable, for_0, form, hidden, lang, name, spellcheck, style, tabindex, title, translate, defineContent) {
    this.element_0.addChildNode_x5x0wf$(new KatydidOutput(this, selector, key, accesskey, contenteditable, dir, disabled, draggable, for_0, form, hidden, lang, name, spellcheck, style, tabindex, title, translate, defineContent));
  };
  KatydidPhrasingContentBuilderImpl.prototype.progress_8ydfv4$$default = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, max, spellcheck, style, tabindex, title, translate, value, defineContent) {
    this.element_0.addChildNode_x5x0wf$(KatydidProgress_init(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, max, spellcheck, style, tabindex, title, translate, value, defineContent));
  };
  KatydidPhrasingContentBuilderImpl.prototype.progress_qjij5p$$default = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, max, spellcheck, style, tabindex, title, translate, value, defineContent) {
    this.element_0.addChildNode_x5x0wf$(KatydidProgress_init_0(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, max, spellcheck, style, tabindex, title, translate, value, defineContent));
  };
  KatydidPhrasingContentBuilderImpl.prototype.q_qckjfy$$default = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    this.element_0.addChildNode_x5x0wf$(new KatydidQ(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent));
  };
  KatydidPhrasingContentBuilderImpl.prototype.ruby_sy7cla$$default = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    this.element_0.addChildNode_x5x0wf$(new KatydidRuby(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent));
  };
  KatydidPhrasingContentBuilderImpl.prototype.rubyContent_bflrjy$ = function (element) {
    this.contentRestrictions.prohibitParam();
    return new KatydidRubyContentBuilderImpl(element, this.contentRestrictions, this.dispatchMessages_0);
  };
  KatydidPhrasingContentBuilderImpl.prototype.s_qckjfy$$default = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    this.element_0.addChildNode_x5x0wf$(new KatydidS(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent));
  };
  KatydidPhrasingContentBuilderImpl.prototype.samp_qckjfy$$default = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    this.element_0.addChildNode_x5x0wf$(new KatydidSamp(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent));
  };
  KatydidPhrasingContentBuilderImpl.prototype.select_7efmz3$$default = function (selector, key, accesskey, autocomplete, autofocus, contenteditable, dir, disabled, draggable, form, hidden, lang, multiple, name, required, size, spellcheck, style, tabindex, title, translate, value, defineContent) {
    this.element_0.addChildNode_x5x0wf$(new KatydidSelect(this, selector, key, accesskey, autocomplete, autofocus, contenteditable, dir, disabled, draggable, form, hidden, lang, multiple, name, required, size, spellcheck, style, tabindex, title, translate, value, defineContent));
  };
  KatydidPhrasingContentBuilderImpl.prototype.selectContent_devcnq$ = function (element) {
    this.contentRestrictions.prohibitParam();
    return new KatydidSelectContentBuilderImpl(element, this.contentRestrictions, this.dispatchMessages_0);
  };
  KatydidPhrasingContentBuilderImpl.prototype.small_qckjfy$$default = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    this.element_0.addChildNode_x5x0wf$(new KatydidSmall(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent));
  };
  KatydidPhrasingContentBuilderImpl.prototype.span_qckjfy$$default = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    this.element_0.addChildNode_x5x0wf$(new KatydidSpan(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent));
  };
  KatydidPhrasingContentBuilderImpl.prototype.strong_qckjfy$$default = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    this.element_0.addChildNode_x5x0wf$(new KatydidStrong(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent));
  };
  KatydidPhrasingContentBuilderImpl.prototype.sub_qckjfy$$default = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    this.element_0.addChildNode_x5x0wf$(new KatydidSub(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent));
  };
  KatydidPhrasingContentBuilderImpl.prototype.sup_qckjfy$$default = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    this.element_0.addChildNode_x5x0wf$(new KatydidSup(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent));
  };
  KatydidPhrasingContentBuilderImpl.prototype.text_4w9ihe$$default = function (nodeValue, key) {
    this.element_0.addChildNode_x5x0wf$(new KatydidText(nodeValue, key));
  };
  KatydidPhrasingContentBuilderImpl.prototype.textarea_1j30yg$$default = function (selector, key, accesskey, autocomplete, autofocus, cols, contenteditable, dir, dirname, disabled, draggable, form, hidden, lang, maxlength, minlength, name, placeholder, readonly, required, rows, spellcheck, style, tabindex, title, translate, wrap, defineContent) {
    this.element_0.addChildNode_x5x0wf$(new KatydidTextArea(this, selector, key, accesskey, autocomplete, autofocus, cols, contenteditable, dir, dirname, disabled, draggable, form, hidden, lang, maxlength, minlength, name, placeholder, readonly, required, rows, spellcheck, style, tabindex, title, translate, wrap, defineContent));
  };
  KatydidPhrasingContentBuilderImpl.prototype.time_y9dz51$$default = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    this.element_0.addChildNode_x5x0wf$(KatydidTime_init(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent));
  };
  KatydidPhrasingContentBuilderImpl.prototype.time_jigsdy$$default = function (selector, key, accesskey, contenteditable, datetime, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    this.element_0.addChildNode_x5x0wf$(KatydidTime_init_0(this, selector, key, accesskey, contenteditable, datetime, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent));
  };
  KatydidPhrasingContentBuilderImpl.prototype.u_qckjfy$$default = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    this.element_0.addChildNode_x5x0wf$(new KatydidU(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent));
  };
  KatydidPhrasingContentBuilderImpl.prototype.var_qckjfy$$default = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    this.element_0.addChildNode_x5x0wf$(new KatydidVar(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent));
  };
  KatydidPhrasingContentBuilderImpl.prototype.video_l9965i$$default = function (selector, key, accesskey, autoplay, contenteditable, controls, crossorigin, dir, draggable, height, hidden, lang, loop, muted, poster, preload, spellcheck, src, style, tabindex, title, translate, width, contentType, defineContent) {
    this.element_0.addChildNode_x5x0wf$(KatydidVideo_init_1(this, selector, key, accesskey, autoplay, contenteditable, controls, crossorigin, dir, draggable, height, hidden, lang, loop, muted, poster, preload, spellcheck, src, style, tabindex, title, translate, width, defineContent));
  };
  KatydidPhrasingContentBuilderImpl.prototype.wbr_9mj9vz$$default = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineAttributes) {
    this.element_0.addChildNode_x5x0wf$(new KatydidBr(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineAttributes));
  };
  KatydidPhrasingContentBuilderImpl.prototype.withAnchorInteractiveContentNotAllowed_bflrjy$ = function (element) {
    this.contentRestrictions.prohibitParam();
    return new KatydidPhrasingContentBuilderImpl(element, this.contentRestrictions.withAnchorInteractiveContentNotAllowed(), this.dispatchMessages_0);
  };
  KatydidPhrasingContentBuilderImpl.prototype.withAreaAllowed_b59t6t$ = function (element) {
    this.contentRestrictions.prohibitParam();
    return new KatydidPhrasingContentBuilderImpl(element, this.contentRestrictions.withAreaAllowed(), this.dispatchMessages_0);
  };
  KatydidPhrasingContentBuilderImpl.prototype.withDfnNotAllowed_bflrjy$ = function (element) {
    this.contentRestrictions.prohibitParam();
    return new KatydidPhrasingContentBuilderImpl(element, this.contentRestrictions.withDfnNotAllowed(), this.dispatchMessages_0);
  };
  KatydidPhrasingContentBuilderImpl.prototype.withInteractiveContentNotAllowed_bflrjy$ = function (element) {
    this.contentRestrictions.prohibitParam();
    return new KatydidPhrasingContentBuilderImpl(element, this.contentRestrictions.withInteractiveContentNotAllowed(), this.dispatchMessages_0);
  };
  KatydidPhrasingContentBuilderImpl.prototype.withLabelNotAllowed_bflrjy$ = function (element) {
    this.contentRestrictions.prohibitParam();
    return new KatydidPhrasingContentBuilderImpl(element, this.contentRestrictions.withLabelNotAllowed(), this.dispatchMessages_0);
  };
  KatydidPhrasingContentBuilderImpl.prototype.withMeterNotAllowed_bflrjy$ = function (element) {
    this.contentRestrictions.prohibitParam();
    return new KatydidPhrasingContentBuilderImpl(element, this.contentRestrictions.withMeterNotAllowed(), this.dispatchMessages_0);
  };
  KatydidPhrasingContentBuilderImpl.prototype.withNoAddedRestrictions_bflrjy$ = function (element) {
    this.contentRestrictions.prohibitParam();
    return new KatydidPhrasingContentBuilderImpl(element, this.contentRestrictions, this.dispatchMessages_0);
  };
  KatydidPhrasingContentBuilderImpl.prototype.withProgressNotAllowed_bflrjy$ = function (element) {
    this.contentRestrictions.prohibitParam();
    return new KatydidPhrasingContentBuilderImpl(element, this.contentRestrictions.withProgressNotAllowed(), this.dispatchMessages_0);
  };
  KatydidPhrasingContentBuilderImpl.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidPhrasingContentBuilderImpl',
    interfaces: [KatydidPhrasingContentBuilder, KatydidEmbeddedContentBuilderImpl]
  };
  function KatydidOrderedListContentBuilderImpl(itsFlowContent, itsElement, itsDispatchMessages) {
    KatydidAttributesContentBuilderImpl.call(this, itsElement, itsDispatchMessages);
    this.flowContent_8be2vx$ = itsFlowContent;
  }
  KatydidOrderedListContentBuilderImpl.prototype.comment_4w9ihe$$default = function (nodeValue, key) {
    this.element_0.addChildNode_x5x0wf$(new KatydidComment(nodeValue, key));
  };
  KatydidOrderedListContentBuilderImpl.prototype.li_wy8x0p$$default = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, value, defineContent) {
    this.element_0.addChildNode_x5x0wf$(KatydidLi_init(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, value, defineContent));
  };
  KatydidOrderedListContentBuilderImpl.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidOrderedListContentBuilderImpl',
    interfaces: [KatydidOrderedListContentBuilder, KatydidAttributesContentBuilderImpl]
  };
  function KatydidUnorderedListContentBuilderImpl(itsFlowContent, itsElement, itsDispatchMessages) {
    KatydidAttributesContentBuilderImpl.call(this, itsElement, itsDispatchMessages);
    this.flowContent_8be2vx$ = itsFlowContent;
  }
  KatydidUnorderedListContentBuilderImpl.prototype.comment_4w9ihe$$default = function (nodeValue, key) {
    this.element_0.addChildNode_x5x0wf$(new KatydidComment(nodeValue, key));
  };
  KatydidUnorderedListContentBuilderImpl.prototype.li_6zr3om$$default = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    this.element_0.addChildNode_x5x0wf$(KatydidLi_init_0(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent));
  };
  KatydidUnorderedListContentBuilderImpl.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidUnorderedListContentBuilderImpl',
    interfaces: [KatydidUnorderedListContentBuilder, KatydidAttributesContentBuilderImpl]
  };
  function KatydidMediaContentRestrictions(itsSourceAllowed) {
    if (itsSourceAllowed === void 0)
      itsSourceAllowed = true;
    this.sourceAllowed_0 = itsSourceAllowed;
    this.trackAllowed_0 = true;
  }
  KatydidMediaContentRestrictions.prototype.confirmSourceAllowed = function () {
    if (!this.sourceAllowed_0) {
      var message = 'Element type <source> not allowed here';
      throw IllegalStateException_init(message.toString());
    }
  };
  KatydidMediaContentRestrictions.prototype.confirmTrackAllowed = function () {
    if (!this.trackAllowed_0) {
      var message = 'Element type <track> not allowed here';
      throw IllegalStateException_init(message.toString());
    }
    this.sourceAllowed_0 = false;
  };
  KatydidMediaContentRestrictions.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidMediaContentRestrictions',
    interfaces: []
  };
  function KatydidMediaEmbeddedContentBuilderImpl(itsElement, itsContentRestrictions, itsMediaContentRestrictions, itsDispatchMessages) {
    if (itsContentRestrictions === void 0)
      itsContentRestrictions = KatydidContentRestrictions_init();
    if (itsMediaContentRestrictions === void 0)
      itsMediaContentRestrictions = new KatydidMediaContentRestrictions();
    KatydidEmbeddedContentBuilderImpl.call(this, itsElement, itsContentRestrictions, itsDispatchMessages);
    this.mediaContentRestrictions = itsMediaContentRestrictions;
  }
  KatydidMediaEmbeddedContentBuilderImpl.prototype.source_7jkj91$$default = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, media, sizes, spellcheck, src, srcset, style, tabindex, title, translate, type, defineAttributes) {
    this.element_0.addChildNode_x5x0wf$(KatydidSource_init(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, media, sizes, spellcheck, src, srcset, style, tabindex, title, translate, type, defineAttributes));
  };
  KatydidMediaEmbeddedContentBuilderImpl.prototype.track_o1vzoi$$default = function (selector, key, accesskey, contenteditable, default_0, dir, draggable, hidden, kind, label, lang, spellcheck, src, srclang, style, tabindex, title, translate, defineAttributes) {
    this.element_0.addChildNode_x5x0wf$(KatydidTrack_init(this, selector, key, accesskey, contenteditable, default_0, dir, draggable, hidden, kind, label, lang, spellcheck, src, srclang, style, tabindex, title, translate, defineAttributes));
  };
  KatydidMediaEmbeddedContentBuilderImpl.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidMediaEmbeddedContentBuilderImpl',
    interfaces: [KatydidMediaEmbeddedContentBuilder, KatydidEmbeddedContentBuilderImpl]
  };
  function KatydidMediaFlowContentBuilderImpl(itsElement, itsContentRestrictions, itsMediaContentRestrictions, itsDispatchMessages) {
    if (itsContentRestrictions === void 0)
      itsContentRestrictions = KatydidContentRestrictions_init();
    if (itsMediaContentRestrictions === void 0)
      itsMediaContentRestrictions = new KatydidMediaContentRestrictions();
    KatydidFlowContentBuilderImpl.call(this, itsElement, itsContentRestrictions, itsDispatchMessages);
    this.mediaContentRestrictions = itsMediaContentRestrictions;
  }
  KatydidMediaFlowContentBuilderImpl.prototype.source_7jkj91$$default = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, media, sizes, spellcheck, src, srcset, style, tabindex, title, translate, type, defineAttributes) {
    this.element_0.addChildNode_x5x0wf$(KatydidSource_init_0(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, media, sizes, spellcheck, src, srcset, style, tabindex, title, translate, type, defineAttributes));
  };
  KatydidMediaFlowContentBuilderImpl.prototype.track_o1vzoi$$default = function (selector, key, accesskey, contenteditable, default_0, dir, draggable, hidden, kind, label, lang, spellcheck, src, srclang, style, tabindex, title, translate, defineAttributes) {
    this.element_0.addChildNode_x5x0wf$(KatydidTrack_init_0(this, selector, key, accesskey, contenteditable, default_0, dir, draggable, hidden, kind, label, lang, spellcheck, src, srclang, style, tabindex, title, translate, defineAttributes));
  };
  KatydidMediaFlowContentBuilderImpl.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidMediaFlowContentBuilderImpl',
    interfaces: [KatydidMediaFlowContentBuilder, KatydidFlowContentBuilderImpl]
  };
  function KatydidMediaPhrasingContentBuilderImpl(itsElement, itsContentRestrictions, itsMediaContentRestrictions, itsDispatchMessages) {
    if (itsContentRestrictions === void 0)
      itsContentRestrictions = KatydidContentRestrictions_init();
    if (itsMediaContentRestrictions === void 0)
      itsMediaContentRestrictions = new KatydidMediaContentRestrictions();
    KatydidPhrasingContentBuilderImpl.call(this, itsElement, itsContentRestrictions, itsDispatchMessages);
    this.mediaContentRestrictions = itsMediaContentRestrictions;
  }
  KatydidMediaPhrasingContentBuilderImpl.prototype.source_7jkj91$$default = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, media, sizes, spellcheck, src, srcset, style, tabindex, title, translate, type, defineAttributes) {
    this.element_0.addChildNode_x5x0wf$(KatydidSource_init_1(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, media, sizes, spellcheck, src, srcset, style, tabindex, title, translate, type, defineAttributes));
  };
  KatydidMediaPhrasingContentBuilderImpl.prototype.track_o1vzoi$$default = function (selector, key, accesskey, contenteditable, default_0, dir, draggable, hidden, kind, label, lang, spellcheck, src, srclang, style, tabindex, title, translate, defineAttributes) {
    this.element_0.addChildNode_x5x0wf$(KatydidTrack_init_1(this, selector, key, accesskey, contenteditable, default_0, dir, draggable, hidden, kind, label, lang, spellcheck, src, srclang, style, tabindex, title, translate, defineAttributes));
  };
  KatydidMediaPhrasingContentBuilderImpl.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidMediaPhrasingContentBuilderImpl',
    interfaces: [KatydidMediaPhrasingContentBuilder, KatydidPhrasingContentBuilderImpl]
  };
  function KatydidPictureContentBuilderImpl(itsElement, itsPictureContentRestrictions, itsDispatchMessages) {
    if (itsPictureContentRestrictions === void 0)
      itsPictureContentRestrictions = new KatydidPictureContentRestrictions();
    KatydidAttributesContentBuilderImpl.call(this, itsElement, itsDispatchMessages);
    this.pictureContentRestrictions = itsPictureContentRestrictions;
  }
  KatydidPictureContentBuilderImpl.prototype.attributesContent_bflrjy$ = function (element) {
    return new KatydidAttributesContentBuilderImpl(element, this.dispatchMessages_0);
  };
  KatydidPictureContentBuilderImpl.prototype.img_1hpfln$$default = function (selector, key, accesskey, alt, contenteditable, crossorigin, dir, draggable, height, hidden, ismap, lang, referrerpolicy, sizes, spellcheck, src, srcset, style, tabindex, title, translate, usemap, width, defineAttributes) {
    this.element_0.addChildNode_x5x0wf$(KatydidImg_init_0(this, selector, key, accesskey, alt, contenteditable, crossorigin, dir, draggable, height, hidden, ismap, lang, referrerpolicy, sizes, spellcheck, src, srcset, style, tabindex, title, translate, usemap, width, defineAttributes));
  };
  KatydidPictureContentBuilderImpl.prototype.source_7jkj91$$default = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, media, sizes, spellcheck, src, srcset, style, tabindex, title, translate, type, defineAttributes) {
    this.element_0.addChildNode_x5x0wf$(KatydidSource_init_2(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, media, sizes, spellcheck, src, srcset, style, tabindex, title, translate, type, defineAttributes));
  };
  KatydidPictureContentBuilderImpl.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidPictureContentBuilderImpl',
    interfaces: [KatydidPictureContentBuilder, KatydidAttributesContentBuilderImpl]
  };
  function KatydidPictureContentRestrictions(itsSourceAllowed) {
    if (itsSourceAllowed === void 0)
      itsSourceAllowed = true;
    this.imgAllowed_0 = true;
    this.sourceAllowed_0 = itsSourceAllowed;
    this.sourceElementSeen_0 = false;
  }
  KatydidPictureContentRestrictions.prototype.confirmImgAllowedThenDisallow = function () {
    if (!this.imgAllowed_0) {
      var message = 'Element type <img> not allowed here';
      throw IllegalStateException_init(message.toString());
    }
    this.sourceAllowed_0 = false;
    this.imgAllowed_0 = false;
  };
  KatydidPictureContentRestrictions.prototype.confirmSourceAllowed = function () {
    if (!this.sourceAllowed_0) {
      var message = 'Element type <source> not allowed here';
      throw IllegalStateException_init(message.toString());
    }
    this.sourceElementSeen_0 = true;
  };
  KatydidPictureContentRestrictions.prototype.confirmSourceElementSeen = function () {
    if (!this.sourceElementSeen_0) {
      var message = 'Img element must have src attribute or parent picture element must have <source> elements.';
      throw IllegalStateException_init(message.toString());
    }
  };
  KatydidPictureContentRestrictions.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidPictureContentRestrictions',
    interfaces: []
  };
  function KatydidDescriptionListContentBuilderImpl(itsElement, itsContentRestrictions, itsDispatchMessages) {
    KatydidAttributesContentBuilderImpl.call(this, itsElement, itsDispatchMessages);
    this.contentRestrictions_8be2vx$ = itsContentRestrictions;
  }
  KatydidDescriptionListContentBuilderImpl.prototype.comment_4w9ihe$$default = function (nodeValue, key) {
    this.element_0.addChildNode_x5x0wf$(new KatydidComment(nodeValue, key));
  };
  KatydidDescriptionListContentBuilderImpl.prototype.dd_6zr3om$$default = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    this.element_0.addChildNode_x5x0wf$(new KatydidDd(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent));
  };
  KatydidDescriptionListContentBuilderImpl.prototype.div_a7rbte$$default = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    this.element_0.addChildNode_x5x0wf$(KatydidDiv_init_0(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent));
  };
  KatydidDescriptionListContentBuilderImpl.prototype.dt_6zr3om$$default = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    this.element_0.addChildNode_x5x0wf$(new KatydidDt(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent));
  };
  KatydidDescriptionListContentBuilderImpl.prototype.flowContent_bflrjy$ = function (element) {
    return new KatydidFlowContentBuilderImpl(element, this.contentRestrictions_8be2vx$, this.dispatchMessages_0);
  };
  KatydidDescriptionListContentBuilderImpl.prototype.withNoAddedRestrictions_orwckh$ = function (element) {
    return new KatydidDescriptionListContentBuilderImpl(element, this.contentRestrictions_8be2vx$, this.dispatchMessages_0);
  };
  KatydidDescriptionListContentBuilderImpl.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidDescriptionListContentBuilderImpl',
    interfaces: [KatydidDescriptionListContentBuilder, KatydidAttributesContentBuilderImpl]
  };
  function KatydidOptGroupContentBuilderImpl(itsElement, itsContentRestrictions, itsDispatchMessages) {
    KatydidAttributesContentBuilderImpl.call(this, itsElement, itsDispatchMessages);
    this.contentRestrictions_8be2vx$ = itsContentRestrictions;
  }
  KatydidOptGroupContentBuilderImpl.prototype.attributesContent_bflrjy$ = function (element) {
    return new KatydidAttributesContentBuilderImpl(element, this.dispatchMessages_0);
  };
  KatydidOptGroupContentBuilderImpl.prototype.comment_4w9ihe$$default = function (nodeValue, key) {
    this.element_0.addChildNode_x5x0wf$(new KatydidComment(nodeValue, key));
  };
  KatydidOptGroupContentBuilderImpl.prototype.option_uvs23e$$default = function (selector, key, accesskey, contenteditable, dir, disabled, draggable, hidden, label, lang, name, selected, spellcheck, style, tabindex, title, translate, value, defineAttributes) {
    this.element_0.addChildNode_x5x0wf$(KatydidOption_init(this, selector, key, accesskey, contenteditable, dir, disabled, draggable, hidden, label, lang, name, selected, spellcheck, style, tabindex, title, translate, value, defineAttributes));
  };
  KatydidOptGroupContentBuilderImpl.prototype.option_o31kud$$default = function (selector, key, accesskey, contenteditable, dir, disabled, draggable, hidden, label, lang, name, selected, spellcheck, style, tabindex, title, translate, defineContent) {
    this.element_0.addChildNode_x5x0wf$(KatydidOption_init_0(this, selector, key, accesskey, contenteditable, dir, disabled, draggable, hidden, label, lang, name, selected, spellcheck, style, tabindex, title, translate, defineContent));
  };
  KatydidOptGroupContentBuilderImpl.prototype.textContent_3x6mf1$ = function (element) {
    return new KatydidTextContentBuilderImpl(element, this.dispatchMessages_0);
  };
  KatydidOptGroupContentBuilderImpl.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidOptGroupContentBuilderImpl',
    interfaces: [KatydidOptGroupContentBuilder, KatydidAttributesContentBuilderImpl]
  };
  function KatydidSelectContentBuilderImpl(itsElement, itsContentRestrictions, itsDispatchMessages) {
    KatydidOptGroupContentBuilderImpl.call(this, itsElement, itsContentRestrictions, itsDispatchMessages);
  }
  KatydidSelectContentBuilderImpl.prototype.optGroup_a8s91r$$default = function (selector, key, accesskey, contenteditable, dir, disabled, draggable, hidden, label, lang, name, spellcheck, style, tabindex, title, translate, defineContent) {
    this.element_0.addChildNode_x5x0wf$(new KatydidOptGroup(this, selector, key, accesskey, contenteditable, dir, disabled, draggable, hidden, label, lang, name, spellcheck, style, tabindex, title, translate, defineContent));
  };
  KatydidSelectContentBuilderImpl.prototype.optGroupContent_32tdoa$ = function (element) {
    return new KatydidOptGroupContentBuilderImpl(element, this.contentRestrictions_8be2vx$, this.dispatchMessages_0);
  };
  KatydidSelectContentBuilderImpl.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidSelectContentBuilderImpl',
    interfaces: [KatydidSelectContentBuilder, KatydidOptGroupContentBuilderImpl]
  };
  function KatydidTextContentBuilderImpl(itsElement, itsDispatchMessages) {
    KatydidAttributesContentBuilderImpl.call(this, itsElement, itsDispatchMessages);
  }
  KatydidTextContentBuilderImpl.prototype.comment_4w9ihe$$default = function (nodeValue, key) {
    this.element_0.addChildNode_x5x0wf$(new KatydidComment(nodeValue, key));
  };
  KatydidTextContentBuilderImpl.prototype.text_4w9ihe$$default = function (nodeValue, key) {
    this.element_0.addChildNode_x5x0wf$(new KatydidText(nodeValue, key));
  };
  KatydidTextContentBuilderImpl.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidTextContentBuilderImpl',
    interfaces: [KatydidTextContentBuilder, KatydidAttributesContentBuilderImpl]
  };
  function KatydidObjectEmbeddedContentBuilderImpl(itsElement, itsContentRestrictions, itsDispatchMessages) {
    if (itsContentRestrictions === void 0)
      itsContentRestrictions = KatydidContentRestrictions_init();
    KatydidEmbeddedContentBuilderImpl.call(this, itsElement, itsContentRestrictions, itsDispatchMessages);
  }
  KatydidObjectEmbeddedContentBuilderImpl.prototype.param_clmic1$$default = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, name, spellcheck, style, tabindex, title, translate, value, defineAttributes) {
    this.contentRestrictions.confirmParamAllowed();
    this.element_0.addChildNode_x5x0wf$(KatydidParam_init(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, name, spellcheck, style, tabindex, title, translate, value, defineAttributes));
  };
  KatydidObjectEmbeddedContentBuilderImpl.prototype.paramAttributesContent_5y5c46$ = function (element) {
    return new KatydidAttributesContentBuilderImpl(element, this.dispatchMessages_0);
  };
  KatydidObjectEmbeddedContentBuilderImpl.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidObjectEmbeddedContentBuilderImpl',
    interfaces: [KatydidObjectEmbeddedContentBuilder, KatydidEmbeddedContentBuilderImpl]
  };
  function KatydidObjectFlowContentBuilderImpl(itsElement, itsContentRestrictions, itsDispatchMessages) {
    if (itsContentRestrictions === void 0)
      itsContentRestrictions = KatydidContentRestrictions_init();
    KatydidFlowContentBuilderImpl.call(this, itsElement, itsContentRestrictions, itsDispatchMessages);
  }
  KatydidObjectFlowContentBuilderImpl.prototype.param_clmic1$$default = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, name, spellcheck, style, tabindex, title, translate, value, defineAttributes) {
    this.contentRestrictions.confirmParamAllowed();
    this.element_0.addChildNode_x5x0wf$(KatydidParam_init_0(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, name, spellcheck, style, tabindex, title, translate, value, defineAttributes));
  };
  KatydidObjectFlowContentBuilderImpl.prototype.paramAttributesContent_5y5c46$ = function (element) {
    return new KatydidAttributesContentBuilderImpl(element, this.dispatchMessages_0);
  };
  KatydidObjectFlowContentBuilderImpl.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidObjectFlowContentBuilderImpl',
    interfaces: [KatydidObjectFlowContentBuilder, KatydidFlowContentBuilderImpl]
  };
  function KatydidObjectPhrasingContentBuilderImpl(itsElement, itsContentRestrictions, itsDispatchMessages) {
    if (itsContentRestrictions === void 0)
      itsContentRestrictions = KatydidContentRestrictions_init();
    KatydidPhrasingContentBuilderImpl.call(this, itsElement, itsContentRestrictions, itsDispatchMessages);
  }
  KatydidObjectPhrasingContentBuilderImpl.prototype.param_clmic1$$default = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, name, spellcheck, style, tabindex, title, translate, value, defineAttributes) {
    this.contentRestrictions.confirmParamAllowed();
    this.element_0.addChildNode_x5x0wf$(KatydidParam_init_1(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, name, spellcheck, style, tabindex, title, translate, value, defineAttributes));
  };
  KatydidObjectPhrasingContentBuilderImpl.prototype.paramAttributesContent_5y5c46$ = function (element) {
    return new KatydidAttributesContentBuilderImpl(element, this.dispatchMessages_0);
  };
  KatydidObjectPhrasingContentBuilderImpl.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidObjectPhrasingContentBuilderImpl',
    interfaces: [KatydidObjectPhrasingContentBuilder, KatydidPhrasingContentBuilderImpl]
  };
  function KatydidRubyContentBuilderImpl(itsElement, itsContentRestrictions, itsDispatchMessages) {
    if (itsContentRestrictions === void 0)
      itsContentRestrictions = KatydidContentRestrictions_init();
    KatydidPhrasingContentBuilderImpl.call(this, itsElement, itsContentRestrictions, itsDispatchMessages);
  }
  KatydidRubyContentBuilderImpl.prototype.rb_qckjfy$$default = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    this.element_0.addChildNode_x5x0wf$(new KatydidRb(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent));
  };
  KatydidRubyContentBuilderImpl.prototype.rp_qckjfy$$default = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    this.element_0.addChildNode_x5x0wf$(new KatydidRp(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent));
  };
  KatydidRubyContentBuilderImpl.prototype.rt_qckjfy$$default = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    this.element_0.addChildNode_x5x0wf$(new KatydidRt(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent));
  };
  KatydidRubyContentBuilderImpl.prototype.rtc_sy7cla$$default = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    this.element_0.addChildNode_x5x0wf$(new KatydidRtc(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent));
  };
  KatydidRubyContentBuilderImpl.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidRubyContentBuilderImpl',
    interfaces: [KatydidRubyContentBuilder, KatydidPhrasingContentBuilderImpl]
  };
  function KatydidColGroupContentBuilderImpl(itsElement, itsDispatchMessages) {
    KatydidAttributesContentBuilderImpl.call(this, itsElement, itsDispatchMessages);
  }
  KatydidColGroupContentBuilderImpl.prototype.attributesContent_jftpzv$ = function (element) {
    return new KatydidAttributesContentBuilderImpl(element, this.dispatchMessages_0);
  };
  KatydidColGroupContentBuilderImpl.prototype.col_xkd41s$$default = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, span, spellcheck, style, tabindex, title, translate, defineAttributes) {
    this.element_0.addChildNode_x5x0wf$(new KatydidCol(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, span, spellcheck, style, tabindex, title, translate, defineAttributes));
  };
  KatydidColGroupContentBuilderImpl.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidColGroupContentBuilderImpl',
    interfaces: [KatydidColGroupContentBuilder, KatydidAttributesContentBuilderImpl]
  };
  function KatydidTableBodyContentBuilderImpl(itsElement, itsContentRestrictions, itsDispatchMessages) {
    if (itsContentRestrictions === void 0)
      itsContentRestrictions = KatydidContentRestrictions_init();
    KatydidAttributesContentBuilderImpl.call(this, itsElement, itsDispatchMessages);
    this.contentRestrictions = itsContentRestrictions;
  }
  KatydidTableBodyContentBuilderImpl.prototype.comment_4w9ihe$$default = function (nodeValue, key) {
    this.element_0.addChildNode_x5x0wf$(new KatydidComment(nodeValue, key));
  };
  KatydidTableBodyContentBuilderImpl.prototype.tableRowContent_rzem3q$ = function (element) {
    return new KatydidTableRowContentBuilderImpl(element, this.contentRestrictions, this.dispatchMessages_0);
  };
  KatydidTableBodyContentBuilderImpl.prototype.tr_n8e5b5$$default = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    this.element_0.addChildNode_x5x0wf$(KatydidTr_init_0(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent));
  };
  KatydidTableBodyContentBuilderImpl.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidTableBodyContentBuilderImpl',
    interfaces: [KatydidTableBodyContentBuilder, KatydidAttributesContentBuilderImpl]
  };
  function KatydidTableContentBuilderImpl(itsElement, itsContentRestrictions, itsDispatchMessages) {
    if (itsContentRestrictions === void 0)
      itsContentRestrictions = KatydidContentRestrictions_init();
    KatydidAttributesContentBuilderImpl.call(this, itsElement, itsDispatchMessages);
    this.contentRestrictions = itsContentRestrictions;
    this.tableContentRestrictions = new KatydidTableContentRestrictions();
  }
  KatydidTableContentBuilderImpl.prototype.attributesContent_kjcqhn$ = function (element) {
    return new KatydidAttributesContentBuilderImpl(element, this.dispatchMessages_0);
  };
  KatydidTableContentBuilderImpl.prototype.caption_6zr3om$$default = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    this.element_0.addChildNode_x5x0wf$(new KatydidCaption(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent));
  };
  KatydidTableContentBuilderImpl.prototype.colgroup_xkd41s$$default = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, span, spellcheck, style, tabindex, title, translate, defineAttributes) {
    this.element_0.addChildNode_x5x0wf$(KatydidColGroup_init_0(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, span, spellcheck, style, tabindex, title, translate, defineAttributes));
  };
  KatydidTableContentBuilderImpl.prototype.colgroup_lo2ydu$$default = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    this.element_0.addChildNode_x5x0wf$(KatydidColGroup_init(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent));
  };
  KatydidTableContentBuilderImpl.prototype.colGroupContent_kjcqhn$ = function (element) {
    return new KatydidColGroupContentBuilderImpl(element, this.dispatchMessages_0);
  };
  KatydidTableContentBuilderImpl.prototype.comment_4w9ihe$$default = function (nodeValue, key) {
    this.element_0.addChildNode_x5x0wf$(new KatydidComment(nodeValue, key));
  };
  KatydidTableContentBuilderImpl.prototype.flowContentWithTableNotAllowed_jl8rlo$ = function (element) {
    return new KatydidFlowContentBuilderImpl(element, this.contentRestrictions.withTableNotAllowed(), this.dispatchMessages_0);
  };
  KatydidTableContentBuilderImpl.prototype.tableRowContent_rzem3q$ = function (element) {
    return new KatydidTableRowContentBuilderImpl(element, this.contentRestrictions, this.dispatchMessages_0);
  };
  KatydidTableContentBuilderImpl.prototype.tbody_w9wujb$$default = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    this.element_0.addChildNode_x5x0wf$(new KatydidTBody(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent));
  };
  KatydidTableContentBuilderImpl.prototype.tfoot_w9wujb$$default = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    this.element_0.addChildNode_x5x0wf$(new KatydidTFoot(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent));
  };
  KatydidTableContentBuilderImpl.prototype.thead_w9wujb$$default = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    this.element_0.addChildNode_x5x0wf$(new KatydidTHead(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent));
  };
  KatydidTableContentBuilderImpl.prototype.tr_n8e5b5$$default = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    this.element_0.addChildNode_x5x0wf$(KatydidTr_init(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent));
  };
  KatydidTableContentBuilderImpl.prototype.tableBodyContent_bflrjy$ = function (element) {
    return new KatydidTableBodyContentBuilderImpl(element, this.contentRestrictions, this.dispatchMessages_0);
  };
  KatydidTableContentBuilderImpl.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidTableContentBuilderImpl',
    interfaces: [KatydidTableContentBuilder, KatydidAttributesContentBuilderImpl]
  };
  function KatydidTableContentRestrictions() {
    this.captionAllowed_0 = true;
    this.colgroupAllowed_0 = true;
    this.tbodyAllowed_0 = true;
    this.tfootAllowed_0 = true;
    this.theadAllowed_0 = true;
    this.trAllowed_0 = true;
  }
  KatydidTableContentRestrictions.prototype.confirmCaptionAllowed = function () {
    if (!this.captionAllowed_0) {
      var message = 'Element type <caption> not allowed here';
      throw IllegalStateException_init(message.toString());
    }
    this.captionAllowed_0 = false;
  };
  KatydidTableContentRestrictions.prototype.confirmColGroupAllowed = function () {
    if (!this.colgroupAllowed_0) {
      var message = 'Element type <colgroup> not allowed here';
      throw IllegalStateException_init(message.toString());
    }
    this.captionAllowed_0 = false;
  };
  KatydidTableContentRestrictions.prototype.confirmTBodyAllowed = function () {
    if (!this.tbodyAllowed_0) {
      var message = 'Element type <tbody> not allowed here';
      throw IllegalStateException_init(message.toString());
    }
    this.captionAllowed_0 = false;
    this.colgroupAllowed_0 = false;
    this.theadAllowed_0 = false;
    this.trAllowed_0 = false;
  };
  KatydidTableContentRestrictions.prototype.confirmTFootAllowed = function () {
    if (!this.tbodyAllowed_0) {
      var message = 'Element type <tfoot> not allowed here';
      throw IllegalStateException_init(message.toString());
    }
    this.captionAllowed_0 = false;
    this.colgroupAllowed_0 = false;
    this.tbodyAllowed_0 = false;
    this.tfootAllowed_0 = false;
    this.theadAllowed_0 = false;
    this.trAllowed_0 = false;
  };
  KatydidTableContentRestrictions.prototype.confirmTHeadAllowed = function () {
    if (!this.theadAllowed_0) {
      var message = 'Element type <thead> not allowed here';
      throw IllegalStateException_init(message.toString());
    }
    this.captionAllowed_0 = false;
    this.colgroupAllowed_0 = false;
  };
  KatydidTableContentRestrictions.prototype.confirmTrAllowed = function () {
    if (!this.trAllowed_0) {
      var message = 'Element type <tr> not allowed here';
      throw IllegalStateException_init(message.toString());
    }
    this.captionAllowed_0 = false;
    this.colgroupAllowed_0 = false;
    this.tbodyAllowed_0 = false;
    this.theadAllowed_0 = false;
  };
  KatydidTableContentRestrictions.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidTableContentRestrictions',
    interfaces: []
  };
  function KatydidTableRowContentBuilderImpl(itsElement, itsContentRestrictions, itsDispatchMessages) {
    if (itsContentRestrictions === void 0)
      itsContentRestrictions = KatydidContentRestrictions_init();
    KatydidAttributesContentBuilderImpl.call(this, itsElement, itsDispatchMessages);
    this.contentRestrictions = itsContentRestrictions;
  }
  KatydidTableRowContentBuilderImpl.prototype.comment_4w9ihe$$default = function (nodeValue, key) {
    this.element_0.addChildNode_x5x0wf$(new KatydidComment(nodeValue, key));
  };
  KatydidTableRowContentBuilderImpl.prototype.flowContent_bflrjy$ = function (element) {
    return new KatydidFlowContentBuilderImpl(element, this.contentRestrictions, this.dispatchMessages_0);
  };
  KatydidTableRowContentBuilderImpl.prototype.td_iemoux$$default = function (selector, key, accesskey, colspan, contenteditable, dir, draggable, headers, hidden, lang, rowspan, spellcheck, style, tabindex, title, translate, defineContent) {
    this.element_0.addChildNode_x5x0wf$(new KatydidTd(this, selector, key, accesskey, colspan, contenteditable, dir, draggable, headers, hidden, lang, rowspan, spellcheck, style, tabindex, title, translate, defineContent));
  };
  KatydidTableRowContentBuilderImpl.prototype.th_f4d2jq$$default = function (selector, key, abbr, accesskey, colspan, contenteditable, dir, draggable, headers, hidden, lang, rowspan, scope, spellcheck, style, tabindex, title, translate, defineContent) {
    this.element_0.addChildNode_x5x0wf$(new KatydidTh(this, selector, key, abbr, accesskey, colspan, contenteditable, dir, draggable, headers, hidden, lang, rowspan, scope, spellcheck, style, tabindex, title, translate, defineContent));
  };
  KatydidTableRowContentBuilderImpl.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidTableRowContentBuilderImpl',
    interfaces: [KatydidTableRowContentBuilder, KatydidAttributesContentBuilderImpl]
  };
  function KatydidAppPseudoNode() {
    KatydidHtmlElementImpl.call(this, null, null);
    this.nodeName_v13oam$_0 = '!APPLICATION';
  }
  Object.defineProperty(KatydidAppPseudoNode.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_v13oam$_0;
    }
  });
  KatydidAppPseudoNode.prototype.afterAddChildNode_x5x0wf$ = function (childNode) {
    this.freeze_0();
  };
  KatydidAppPseudoNode.prototype.fill_2syken$ = function (dispatchMessages, defineContent) {
    defineContent(new KatydidFlowContentBuilderImpl(this, KatydidContentRestrictions_init(), dispatchMessages));
    if (!this.isConstructed_0) {
      var message = 'Application node should be filled with exactly one child node.';
      throw IllegalArgumentException_init(message.toString());
    }
  };
  KatydidAppPseudoNode.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidAppPseudoNode',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidDel() {
    this.nodeName_w37g33$_0 = 'DEL';
  }
  Object.defineProperty(KatydidDel.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_w37g33$_0;
    }
  });
  KatydidDel.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidDel',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidDel_init(phrasingContent, selector, key, accesskey, cite, contenteditable, datetime, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent, $this) {
    $this = $this || Object.create(KatydidDel.prototype);
    KatydidHtmlElementImpl.call($this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    KatydidDel.call($this);
    $this.setAttribute_jyasbz$('cite', cite);
    $this.setDateTimeAttribute_qhpdwr$('datetime', datetime);
    defineContent(phrasingContent.withNoAddedRestrictions_bflrjy$($this));
    $this.freeze_0();
    return $this;
  }
  function KatydidDel_init_0(flowContent, selector, key, accesskey, cite, contenteditable, datetime, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, contentType, defineContent, $this) {
    $this = $this || Object.create(KatydidDel.prototype);
    KatydidHtmlElementImpl.call($this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    KatydidDel.call($this);
    $this.setAttribute_jyasbz$('cite', cite);
    $this.setDateTimeAttribute_qhpdwr$('datetime', datetime);
    defineContent(flowContent.withNoAddedRestrictions_bflrjy$($this));
    $this.freeze_0();
    return $this;
  }
  function KatydidIns() {
    this.nodeName_w3s9xu$_0 = 'INS';
  }
  Object.defineProperty(KatydidIns.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_w3s9xu$_0;
    }
  });
  KatydidIns.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidIns',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidIns_init(phrasingContent, selector, key, accesskey, cite, contenteditable, datetime, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent, $this) {
    $this = $this || Object.create(KatydidIns.prototype);
    KatydidHtmlElementImpl.call($this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    KatydidIns.call($this);
    $this.setAttribute_jyasbz$('cite', cite);
    $this.setDateTimeAttribute_qhpdwr$('datetime', datetime);
    defineContent(phrasingContent.withNoAddedRestrictions_bflrjy$($this));
    $this.freeze_0();
    return $this;
  }
  function KatydidIns_init_0(flowContent, selector, key, accesskey, cite, contenteditable, datetime, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, contentType, defineContent, $this) {
    $this = $this || Object.create(KatydidIns.prototype);
    KatydidHtmlElementImpl.call($this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    KatydidIns.call($this);
    $this.setAttribute_jyasbz$('cite', cite);
    $this.setDateTimeAttribute_qhpdwr$('datetime', datetime);
    defineContent(flowContent.withNoAddedRestrictions_bflrjy$($this));
    $this.freeze_0();
    return $this;
  }
  function KatydidArea(phrasingContent, selector, key, accesskey, alt, contenteditable, coords, dir, download, draggable, hidden, href, hreflang, lang, referrerpolicy, rel, spellcheck, shape, style, tabindex, target, title, translate, type, defineAttributes) {
    KatydidHtmlElementImpl.call(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    phrasingContent.contentRestrictions.confirmAreaAllowed();
    this.setAttribute_jyasbz$('alt', alt);
    this.setAttribute_jyasbz$('coords', coords);
    this.setAttribute_jyasbz$('download', download);
    this.setAttribute_jyasbz$('href', href);
    this.setAttribute_jyasbz$('hreflang', hreflang);
    this.setAttribute_jyasbz$('referrerpolicy', referrerpolicy != null ? referrerpolicy.toHtmlString() : null);
    this.setAttribute_jyasbz$('rel', rel != null ? rel.toHtmlString() : null);
    this.setAttribute_jyasbz$('shape', shape != null ? shape.toHtmlString() : null);
    this.setAttribute_jyasbz$('target', target);
    this.setAttribute_jyasbz$('type', type);
    defineAttributes(phrasingContent.attributesContent_bflrjy$(this));
    this.freeze_0();
    this.nodeName_30yg5s$_0 = 'AREA';
  }
  Object.defineProperty(KatydidArea.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_30yg5s$_0;
    }
  });
  KatydidArea.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidArea',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidAudio() {
    this.nodeName_dubkkx$_0 = 'AUDIO';
  }
  Object.defineProperty(KatydidAudio.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_dubkkx$_0;
    }
  });
  KatydidAudio.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidAudio',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidAudio_init(embeddedContent, selector, key, accesskey, autoplay, contenteditable, controls, crossorigin, dir, draggable, hidden, lang, loop, muted, preload, spellcheck, src, style, tabindex, title, translate, defineContent, $this) {
    $this = $this || Object.create(KatydidAudio.prototype);
    KatydidHtmlElementImpl.call($this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    KatydidAudio.call($this);
    embeddedContent.contentRestrictions.confirmMediaElementAllowed();
    $this.setBooleanAttribute_h92gdm$('autoplay', autoplay);
    $this.setBooleanAttribute_h92gdm$('controls', controls);
    $this.setAttribute_jyasbz$('crossorigin', crossorigin != null ? crossorigin.toHtmlString() : null);
    $this.setBooleanAttribute_h92gdm$('loop', loop);
    $this.setBooleanAttribute_h92gdm$('muted', muted);
    $this.setAttribute_jyasbz$('preload', preload != null ? preload.toHtmlString() : null);
    $this.setAttribute_jyasbz$('src', src);
    defineContent(embeddedContent.mediaEmbeddedContent_wzqe2t$($this, src == null));
    $this.freeze_0();
    return $this;
  }
  function KatydidAudio_init_0(flowContent, selector, key, accesskey, autoplay, contenteditable, controls, crossorigin, dir, draggable, hidden, lang, loop, muted, preload, spellcheck, src, style, tabindex, title, translate, defineContent, $this) {
    $this = $this || Object.create(KatydidAudio.prototype);
    KatydidHtmlElementImpl.call($this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    KatydidAudio.call($this);
    flowContent.contentRestrictions.confirmMediaElementAllowed();
    $this.setBooleanAttribute_h92gdm$('autoplay', autoplay);
    $this.setBooleanAttribute_h92gdm$('controls', controls);
    $this.setAttribute_jyasbz$('crossorigin', crossorigin != null ? crossorigin.toHtmlString() : null);
    $this.setBooleanAttribute_h92gdm$('loop', loop);
    $this.setBooleanAttribute_h92gdm$('muted', muted);
    $this.setAttribute_jyasbz$('preload', preload != null ? preload.toHtmlString() : null);
    $this.setAttribute_jyasbz$('src', src);
    defineContent(flowContent.mediaFlowContent_wzqe2t$($this, src == null));
    $this.freeze_0();
    return $this;
  }
  function KatydidAudio_init_1(phrasingContent, selector, key, accesskey, autoplay, contenteditable, controls, crossorigin, dir, draggable, hidden, lang, loop, muted, preload, spellcheck, src, style, tabindex, title, translate, defineContent, $this) {
    $this = $this || Object.create(KatydidAudio.prototype);
    KatydidHtmlElementImpl.call($this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    KatydidAudio.call($this);
    phrasingContent.contentRestrictions.confirmMediaElementAllowed();
    $this.setBooleanAttribute_h92gdm$('autoplay', autoplay);
    $this.setBooleanAttribute_h92gdm$('controls', controls);
    $this.setAttribute_jyasbz$('crossorigin', crossorigin != null ? crossorigin.toHtmlString() : null);
    $this.setBooleanAttribute_h92gdm$('loop', loop);
    $this.setBooleanAttribute_h92gdm$('muted', muted);
    $this.setAttribute_jyasbz$('preload', preload != null ? preload.toHtmlString() : null);
    $this.setAttribute_jyasbz$('src', src);
    defineContent(phrasingContent.mediaPhrasingContent_wzqe2t$($this, src == null));
    $this.freeze_0();
    return $this;
  }
  function KatydidEmbed(embeddedContent, selector, key, accesskey, contenteditable, dir, draggable, height, hidden, lang, spellcheck, src, style, tabindex, title, translate, type, width, defineContent) {
    KatydidHtmlElementImpl.call(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    this.setNumberAttribute_hzlfav$('height', height);
    this.setAttribute_jyasbz$('src', src);
    this.setAttribute_jyasbz$('type', type != null ? type.toString() : null);
    this.setNumberAttribute_hzlfav$('width', width);
    defineContent(embeddedContent.textContent_bflrjy$(this));
    this.freeze_0();
    this.nodeName_bb4xmc$_0 = 'EMBED';
  }
  Object.defineProperty(KatydidEmbed.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_bb4xmc$_0;
    }
  });
  KatydidEmbed.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidEmbed',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidIframe(embeddedContent, selector, key, accesskey, allowfullscreen, allowpaymentrequest, contenteditable, dir, draggable, height, hidden, lang, name, referrerpolicy, sandbox, spellcheck, src, srcdoc, style, tabindex, title, translate, width, defineContent) {
    KatydidHtmlElementImpl.call(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    this.setBooleanAttribute_h92gdm$('allowfullscreen', allowfullscreen);
    this.setBooleanAttribute_h92gdm$('allowpaymentrequest', allowpaymentrequest);
    this.setNumberAttribute_hzlfav$('height', height);
    this.setAttribute_jyasbz$('name', name);
    this.setAttribute_jyasbz$('referrerpolicy', referrerpolicy != null ? referrerpolicy.toHtmlString() : null);
    if (sandbox != null) {
      this.setAttribute_jyasbz$('sandbox', joinToString(sandbox, ' ', void 0, void 0, void 0, void 0, KatydidIframe_init$lambda));
    }
    this.setAttribute_jyasbz$('src', src);
    this.setAttribute_jyasbz$('srcdoc', srcdoc);
    this.setNumberAttribute_hzlfav$('width', width);
    defineContent(embeddedContent.textContent_bflrjy$(this));
    this.freeze_0();
    this.nodeName_sycu87$_0 = 'IFRAME';
  }
  Object.defineProperty(KatydidIframe.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_sycu87$_0;
    }
  });
  function KatydidIframe_init$lambda(s) {
    return s.toHtmlString();
  }
  KatydidIframe.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidIframe',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidImg() {
    this.nodeName_g9u$_0 = 'IMG';
  }
  Object.defineProperty(KatydidImg.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_g9u$_0;
    }
  });
  KatydidImg.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidImg',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidImg_init(embeddedContent, selector, key, accesskey, alt, contenteditable, crossorigin, dir, draggable, height, hidden, ismap, lang, referrerpolicy, sizes, spellcheck, src, srcset, style, tabindex, title, translate, usemap, width, defineAttributes, $this) {
    $this = $this || Object.create(KatydidImg.prototype);
    KatydidHtmlElementImpl.call($this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    KatydidImg.call($this);
    $this.setAttribute_jyasbz$('alt', alt);
    $this.setAttribute_jyasbz$('crossorigin', crossorigin != null ? crossorigin.toHtmlString() : null);
    $this.setNumberAttribute_hzlfav$('height', height);
    $this.setBooleanAttribute_h92gdm$('ismap', ismap);
    $this.setAttribute_jyasbz$('referrerpolicy', referrerpolicy != null ? referrerpolicy.toHtmlString() : null);
    $this.setAttribute_jyasbz$('sizes', sizes);
    $this.setAttribute_jyasbz$('src', src);
    $this.setAttribute_jyasbz$('srcset', srcset);
    $this.setAttribute_jyasbz$('usemap', usemap);
    $this.setNumberAttribute_hzlfav$('width', width);
    defineAttributes(embeddedContent.attributesContent_bflrjy$($this));
    $this.freeze_0();
    return $this;
  }
  function KatydidImg_init_0(pictureContent, selector, key, accesskey, alt, contenteditable, crossorigin, dir, draggable, height, hidden, ismap, lang, referrerpolicy, sizes, spellcheck, src, srcset, style, tabindex, title, translate, usemap, width, defineAttributes, $this) {
    $this = $this || Object.create(KatydidImg.prototype);
    KatydidHtmlElementImpl.call($this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    KatydidImg.call($this);
    pictureContent.pictureContentRestrictions.confirmImgAllowedThenDisallow();
    if (src == null) {
      pictureContent.pictureContentRestrictions.confirmSourceElementSeen();
    }
    $this.setAttribute_jyasbz$('alt', alt);
    $this.setAttribute_jyasbz$('crossorigin', crossorigin != null ? crossorigin.toHtmlString() : null);
    $this.setNumberAttribute_hzlfav$('height', height);
    $this.setBooleanAttribute_h92gdm$('ismap', ismap);
    $this.setAttribute_jyasbz$('referrerpolicy', referrerpolicy != null ? referrerpolicy.toHtmlString() : null);
    $this.setAttribute_jyasbz$('sizes', sizes);
    $this.setAttribute_jyasbz$('src', src);
    $this.setAttribute_jyasbz$('srcset', srcset);
    $this.setAttribute_jyasbz$('usemap', usemap);
    $this.setNumberAttribute_hzlfav$('width', width);
    defineAttributes(pictureContent.attributesContent_bflrjy$($this));
    $this.freeze_0();
    return $this;
  }
  function KatydidMap() {
    this.nodeName_sd98g9$_0 = 'MAP';
  }
  Object.defineProperty(KatydidMap.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_sd98g9$_0;
    }
  });
  KatydidMap.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidMap',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidMap_init(phrasingContent, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, name, spellcheck, style, tabindex, title, translate, defineContent, $this) {
    $this = $this || Object.create(KatydidMap.prototype);
    KatydidHtmlElementImpl.call($this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    KatydidMap.call($this);
    $this.setAttribute_jyasbz$('name', name);
    defineContent(phrasingContent.withAreaAllowed_b59t6t$($this));
    $this.freeze_0();
    return $this;
  }
  function KatydidMap_init_0(flowContent, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, name, spellcheck, style, tabindex, title, translate, contentType, defineContent, $this) {
    $this = $this || Object.create(KatydidMap.prototype);
    KatydidHtmlElementImpl.call($this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    KatydidMap.call($this);
    $this.setAttribute_jyasbz$('name', name);
    defineContent(flowContent.withNoAddedRestrictions_bflrjy$($this));
    $this.freeze_0();
    return $this;
  }
  function KatydidObject() {
    this.nodeName_r63uua$_0 = 'OBJECT';
  }
  KatydidObject.prototype.setAttributes_0 = function (data, form, height, name, type, typemustmatch, width) {
    this.setAttribute_jyasbz$('data', data);
    this.setAttribute_jyasbz$('form', form);
    this.setNumberAttribute_hzlfav$('height', height);
    this.setAttribute_jyasbz$('name', name);
    this.setAttribute_jyasbz$('type', type != null ? type.toString() : null);
    this.setBooleanAttribute_h92gdm$('typemustmatch', typemustmatch);
    this.setNumberAttribute_hzlfav$('width', width);
  };
  Object.defineProperty(KatydidObject.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_r63uua$_0;
    }
  });
  KatydidObject.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidObject',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidObject_init(embeddedContent, selector, key, accesskey, contenteditable, data, dir, draggable, form, height, hidden, lang, name, spellcheck, style, tabindex, title, translate, type, typemustmatch, width, defineContent, $this) {
    $this = $this || Object.create(KatydidObject.prototype);
    KatydidHtmlElementImpl.call($this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    KatydidObject.call($this);
    $this.setAttributes_0(data, form, height, name, type, typemustmatch, width);
    defineContent(embeddedContent.objectEmbeddedContent_5czpdc$($this));
    $this.freeze_0();
    return $this;
  }
  function KatydidObject_init_0(flowContent, selector, key, accesskey, contenteditable, data, dir, draggable, form, height, hidden, lang, name, spellcheck, style, tabindex, title, translate, type, typemustmatch, width, defineContent, $this) {
    $this = $this || Object.create(KatydidObject.prototype);
    KatydidHtmlElementImpl.call($this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    KatydidObject.call($this);
    $this.setAttributes_0(data, form, height, name, type, typemustmatch, width);
    defineContent(flowContent.objectFlowContent_5czpdc$($this));
    $this.freeze_0();
    return $this;
  }
  function KatydidObject_init_1(phrasingContent, selector, key, accesskey, contenteditable, data, dir, draggable, form, height, hidden, lang, name, spellcheck, style, tabindex, title, translate, type, typemustmatch, width, defineContent, $this) {
    $this = $this || Object.create(KatydidObject.prototype);
    KatydidHtmlElementImpl.call($this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    KatydidObject.call($this);
    $this.setAttributes_0(data, form, height, name, type, typemustmatch, width);
    defineContent(phrasingContent.objectPhrasingContent_5czpdc$($this));
    $this.freeze_0();
    return $this;
  }
  function KatydidParam() {
    this.nodeName_w94yy0$_0 = 'PARAM';
  }
  KatydidParam.prototype.setAttributes_0 = function (name, value) {
    this.setAttribute_jyasbz$('name', name);
    this.setAttribute_jyasbz$('value', value);
  };
  Object.defineProperty(KatydidParam.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_w94yy0$_0;
    }
  });
  KatydidParam.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidParam',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidParam_init(embeddedContent, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, name, spellcheck, style, tabindex, title, translate, value, defineAttributes, $this) {
    $this = $this || Object.create(KatydidParam.prototype);
    KatydidHtmlElementImpl.call($this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    KatydidParam.call($this);
    $this.setAttributes_0(name, value);
    defineAttributes(embeddedContent.paramAttributesContent_5y5c46$($this));
    $this.freeze_0();
    return $this;
  }
  function KatydidParam_init_0(flowContent, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, name, spellcheck, style, tabindex, title, translate, value, defineAttributes, $this) {
    $this = $this || Object.create(KatydidParam.prototype);
    KatydidHtmlElementImpl.call($this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    KatydidParam.call($this);
    $this.setAttributes_0(name, value);
    defineAttributes(flowContent.paramAttributesContent_5y5c46$($this));
    $this.freeze_0();
    return $this;
  }
  function KatydidParam_init_1(phrasingContent, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, name, spellcheck, style, tabindex, title, translate, value, defineAttributes, $this) {
    $this = $this || Object.create(KatydidParam.prototype);
    KatydidHtmlElementImpl.call($this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    KatydidParam.call($this);
    $this.setAttributes_0(name, value);
    defineAttributes(phrasingContent.paramAttributesContent_5y5c46$($this));
    $this.freeze_0();
    return $this;
  }
  function KatydidPicture(embeddedContent, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    KatydidHtmlElementImpl.call(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    embeddedContent.contentRestrictions.confirmMediaElementAllowed();
    defineContent(embeddedContent.pictureContent_rc0r53$(this));
    this.freeze_0();
    this.nodeName_udu7zb$_0 = 'PICTURE';
  }
  Object.defineProperty(KatydidPicture.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_udu7zb$_0;
    }
  });
  KatydidPicture.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidPicture',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidSource() {
    this.nodeName_v1hao2$_0 = 'SOURCE';
  }
  Object.defineProperty(KatydidSource.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_v1hao2$_0;
    }
  });
  KatydidSource.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidSource',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidSource_init(mediaContent, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, media, sizes, spellcheck, src, srcset, style, tabindex, title, translate, type, defineAttributes, $this) {
    $this = $this || Object.create(KatydidSource.prototype);
    KatydidHtmlElementImpl.call($this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    KatydidSource.call($this);
    mediaContent.mediaContentRestrictions.confirmSourceAllowed();
    $this.setAttribute_jyasbz$('media', media);
    $this.setAttribute_jyasbz$('sizes', sizes);
    $this.setAttribute_jyasbz$('src', src);
    $this.setAttribute_jyasbz$('srcset', srcset);
    $this.setAttribute_jyasbz$('type', type != null ? type.toString() : null);
    defineAttributes(mediaContent.attributesContent_bflrjy$($this));
    $this.freeze_0();
    return $this;
  }
  function KatydidSource_init_0(mediaContent, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, media, sizes, spellcheck, src, srcset, style, tabindex, title, translate, type, defineAttributes, $this) {
    $this = $this || Object.create(KatydidSource.prototype);
    KatydidHtmlElementImpl.call($this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    KatydidSource.call($this);
    mediaContent.mediaContentRestrictions.confirmSourceAllowed();
    $this.setAttribute_jyasbz$('media', media);
    $this.setAttribute_jyasbz$('sizes', sizes);
    $this.setAttribute_jyasbz$('src', src);
    $this.setAttribute_jyasbz$('srcset', srcset);
    $this.setAttribute_jyasbz$('type', type != null ? type.toString() : null);
    defineAttributes(mediaContent.attributesContent_bflrjy$($this));
    $this.freeze_0();
    return $this;
  }
  function KatydidSource_init_1(mediaContent, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, media, sizes, spellcheck, src, srcset, style, tabindex, title, translate, type, defineAttributes, $this) {
    $this = $this || Object.create(KatydidSource.prototype);
    KatydidHtmlElementImpl.call($this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    KatydidSource.call($this);
    mediaContent.mediaContentRestrictions.confirmSourceAllowed();
    $this.setAttribute_jyasbz$('media', media);
    $this.setAttribute_jyasbz$('sizes', sizes);
    $this.setAttribute_jyasbz$('src', src);
    $this.setAttribute_jyasbz$('srcset', srcset);
    $this.setAttribute_jyasbz$('type', type != null ? type.toString() : null);
    defineAttributes(mediaContent.attributesContent_bflrjy$($this));
    $this.freeze_0();
    return $this;
  }
  function KatydidSource_init_2(pictureContent, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, media, sizes, spellcheck, src, srcset, style, tabindex, title, translate, type, defineAttributes, $this) {
    $this = $this || Object.create(KatydidSource.prototype);
    KatydidHtmlElementImpl.call($this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    KatydidSource.call($this);
    pictureContent.pictureContentRestrictions.confirmSourceAllowed();
    $this.setAttribute_jyasbz$('media', media);
    $this.setAttribute_jyasbz$('sizes', sizes);
    $this.setAttribute_jyasbz$('src', src);
    $this.setAttribute_jyasbz$('srcset', srcset);
    $this.setAttribute_jyasbz$('type', type != null ? type.toString() : null);
    defineAttributes(pictureContent.attributesContent_bflrjy$($this));
    $this.freeze_0();
    return $this;
  }
  function KatydidTrack() {
    this.nodeName_60qlzu$_0 = 'TRACK';
  }
  Object.defineProperty(KatydidTrack.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_60qlzu$_0;
    }
  });
  KatydidTrack.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidTrack',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidTrack_init(mediaContent, selector, key, accesskey, contenteditable, default_0, dir, draggable, hidden, kind, label, lang, spellcheck, src, srclang, style, tabindex, title, translate, defineAttributes, $this) {
    $this = $this || Object.create(KatydidTrack.prototype);
    KatydidHtmlElementImpl.call($this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    KatydidTrack.call($this);
    mediaContent.mediaContentRestrictions.confirmTrackAllowed();
    $this.setBooleanAttribute_h92gdm$('default', default_0);
    $this.setAttribute_jyasbz$('kind', kind != null ? kind.toHtmlString() : null);
    $this.setAttribute_jyasbz$('label', label);
    $this.setAttribute_jyasbz$('src', src);
    $this.setAttribute_jyasbz$('srclang', srclang);
    defineAttributes(mediaContent.attributesContent_bflrjy$($this));
    $this.freeze_0();
    return $this;
  }
  function KatydidTrack_init_0(mediaContent, selector, key, accesskey, contenteditable, default_0, dir, draggable, hidden, kind, label, lang, spellcheck, src, srclang, style, tabindex, title, translate, defineAttributes, $this) {
    $this = $this || Object.create(KatydidTrack.prototype);
    KatydidHtmlElementImpl.call($this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    KatydidTrack.call($this);
    mediaContent.mediaContentRestrictions.confirmTrackAllowed();
    $this.setBooleanAttribute_h92gdm$('default', default_0);
    $this.setAttribute_jyasbz$('kind', kind != null ? kind.toHtmlString() : null);
    $this.setAttribute_jyasbz$('label', label);
    $this.setAttribute_jyasbz$('src', src);
    $this.setAttribute_jyasbz$('srclang', srclang);
    defineAttributes(mediaContent.attributesContent_bflrjy$($this));
    $this.freeze_0();
    return $this;
  }
  function KatydidTrack_init_1(mediaContent, selector, key, accesskey, contenteditable, default_0, dir, draggable, hidden, kind, label, lang, spellcheck, src, srclang, style, tabindex, title, translate, defineAttributes, $this) {
    $this = $this || Object.create(KatydidTrack.prototype);
    KatydidHtmlElementImpl.call($this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    KatydidTrack.call($this);
    mediaContent.mediaContentRestrictions.confirmTrackAllowed();
    $this.setBooleanAttribute_h92gdm$('default', default_0);
    $this.setAttribute_jyasbz$('kind', kind != null ? kind.toHtmlString() : null);
    $this.setAttribute_jyasbz$('label', label);
    $this.setAttribute_jyasbz$('src', src);
    $this.setAttribute_jyasbz$('srclang', srclang);
    defineAttributes(mediaContent.attributesContent_bflrjy$($this));
    $this.freeze_0();
    return $this;
  }
  function KatydidVideo() {
    this.nodeName_a2frfu$_0 = 'VIDEO';
  }
  Object.defineProperty(KatydidVideo.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_a2frfu$_0;
    }
  });
  KatydidVideo.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidVideo',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidVideo_init(embeddedContent, selector, key, accesskey, autoplay, contenteditable, controls, crossorigin, dir, draggable, height, hidden, lang, loop, muted, poster, preload, spellcheck, src, style, tabindex, title, translate, width, defineContent, $this) {
    $this = $this || Object.create(KatydidVideo.prototype);
    KatydidHtmlElementImpl.call($this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    KatydidVideo.call($this);
    embeddedContent.contentRestrictions.confirmMediaElementAllowed();
    $this.setBooleanAttribute_h92gdm$('autoplay', autoplay);
    $this.setBooleanAttribute_h92gdm$('controls', controls);
    $this.setAttribute_jyasbz$('crossorigin', crossorigin != null ? crossorigin.toHtmlString() : null);
    $this.setNumberAttribute_hzlfav$('height', height);
    $this.setBooleanAttribute_h92gdm$('loop', loop);
    $this.setBooleanAttribute_h92gdm$('muted', muted);
    $this.setAttribute_jyasbz$('poster', poster);
    $this.setAttribute_jyasbz$('preload', preload != null ? preload.toHtmlString() : null);
    $this.setAttribute_jyasbz$('src', src);
    $this.setNumberAttribute_hzlfav$('width', width);
    defineContent(embeddedContent.mediaEmbeddedContent_wzqe2t$($this, src == null));
    $this.freeze_0();
    return $this;
  }
  function KatydidVideo_init_0(flowContent, selector, key, accesskey, autoplay, contenteditable, controls, crossorigin, dir, draggable, height, hidden, lang, loop, muted, poster, preload, spellcheck, src, style, tabindex, title, translate, width, defineContent, $this) {
    $this = $this || Object.create(KatydidVideo.prototype);
    KatydidHtmlElementImpl.call($this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    KatydidVideo.call($this);
    flowContent.contentRestrictions.confirmMediaElementAllowed();
    $this.setBooleanAttribute_h92gdm$('autoplay', autoplay);
    $this.setBooleanAttribute_h92gdm$('controls', controls);
    $this.setAttribute_jyasbz$('crossorigin', crossorigin != null ? crossorigin.toHtmlString() : null);
    $this.setNumberAttribute_hzlfav$('height', height);
    $this.setBooleanAttribute_h92gdm$('loop', loop);
    $this.setBooleanAttribute_h92gdm$('muted', muted);
    $this.setAttribute_jyasbz$('poster', poster);
    $this.setAttribute_jyasbz$('preload', preload != null ? preload.toHtmlString() : null);
    $this.setAttribute_jyasbz$('src', src);
    $this.setNumberAttribute_hzlfav$('width', width);
    defineContent(flowContent.mediaFlowContent_wzqe2t$($this, src == null));
    $this.freeze_0();
    return $this;
  }
  function KatydidVideo_init_1(phrasingContent, selector, key, accesskey, autoplay, contenteditable, controls, crossorigin, dir, draggable, height, hidden, lang, loop, muted, poster, preload, spellcheck, src, style, tabindex, title, translate, width, defineContent, $this) {
    $this = $this || Object.create(KatydidVideo.prototype);
    KatydidHtmlElementImpl.call($this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    KatydidVideo.call($this);
    phrasingContent.contentRestrictions.confirmMediaElementAllowed();
    $this.setBooleanAttribute_h92gdm$('autoplay', autoplay);
    $this.setBooleanAttribute_h92gdm$('controls', controls);
    $this.setAttribute_jyasbz$('crossorigin', crossorigin != null ? crossorigin.toHtmlString() : null);
    $this.setNumberAttribute_hzlfav$('height', height);
    $this.setBooleanAttribute_h92gdm$('loop', loop);
    $this.setBooleanAttribute_h92gdm$('muted', muted);
    $this.setAttribute_jyasbz$('poster', poster);
    $this.setAttribute_jyasbz$('preload', preload != null ? preload.toHtmlString() : null);
    $this.setAttribute_jyasbz$('src', src);
    $this.setNumberAttribute_hzlfav$('width', width);
    defineContent(phrasingContent.mediaPhrasingContent_wzqe2t$($this, src == null));
    $this.freeze_0();
    return $this;
  }
  function KatydidButton(phrasingContent, selector, key, accesskey, autofocus, contenteditable, dir, disabled, draggable, form, formaction, formenctype, formmethod, formnovalidate, formtarget, hidden, lang, name, spellcheck, style, tabindex, title, translate, type, value, defineContent) {
    KatydidHtmlElementImpl.call(this, selector, key != null ? key : name, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    phrasingContent.contentRestrictions.confirmInteractiveContentAllowed();
    this.setBooleanAttribute_h92gdm$('autofocus', autofocus);
    this.setBooleanAttribute_h92gdm$('disabled', disabled);
    this.setAttribute_jyasbz$('form', form);
    this.setAttribute_jyasbz$('formaction', formaction);
    this.setAttribute_jyasbz$('formenctype', formenctype != null ? formenctype.toHtmlString() : null);
    this.setAttribute_jyasbz$('formmethod', formmethod != null ? formmethod.toHtmlString() : null);
    this.setBooleanAttribute_h92gdm$('formnovalidate', formnovalidate);
    this.setAttribute_jyasbz$('formtarget', formtarget);
    this.setAttribute_jyasbz$('name', name);
    this.setAttribute_jyasbz$('type', type != null ? type.toHtmlString() : null);
    this.setAttribute_jyasbz$('value', value);
    defineContent(phrasingContent.withInteractiveContentNotAllowed_bflrjy$(this));
    this.freeze_0();
    this.nodeName_9ntdwy$_0 = 'BUTTON';
  }
  Object.defineProperty(KatydidButton.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_9ntdwy$_0;
    }
  });
  KatydidButton.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidButton',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidDataList() {
    this.nodeName_lrkons$_0 = 'DATALIST';
  }
  Object.defineProperty(KatydidDataList.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_lrkons$_0;
    }
  });
  KatydidDataList.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidDataList',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidDataList_init(phrasingContent, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent, $this) {
    $this = $this || Object.create(KatydidDataList.prototype);
    KatydidHtmlElementImpl.call($this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    KatydidDataList.call($this);
    defineContent(phrasingContent.optGroupContent_gwhh62$($this));
    $this.freeze_0();
    return $this;
  }
  function KatydidDataList_init_0(phrasingContent, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, contentType, defineContent, $this) {
    $this = $this || Object.create(KatydidDataList.prototype);
    KatydidHtmlElementImpl.call($this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    KatydidDataList.call($this);
    defineContent(phrasingContent.withNoAddedRestrictions_bflrjy$($this));
    $this.freeze_0();
    return $this;
  }
  function KatydidFieldSet(flowContent, selector, key, accesskey, contenteditable, dir, disabled, draggable, form, hidden, lang, name, spellcheck, style, tabindex, title, translate, defineContent) {
    KatydidHtmlElementImpl.call(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    this.setBooleanAttribute_h92gdm$('disabled', disabled);
    this.setAttribute_jyasbz$('form', form);
    this.setAttribute_jyasbz$('name', name);
    defineContent(flowContent.withLegendAllowed_bflrjy$(this));
    this.freeze_0();
    this.nodeName_orzg3c$_0 = 'FIELDSET';
  }
  Object.defineProperty(KatydidFieldSet.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_orzg3c$_0;
    }
  });
  KatydidFieldSet.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidFieldSet',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidForm(flowContent, selector, key, acceptCharset, accesskey, action, autocomplete, contenteditable, dir, draggable, enctype, hidden, lang, method, name, novalidate, spellcheck, style, tabindex, target, title, translate, defineContent) {
    KatydidHtmlElementImpl.call(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    flowContent.contentRestrictions.confirmFormAllowed();
    this.setAttribute_jyasbz$('accept-charset', acceptCharset);
    this.setAttribute_jyasbz$('action', action);
    this.setAttribute_jyasbz$('autocomplete', autocomplete);
    this.setAttribute_jyasbz$('enctype', enctype != null ? enctype.toHtmlString() : null);
    this.setAttribute_jyasbz$('method', method != null ? method.toHtmlString() : null);
    this.setAttribute_jyasbz$('name', name);
    this.setBooleanAttribute_h92gdm$('novalidate', novalidate);
    this.setAttribute_jyasbz$('target', target);
    defineContent(flowContent.withFormNotAllowed_bflrjy$(this));
    this.freeze_0();
    this.nodeName_jnzu2k$_0 = 'FORM';
  }
  Object.defineProperty(KatydidForm.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_jnzu2k$_0;
    }
  });
  KatydidForm.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidForm',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidInputButton(phrasingContent, selector, key, accesskey, contenteditable, dir, disabled, draggable, form, hidden, lang, name, spellcheck, style, tabindex, title, translate, value, defineAttributes) {
    KatydidHtmlElementImpl.call(this, selector, key != null ? key : name, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    phrasingContent.contentRestrictions.confirmInteractiveContentAllowed();
    this.setBooleanAttribute_h92gdm$('disabled', disabled);
    this.setAttribute_jyasbz$('form', form);
    this.setAttribute_jyasbz$('name', name);
    this.setAttribute_jyasbz$('value', value);
    this.setAttribute_jyasbz$('type', 'button');
    defineAttributes(phrasingContent.attributesContent_bflrjy$(this));
    this.freeze_0();
    this.nodeName_vhfqkm$_0 = 'INPUT';
  }
  Object.defineProperty(KatydidInputButton.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_vhfqkm$_0;
    }
  });
  KatydidInputButton.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidInputButton',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidInputCheckbox(phrasingContent, selector, key, accesskey, autofocus, checked, contenteditable, dir, disabled, draggable, form, hidden, lang, name, required, spellcheck, style, tabindex, title, translate, value, defineAttributes) {
    KatydidHtmlElementImpl.call(this, selector, key != null ? key : name, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    phrasingContent.contentRestrictions.confirmInteractiveContentAllowed();
    this.setBooleanAttribute_h92gdm$('autofocus', autofocus);
    this.setBooleanAttribute_h92gdm$('checked', checked);
    this.setBooleanAttribute_h92gdm$('disabled', disabled);
    this.setAttribute_jyasbz$('form', form);
    this.setAttribute_jyasbz$('name', name);
    this.setBooleanAttribute_h92gdm$('required', required);
    this.setAttribute_jyasbz$('value', value);
    this.setAttribute_jyasbz$('type', 'checkbox');
    defineAttributes(phrasingContent.attributesContent_bflrjy$(this));
    this.freeze_0();
    this.nodeName_1r5fed$_0 = 'INPUT';
  }
  Object.defineProperty(KatydidInputCheckbox.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_1r5fed$_0;
    }
  });
  KatydidInputCheckbox.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidInputCheckbox',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidInputColor(phrasingContent, selector, key, accesskey, autocomplete, autofocus, contenteditable, dir, disabled, draggable, form, hidden, lang, list, name, spellcheck, style, tabindex, title, translate, value, defineAttributes) {
    KatydidHtmlElementImpl.call(this, selector, key != null ? key : name, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    phrasingContent.contentRestrictions.confirmInteractiveContentAllowed();
    this.setAttribute_jyasbz$('autocomplete', autocomplete);
    this.setBooleanAttribute_h92gdm$('autofocus', autofocus);
    this.setBooleanAttribute_h92gdm$('disabled', disabled);
    this.setAttribute_jyasbz$('form', form);
    this.setAttribute_jyasbz$('list', list);
    this.setAttribute_jyasbz$('name', name);
    this.setAttribute_jyasbz$('value', value);
    this.setAttribute_jyasbz$('type', 'color');
    defineAttributes(phrasingContent.attributesContent_bflrjy$(this));
    this.freeze_0();
    this.nodeName_mac0l5$_0 = 'INPUT';
  }
  Object.defineProperty(KatydidInputColor.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_mac0l5$_0;
    }
  });
  KatydidInputColor.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidInputColor',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidInputDate(phrasingContent, selector, key, accesskey, autocomplete, autofocus, contenteditable, dir, disabled, draggable, form, hidden, lang, list, max, min, name, readonly, required, spellcheck, step, style, tabindex, title, translate, value, defineAttributes) {
    KatydidHtmlElementImpl.call(this, selector, key != null ? key : name, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    phrasingContent.contentRestrictions.confirmInteractiveContentAllowed();
    this.setAttribute_jyasbz$('autocomplete', autocomplete);
    this.setBooleanAttribute_h92gdm$('autofocus', autofocus);
    this.setBooleanAttribute_h92gdm$('disabled', disabled);
    this.setAttribute_jyasbz$('form', form);
    this.setAttribute_jyasbz$('list', list);
    this.setAttribute_jyasbz$('max', max);
    this.setAttribute_jyasbz$('min', min);
    this.setAttribute_jyasbz$('name', name);
    this.setBooleanAttribute_h92gdm$('readonly', readonly);
    this.setBooleanAttribute_h92gdm$('required', required);
    this.setAttribute_jyasbz$('step', step);
    this.setAttribute_jyasbz$('value', value);
    this.setAttribute_jyasbz$('type', 'date');
    defineAttributes(phrasingContent.attributesContent_bflrjy$(this));
    this.freeze_0();
    this.nodeName_geny46$_0 = 'INPUT';
  }
  Object.defineProperty(KatydidInputDate.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_geny46$_0;
    }
  });
  KatydidInputDate.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidInputDate',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidInputDateTimeLocal(phrasingContent, selector, key, accesskey, autocomplete, autofocus, contenteditable, dir, disabled, draggable, form, hidden, lang, list, max, min, name, readonly, required, spellcheck, step, style, tabindex, title, translate, value, defineAttributes) {
    KatydidHtmlElementImpl.call(this, selector, key != null ? key : name, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    phrasingContent.contentRestrictions.confirmInteractiveContentAllowed();
    this.setAttribute_jyasbz$('autocomplete', autocomplete);
    this.setBooleanAttribute_h92gdm$('autofocus', autofocus);
    this.setBooleanAttribute_h92gdm$('disabled', disabled);
    this.setAttribute_jyasbz$('form', form);
    this.setAttribute_jyasbz$('list', list);
    this.setAttribute_jyasbz$('max', max);
    this.setAttribute_jyasbz$('min', min);
    this.setAttribute_jyasbz$('name', name);
    this.setBooleanAttribute_h92gdm$('readonly', readonly);
    this.setBooleanAttribute_h92gdm$('required', required);
    this.setAttribute_jyasbz$('step', step);
    this.setAttribute_jyasbz$('value', value);
    this.setAttribute_jyasbz$('type', 'datetime-local');
    defineAttributes(phrasingContent.attributesContent_bflrjy$(this));
    this.freeze_0();
    this.nodeName_ip5pne$_0 = 'INPUT';
  }
  Object.defineProperty(KatydidInputDateTimeLocal.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_ip5pne$_0;
    }
  });
  KatydidInputDateTimeLocal.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidInputDateTimeLocal',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidInputEmail(phrasingContent, selector, key, accesskey, autocomplete, autofocus, contenteditable, dir, disabled, draggable, form, hidden, lang, list, maxlength, minlength, multiple, name, pattern, placeholder, readonly, required, size, spellcheck, style, tabindex, title, translate, value, defineAttributes) {
    KatydidHtmlElementImpl.call(this, selector, key != null ? key : name, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    phrasingContent.contentRestrictions.confirmInteractiveContentAllowed();
    if (!(maxlength == null || maxlength >= 0)) {
      var message = 'Attribute maxlength must be non-negative.';
      throw IllegalArgumentException_init(message.toString());
    }
    if (!(minlength == null || minlength >= 0)) {
      var message_0 = 'Attribute minlength must be non-negative.';
      throw IllegalArgumentException_init(message_0.toString());
    }
    if (!(size == null || size >= 0)) {
      var message_1 = 'Attribute size must be non-negative.';
      throw IllegalArgumentException_init(message_1.toString());
    }
    this.setAttribute_jyasbz$('autocomplete', autocomplete);
    this.setBooleanAttribute_h92gdm$('autofocus', autofocus);
    this.setBooleanAttribute_h92gdm$('disabled', disabled);
    this.setAttribute_jyasbz$('form', form);
    this.setAttribute_jyasbz$('list', list);
    this.setNumberAttribute_hzlfav$('maxlength', maxlength);
    this.setNumberAttribute_hzlfav$('minlength', minlength);
    this.setBooleanAttribute_h92gdm$('multiple', multiple);
    this.setAttribute_jyasbz$('name', name);
    this.setAttribute_jyasbz$('pattern', pattern);
    this.setAttribute_jyasbz$('placeholder', placeholder);
    this.setBooleanAttribute_h92gdm$('readonly', readonly);
    this.setBooleanAttribute_h92gdm$('required', required);
    this.setNumberAttribute_hzlfav$('size', size);
    this.setAttribute_jyasbz$('value', value);
    this.setAttribute_jyasbz$('type', 'email');
    defineAttributes(phrasingContent.attributesContent_bflrjy$(this));
    this.freeze_0();
    this.nodeName_nmk1yq$_0 = 'INPUT';
  }
  Object.defineProperty(KatydidInputEmail.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_nmk1yq$_0;
    }
  });
  KatydidInputEmail.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidInputEmail',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidInputFile(phrasingContent, selector, key, accept, accesskey, autofocus, contenteditable, dir, disabled, draggable, form, hidden, lang, multiple, name, required, spellcheck, style, tabindex, title, translate, value, defineAttributes) {
    KatydidHtmlElementImpl.call(this, selector, key != null ? key : name, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    phrasingContent.contentRestrictions.confirmInteractiveContentAllowed();
    this.setAttribute_jyasbz$('accept', accept);
    this.setBooleanAttribute_h92gdm$('autofocus', autofocus);
    this.setBooleanAttribute_h92gdm$('disabled', disabled);
    this.setAttribute_jyasbz$('form', form);
    this.setBooleanAttribute_h92gdm$('multiple', multiple);
    this.setAttribute_jyasbz$('name', name);
    this.setBooleanAttribute_h92gdm$('required', required);
    this.setAttribute_jyasbz$('value', value);
    this.setAttribute_jyasbz$('type', 'file');
    defineAttributes(phrasingContent.attributesContent_bflrjy$(this));
    this.freeze_0();
    this.nodeName_ethkg4$_0 = 'INPUT';
  }
  Object.defineProperty(KatydidInputFile.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_ethkg4$_0;
    }
  });
  KatydidInputFile.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidInputFile',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidInputHidden(phrasingContent, selector, key, accesskey, contenteditable, dir, disabled, draggable, form, hidden, lang, name, spellcheck, style, tabindex, title, translate, value, defineAttributes) {
    KatydidHtmlElementImpl.call(this, selector, key != null ? key : name, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    this.setBooleanAttribute_h92gdm$('disabled', disabled);
    this.setAttribute_jyasbz$('form', form);
    this.setAttribute_jyasbz$('name', name);
    this.setAttribute_jyasbz$('value', value);
    this.setAttribute_jyasbz$('type', 'hidden');
    defineAttributes(phrasingContent.attributesContent_bflrjy$(this));
    this.freeze_0();
    this.nodeName_lttxde$_0 = 'INPUT';
  }
  Object.defineProperty(KatydidInputHidden.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_lttxde$_0;
    }
  });
  KatydidInputHidden.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidInputHidden',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidInputImageButton(phrasingContent, selector, key, accesskey, alt, contenteditable, dir, disabled, draggable, form, formaction, formenctype, formmethod, formnovalidate, formtarget, height, hidden, lang, name, spellcheck, src, style, tabindex, title, translate, width, defineAttributes) {
    KatydidHtmlElementImpl.call(this, selector, key != null ? key : name, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    phrasingContent.contentRestrictions.confirmInteractiveContentAllowed();
    this.setAttribute_jyasbz$('alt', alt);
    this.setBooleanAttribute_h92gdm$('disabled', disabled);
    this.setAttribute_jyasbz$('form', form);
    this.setAttribute_jyasbz$('formaction', formaction);
    this.setAttribute_jyasbz$('formenctype', formenctype != null ? formenctype.toHtmlString() : null);
    this.setAttribute_jyasbz$('formmethod', formmethod != null ? formmethod.toHtmlString() : null);
    this.setBooleanAttribute_h92gdm$('formnovalidate', formnovalidate);
    this.setAttribute_jyasbz$('formtarget', formtarget);
    this.setNumberAttribute_hzlfav$('height', height);
    this.setAttribute_jyasbz$('name', name);
    this.setAttribute_jyasbz$('src', src);
    this.setNumberAttribute_hzlfav$('width', width);
    this.setAttribute_jyasbz$('type', 'image');
    defineAttributes(phrasingContent.attributesContent_bflrjy$(this));
    this.freeze_0();
    this.nodeName_hxoekd$_0 = 'INPUT';
  }
  Object.defineProperty(KatydidInputImageButton.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_hxoekd$_0;
    }
  });
  KatydidInputImageButton.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidInputImageButton',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidInputMonth(phrasingContent, selector, key, accesskey, autocomplete, autofocus, contenteditable, dir, disabled, draggable, form, hidden, lang, list, max, min, name, readonly, required, spellcheck, step, style, tabindex, title, translate, value, defineAttributes) {
    KatydidHtmlElementImpl.call(this, selector, key != null ? key : name, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    phrasingContent.contentRestrictions.confirmInteractiveContentAllowed();
    this.setAttribute_jyasbz$('autocomplete', autocomplete);
    this.setBooleanAttribute_h92gdm$('autofocus', autofocus);
    this.setBooleanAttribute_h92gdm$('disabled', disabled);
    this.setAttribute_jyasbz$('form', form);
    this.setAttribute_jyasbz$('list', list);
    this.setAttribute_jyasbz$('max', max);
    this.setAttribute_jyasbz$('min', min);
    this.setAttribute_jyasbz$('name', name);
    this.setBooleanAttribute_h92gdm$('readonly', readonly);
    this.setBooleanAttribute_h92gdm$('required', required);
    this.setAttribute_jyasbz$('step', step);
    this.setAttribute_jyasbz$('value', value);
    this.setAttribute_jyasbz$('type', 'month');
    defineAttributes(phrasingContent.attributesContent_bflrjy$(this));
    this.freeze_0();
    this.nodeName_1ihgba$_0 = 'INPUT';
  }
  Object.defineProperty(KatydidInputMonth.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_1ihgba$_0;
    }
  });
  KatydidInputMonth.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidInputMonth',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidInputNumber() {
    this.nodeName_ewmcr5$_0 = 'INPUT';
  }
  Object.defineProperty(KatydidInputNumber.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_ewmcr5$_0;
    }
  });
  KatydidInputNumber.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidInputNumber',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidInputNumber_init(phrasingContent, selector, key, accesskey, autocomplete, autofocus, contenteditable, dir, disabled, draggable, form, hidden, lang, list, max, min, name, placeholder, readonly, required, spellcheck, step, style, tabindex, title, translate, value, defineAttributes, $this) {
    $this = $this || Object.create(KatydidInputNumber.prototype);
    KatydidHtmlElementImpl.call($this, selector, key != null ? key : name, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    KatydidInputNumber.call($this);
    phrasingContent.contentRestrictions.confirmInteractiveContentAllowed();
    if (min != null && max != null) {
      if (!(min <= max)) {
        var message = Unit;
        throw IllegalArgumentException_init(message.toString());
      }
    }
    $this.setAttribute_jyasbz$('autocomplete', autocomplete);
    $this.setBooleanAttribute_h92gdm$('autofocus', autofocus);
    $this.setBooleanAttribute_h92gdm$('disabled', disabled);
    $this.setAttribute_jyasbz$('form', form);
    $this.setAttribute_jyasbz$('list', list);
    $this.setNumberAttribute_hzlfav$('max', max);
    $this.setNumberAttribute_hzlfav$('min', min);
    $this.setAttribute_jyasbz$('name', name);
    $this.setAttribute_jyasbz$('placeholder', placeholder);
    $this.setBooleanAttribute_h92gdm$('readonly', readonly);
    $this.setBooleanAttribute_h92gdm$('required', required);
    $this.setNumberAttribute_hzlfav$('step', step);
    $this.setNumberAttribute_hzlfav$('value', value);
    $this.setAttribute_jyasbz$('type', 'number');
    defineAttributes(phrasingContent.attributesContent_bflrjy$($this));
    $this.freeze_0();
    return $this;
  }
  function KatydidInputNumber_init_0(phrasingContent, selector, key, accesskey, autocomplete, autofocus, contenteditable, dir, disabled, draggable, form, hidden, lang, list, max, min, name, placeholder, readonly, required, spellcheck, step, style, tabindex, title, translate, value, defineAttributes, $this) {
    $this = $this || Object.create(KatydidInputNumber.prototype);
    KatydidHtmlElementImpl.call($this, selector, key != null ? key : name, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    KatydidInputNumber.call($this);
    phrasingContent.contentRestrictions.confirmInteractiveContentAllowed();
    if (min != null && max != null) {
      if (!(min <= max)) {
        var message = Unit;
        throw IllegalArgumentException_init(message.toString());
      }
    }
    $this.setAttribute_jyasbz$('autocomplete', autocomplete);
    $this.setBooleanAttribute_h92gdm$('autofocus', autofocus);
    $this.setBooleanAttribute_h92gdm$('disabled', disabled);
    $this.setAttribute_jyasbz$('form', form);
    $this.setAttribute_jyasbz$('list', list);
    $this.setNumberAttribute_hzlfav$('max', max);
    $this.setNumberAttribute_hzlfav$('min', min);
    $this.setAttribute_jyasbz$('name', name);
    $this.setAttribute_jyasbz$('placeholder', placeholder);
    $this.setBooleanAttribute_h92gdm$('readonly', readonly);
    $this.setBooleanAttribute_h92gdm$('required', required);
    $this.setNumberAttribute_hzlfav$('step', step);
    $this.setNumberAttribute_hzlfav$('value', value);
    $this.setAttribute_jyasbz$('type', 'number');
    defineAttributes(phrasingContent.attributesContent_bflrjy$($this));
    $this.freeze_0();
    return $this;
  }
  function KatydidInputPassword(phrasingContent, selector, key, accesskey, autocomplete, autofocus, contenteditable, dir, disabled, draggable, form, hidden, lang, maxlength, minlength, name, pattern, placeholder, readonly, required, size, spellcheck, style, tabindex, title, translate, value, defineAttributes) {
    KatydidHtmlElementImpl.call(this, selector, key != null ? key : name, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    phrasingContent.contentRestrictions.confirmInteractiveContentAllowed();
    if (!(maxlength == null || maxlength >= 0)) {
      var message = 'Attribute maxlength must be non-negative.';
      throw IllegalArgumentException_init(message.toString());
    }
    if (!(minlength == null || minlength >= 0)) {
      var message_0 = 'Attribute minlength must be non-negative.';
      throw IllegalArgumentException_init(message_0.toString());
    }
    if (!(size == null || size >= 0)) {
      var message_1 = 'Attribute size must be non-negative.';
      throw IllegalArgumentException_init(message_1.toString());
    }
    this.setAttribute_jyasbz$('autocomplete', autocomplete);
    this.setBooleanAttribute_h92gdm$('autofocus', autofocus);
    this.setBooleanAttribute_h92gdm$('disabled', disabled);
    this.setAttribute_jyasbz$('form', form);
    this.setNumberAttribute_hzlfav$('maxlength', maxlength);
    this.setNumberAttribute_hzlfav$('minlength', minlength);
    this.setAttribute_jyasbz$('name', name);
    this.setAttribute_jyasbz$('pattern', pattern);
    this.setAttribute_jyasbz$('placeholder', placeholder);
    this.setBooleanAttribute_h92gdm$('readonly', readonly);
    this.setBooleanAttribute_h92gdm$('required', required);
    this.setNumberAttribute_hzlfav$('size', size);
    this.setAttribute_jyasbz$('value', value);
    this.setAttribute_jyasbz$('type', 'password');
    defineAttributes(phrasingContent.attributesContent_bflrjy$(this));
    this.freeze_0();
    this.nodeName_9vmvdp$_0 = 'INPUT';
  }
  Object.defineProperty(KatydidInputPassword.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_9vmvdp$_0;
    }
  });
  KatydidInputPassword.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidInputPassword',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidInputRadioButton(phrasingContent, selector, key, accesskey, autofocus, checked, contenteditable, dir, disabled, draggable, form, hidden, lang, name, required, spellcheck, style, tabindex, title, translate, value, defineAttributes) {
    KatydidHtmlElementImpl.call(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    phrasingContent.contentRestrictions.confirmInteractiveContentAllowed();
    this.setBooleanAttribute_h92gdm$('autofocus', autofocus);
    this.setBooleanAttribute_h92gdm$('checked', checked);
    this.setBooleanAttribute_h92gdm$('disabled', disabled);
    this.setAttribute_jyasbz$('form', form);
    this.setAttribute_jyasbz$('name', name);
    this.setBooleanAttribute_h92gdm$('required', required);
    this.setAttribute_jyasbz$('value', value);
    this.setAttribute_jyasbz$('type', 'radio');
    defineAttributes(phrasingContent.attributesContent_bflrjy$(this));
    this.freeze_0();
    this.nodeName_uhzg83$_0 = 'INPUT';
  }
  Object.defineProperty(KatydidInputRadioButton.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_uhzg83$_0;
    }
  });
  KatydidInputRadioButton.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidInputRadioButton',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidInputRange(phrasingContent, selector, key, accesskey, autocomplete, autofocus, contenteditable, dir, disabled, draggable, form, hidden, lang, list, max, min, name, spellcheck, step, style, tabindex, title, translate, value, defineAttributes) {
    KatydidHtmlElementImpl.call(this, selector, key != null ? key : name, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    phrasingContent.contentRestrictions.confirmInteractiveContentAllowed();
    this.setAttribute_jyasbz$('autocomplete', autocomplete);
    this.setBooleanAttribute_h92gdm$('autofocus', autofocus);
    this.setBooleanAttribute_h92gdm$('disabled', disabled);
    this.setAttribute_jyasbz$('form', form);
    this.setAttribute_jyasbz$('list', list);
    this.setNumberAttribute_hzlfav$('max', max);
    this.setNumberAttribute_hzlfav$('min', min);
    this.setAttribute_jyasbz$('name', name);
    this.setAttribute_jyasbz$('step', step);
    this.setNumberAttribute_hzlfav$('value', value);
    this.setAttribute_jyasbz$('type', 'range');
    defineAttributes(phrasingContent.attributesContent_bflrjy$(this));
    this.freeze_0();
    this.nodeName_ki9kcz$_0 = 'INPUT';
  }
  Object.defineProperty(KatydidInputRange.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_ki9kcz$_0;
    }
  });
  KatydidInputRange.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidInputRange',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidInputResetButton(phrasingContent, selector, key, accesskey, contenteditable, dir, disabled, draggable, form, hidden, lang, name, spellcheck, style, tabindex, title, translate, value, defineAttributes) {
    KatydidHtmlElementImpl.call(this, selector, key != null ? key : name, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    phrasingContent.contentRestrictions.confirmInteractiveContentAllowed();
    this.setBooleanAttribute_h92gdm$('disabled', disabled);
    this.setAttribute_jyasbz$('form', form);
    this.setAttribute_jyasbz$('name', name);
    this.setAttribute_jyasbz$('value', value);
    this.setAttribute_jyasbz$('type', 'reset');
    defineAttributes(phrasingContent.attributesContent_bflrjy$(this));
    this.freeze_0();
    this.nodeName_s64kw9$_0 = 'INPUT';
  }
  Object.defineProperty(KatydidInputResetButton.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_s64kw9$_0;
    }
  });
  KatydidInputResetButton.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidInputResetButton',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidInputSearch(phrasingContent, selector, key, accesskey, autocomplete, autofocus, contenteditable, dir, dirname, disabled, draggable, form, hidden, lang, list, maxlength, minlength, name, pattern, placeholder, readonly, required, size, spellcheck, style, tabindex, title, translate, value, defineAttributes) {
    KatydidHtmlElementImpl.call(this, selector, key != null ? key : name, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    phrasingContent.contentRestrictions.confirmInteractiveContentAllowed();
    if (!(maxlength == null || maxlength >= 0)) {
      var message = 'Attribute maxlength must be non-negative.';
      throw IllegalArgumentException_init(message.toString());
    }
    if (!(minlength == null || minlength >= 0)) {
      var message_0 = 'Attribute minlength must be non-negative.';
      throw IllegalArgumentException_init(message_0.toString());
    }
    if (!(size == null || size >= 0)) {
      var message_1 = 'Attribute size must be non-negative.';
      throw IllegalArgumentException_init(message_1.toString());
    }
    this.setAttribute_jyasbz$('autocomplete', autocomplete);
    this.setBooleanAttribute_h92gdm$('autofocus', autofocus);
    this.setAttribute_jyasbz$('dirname', dirname);
    this.setBooleanAttribute_h92gdm$('disabled', disabled);
    this.setAttribute_jyasbz$('form', form);
    this.setAttribute_jyasbz$('list', list);
    this.setNumberAttribute_hzlfav$('maxlength', maxlength);
    this.setNumberAttribute_hzlfav$('minlength', minlength);
    this.setAttribute_jyasbz$('name', name);
    this.setAttribute_jyasbz$('pattern', pattern);
    this.setAttribute_jyasbz$('placeholder', placeholder);
    this.setBooleanAttribute_h92gdm$('readonly', readonly);
    this.setBooleanAttribute_h92gdm$('required', required);
    this.setNumberAttribute_hzlfav$('size', size);
    this.setAttribute_jyasbz$('value', value);
    this.setAttribute_jyasbz$('type', 'search');
    defineAttributes(phrasingContent.attributesContent_bflrjy$(this));
    this.freeze_0();
    this.nodeName_vg0n8w$_0 = 'INPUT';
  }
  Object.defineProperty(KatydidInputSearch.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_vg0n8w$_0;
    }
  });
  KatydidInputSearch.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidInputSearch',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidInputSubmitButton(phrasingContent, selector, key, accesskey, contenteditable, dir, disabled, draggable, form, formaction, formenctype, formmethod, formnovalidate, formtarget, hidden, lang, name, spellcheck, style, tabindex, title, translate, value, defineAttributes) {
    KatydidHtmlElementImpl.call(this, selector, key != null ? key : name, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    phrasingContent.contentRestrictions.confirmInteractiveContentAllowed();
    this.setBooleanAttribute_h92gdm$('disabled', disabled);
    this.setAttribute_jyasbz$('form', form);
    this.setAttribute_jyasbz$('formaction', formaction);
    this.setAttribute_jyasbz$('formenctype', formenctype != null ? formenctype.toHtmlString() : null);
    this.setAttribute_jyasbz$('formmethod', formmethod != null ? formmethod.toHtmlString() : null);
    this.setBooleanAttribute_h92gdm$('formnovalidate', formnovalidate);
    this.setAttribute_jyasbz$('formtarget', formtarget);
    this.setAttribute_jyasbz$('name', name);
    this.setAttribute_jyasbz$('value', value);
    this.setAttribute_jyasbz$('type', 'submit');
    defineAttributes(phrasingContent.attributesContent_bflrjy$(this));
    this.freeze_0();
    this.nodeName_w4hhrm$_0 = 'INPUT';
  }
  Object.defineProperty(KatydidInputSubmitButton.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_w4hhrm$_0;
    }
  });
  KatydidInputSubmitButton.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidInputSubmitButton',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidInputTelephone(phrasingContent, selector, key, accesskey, autocomplete, autofocus, contenteditable, dir, disabled, draggable, form, hidden, lang, list, maxlength, minlength, name, pattern, placeholder, readonly, required, size, spellcheck, style, tabindex, title, translate, value, defineAttributes) {
    KatydidHtmlElementImpl.call(this, selector, key != null ? key : name, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    phrasingContent.contentRestrictions.confirmInteractiveContentAllowed();
    if (!(maxlength == null || maxlength >= 0)) {
      var message = 'Attribute maxlength must be non-negative.';
      throw IllegalArgumentException_init(message.toString());
    }
    if (!(minlength == null || minlength >= 0)) {
      var message_0 = 'Attribute minlength must be non-negative.';
      throw IllegalArgumentException_init(message_0.toString());
    }
    if (!(size == null || size >= 0)) {
      var message_1 = 'Attribute size must be non-negative.';
      throw IllegalArgumentException_init(message_1.toString());
    }
    this.setAttribute_jyasbz$('autocomplete', autocomplete);
    this.setBooleanAttribute_h92gdm$('autofocus', autofocus);
    this.setBooleanAttribute_h92gdm$('disabled', disabled);
    this.setAttribute_jyasbz$('form', form);
    this.setAttribute_jyasbz$('list', list);
    this.setNumberAttribute_hzlfav$('maxlength', maxlength);
    this.setNumberAttribute_hzlfav$('minlength', minlength);
    this.setAttribute_jyasbz$('name', name);
    this.setAttribute_jyasbz$('pattern', pattern);
    this.setAttribute_jyasbz$('placeholder', placeholder);
    this.setBooleanAttribute_h92gdm$('readonly', readonly);
    this.setBooleanAttribute_h92gdm$('required', required);
    this.setNumberAttribute_hzlfav$('size', size);
    this.setAttribute_jyasbz$('value', value);
    this.setAttribute_jyasbz$('type', 'tel');
    defineAttributes(phrasingContent.attributesContent_bflrjy$(this));
    this.freeze_0();
    this.nodeName_3fy8re$_0 = 'INPUT';
  }
  Object.defineProperty(KatydidInputTelephone.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_3fy8re$_0;
    }
  });
  KatydidInputTelephone.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidInputTelephone',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidInputText(phrasingContent, selector, key, accesskey, autocomplete, autofocus, contenteditable, dir, dirname, disabled, draggable, form, hidden, lang, list, maxlength, minlength, name, pattern, placeholder, readonly, required, size, spellcheck, style, tabindex, title, translate, value, defineAttributes) {
    KatydidHtmlElementImpl.call(this, selector, key != null ? key : name, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    phrasingContent.contentRestrictions.confirmInteractiveContentAllowed();
    if (!(maxlength == null || maxlength >= 0)) {
      var message = 'Input attribute maxlength must be non-negative.';
      throw IllegalArgumentException_init(message.toString());
    }
    if (!(minlength == null || minlength >= 0)) {
      var message_0 = 'Input attribute minlength must be non-negative.';
      throw IllegalArgumentException_init(message_0.toString());
    }
    if (!(minlength == null || maxlength == null || minlength <= maxlength)) {
      var message_1 = 'Input attribute minlength must be less than maxlength.';
      throw IllegalArgumentException_init(message_1.toString());
    }
    if (!(size == null || size > 0)) {
      var message_2 = 'Input attribute size must greater than zero.';
      throw IllegalArgumentException_init(message_2.toString());
    }
    this.setAttribute_jyasbz$('autocomplete', autocomplete);
    this.setBooleanAttribute_h92gdm$('autofocus', autofocus);
    this.setAttribute_jyasbz$('dirname', dirname);
    this.setBooleanAttribute_h92gdm$('disabled', disabled);
    this.setAttribute_jyasbz$('form', form);
    this.setAttribute_jyasbz$('list', list);
    this.setNumberAttribute_hzlfav$('maxlength', maxlength);
    this.setNumberAttribute_hzlfav$('minlength', minlength);
    this.setAttribute_jyasbz$('name', name);
    this.setAttribute_jyasbz$('pattern', pattern);
    this.setAttribute_jyasbz$('placeholder', placeholder);
    this.setBooleanAttribute_h92gdm$('readonly', readonly);
    this.setBooleanAttribute_h92gdm$('required', required);
    this.setNumberAttribute_hzlfav$('size', size);
    this.setAttribute_jyasbz$('value', value);
    this.setAttribute_jyasbz$('type', 'text');
    defineAttributes(phrasingContent.attributesContent_bflrjy$(this));
    this.freeze_0();
    this.nodeName_5rl03v$_0 = 'INPUT';
  }
  Object.defineProperty(KatydidInputText.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_5rl03v$_0;
    }
  });
  KatydidInputText.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidInputText',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidInputTime(phrasingContent, selector, key, accesskey, autocomplete, autofocus, contenteditable, dir, disabled, draggable, form, hidden, lang, list, max, min, name, readonly, required, spellcheck, step, style, tabindex, title, translate, value, defineAttributes) {
    KatydidHtmlElementImpl.call(this, selector, key != null ? key : name, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    phrasingContent.contentRestrictions.confirmInteractiveContentAllowed();
    this.setAttribute_jyasbz$('autocomplete', autocomplete);
    this.setBooleanAttribute_h92gdm$('autofocus', autofocus);
    this.setBooleanAttribute_h92gdm$('disabled', disabled);
    this.setAttribute_jyasbz$('form', form);
    this.setAttribute_jyasbz$('list', list);
    this.setAttribute_jyasbz$('max', max);
    this.setAttribute_jyasbz$('min', min);
    this.setAttribute_jyasbz$('name', name);
    this.setBooleanAttribute_h92gdm$('readonly', readonly);
    this.setBooleanAttribute_h92gdm$('required', required);
    this.setAttribute_jyasbz$('step', step);
    this.setTimeAttribute_qhpdwr$('value', value);
    this.setAttribute_jyasbz$('type', 'time');
    defineAttributes(phrasingContent.attributesContent_bflrjy$(this));
    this.freeze_0();
    this.nodeName_t2hy5n$_0 = 'INPUT';
  }
  Object.defineProperty(KatydidInputTime.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_t2hy5n$_0;
    }
  });
  KatydidInputTime.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidInputTime',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidInputUrl(phrasingContent, selector, key, accesskey, autocomplete, autofocus, contenteditable, dir, disabled, draggable, form, hidden, lang, list, maxlength, minlength, name, pattern, placeholder, readonly, required, size, spellcheck, style, tabindex, title, translate, value, defineAttributes) {
    KatydidHtmlElementImpl.call(this, selector, key != null ? key : name, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    phrasingContent.contentRestrictions.confirmInteractiveContentAllowed();
    if (!(maxlength == null || maxlength >= 0)) {
      var message = 'Attribute maxlength must be non-negative.';
      throw IllegalArgumentException_init(message.toString());
    }
    if (!(minlength == null || minlength >= 0)) {
      var message_0 = 'Attribute minlength must be non-negative.';
      throw IllegalArgumentException_init(message_0.toString());
    }
    if (!(size == null || size >= 0)) {
      var message_1 = 'Attribute size must be non-negative.';
      throw IllegalArgumentException_init(message_1.toString());
    }
    this.setAttribute_jyasbz$('autocomplete', autocomplete);
    this.setBooleanAttribute_h92gdm$('autofocus', autofocus);
    this.setBooleanAttribute_h92gdm$('disabled', disabled);
    this.setAttribute_jyasbz$('form', form);
    this.setAttribute_jyasbz$('list', list);
    this.setNumberAttribute_hzlfav$('maxlength', maxlength);
    this.setNumberAttribute_hzlfav$('minlength', minlength);
    this.setAttribute_jyasbz$('name', name);
    this.setAttribute_jyasbz$('pattern', pattern);
    this.setAttribute_jyasbz$('placeholder', placeholder);
    this.setBooleanAttribute_h92gdm$('readonly', readonly);
    this.setBooleanAttribute_h92gdm$('required', required);
    this.setNumberAttribute_hzlfav$('size', size);
    this.setAttribute_jyasbz$('value', value);
    this.setAttribute_jyasbz$('type', 'url');
    defineAttributes(phrasingContent.attributesContent_bflrjy$(this));
    this.freeze_0();
    this.nodeName_72el6t$_0 = 'INPUT';
  }
  Object.defineProperty(KatydidInputUrl.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_72el6t$_0;
    }
  });
  KatydidInputUrl.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidInputUrl',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidInputWeek(phrasingContent, selector, key, accesskey, autocomplete, autofocus, contenteditable, dir, disabled, draggable, form, hidden, lang, list, max, min, name, readonly, required, spellcheck, step, style, tabindex, title, translate, value, defineAttributes) {
    KatydidHtmlElementImpl.call(this, selector, key != null ? key : name, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    phrasingContent.contentRestrictions.confirmInteractiveContentAllowed();
    this.setAttribute_jyasbz$('autocomplete', autocomplete);
    this.setBooleanAttribute_h92gdm$('autofocus', autofocus);
    this.setBooleanAttribute_h92gdm$('disabled', disabled);
    this.setAttribute_jyasbz$('form', form);
    this.setAttribute_jyasbz$('list', list);
    this.setAttribute_jyasbz$('max', max);
    this.setAttribute_jyasbz$('min', min);
    this.setAttribute_jyasbz$('name', name);
    this.setBooleanAttribute_h92gdm$('readonly', readonly);
    this.setBooleanAttribute_h92gdm$('required', required);
    this.setAttribute_jyasbz$('step', step);
    this.setAttribute_jyasbz$('value', value);
    this.setAttribute_jyasbz$('type', 'week');
    defineAttributes(phrasingContent.attributesContent_bflrjy$(this));
    this.freeze_0();
    this.nodeName_h1ds5g$_0 = 'INPUT';
  }
  Object.defineProperty(KatydidInputWeek.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_h1ds5g$_0;
    }
  });
  KatydidInputWeek.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidInputWeek',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidLabel(phrasingContent, selector, key, accesskey, contenteditable, dir, draggable, for_0, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    KatydidHtmlElementImpl.call(this, selector, key != null ? key : for_0 != null ? for_0 + '-label' : null, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    phrasingContent.contentRestrictions.confirmInteractiveContentAllowed();
    phrasingContent.contentRestrictions.confirmLabelAllowed();
    this.setAttribute_jyasbz$('for', for_0);
    defineContent(phrasingContent.withLabelNotAllowed_bflrjy$(this));
    this.freeze_0();
    this.nodeName_bg9q5q$_0 = 'LABEL';
  }
  Object.defineProperty(KatydidLabel.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_bg9q5q$_0;
    }
  });
  KatydidLabel.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidLabel',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidLegend(flowContent, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    KatydidHtmlElementImpl.call(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    flowContent.contentRestrictions.confirmLegendAllowedThenDisallow();
    defineContent(flowContent.phrasingContent_bflrjy$(this));
    this.freeze_0();
    this.nodeName_2u9ivh$_0 = 'LEGEND';
  }
  Object.defineProperty(KatydidLegend.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_2u9ivh$_0;
    }
  });
  KatydidLegend.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidLegend',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidMeter() {
    this.nodeName_1hpyzd$_0 = 'METER';
  }
  Object.defineProperty(KatydidMeter.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_1hpyzd$_0;
    }
  });
  KatydidMeter.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidMeter',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidMeter_init(phrasingContent, selector, key, accesskey, contenteditable, dir, draggable, hidden, high, lang, low, max, min, optimum, spellcheck, style, tabindex, title, translate, value, defineContent, $this) {
    $this = $this || Object.create(KatydidMeter.prototype);
    KatydidHtmlElementImpl.call($this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    KatydidMeter.call($this);
    phrasingContent.contentRestrictions.confirmMeterAllowed();
    var maximum = max != null ? max : 1.0;
    var minimum = min != null ? min : 0.0;
    if (!(minimum < maximum)) {
      var message = 'Meter max must be greater than min.';
      throw IllegalArgumentException_init(message.toString());
    }
    var checkInRange = KatydidMeter_init$checkInRange(minimum, maximum);
    checkInRange(value, 'value');
    checkInRange(low, 'low');
    checkInRange(high, 'high');
    checkInRange(optimum, 'optimum');
    $this.setNumberAttribute_hzlfav$('high', high);
    $this.setNumberAttribute_hzlfav$('low', low);
    $this.setNumberAttribute_hzlfav$('max', max);
    $this.setNumberAttribute_hzlfav$('min', min);
    $this.setNumberAttribute_hzlfav$('optimum', optimum);
    $this.setNumberAttribute_hzlfav$('value', value);
    defineContent(phrasingContent.withMeterNotAllowed_bflrjy$($this));
    $this.freeze_0();
    return $this;
  }
  function KatydidMeter_init$checkInRange(closure$minimum, closure$maximum) {
    return function (value, attributeName) {
      if (value != null) {
        if (!(closure$minimum <= value)) {
          var message = 'Meter ' + attributeName + ' is smaller than minimum.';
          throw IllegalArgumentException_init(message.toString());
        }
        if (!(value <= closure$maximum)) {
          var message_0 = 'Meter ' + attributeName + ' is greater than maximum.';
          throw IllegalArgumentException_init(message_0.toString());
        }
      }
    };
  }
  function KatydidMeter_init_0(phrasingContent, selector, key, accesskey, contenteditable, dir, draggable, hidden, high, lang, low, max, min, optimum, spellcheck, style, tabindex, title, translate, value, defineContent, $this) {
    $this = $this || Object.create(KatydidMeter.prototype);
    KatydidHtmlElementImpl.call($this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    KatydidMeter.call($this);
    phrasingContent.contentRestrictions.confirmMeterAllowed();
    var minimum = min != null ? min : 0;
    if (!(minimum < max)) {
      var message = 'Meter max must be greater than min.';
      throw IllegalArgumentException_init(message.toString());
    }
    var checkInRange = KatydidMeter_init$checkInRange_0(minimum, max);
    checkInRange(value, 'value');
    checkInRange(low, 'low');
    checkInRange(high, 'high');
    checkInRange(optimum, 'optimum');
    $this.setNumberAttribute_hzlfav$('high', high);
    $this.setNumberAttribute_hzlfav$('low', low);
    $this.setNumberAttribute_hzlfav$('max', max);
    $this.setNumberAttribute_hzlfav$('min', min);
    $this.setNumberAttribute_hzlfav$('optimum', optimum);
    $this.setNumberAttribute_hzlfav$('value', value);
    defineContent(phrasingContent.withMeterNotAllowed_bflrjy$($this));
    $this.freeze_0();
    return $this;
  }
  function KatydidMeter_init$checkInRange_0(closure$minimum, closure$max) {
    return function (value, attributeName) {
      if (value != null) {
        if (!(closure$minimum <= value)) {
          var message = 'Meter ' + attributeName + ' is smaller than minimum.';
          throw IllegalArgumentException_init(message.toString());
        }
        if (!(value <= closure$max)) {
          var message_0 = 'Meter ' + attributeName + ' is greater than maximum.';
          throw IllegalArgumentException_init(message_0.toString());
        }
      }
    };
  }
  function KatydidOptGroup(selectContent, selector, key, accesskey, contenteditable, dir, disabled, draggable, hidden, label, lang, name, spellcheck, style, tabindex, title, translate, defineContent) {
    KatydidHtmlElementImpl.call(this, selector, key != null ? key : name, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    if (!!(label.length === 0)) {
      var message = 'Attribute label may not be an empty string.';
      throw IllegalArgumentException_init(message.toString());
    }
    this.setBooleanAttribute_h92gdm$('disabled', disabled);
    this.setAttribute_jyasbz$('label', label);
    defineContent(selectContent.optGroupContent_32tdoa$(this));
    this.freeze_0();
    this.nodeName_t1u46s$_0 = 'OPTGROUP';
  }
  Object.defineProperty(KatydidOptGroup.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_t1u46s$_0;
    }
  });
  KatydidOptGroup.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidOptGroup',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidOption() {
    this.nodeName_tbohxn$_0 = 'OPTION';
  }
  KatydidOption.prototype.setAttributes_0 = function (disabled, label, selected) {
    var tmp$ = label == null;
    if (!tmp$) {
      tmp$ = !(label.length === 0);
    }
    if (!tmp$) {
      var message = 'Attribute label may not be an empty string.';
      throw IllegalArgumentException_init(message.toString());
    }
    this.setBooleanAttribute_h92gdm$('disabled', disabled);
    this.setAttribute_jyasbz$('label', label);
    this.setBooleanAttribute_h92gdm$('selected', selected);
  };
  Object.defineProperty(KatydidOption.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_tbohxn$_0;
    }
  });
  KatydidOption.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidOption',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidOption_init(optionContent, selector, key, accesskey, contenteditable, dir, disabled, draggable, hidden, label, lang, name, selected, spellcheck, style, tabindex, title, translate, value, defineAttributes, $this) {
    $this = $this || Object.create(KatydidOption.prototype);
    KatydidHtmlElementImpl.call($this, selector, key != null ? key : name, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    KatydidOption.call($this);
    $this.setAttributes_0(disabled, label, selected);
    $this.setAttribute_jyasbz$('value', value);
    defineAttributes(optionContent.attributesContent_bflrjy$($this));
    $this.freeze_0();
    return $this;
  }
  function KatydidOption_init_0(optionContent, selector, key, accesskey, contenteditable, dir, disabled, draggable, hidden, label, lang, name, selected, spellcheck, style, tabindex, title, translate, defineContent, $this) {
    $this = $this || Object.create(KatydidOption.prototype);
    KatydidHtmlElementImpl.call($this, selector, key != null ? key : name, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    KatydidOption.call($this);
    $this.setAttributes_0(disabled, label, selected);
    defineContent(optionContent.textContent_3x6mf1$($this));
    $this.freeze_0();
    return $this;
  }
  function KatydidOutput(phrasingContent, selector, key, accesskey, contenteditable, dir, disabled, draggable, for_0, form, hidden, lang, name, spellcheck, style, tabindex, title, translate, defineContent) {
    KatydidHtmlElementImpl.call(this, selector, key != null ? key : name, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    this.setBooleanAttribute_h92gdm$('disabled', disabled);
    this.setAttribute_jyasbz$('for', for_0);
    this.setAttribute_jyasbz$('form', form);
    this.setAttribute_jyasbz$('name', name);
    defineContent(phrasingContent.withNoAddedRestrictions_bflrjy$(this));
    this.freeze_0();
    this.nodeName_x3lwe7$_0 = 'OUTPUT';
  }
  Object.defineProperty(KatydidOutput.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_x3lwe7$_0;
    }
  });
  KatydidOutput.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidOutput',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidProgress() {
    this.nodeName_d0xwod$_0 = 'PROGRESS';
  }
  Object.defineProperty(KatydidProgress.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_d0xwod$_0;
    }
  });
  KatydidProgress.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidProgress',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidProgress_init(phrasingContent, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, max, spellcheck, style, tabindex, title, translate, value, defineContent, $this) {
    $this = $this || Object.create(KatydidProgress.prototype);
    KatydidHtmlElementImpl.call($this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    KatydidProgress.call($this);
    phrasingContent.contentRestrictions.confirmProgressAllowed();
    var maximum = max != null ? max : 1.0;
    if (!(maximum > 0)) {
      var message = 'Progress max must be greater than zero.';
      throw IllegalArgumentException_init(message.toString());
    }
    if (value != null) {
      if (!(0 <= value)) {
        var message_0 = 'Progress value is smaller than zero.';
        throw IllegalArgumentException_init(message_0.toString());
      }
      if (!(value <= maximum)) {
        var message_1 = 'Progress value is greater than maximum.';
        throw IllegalArgumentException_init(message_1.toString());
      }
    }
    $this.setNumberAttribute_hzlfav$('max', max);
    $this.setNumberAttribute_hzlfav$('value', value);
    defineContent(phrasingContent.withProgressNotAllowed_bflrjy$($this));
    $this.freeze_0();
    return $this;
  }
  function KatydidProgress_init_0(phrasingContent, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, max, spellcheck, style, tabindex, title, translate, value, defineContent, $this) {
    $this = $this || Object.create(KatydidProgress.prototype);
    KatydidHtmlElementImpl.call($this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    KatydidProgress.call($this);
    phrasingContent.contentRestrictions.confirmProgressAllowed();
    if (!(max > 0)) {
      var message = 'Progress max must be greater than zero.';
      throw IllegalArgumentException_init(message.toString());
    }
    if (value != null) {
      if (!(0 <= value)) {
        var message_0 = 'Progress value is smaller than zero.';
        throw IllegalArgumentException_init(message_0.toString());
      }
      if (!(value <= max)) {
        var message_1 = 'Progress value is greater than maximum.';
        throw IllegalArgumentException_init(message_1.toString());
      }
    }
    $this.setNumberAttribute_hzlfav$('max', max);
    $this.setNumberAttribute_hzlfav$('value', value);
    defineContent(phrasingContent.withProgressNotAllowed_bflrjy$($this));
    $this.freeze_0();
    return $this;
  }
  function KatydidSelect(phrasingContent, selector, key, accesskey, autocomplete, autofocus, contenteditable, dir, disabled, draggable, form, hidden, lang, multiple, name, required, size, spellcheck, style, tabindex, title, translate, value, defineContent) {
    KatydidHtmlElementImpl.call(this, selector, key != null ? key : name, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    phrasingContent.contentRestrictions.confirmInteractiveContentAllowed();
    if (!(size == null || size > 0)) {
      var message = 'Attribute size must be greater than zero.';
      throw IllegalArgumentException_init(message.toString());
    }
    this.setAttribute_jyasbz$('autocomplete', autocomplete);
    this.setBooleanAttribute_h92gdm$('autofocus', autofocus);
    this.setBooleanAttribute_h92gdm$('disabled', disabled);
    this.setAttribute_jyasbz$('form', form);
    this.setBooleanAttribute_h92gdm$('multiple', multiple);
    this.setAttribute_jyasbz$('name', name);
    this.setBooleanAttribute_h92gdm$('required', required);
    this.setNumberAttribute_hzlfav$('size', size);
    this.setAttribute_jyasbz$('value', value);
    defineContent(phrasingContent.selectContent_devcnq$(this));
    this.freeze_0();
    this.nodeName_ssn404$_0 = 'SELECT';
  }
  Object.defineProperty(KatydidSelect.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_ssn404$_0;
    }
  });
  KatydidSelect.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidSelect',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidTextArea(phrasingContent, selector, key, accesskey, autocomplete, autofocus, cols, contenteditable, dir, dirname, disabled, draggable, form, hidden, lang, maxlength, minlength, name, placeholder, readonly, required, rows, spellcheck, style, tabindex, title, translate, wrap, defineContent) {
    KatydidHtmlElementImpl.call(this, selector, key != null ? key : name, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    phrasingContent.contentRestrictions.confirmInteractiveContentAllowed();
    if (!(cols == null || cols > 0)) {
      var message = 'Attribute cols must be greater than zero.';
      throw IllegalArgumentException_init(message.toString());
    }
    if (!(maxlength == null || maxlength >= 0)) {
      var message_0 = 'Attribute maxlength must be non-negative.';
      throw IllegalArgumentException_init(message_0.toString());
    }
    if (!(minlength == null || minlength >= 0)) {
      var message_1 = 'Attribute minlength must be non-negative.';
      throw IllegalArgumentException_init(message_1.toString());
    }
    if (!(minlength == null || maxlength == null || minlength <= maxlength)) {
      var message_2 = 'Input attribute minlength must be less than maxlength.';
      throw IllegalArgumentException_init(message_2.toString());
    }
    if (!(rows == null || rows > 0)) {
      var message_3 = 'Attribute rows must be greater than zero.';
      throw IllegalArgumentException_init(message_3.toString());
    }
    this.setAttribute_jyasbz$('autocomplete', autocomplete);
    this.setBooleanAttribute_h92gdm$('autofocus', autofocus);
    this.setNumberAttribute_hzlfav$('cols', cols);
    this.setAttribute_jyasbz$('dirname', dirname);
    this.setBooleanAttribute_h92gdm$('disabled', disabled);
    this.setAttribute_jyasbz$('form', form);
    this.setNumberAttribute_hzlfav$('maxlength', maxlength);
    this.setNumberAttribute_hzlfav$('minlength', minlength);
    this.setAttribute_jyasbz$('name', name);
    this.setAttribute_jyasbz$('placeholder', placeholder);
    this.setBooleanAttribute_h92gdm$('readonly', readonly);
    this.setBooleanAttribute_h92gdm$('required', required);
    this.setNumberAttribute_hzlfav$('rows', rows);
    this.setAttribute_jyasbz$('wrap', wrap != null ? wrap.toHtmlString() : null);
    defineContent(phrasingContent.textContent_bflrjy$(this));
    this.freeze_0();
    this.nodeName_pg6uee$_0 = 'TEXTAREA';
  }
  Object.defineProperty(KatydidTextArea.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_pg6uee$_0;
    }
  });
  KatydidTextArea.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidTextArea',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidAddress(flowContent, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    KatydidHtmlElementImpl.call(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    flowContent.contentRestrictions.confirmAddressAllowed();
    defineContent(flowContent.withFooterHeaderAddressNotAllowed_bflrjy$(this));
    this.freeze_0();
    this.nodeName_k69ive$_0 = 'ADDRESS';
  }
  Object.defineProperty(KatydidAddress.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_k69ive$_0;
    }
  });
  KatydidAddress.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidAddress',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidBlockQuote(flowContent, selector, key, accesskey, cite, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    KatydidHtmlElementImpl.call(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    this.setAttribute_jyasbz$('cite', cite);
    defineContent(flowContent.withNoAddedRestrictions_bflrjy$(this));
    this.freeze_0();
    this.nodeName_uuzpth$_0 = 'BLOCKQUOTE';
  }
  Object.defineProperty(KatydidBlockQuote.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_uuzpth$_0;
    }
  });
  KatydidBlockQuote.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidBlockQuote',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidDd(descriptionListContent, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    KatydidHtmlElementImpl.call(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    defineContent(descriptionListContent.flowContent_bflrjy$(this));
    this.freeze_0();
    this.nodeName_x9nye4$_0 = 'DD';
  }
  Object.defineProperty(KatydidDd.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_x9nye4$_0;
    }
  });
  KatydidDd.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidDd',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidDiv() {
    this.nodeName_ldvz0z$_0 = 'DIV';
  }
  Object.defineProperty(KatydidDiv.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_ldvz0z$_0;
    }
  });
  KatydidDiv.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidDiv',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidDiv_init(flowContent, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent, $this) {
    $this = $this || Object.create(KatydidDiv.prototype);
    KatydidHtmlElementImpl.call($this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    KatydidDiv.call($this);
    defineContent(flowContent.withNoAddedRestrictions_bflrjy$($this));
    $this.freeze_0();
    return $this;
  }
  function KatydidDiv_init_0(descriptionListContent, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent, $this) {
    $this = $this || Object.create(KatydidDiv.prototype);
    KatydidHtmlElementImpl.call($this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    KatydidDiv.call($this);
    defineContent(descriptionListContent.withNoAddedRestrictions_orwckh$($this));
    $this.freeze_0();
    return $this;
  }
  function KatydidDl(flowContent, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    KatydidHtmlElementImpl.call(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    defineContent(flowContent.descriptionListContent_wcji1e$(this));
    this.freeze_0();
    this.nodeName_8m4vz8$_0 = 'DL';
  }
  Object.defineProperty(KatydidDl.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_8m4vz8$_0;
    }
  });
  KatydidDl.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidDl',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidDt(descriptionListContent, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    KatydidHtmlElementImpl.call(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    defineContent(descriptionListContent.flowContent_bflrjy$(this));
    this.freeze_0();
    this.nodeName_g1e6fo$_0 = 'DT';
  }
  Object.defineProperty(KatydidDt.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_g1e6fo$_0;
    }
  });
  KatydidDt.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidDt',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidFigCaption(flowContent, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    KatydidHtmlElementImpl.call(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    flowContent.contentRestrictions.confirmFigCaptionAllowedThenDisallow();
    defineContent(flowContent.withNoAddedRestrictions_bflrjy$(this));
    this.freeze_0();
    this.nodeName_gdjbxa$_0 = 'FIGCAPTION';
  }
  Object.defineProperty(KatydidFigCaption.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_gdjbxa$_0;
    }
  });
  KatydidFigCaption.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidFigCaption',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidFigure(flowContent, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    KatydidHtmlElementImpl.call(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    defineContent(flowContent.withFigCaptionAllowed_bflrjy$(this));
    this.freeze_0();
    this.nodeName_gmi80$_0 = 'FIGURE';
  }
  Object.defineProperty(KatydidFigure.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_gmi80$_0;
    }
  });
  KatydidFigure.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidFigure',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidHr(flowContent, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineAttributes) {
    KatydidHtmlElementImpl.call(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    defineAttributes(flowContent.attributesContent_bflrjy$(this));
    this.freeze_0();
    this.nodeName_j3dnve$_0 = 'HR';
  }
  Object.defineProperty(KatydidHr.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_j3dnve$_0;
    }
  });
  KatydidHr.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidHr',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidLi() {
    this.nodeName_r7ozfr$_0 = 'LI';
  }
  Object.defineProperty(KatydidLi.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_r7ozfr$_0;
    }
  });
  KatydidLi.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidLi',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidLi_init(listContent, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, value, defineContent, $this) {
    $this = $this || Object.create(KatydidLi.prototype);
    KatydidHtmlElementImpl.call($this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    KatydidLi.call($this);
    $this.setNumberAttribute_hzlfav$('value', value);
    defineContent(listContent.flowContent_8be2vx$.withNoAddedRestrictions_bflrjy$($this));
    $this.freeze_0();
    return $this;
  }
  function KatydidLi_init_0(listContent, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent, $this) {
    $this = $this || Object.create(KatydidLi.prototype);
    KatydidHtmlElementImpl.call($this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    KatydidLi.call($this);
    defineContent(listContent.flowContent_8be2vx$.withNoAddedRestrictions_bflrjy$($this));
    $this.freeze_0();
    return $this;
  }
  function KatydidMain(flowContent, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    KatydidHtmlElementImpl.call(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    flowContent.contentRestrictions.confirmMainAllowed();
    defineContent(flowContent.withMainNotAllowed_bflrjy$(this));
    this.freeze_0();
    this.nodeName_t05rbp$_0 = 'MAIN';
  }
  Object.defineProperty(KatydidMain.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_t05rbp$_0;
    }
  });
  KatydidMain.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidMain',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidOl(flowContent, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, reversed, spellcheck, start, style, tabindex, title, translate, type, defineContent) {
    KatydidHtmlElementImpl.call(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    this.setBooleanAttribute_h92gdm$('reversed', reversed);
    this.setNumberAttribute_hzlfav$('start', start);
    this.setAttribute_jyasbz$('type', type != null ? type.toHtmlString() : null);
    defineContent(flowContent.listContent_cyehjb$(this));
    this.freeze_0();
    this.nodeName_w3ihh5$_0 = 'OL';
  }
  Object.defineProperty(KatydidOl.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_w3ihh5$_0;
    }
  });
  KatydidOl.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidOl',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidP(flowContent, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    KatydidHtmlElementImpl.call(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    defineContent(flowContent.phrasingContent_bflrjy$(this));
    this.freeze_0();
    this.nodeName_j3ecjy$_0 = 'P';
  }
  Object.defineProperty(KatydidP.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_j3ecjy$_0;
    }
  });
  KatydidP.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidP',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidPre(flowContent, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    KatydidHtmlElementImpl.call(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    defineContent(flowContent.phrasingContent_bflrjy$(this));
    this.freeze_0();
    this.nodeName_9mukbf$_0 = 'PRE';
  }
  Object.defineProperty(KatydidPre.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_9mukbf$_0;
    }
  });
  KatydidPre.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidPre',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidUl(flowContent, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    KatydidHtmlElementImpl.call(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    defineContent(flowContent.listContent_42v5tr$(this));
    this.freeze_0();
    this.nodeName_q4hfbh$_0 = 'UL';
  }
  Object.defineProperty(KatydidUl.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_q4hfbh$_0;
    }
  });
  KatydidUl.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidUl',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidDetails(flowContent, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, open, spellcheck, style, tabindex, title, translate, defineContent) {
    KatydidHtmlElementImpl.call(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    this.setBooleanAttribute_h92gdm$('open', open);
    defineContent(flowContent.detailsFlowContent_98eimz$(this));
    this.freeze_0();
    this.nodeName_at8he5$_0 = 'DETAILS';
  }
  Object.defineProperty(KatydidDetails.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_at8he5$_0;
    }
  });
  KatydidDetails.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidDetails',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidDialog(flowContent, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, open, spellcheck, style, tabindex, title, translate, defineContent) {
    KatydidHtmlElementImpl.call(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    this.setBooleanAttribute_h92gdm$('open', open);
    defineContent(flowContent.withNoAddedRestrictions_bflrjy$(this));
    this.freeze_0();
    this.nodeName_worwmz$_0 = 'DIALOG';
  }
  Object.defineProperty(KatydidDialog.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_worwmz$_0;
    }
  });
  KatydidDialog.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidDialog',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidSummary() {
    this.nodeName_mzp375$_0 = 'SUMMARY';
  }
  Object.defineProperty(KatydidSummary.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_mzp375$_0;
    }
  });
  KatydidSummary.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidSummary',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidSummary_init(detailsContent, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent, $this) {
    $this = $this || Object.create(KatydidSummary.prototype);
    KatydidHtmlElementImpl.call($this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    KatydidSummary.call($this);
    detailsContent.detailsContentRestrictions.confirmSummaryAllowedThenDisallow();
    defineContent(detailsContent.withNoAddedRestrictions_bflrjy$($this));
    $this.freeze_0();
    return $this;
  }
  function KatydidSummary_init_0(detailsContent, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, withHeading, defineContent, $this) {
    $this = $this || Object.create(KatydidSummary.prototype);
    KatydidHtmlElementImpl.call($this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    KatydidSummary.call($this);
    if (!withHeading) {
      var message = "Artificial 'withHeading' parameter not set.";
      throw IllegalArgumentException_init(message.toString());
    }
    detailsContent.detailsContentRestrictions.confirmSummaryAllowedThenDisallow();
    defineContent(detailsContent.withNoAddedRestrictions_bflrjy$($this));
    $this.freeze_0();
    return $this;
  }
  function KatydidElementImpl() {
    KatydidElementImpl$Companion_getInstance();
    this.attributes_0 = LinkedHashMap_init();
    this.booleanAttributes_0 = LinkedHashSet_init();
    this.classList_0 = LinkedHashSet_init();
    this.dataset_0 = LinkedHashMap_init();
  }
  function KatydidElementImpl$Unused() {
    KatydidElementImpl$Unused_instance = this;
    this.classList = new UnusedSet();
    this.dataset = new UnusedMap();
  }
  KatydidElementImpl$Unused.$metadata$ = {
    kind: Kind_OBJECT,
    simpleName: 'Unused',
    interfaces: []
  };
  var KatydidElementImpl$Unused_instance = null;
  function KatydidElementImpl$Unused_getInstance() {
    if (KatydidElementImpl$Unused_instance === null) {
      new KatydidElementImpl$Unused();
    }
    return KatydidElementImpl$Unused_instance;
  }
  KatydidElementImpl.prototype.addClass_61zpoe$ = function (className) {
    if (!this.isAddingAttributes_0) {
      var message = 'Cannot modify Katydid-VDOM attributes after beginning to add event handlers or child nodes.';
      throw IllegalStateException_init(message.toString());
    }
    this.classList_0.add_11rb$(className);
  };
  KatydidElementImpl.prototype.addClasses_upaayv$ = function (classes) {
    if (!this.isAddingAttributes_0) {
      var message = 'Cannot modify Katydid-VDOM attributes after beginning to add event handlers or child nodes.';
      throw IllegalStateException_init(message.toString());
    }
    addAll(this.classList_0, classes);
  };
  KatydidElementImpl.prototype.establishAttributes_b3w3xb$ = function (domElement) {
    var tmp$, tmp$_0;
    if (!Kotlin.isType(domElement, Element))
      throw IllegalArgumentException_init('DOM node expected to be an element.');
    tmp$ = this.attributes_0.entries.iterator();
    while (tmp$.hasNext()) {
      var tmp$_1 = tmp$.next();
      var key = tmp$_1.key;
      var value = tmp$_1.value;
      domElement.setAttribute(key, value);
    }
    tmp$_0 = this.booleanAttributes_0.iterator();
    while (tmp$_0.hasNext()) {
      var key_0 = tmp$_0.next();
      domElement.setAttribute(key_0, '');
    }
    if (false) {
      var debugAttr = KatydidElementImpl$Companion_getInstance().nodeCount.toString() + ';' + toString(this.key);
      domElement.setAttribute('data-debug', debugAttr);
      KatydidElementImpl$Companion_getInstance().nodeCount = KatydidElementImpl$Companion_getInstance().nodeCount + 1 | 0;
    }
  };
  KatydidElementImpl.prototype.freezeAttributes = function () {
    var tmp$;
    if (!this.classList_0.isEmpty()) {
      var attrClasses = this.attributes_0.get_11rb$('class');
      if (attrClasses != null) {
        this.classList_0.addAll_brywnq$(split(attrClasses, [' ']));
      }
      var $receiver = this.attributes_0;
      var value = joinToString(sorted(this.classList_0), ' ');
      $receiver.put_xwzc9p$('class', value);
    }
    tmp$ = this.dataset_0.entries.iterator();
    while (tmp$.hasNext()) {
      var tmp$_0 = tmp$.next();
      var name = tmp$_0.key;
      var value_0 = tmp$_0.value;
      this.setAttribute_jyasbz$('data-' + name, value_0);
    }
    this.classList_0 = KatydidElementImpl$Unused_getInstance().classList;
    this.dataset_0 = KatydidElementImpl$Unused_getInstance().dataset;
  };
  KatydidElementImpl.prototype.patchAttributes_jeu6e6$ = function (domElement, priorElement) {
    var tmp$, tmp$_0, tmp$_1, tmp$_2;
    if (!Kotlin.isType(domElement, Element))
      throw IllegalArgumentException_init('DOM node expected to be an element.');
    if (!Kotlin.isType(priorElement, KatydidElementImpl))
      throw IllegalArgumentException_init('Katydid-VDOM node expected to be element.');
    tmp$ = this.attributes_0.entries.iterator();
    while (tmp$.hasNext()) {
      var tmp$_3 = tmp$.next();
      var key = tmp$_3.key;
      var newValue = tmp$_3.value;
      if (!equals(newValue, priorElement.attributes_0.get_11rb$(key))) {
        setAttributeAndProperty(domElement, key, newValue);
      }
    }
    tmp$_0 = priorElement.attributes_0.entries.iterator();
    while (tmp$_0.hasNext()) {
      var tmp$_4 = tmp$_0.next();
      var key_0 = tmp$_4.key;
      var $receiver = this.attributes_0;
      var tmp$_5;
      if (!(Kotlin.isType(tmp$_5 = $receiver, Map) ? tmp$_5 : throwCCE()).containsKey_11rb$(key_0)) {
        removeAttributeAndProperty(domElement, key_0);
      }
    }
    tmp$_1 = this.booleanAttributes_0.iterator();
    while (tmp$_1.hasNext()) {
      var key_1 = tmp$_1.next();
      if (!priorElement.booleanAttributes_0.contains_11rb$(key_1)) {
        setBooleanAttributeAndProperty(domElement, key_1);
      }
    }
    tmp$_2 = priorElement.booleanAttributes_0.iterator();
    while (tmp$_2.hasNext()) {
      var key_2 = tmp$_2.next();
      if (!this.booleanAttributes_0.contains_11rb$(key_2)) {
        removeAttributeAndProperty(domElement, key_2);
      }
    }
  };
  KatydidElementImpl.prototype.setAttribute_jyasbz$ = function (name, value) {
    if (!this.isAddingAttributes_0) {
      var message = 'Cannot modify Katydid-VDOM attributes after beginning to add event handlers or child nodes.';
      throw IllegalStateException_init(message.toString());
    }
    if (value == null) {
      this.attributes_0.remove_11rb$(name);
    }
     else {
      this.attributes_0.put_xwzc9p$(name, value);
    }
  };
  KatydidElementImpl.prototype.setAttributes_y0zsll$ = function (attributes) {
    var tmp$;
    if (!this.isAddingAttributes_0) {
      var message = 'Cannot modify Katydid-VDOM attributes after beginning to add event handlers or child nodes.';
      throw IllegalStateException_init(message.toString());
    }
    tmp$ = attributes.entries.iterator();
    while (tmp$.hasNext()) {
      var tmp$_0 = tmp$.next();
      var name = tmp$_0.key;
      var value = tmp$_0.value;
      this.setAttribute_jyasbz$(name, value);
    }
  };
  KatydidElementImpl.prototype.setBooleanAttribute_h92gdm$ = function (name, value) {
    if (!this.isAddingAttributes_0) {
      var message = 'Cannot modify Katydid-VDOM attributes after beginning to add event handlers or child nodes.';
      throw IllegalStateException_init(message.toString());
    }
    if (value != null && value) {
      this.booleanAttributes_0.add_11rb$(name);
    }
     else {
      this.booleanAttributes_0.remove_11rb$(name);
    }
  };
  KatydidElementImpl.prototype.setDateTimeAttribute_qhpdwr$ = function (name, value) {
    if (!this.isAddingAttributes_0) {
      var message = 'Cannot modify Katydid-VDOM attributes after beginning to add event handlers or child nodes.';
      throw IllegalStateException_init(message.toString());
    }
    if (value == null) {
      this.attributes_0.remove_11rb$(name);
    }
     else {
      var $receiver = this.attributes_0;
      var value_0 = formatHtmlDateTime(value);
      $receiver.put_xwzc9p$(name, value_0);
    }
  };
  KatydidElementImpl.prototype.setTimeAttribute_qhpdwr$ = function (name, value) {
    if (!this.isAddingAttributes_0) {
      var message = 'Cannot modify Katydid-VDOM attributes after beginning to add event handlers or child nodes.';
      throw IllegalStateException_init(message.toString());
    }
    if (value == null) {
      this.attributes_0.remove_11rb$(name);
    }
     else {
      var $receiver = this.attributes_0;
      var value_0 = formatHtmlTime(value);
      $receiver.put_xwzc9p$(name, value_0);
    }
  };
  KatydidElementImpl.prototype.setData_puj7f4$ = function (name, value) {
    if (!this.isAddingAttributes_0) {
      var message = 'Cannot modify Katydid-VDOM attributes after beginning to add event handlers or child nodes.';
      throw IllegalStateException_init(message.toString());
    }
    if (startsWith(name, 'data-')) {
      var tmp$ = this.dataset_0;
      var key = name.substring(5);
      tmp$.put_xwzc9p$(key, value);
    }
     else {
      this.dataset_0.put_xwzc9p$(name, value);
    }
  };
  KatydidElementImpl.prototype.setData_y0zsll$ = function (dataset) {
    var tmp$;
    if (!this.isAddingAttributes_0) {
      var message = 'Cannot modify Katydid-VDOM attributes after beginning to add event handlers or child nodes.';
      throw IllegalStateException_init(message.toString());
    }
    tmp$ = dataset.entries.iterator();
    while (tmp$.hasNext()) {
      var tmp$_0 = tmp$.next();
      var name = tmp$_0.key;
      var value = tmp$_0.value;
      this.setData_puj7f4$(name, value);
    }
  };
  KatydidElementImpl.prototype.setNumberAttribute_hzlfav$ = function (name, value) {
    if (!this.isAddingAttributes_0) {
      var message = 'Cannot modify Katydid-VDOM attributes after beginning to add event handlers or child nodes.';
      throw IllegalStateException_init(message.toString());
    }
    if (value != null) {
      var $receiver = this.attributes_0;
      var value_0 = value.toString();
      $receiver.put_xwzc9p$(name, value_0);
    }
     else {
      this.attributes_0.remove_11rb$(name);
    }
  };
  KatydidElementImpl.prototype.setStyle_pdl1vj$ = function (style) {
    if (!this.isAddingAttributes_0) {
      var message = 'Cannot modify Katydid-VDOM attributes after beginning to add event handlers or child nodes.';
      throw IllegalStateException_init(message.toString());
    }
    this.setAttribute_jyasbz$('style', style);
  };
  KatydidElementImpl.prototype.setTrueFalseAttribute_h92gdm$ = function (name, value) {
    if (!this.isAddingAttributes_0) {
      var message = 'Cannot modify Katydid-VDOM attributes after beginning to add event handlers or child nodes.';
      throw IllegalStateException_init(message.toString());
    }
    if (value != null) {
      if (value) {
        this.attributes_0.put_xwzc9p$(name, 'true');
      }
       else {
        this.attributes_0.put_xwzc9p$(name, 'false');
      }
    }
     else {
      this.attributes_0.remove_11rb$(name);
    }
  };
  KatydidElementImpl.prototype.setYesNoAttribute_h92gdm$ = function (name, value) {
    if (!this.isAddingAttributes_0) {
      var message = 'Cannot modify Katydid-VDOM attributes after beginning to add event handlers or child nodes.';
      throw IllegalStateException_init(message.toString());
    }
    if (value != null) {
      if (value) {
        this.attributes_0.put_xwzc9p$(name, 'yes');
      }
       else {
        this.attributes_0.put_xwzc9p$(name, 'no');
      }
    }
     else {
      this.attributes_0.remove_11rb$(name);
    }
  };
  KatydidElementImpl.prototype.toString = function () {
    var result = {v: '<' + this.nodeName.toLowerCase()};
    var tmp$;
    tmp$ = this.attributes_0.entries.iterator();
    while (tmp$.hasNext()) {
      var element = tmp$.next();
      result.v += ' ' + element.key + '="' + element.value + '"';
    }
    var tmp$_0;
    tmp$_0 = this.booleanAttributes_0.iterator();
    while (tmp$_0.hasNext()) {
      var element_0 = tmp$_0.next();
      result.v += ' ' + element_0;
    }
    return result.v + '>';
  };
  function KatydidElementImpl$Companion() {
    KatydidElementImpl$Companion_instance = this;
    this.nodeCount = 1;
  }
  KatydidElementImpl$Companion.prototype.keyFromSelector_d29504$ = function (selectorPieces) {
    var tmp$ = selectorPieces != null;
    if (tmp$) {
      tmp$ = !selectorPieces.isEmpty();
    }
    if (tmp$ && startsWith(selectorPieces.get_za3lpa$(0), '#')) {
      return selectorPieces.get_za3lpa$(0).substring(1);
    }
    return null;
  };
  KatydidElementImpl$Companion.$metadata$ = {
    kind: Kind_OBJECT,
    simpleName: 'Companion',
    interfaces: []
  };
  var KatydidElementImpl$Companion_instance = null;
  function KatydidElementImpl$Companion_getInstance() {
    if (KatydidElementImpl$Companion_instance === null) {
      new KatydidElementImpl$Companion();
    }
    return KatydidElementImpl$Companion_instance;
  }
  KatydidElementImpl.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidElementImpl',
    interfaces: [KatydidElement, KatydidNodeImpl]
  };
  function KatydidElementImpl_init(selectorPieces, key, $this) {
    $this = $this || Object.create(KatydidElementImpl.prototype);
    KatydidNodeImpl.call($this, key != null ? key : KatydidElementImpl$Companion_getInstance().keyFromSelector_d29504$(selectorPieces));
    KatydidElementImpl.call($this);
    var tmp$ = selectorPieces != null;
    if (tmp$) {
      tmp$ = !selectorPieces.isEmpty();
    }
    if (tmp$) {
      if (startsWith(selectorPieces.get_za3lpa$(0), '#')) {
        $this.setAttribute_jyasbz$('id', selectorPieces.get_za3lpa$(0).substring(1));
      }
       else {
        if (selectorPieces.get_za3lpa$(0).length === 0) {
          if (!(selectorPieces.get_za3lpa$(0).length === 0)) {
            var message = "Selector should start with '#' or '.'.";
            throw IllegalStateException_init(message.toString());
          }
        }
      }
      $this.classList_0.addAll_brywnq$(selectorPieces.subList_vux9f0$(1, selectorPieces.size));
    }
    return $this;
  }
  function KatydidElementImpl_init_0(selector, key, style, tabindex, $this) {
    $this = $this || Object.create(KatydidElementImpl.prototype);
    KatydidElementImpl_init(selector != null ? split(selector, ['.']) : null, key, $this);
    $this.setAttribute_jyasbz$('style', style);
    $this.setNumberAttribute_hzlfav$('tabindex', tabindex);
    return $this;
  }
  function KatydidHtmlElementImpl(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate) {
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    KatydidElementImpl_init_0(selector, key, style, tabindex, this);
    if (!(draggable == null || title != null)) {
      var message = 'Draggable elements should have a title.';
      throw IllegalStateException_init(message.toString());
    }
    this.setAttribute_jyasbz$('accesskey', accesskey != null ? String.fromCharCode(accesskey) : null);
    this.setTrueFalseAttribute_h92gdm$('contenteditable', contenteditable);
    this.setAttribute_jyasbz$('dir', dir != null ? dir.toHtmlString() : null);
    this.setTrueFalseAttribute_h92gdm$('draggable', draggable);
    this.setBooleanAttribute_h92gdm$('hidden', hidden);
    this.setAttribute_jyasbz$('lang', lang);
    this.setTrueFalseAttribute_h92gdm$('spellcheck', spellcheck);
    this.setAttribute_jyasbz$('title', title);
    this.setYesNoAttribute_h92gdm$('translate', translate);
  }
  KatydidHtmlElementImpl.prototype.createDomNode_2xapuv$ = function (document, parentDomNode, followingDomChild) {
    var childElement = document.createElement(this.nodeName);
    this.establish_b3w3xb$(childElement);
    parentDomNode.insertBefore(childElement, followingDomChild);
  };
  KatydidHtmlElementImpl.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidHtmlElementImpl',
    interfaces: [KatydidHtmlElement, KatydidElementImpl]
  };
  function KatydidNodeImpl(_key) {
    this._key_0 = _key;
    this.childNodesByKey_0 = HashMap_init();
    this.domNode_0 = null;
    this.eventHandlers_0 = LinkedHashMap_init();
    this.firstChildNode_0 = null;
    this.lastChildNode_0 = null;
    this.nextSiblingNode_0 = null;
    this.prevSiblingNode_0 = null;
    this.state_0 = KatydidNodeImpl$EState$ADDING_ATTRIBUTES_getInstance();
  }
  function KatydidNodeImpl$EState(name, ordinal) {
    Enum.call(this);
    this.name$ = name;
    this.ordinal$ = ordinal;
  }
  function KatydidNodeImpl$EState_initFields() {
    KatydidNodeImpl$EState_initFields = function () {
    };
    KatydidNodeImpl$EState$ADDING_ATTRIBUTES_instance = new KatydidNodeImpl$EState('ADDING_ATTRIBUTES', 0);
    KatydidNodeImpl$EState$ADDING_EVENT_HANDLERS_instance = new KatydidNodeImpl$EState('ADDING_EVENT_HANDLERS', 1);
    KatydidNodeImpl$EState$ADDING_CHILD_NODES_instance = new KatydidNodeImpl$EState('ADDING_CHILD_NODES', 2);
    KatydidNodeImpl$EState$CONSTRUCTED_instance = new KatydidNodeImpl$EState('CONSTRUCTED', 3);
    KatydidNodeImpl$EState$ESTABLISHED_instance = new KatydidNodeImpl$EState('ESTABLISHED', 4);
    KatydidNodeImpl$EState$PATCHED_REPLACED_instance = new KatydidNodeImpl$EState('PATCHED_REPLACED', 5);
    KatydidNodeImpl$EState$PATCHED_REMOVED_instance = new KatydidNodeImpl$EState('PATCHED_REMOVED', 6);
  }
  var KatydidNodeImpl$EState$ADDING_ATTRIBUTES_instance;
  function KatydidNodeImpl$EState$ADDING_ATTRIBUTES_getInstance() {
    KatydidNodeImpl$EState_initFields();
    return KatydidNodeImpl$EState$ADDING_ATTRIBUTES_instance;
  }
  var KatydidNodeImpl$EState$ADDING_EVENT_HANDLERS_instance;
  function KatydidNodeImpl$EState$ADDING_EVENT_HANDLERS_getInstance() {
    KatydidNodeImpl$EState_initFields();
    return KatydidNodeImpl$EState$ADDING_EVENT_HANDLERS_instance;
  }
  var KatydidNodeImpl$EState$ADDING_CHILD_NODES_instance;
  function KatydidNodeImpl$EState$ADDING_CHILD_NODES_getInstance() {
    KatydidNodeImpl$EState_initFields();
    return KatydidNodeImpl$EState$ADDING_CHILD_NODES_instance;
  }
  var KatydidNodeImpl$EState$CONSTRUCTED_instance;
  function KatydidNodeImpl$EState$CONSTRUCTED_getInstance() {
    KatydidNodeImpl$EState_initFields();
    return KatydidNodeImpl$EState$CONSTRUCTED_instance;
  }
  var KatydidNodeImpl$EState$ESTABLISHED_instance;
  function KatydidNodeImpl$EState$ESTABLISHED_getInstance() {
    KatydidNodeImpl$EState_initFields();
    return KatydidNodeImpl$EState$ESTABLISHED_instance;
  }
  var KatydidNodeImpl$EState$PATCHED_REPLACED_instance;
  function KatydidNodeImpl$EState$PATCHED_REPLACED_getInstance() {
    KatydidNodeImpl$EState_initFields();
    return KatydidNodeImpl$EState$PATCHED_REPLACED_instance;
  }
  var KatydidNodeImpl$EState$PATCHED_REMOVED_instance;
  function KatydidNodeImpl$EState$PATCHED_REMOVED_getInstance() {
    KatydidNodeImpl$EState_initFields();
    return KatydidNodeImpl$EState$PATCHED_REMOVED_instance;
  }
  KatydidNodeImpl$EState.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'EState',
    interfaces: [Enum]
  };
  function KatydidNodeImpl$EState$values() {
    return [KatydidNodeImpl$EState$ADDING_ATTRIBUTES_getInstance(), KatydidNodeImpl$EState$ADDING_EVENT_HANDLERS_getInstance(), KatydidNodeImpl$EState$ADDING_CHILD_NODES_getInstance(), KatydidNodeImpl$EState$CONSTRUCTED_getInstance(), KatydidNodeImpl$EState$ESTABLISHED_getInstance(), KatydidNodeImpl$EState$PATCHED_REPLACED_getInstance(), KatydidNodeImpl$EState$PATCHED_REMOVED_getInstance()];
  }
  KatydidNodeImpl$EState.values = KatydidNodeImpl$EState$values;
  function KatydidNodeImpl$EState$valueOf(name) {
    switch (name) {
      case 'ADDING_ATTRIBUTES':
        return KatydidNodeImpl$EState$ADDING_ATTRIBUTES_getInstance();
      case 'ADDING_EVENT_HANDLERS':
        return KatydidNodeImpl$EState$ADDING_EVENT_HANDLERS_getInstance();
      case 'ADDING_CHILD_NODES':
        return KatydidNodeImpl$EState$ADDING_CHILD_NODES_getInstance();
      case 'CONSTRUCTED':
        return KatydidNodeImpl$EState$CONSTRUCTED_getInstance();
      case 'ESTABLISHED':
        return KatydidNodeImpl$EState$ESTABLISHED_getInstance();
      case 'PATCHED_REPLACED':
        return KatydidNodeImpl$EState$PATCHED_REPLACED_getInstance();
      case 'PATCHED_REMOVED':
        return KatydidNodeImpl$EState$PATCHED_REMOVED_getInstance();
      default:throwISE('No enum constant i.katydid.vdom.elements.KatydidNodeImpl.EState.' + name);
    }
  }
  KatydidNodeImpl$EState.valueOf_61zpoe$ = KatydidNodeImpl$EState$valueOf;
  Object.defineProperty(KatydidNodeImpl.prototype, 'isAddingAttributes_0', {
    get: function () {
      return this.state_0 === KatydidNodeImpl$EState$ADDING_ATTRIBUTES_getInstance();
    }
  });
  Object.defineProperty(KatydidNodeImpl.prototype, 'isAddingChildNodes_0', {
    get: function () {
      return this.state_0 === KatydidNodeImpl$EState$ADDING_CHILD_NODES_getInstance();
    }
  });
  Object.defineProperty(KatydidNodeImpl.prototype, 'isAddingEventHandlers_0', {
    get: function () {
      return this.state_0 === KatydidNodeImpl$EState$ADDING_EVENT_HANDLERS_getInstance();
    }
  });
  Object.defineProperty(KatydidNodeImpl.prototype, 'isConstructed_0', {
    get: function () {
      return this.state_0 === KatydidNodeImpl$EState$CONSTRUCTED_getInstance();
    }
  });
  Object.defineProperty(KatydidNodeImpl.prototype, 'isEstablished_0', {
    get: function () {
      return this.state_0 === KatydidNodeImpl$EState$ESTABLISHED_getInstance();
    }
  });
  Object.defineProperty(KatydidNodeImpl.prototype, 'isPatchedRemoved_0', {
    get: function () {
      return this.state_0 === KatydidNodeImpl$EState$PATCHED_REMOVED_getInstance();
    }
  });
  Object.defineProperty(KatydidNodeImpl.prototype, 'isPatchedReplaced_0', {
    get: function () {
      return this.state_0 === KatydidNodeImpl$EState$PATCHED_REPLACED_getInstance();
    }
  });
  Object.defineProperty(KatydidNodeImpl.prototype, 'key', {
    get: function () {
      var tmp$;
      return (tmp$ = this._key_0) != null ? tmp$ : this.nodeName;
    }
  });
  Object.defineProperty(KatydidNodeImpl.prototype, 'soleChildNode', {
    get: function () {
      if (!(this.firstChildNode_0 != null)) {
        var message = 'No child found.';
        throw IllegalStateException_init(message.toString());
      }
      if (!equals(this.firstChildNode_0, this.lastChildNode_0)) {
        var message_0 = 'More than one child node found.';
        throw IllegalStateException_init(message_0.toString());
      }
      return ensureNotNull(this.firstChildNode_0);
    }
  });
  KatydidNodeImpl.prototype.addChildNode_x5x0wf$ = function (childNode) {
    if (this.isAddingAttributes_0) {
      this.freezeAttributes();
      this.state_0 = KatydidNodeImpl$EState$ADDING_CHILD_NODES_getInstance();
    }
     else if (this.isAddingEventHandlers_0)
      this.state_0 = KatydidNodeImpl$EState$ADDING_CHILD_NODES_getInstance();
    else {
      if (!this.isAddingChildNodes_0) {
        var message = 'Cannot modify a Katydid-VDOM node after it has been fully constructed.';
        throw IllegalStateException_init(message.toString());
      }
    }
    if (!!this.childNodesByKey_0.containsKey_11rb$(childNode.key)) {
      var message_0 = 'Duplicate key: ' + toString(childNode.key) + ' in parent element with key ' + toString(this.key);
      throw IllegalArgumentException_init(message_0.toString());
    }
    if (this.firstChildNode_0 == null) {
      this.firstChildNode_0 = childNode;
      this.lastChildNode_0 = childNode;
    }
     else {
      childNode.prevSiblingNode_0 = this.lastChildNode_0;
      ensureNotNull(this.lastChildNode_0).nextSiblingNode_0 = childNode;
      this.lastChildNode_0 = childNode;
    }
    var $receiver = this.childNodesByKey_0;
    var key = childNode.key;
    $receiver.put_xwzc9p$(key, childNode);
    this.afterAddChildNode_x5x0wf$(childNode);
  };
  function KatydidNodeImpl$addEventHandler$lambda(closure$handler) {
    return function (event) {
      try {
        closure$handler(event);
      }
       catch (exception) {
        if (Kotlin.isType(exception, EventCancellationException)) {
          event.preventDefault();
        }
         else
          throw exception;
      }
      return Unit;
    };
  }
  KatydidNodeImpl.prototype.addEventHandler_8s0k5j$ = function (eventName, handler) {
    if (this.isAddingAttributes_0) {
      this.freezeAttributes();
      this.state_0 = KatydidNodeImpl$EState$ADDING_EVENT_HANDLERS_getInstance();
    }
     else {
      if (!this.isAddingEventHandlers_0) {
        var message = "Katydid-VDOM node's event handlers must be defined before its child nodes.";
        throw IllegalStateException_init(message.toString());
      }
    }
    if (!!this.eventHandlers_0.containsKey_11rb$(eventName)) {
      var message_0 = "Only one '" + eventName + "' handler can be defined per element.";
      throw IllegalStateException_init(message_0.toString());
    }
    this.eventHandlers_0.put_xwzc9p$(eventName, KatydidNodeImpl$addEventHandler$lambda(handler));
  };
  KatydidNodeImpl.prototype.afterAddChildNode_x5x0wf$ = function (childNode) {
  };
  KatydidNodeImpl.prototype.establish_b3w3xb$ = function (domNode) {
    if (!(this.state_0.compareTo_11rb$(KatydidNodeImpl$EState$CONSTRUCTED_getInstance()) >= 0)) {
      var message = 'Katydid-VDOM node must be fully constructed before establishing the real DOM.';
      throw IllegalStateException_init(message.toString());
    }
    if (!(this.state_0.compareTo_11rb$(KatydidNodeImpl$EState$CONSTRUCTED_getInstance()) <= 0)) {
      var message_0 = 'Katydid-VDOM node already established.';
      throw IllegalStateException_init(message_0.toString());
    }
    if (!equals(domNode.nodeName, this.nodeName)) {
      var message_1 = 'Cannot establish a real DOM node differing in type from the Katydid-VDOM node.';
      throw IllegalArgumentException_init(message_1.toString());
    }
    if (!equals(this.nodeName, '#text')) {
      this.establishAttributes_b3w3xb$(domNode);
      this.establishEventHandlers_0(domNode);
      this.establishChildNodes_0(domNode);
    }
    this.domNode_0 = domNode;
    this.state_0 = KatydidNodeImpl$EState$ESTABLISHED_getInstance();
  };
  KatydidNodeImpl.prototype.establishChildNodes_0 = function (domNode) {
    var value = domNode.ownerDocument;
    var checkNotNull$result;
    if (value == null) {
      var message = 'DOM element must have an owner document.';
      throw IllegalStateException_init(message.toString());
    }
     else {
      checkNotNull$result = value;
    }
    var document = checkNotNull$result;
    var childNode = this.firstChildNode_0;
    while (childNode != null) {
      childNode.createDomNode_2xapuv$(document, domNode, null);
      childNode = childNode.nextSiblingNode_0;
    }
  };
  KatydidNodeImpl.prototype.establishEventHandlers_0 = function (domNode) {
    var tmp$;
    tmp$ = this.eventHandlers_0.entries.iterator();
    while (tmp$.hasNext()) {
      var tmp$_0 = tmp$.next();
      var key = tmp$_0.key;
      var eventHandler = tmp$_0.value;
      domNode.addEventListener(key, eventHandler);
    }
  };
  KatydidNodeImpl.prototype.freeze_0 = function () {
    if (!(this.state_0.compareTo_11rb$(KatydidNodeImpl$EState$CONSTRUCTED_getInstance()) <= 0)) {
      var message = 'Katydid-VDOM node already fully constructed.';
      throw IllegalStateException_init(message.toString());
    }
    if (this.isAddingAttributes_0) {
      this.freezeAttributes();
    }
    this.state_0 = KatydidNodeImpl$EState$CONSTRUCTED_getInstance();
  };
  KatydidNodeImpl.prototype.matches_0 = function (otherNode) {
    if (otherNode == null) {
      return false;
    }
    if (!equals(this.nodeName, otherNode.nodeName)) {
      return false;
    }
    return equals(this.key, otherNode.key);
  };
  KatydidNodeImpl.prototype.patch_x5x0wf$ = function (priorNode) {
    if (this === priorNode) {
      if (!this.isPatchedReplaced_0) {
        var message = 'New Katydid-VDOM node is identical to prior node but prior node has not been patched.';
        throw IllegalStateException_init(message.toString());
      }
      return;
    }
    if (!(this.state_0.compareTo_11rb$(KatydidNodeImpl$EState$CONSTRUCTED_getInstance()) >= 0)) {
      var message_0 = 'Katydid-VDOM node must be fully constructed before establishing the real DOM.';
      throw IllegalStateException_init(message_0.toString());
    }
    if (!(this.state_0.compareTo_11rb$(KatydidNodeImpl$EState$CONSTRUCTED_getInstance()) <= 0)) {
      var message_1 = 'Katydid-VDOM node already established.';
      throw IllegalStateException_init(message_1.toString());
    }
    if (!!priorNode.isPatchedRemoved_0) {
      var message_2 = 'Prior node cannot be patched after being removed.';
      throw IllegalStateException_init(message_2.toString());
    }
    if (!!priorNode.isPatchedReplaced_0) {
      var message_3 = 'Prior node cannot be patched twice.';
      throw IllegalStateException_init(message_3.toString());
    }
    if (!priorNode.isEstablished_0) {
      var message_4 = 'Prior Katydid-VDOM node must be established before patching. ' + priorNode.nodeName + '.' + toString(priorNode.key);
      throw IllegalStateException_init(message_4.toString());
    }
    if (!equals(priorNode.nodeName, this.nodeName)) {
      var message_5 = 'Cannot patch a difference between two Katydid-VDOM nodes of different types.';
      throw IllegalArgumentException_init(message_5.toString());
    }
    var value = priorNode.domNode_0;
    var checkNotNull$result;
    if (value == null) {
      var message_6 = 'Prior Katydid-VDOM node is not linked to its DOM node.';
      throw IllegalStateException_init(message_6.toString());
    }
     else {
      checkNotNull$result = value;
    }
    var domNode = checkNotNull$result;
    this.patchAttributes_jeu6e6$(domNode, priorNode);
    this.patchEventHandlers_0(domNode, priorNode);
    if (priorNode.firstChildNode_0 == null)
      this.establishChildNodes_0(domNode);
    else if (this.firstChildNode_0 == null)
      while (domNode.hasChildNodes()) {
        domNode.removeChild(ensureNotNull(domNode.firstChild));
      }
     else
      this.patchChildNodes_0(domNode, priorNode);
    this.domNode_0 = domNode;
    this.state_0 = KatydidNodeImpl$EState$ESTABLISHED_getInstance();
    priorNode.state_0 = KatydidNodeImpl$EState$PATCHED_REPLACED_getInstance();
  };
  KatydidNodeImpl.prototype.patchChildNodes_0 = function (domNode, priorNode) {
    var startChild = this.firstChildNode_0;
    var endChild = this.lastChildNode_0;
    var priorStartChild = priorNode.firstChildNode_0;
    var priorEndChild = priorNode.lastChildNode_0;
    var domChild = domNode.firstChild;
    var value = domNode.ownerDocument;
    var checkNotNull$result;
    if (value == null) {
      var message = 'DOM element must have an owner document.';
      throw IllegalStateException_init(message.toString());
    }
     else {
      checkNotNull$result = value;
    }
    var document = checkNotNull$result;
    while (startChild != null && endChild != null && !equals(startChild, endChild.nextSiblingNode_0) && !equals(endChild, startChild.prevSiblingNode_0)) {
      if (startChild.matches_0(priorStartChild)) {
        domChild = ensureNotNull(domChild).nextSibling;
        startChild.patch_x5x0wf$(ensureNotNull(priorStartChild));
        startChild = startChild.nextSiblingNode_0;
        priorStartChild = priorStartChild.nextSiblingNode_0;
      }
       else if (endChild.matches_0(priorEndChild)) {
        endChild.patch_x5x0wf$(ensureNotNull(priorEndChild));
        endChild = endChild.prevSiblingNode_0;
        priorEndChild = priorEndChild.prevSiblingNode_0;
      }
       else if (startChild.matches_0(priorEndChild)) {
        domNode.insertBefore(ensureNotNull(ensureNotNull(priorEndChild).domNode_0), domChild);
        startChild.patch_x5x0wf$(priorEndChild);
        startChild = startChild.nextSiblingNode_0;
        priorEndChild = priorEndChild.prevSiblingNode_0;
      }
       else if (endChild.matches_0(priorStartChild)) {
        if (endChild.nextSiblingNode_0 == null) {
          domNode.insertBefore(ensureNotNull(ensureNotNull(priorStartChild).domNode_0), null);
        }
         else {
          domNode.insertBefore(ensureNotNull(ensureNotNull(priorStartChild).domNode_0), ensureNotNull(endChild.nextSiblingNode_0).domNode_0);
        }
        endChild.patch_x5x0wf$(priorStartChild);
        endChild = endChild.prevSiblingNode_0;
        priorStartChild = priorStartChild.nextSiblingNode_0;
      }
       else {
        var priorChild = priorNode.childNodesByKey_0.get_11rb$(startChild.key);
        if (priorChild != null) {
          domNode.insertBefore(ensureNotNull(priorChild.domNode_0), domChild);
          startChild.patch_x5x0wf$(priorChild);
        }
         else {
          startChild.createDomNode_2xapuv$(document, domNode, domChild);
        }
        startChild = startChild.nextSiblingNode_0;
      }
    }
    while (priorStartChild != null && priorEndChild != null && !equals(priorStartChild, priorEndChild.nextSiblingNode_0)) {
      if (priorStartChild.isEstablished_0) {
        domNode.removeChild(ensureNotNull(priorStartChild.domNode_0));
        priorStartChild.state_0 = KatydidNodeImpl$EState$PATCHED_REMOVED_getInstance();
      }
      priorStartChild = priorStartChild.nextSiblingNode_0;
    }
  };
  KatydidNodeImpl.prototype.patchEventHandlers_0 = function (domNode, priorNode) {
    var tmp$, tmp$_0;
    tmp$ = this.eventHandlers_0.entries.iterator();
    while (tmp$.hasNext()) {
      var tmp$_1 = tmp$.next();
      var key = tmp$_1.key;
      var eventHandler = tmp$_1.value;
      if (!equals(eventHandler, priorNode.eventHandlers_0.get_11rb$(key))) {
        var priorEventHandler = priorNode.eventHandlers_0.get_11rb$(key);
        if (priorEventHandler != null) {
          domNode.removeEventListener(key, priorEventHandler);
        }
        domNode.addEventListener(key, eventHandler);
      }
    }
    tmp$_0 = priorNode.eventHandlers_0.entries.iterator();
    while (tmp$_0.hasNext()) {
      var tmp$_2 = tmp$_0.next();
      var key_0 = tmp$_2.key;
      var priorEventHandler_0 = tmp$_2.value;
      var $receiver = this.eventHandlers_0;
      var tmp$_3;
      if (!(Kotlin.isType(tmp$_3 = $receiver, Map) ? tmp$_3 : throwCCE()).containsKey_11rb$(key_0)) {
        domNode.removeEventListener(key_0, priorEventHandler_0);
      }
    }
  };
  KatydidNodeImpl.prototype.toString = function () {
    return '<' + this.nodeName.toLowerCase() + '>';
  };
  KatydidNodeImpl.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidNodeImpl',
    interfaces: [KatydidNode]
  };
  function KatydidRb(phrasingContent, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    KatydidHtmlElementImpl.call(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    defineContent(phrasingContent.withNoAddedRestrictions_bflrjy$(this));
    this.freeze_0();
    this.nodeName_ybep5v$_0 = 'RB';
  }
  Object.defineProperty(KatydidRb.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_ybep5v$_0;
    }
  });
  KatydidRb.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidRb',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidRp(phrasingContent, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    KatydidHtmlElementImpl.call(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    defineContent(phrasingContent.withNoAddedRestrictions_bflrjy$(this));
    this.freeze_0();
    this.nodeName_ql1ojz$_0 = 'RP';
  }
  Object.defineProperty(KatydidRp.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_ql1ojz$_0;
    }
  });
  KatydidRp.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidRp',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidRt(phrasingContent, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    KatydidHtmlElementImpl.call(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    defineContent(phrasingContent.withNoAddedRestrictions_bflrjy$(this));
    this.freeze_0();
    this.nodeName_3e96rv$_0 = 'RT';
  }
  Object.defineProperty(KatydidRt.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_3e96rv$_0;
    }
  });
  KatydidRt.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidRt',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidRtc(phrasingContent, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    KatydidHtmlElementImpl.call(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    defineContent(phrasingContent.rubyContent_bflrjy$(this));
    this.freeze_0();
    this.nodeName_70aooc$_0 = 'RTC';
  }
  Object.defineProperty(KatydidRtc.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_70aooc$_0;
    }
  });
  KatydidRtc.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidRtc',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidRuby(phrasingContent, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    KatydidHtmlElementImpl.call(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    defineContent(phrasingContent.rubyContent_bflrjy$(this));
    this.freeze_0();
    this.nodeName_nwjthp$_0 = 'RUBY';
  }
  Object.defineProperty(KatydidRuby.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_nwjthp$_0;
    }
  });
  KatydidRuby.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidRuby',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidCanvas() {
    this.nodeName_7e8hpc$_0 = 'CANVAS';
  }
  Object.defineProperty(KatydidCanvas.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_7e8hpc$_0;
    }
  });
  KatydidCanvas.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidCanvas',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidCanvas_init(embeddedContent, selector, key, accesskey, contenteditable, dir, draggable, height, hidden, lang, spellcheck, style, tabindex, title, translate, width, defineContent, $this) {
    $this = $this || Object.create(KatydidCanvas.prototype);
    KatydidHtmlElementImpl.call($this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    KatydidCanvas.call($this);
    $this.setNumberAttribute_hzlfav$('height', height);
    $this.setNumberAttribute_hzlfav$('width', width);
    defineContent(embeddedContent.withNoAddedRestrictions_bflrjy$($this));
    $this.freeze_0();
    return $this;
  }
  function KatydidCanvas_init_0(flowContent, selector, key, accesskey, contenteditable, dir, draggable, height, hidden, lang, spellcheck, style, tabindex, title, translate, width, defineContent, $this) {
    $this = $this || Object.create(KatydidCanvas.prototype);
    KatydidHtmlElementImpl.call($this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    KatydidCanvas.call($this);
    $this.setNumberAttribute_hzlfav$('height', height);
    $this.setNumberAttribute_hzlfav$('width', width);
    defineContent(flowContent.withNoAddedRestrictions_bflrjy$($this));
    $this.freeze_0();
    return $this;
  }
  function KatydidCanvas_init_1(phrasingContent, selector, key, accesskey, contenteditable, dir, draggable, height, hidden, lang, spellcheck, style, tabindex, title, translate, width, defineContent, $this) {
    $this = $this || Object.create(KatydidCanvas.prototype);
    KatydidHtmlElementImpl.call($this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    KatydidCanvas.call($this);
    $this.setNumberAttribute_hzlfav$('height', height);
    $this.setNumberAttribute_hzlfav$('width', width);
    defineContent(phrasingContent.withNoAddedRestrictions_bflrjy$($this));
    $this.freeze_0();
    return $this;
  }
  function KatydidArticle(flowContent, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    KatydidHtmlElementImpl.call(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    flowContent.contentRestrictions.confirmSectioningAllowed();
    defineContent(flowContent.withMainNotAllowed_bflrjy$(this));
    this.freeze_0();
    this.nodeName_7zf6jx$_0 = 'ARTICLE';
  }
  Object.defineProperty(KatydidArticle.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_7zf6jx$_0;
    }
  });
  KatydidArticle.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidArticle',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidAside(flowContent, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    KatydidHtmlElementImpl.call(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    flowContent.contentRestrictions.confirmSectioningAllowed();
    defineContent(flowContent.withMainNotAllowed_bflrjy$(this));
    this.freeze_0();
    this.nodeName_94smnj$_0 = 'ASIDE';
  }
  Object.defineProperty(KatydidAside.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_94smnj$_0;
    }
  });
  KatydidAside.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidAside',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidFooter(flowContent, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    KatydidHtmlElementImpl.call(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    flowContent.contentRestrictions.confirmFooterAllowed();
    defineContent(flowContent.withFooterHeaderMainNotAllowed_bflrjy$(this));
    this.freeze_0();
    this.nodeName_z1lazm$_0 = 'FOOTER';
  }
  Object.defineProperty(KatydidFooter.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_z1lazm$_0;
    }
  });
  KatydidFooter.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidFooter',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidH1(flowContent, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    KatydidHtmlElementImpl.call(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    flowContent.contentRestrictions.confirmHeadingsAllowed();
    defineContent(flowContent.phrasingContent_bflrjy$(this));
    this.freeze_0();
    this.nodeName_9wpvv4$_0 = 'H1';
  }
  Object.defineProperty(KatydidH1.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_9wpvv4$_0;
    }
  });
  KatydidH1.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidH1',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidH2(flowContent, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    KatydidHtmlElementImpl.call(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    flowContent.contentRestrictions.confirmHeadingsAllowed();
    defineContent(flowContent.phrasingContent_bflrjy$(this));
    this.freeze_0();
    this.nodeName_jt50of$_0 = 'H2';
  }
  Object.defineProperty(KatydidH2.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_jt50of$_0;
    }
  });
  KatydidH2.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidH2',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidH3(flowContent, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    KatydidHtmlElementImpl.call(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    flowContent.contentRestrictions.confirmHeadingsAllowed();
    defineContent(flowContent.phrasingContent_bflrjy$(this));
    this.freeze_0();
    this.nodeName_li44r6$_0 = 'H3';
  }
  Object.defineProperty(KatydidH3.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_li44r6$_0;
    }
  });
  KatydidH3.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidH3',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidH4(flowContent, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    KatydidHtmlElementImpl.call(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    flowContent.contentRestrictions.confirmHeadingsAllowed();
    defineContent(flowContent.phrasingContent_bflrjy$(this));
    this.freeze_0();
    this.nodeName_87qrsd$_0 = 'H4';
  }
  Object.defineProperty(KatydidH4.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_87qrsd$_0;
    }
  });
  KatydidH4.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidH4',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidH5(flowContent, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    KatydidHtmlElementImpl.call(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    flowContent.contentRestrictions.confirmHeadingsAllowed();
    defineContent(flowContent.phrasingContent_bflrjy$(this));
    this.freeze_0();
    this.nodeName_x3idn8$_0 = 'H5';
  }
  Object.defineProperty(KatydidH5.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_x3idn8$_0;
    }
  });
  KatydidH5.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidH5',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidH6(flowContent, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    KatydidHtmlElementImpl.call(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    flowContent.contentRestrictions.confirmHeadingsAllowed();
    defineContent(flowContent.phrasingContent_bflrjy$(this));
    this.freeze_0();
    this.nodeName_3dnh3p$_0 = 'H6';
  }
  Object.defineProperty(KatydidH6.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_3dnh3p$_0;
    }
  });
  KatydidH6.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidH6',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidHeader(flowContent, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    KatydidHtmlElementImpl.call(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    flowContent.contentRestrictions.confirmHeaderAllowed();
    defineContent(flowContent.withFooterHeaderMainNotAllowed_bflrjy$(this));
    this.freeze_0();
    this.nodeName_yk485w$_0 = 'HEADER';
  }
  Object.defineProperty(KatydidHeader.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_yk485w$_0;
    }
  });
  KatydidHeader.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidHeader',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidNav(flowContent, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    KatydidHtmlElementImpl.call(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    flowContent.contentRestrictions.confirmSectioningAllowed();
    defineContent(flowContent.withMainNotAllowed_bflrjy$(this));
    this.freeze_0();
    this.nodeName_svvom$_0 = 'NAV';
  }
  Object.defineProperty(KatydidNav.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_svvom$_0;
    }
  });
  KatydidNav.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidNav',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidSection(flowContent, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    KatydidHtmlElementImpl.call(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    flowContent.contentRestrictions.confirmSectioningAllowed();
    defineContent(flowContent.withNoAddedRestrictions_bflrjy$(this));
    this.freeze_0();
    this.nodeName_19bc2s$_0 = 'SECTION';
  }
  Object.defineProperty(KatydidSection.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_19bc2s$_0;
    }
  });
  KatydidSection.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidSection',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidCaption(tableContent, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    KatydidHtmlElementImpl.call(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    tableContent.tableContentRestrictions.confirmCaptionAllowed();
    defineContent(tableContent.flowContentWithTableNotAllowed_jl8rlo$(this));
    this.freeze_0();
    this.nodeName_b21yvq$_0 = 'CAPTION';
  }
  Object.defineProperty(KatydidCaption.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_b21yvq$_0;
    }
  });
  KatydidCaption.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidCaption',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidCol(colGroupContent, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, span, spellcheck, style, tabindex, title, translate, defineAttributes) {
    KatydidHtmlElementImpl.call(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    this.setNumberAttribute_hzlfav$('span', span);
    defineAttributes(colGroupContent.attributesContent_jftpzv$(this));
    this.freeze_0();
    this.nodeName_34a2kw$_0 = 'COL';
  }
  Object.defineProperty(KatydidCol.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_34a2kw$_0;
    }
  });
  KatydidCol.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidCol',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidColGroup() {
    this.nodeName_eww4zx$_0 = 'COLGROUP';
  }
  Object.defineProperty(KatydidColGroup.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_eww4zx$_0;
    }
  });
  KatydidColGroup.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidColGroup',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidColGroup_init(tableContent, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent, $this) {
    $this = $this || Object.create(KatydidColGroup.prototype);
    KatydidHtmlElementImpl.call($this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    KatydidColGroup.call($this);
    tableContent.tableContentRestrictions.confirmColGroupAllowed();
    defineContent(tableContent.colGroupContent_kjcqhn$($this));
    $this.freeze_0();
    return $this;
  }
  function KatydidColGroup_init_0(tableContent, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, span, spellcheck, style, tabindex, title, translate, defineAttributes, $this) {
    $this = $this || Object.create(KatydidColGroup.prototype);
    KatydidHtmlElementImpl.call($this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    KatydidColGroup.call($this);
    tableContent.tableContentRestrictions.confirmColGroupAllowed();
    $this.setNumberAttribute_hzlfav$('span', span);
    defineAttributes(tableContent.attributesContent_kjcqhn$($this));
    $this.freeze_0();
    return $this;
  }
  function KatydidTable(flowContent, selector, key, accesskey, border, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    KatydidHtmlElementImpl.call(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    flowContent.contentRestrictions.confirmTableAllowed();
    if (border != null) {
      this.setAttribute_jyasbz$('border', border ? '1' : '');
    }
    defineContent(flowContent.tableContent_th3er0$(this));
    this.freeze_0();
    this.nodeName_8j93i6$_0 = 'TABLE';
  }
  Object.defineProperty(KatydidTable.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_8j93i6$_0;
    }
  });
  KatydidTable.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidTable',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidTBody(tableContent, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    KatydidHtmlElementImpl.call(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    tableContent.tableContentRestrictions.confirmTBodyAllowed();
    defineContent(tableContent.tableBodyContent_bflrjy$(this));
    this.freeze_0();
    this.nodeName_jdxld2$_0 = 'TBODY';
  }
  Object.defineProperty(KatydidTBody.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_jdxld2$_0;
    }
  });
  KatydidTBody.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidTBody',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidTd(tableRowContent, selector, key, accesskey, colspan, contenteditable, dir, draggable, headers, hidden, lang, rowspan, spellcheck, style, tabindex, title, translate, defineContent) {
    KatydidHtmlElementImpl.call(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    this.setNumberAttribute_hzlfav$('colspan', colspan);
    this.setAttribute_jyasbz$('headers', headers);
    this.setNumberAttribute_hzlfav$('rowspan', rowspan);
    defineContent(tableRowContent.flowContent_bflrjy$(this));
    this.freeze_0();
    this.nodeName_cxyl7i$_0 = 'TD';
  }
  Object.defineProperty(KatydidTd.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_cxyl7i$_0;
    }
  });
  KatydidTd.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidTd',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidTFoot(tableContent, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    KatydidHtmlElementImpl.call(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    tableContent.tableContentRestrictions.confirmTFootAllowed();
    defineContent(tableContent.tableBodyContent_bflrjy$(this));
    this.freeze_0();
    this.nodeName_fye3hu$_0 = 'TFOOT';
  }
  Object.defineProperty(KatydidTFoot.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_fye3hu$_0;
    }
  });
  KatydidTFoot.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidTFoot',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidTh(tableRowContent, selector, key, abbr, accesskey, colspan, contenteditable, dir, draggable, headers, hidden, lang, rowspan, scope, spellcheck, style, tabindex, title, translate, defineContent) {
    KatydidHtmlElementImpl.call(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    this.setAttribute_jyasbz$('abbr', abbr);
    this.setNumberAttribute_hzlfav$('colspan', colspan);
    this.setAttribute_jyasbz$('headers', headers);
    this.setNumberAttribute_hzlfav$('rowspan', rowspan);
    this.setAttribute_jyasbz$('scope', scope != null ? scope.toHtmlString() : null);
    defineContent(tableRowContent.flowContent_bflrjy$(this));
    this.freeze_0();
    this.nodeName_ywcyzi$_0 = 'TH';
  }
  Object.defineProperty(KatydidTh.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_ywcyzi$_0;
    }
  });
  KatydidTh.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidTh',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidTHead(tableContent, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    KatydidHtmlElementImpl.call(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    tableContent.tableContentRestrictions.confirmTHeadAllowed();
    defineContent(tableContent.tableBodyContent_bflrjy$(this));
    this.freeze_0();
    this.nodeName_3uqspo$_0 = 'THEAD';
  }
  Object.defineProperty(KatydidTHead.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_3uqspo$_0;
    }
  });
  KatydidTHead.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidTHead',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidTr() {
    this.nodeName_n2m9gs$_0 = 'TR';
  }
  Object.defineProperty(KatydidTr.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_n2m9gs$_0;
    }
  });
  KatydidTr.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidTr',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidTr_init(tableContent, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent, $this) {
    $this = $this || Object.create(KatydidTr.prototype);
    KatydidHtmlElementImpl.call($this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    KatydidTr.call($this);
    tableContent.tableContentRestrictions.confirmTrAllowed();
    defineContent(tableContent.tableRowContent_rzem3q$($this));
    $this.freeze_0();
    return $this;
  }
  function KatydidTr_init_0(tableBodyContent, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent, $this) {
    $this = $this || Object.create(KatydidTr.prototype);
    KatydidHtmlElementImpl.call($this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    KatydidTr.call($this);
    defineContent(tableBodyContent.tableRowContent_rzem3q$($this));
    $this.freeze_0();
    return $this;
  }
  function KatydidA() {
    this.nodeName_z8q1fr$_0 = 'A';
  }
  KatydidA.prototype.setAttributes_0 = function (download, href, hreflang, rel, rev, target, type) {
    this.setAttribute_jyasbz$('download', download);
    this.setAttribute_jyasbz$('href', href);
    this.setAttribute_jyasbz$('hreflang', hreflang);
    if (rel != null) {
      this.setAttribute_jyasbz$('rel', joinToString(rel, ' ', void 0, void 0, void 0, void 0, getCallableRef('toHtmlString', function ($receiver) {
        return $receiver.toHtmlString();
      })));
    }
    if (rev != null) {
      this.setAttribute_jyasbz$('rev', joinToString(rev, ' ', void 0, void 0, void 0, void 0, getCallableRef('toHtmlString', function ($receiver) {
        return $receiver.toHtmlString();
      })));
    }
    this.setAttribute_jyasbz$('target', target);
    this.setAttribute_jyasbz$('type', type);
  };
  Object.defineProperty(KatydidA.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_z8q1fr$_0;
    }
  });
  KatydidA.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidA',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidA_init(phrasingContent, selector, key, accesskey, contenteditable, dir, download, draggable, hidden, href, hreflang, lang, rel, rev, spellcheck, style, tabindex, target, title, translate, type, defineContent, $this) {
    $this = $this || Object.create(KatydidA.prototype);
    KatydidHtmlElementImpl.call($this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    KatydidA.call($this);
    phrasingContent.contentRestrictions.confirmAnchorAllowed();
    if (href != null) {
      phrasingContent.contentRestrictions.confirmInteractiveContentAllowed();
    }
    $this.setAttributes_0(download, href, hreflang, rel, rev, target, type);
    defineContent(phrasingContent.withInteractiveContentNotAllowed_bflrjy$($this));
    $this.freeze_0();
    return $this;
  }
  function KatydidA_init_0(flowContent, selector, key, accesskey, contenteditable, dir, download, draggable, hidden, href, hreflang, lang, rel, rev, spellcheck, style, tabindex, target, title, translate, type, defineContent, $this) {
    $this = $this || Object.create(KatydidA.prototype);
    KatydidHtmlElementImpl.call($this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    KatydidA.call($this);
    flowContent.contentRestrictions.confirmAnchorAllowed();
    if (href != null) {
      flowContent.contentRestrictions.confirmInteractiveContentAllowed();
    }
    $this.setAttributes_0(download, href, hreflang, rel, rev, target, type);
    defineContent(flowContent.withInteractiveContentNotAllowed_bflrjy$($this));
    $this.freeze_0();
    return $this;
  }
  function KatydidAbbr(phrasingContent, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    KatydidHtmlElementImpl.call(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    defineContent(phrasingContent.withNoAddedRestrictions_bflrjy$(this));
    this.freeze_0();
    this.nodeName_xrq1xl$_0 = 'ABBR';
  }
  Object.defineProperty(KatydidAbbr.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_xrq1xl$_0;
    }
  });
  KatydidAbbr.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidAbbr',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidB(phrasingContent, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    KatydidHtmlElementImpl.call(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    defineContent(phrasingContent.withNoAddedRestrictions_bflrjy$(this));
    this.freeze_0();
    this.nodeName_62j3zu$_0 = 'B';
  }
  Object.defineProperty(KatydidB.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_62j3zu$_0;
    }
  });
  KatydidB.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidB',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidBdi(phrasingContent, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    KatydidHtmlElementImpl.call(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    defineContent(phrasingContent.withNoAddedRestrictions_bflrjy$(this));
    this.freeze_0();
    this.nodeName_gfwdq7$_0 = 'BDI';
  }
  Object.defineProperty(KatydidBdi.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_gfwdq7$_0;
    }
  });
  KatydidBdi.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidBdi',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidBdo(phrasingContent, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    KatydidHtmlElementImpl.call(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    if (!(dir !== EDirection$auto_getInstance())) {
      var message = 'Attribute dir must be ltr or rtl in a <bdo> element.';
      throw IllegalArgumentException_init(message.toString());
    }
    defineContent(phrasingContent.withNoAddedRestrictions_bflrjy$(this));
    this.freeze_0();
    this.nodeName_jt0xkr$_0 = 'BDO';
  }
  Object.defineProperty(KatydidBdo.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_jt0xkr$_0;
    }
  });
  KatydidBdo.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidBdo',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidBr(phrasingContent, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineAttributes) {
    KatydidHtmlElementImpl.call(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    defineAttributes(phrasingContent.attributesContent_bflrjy$(this));
    this.freeze_0();
    this.nodeName_38zhnu$_0 = 'BR';
  }
  Object.defineProperty(KatydidBr.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_38zhnu$_0;
    }
  });
  KatydidBr.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidBr',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidCite(phrasingContent, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    KatydidHtmlElementImpl.call(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    defineContent(phrasingContent.withNoAddedRestrictions_bflrjy$(this));
    this.freeze_0();
    this.nodeName_eukeqr$_0 = 'CITE';
  }
  Object.defineProperty(KatydidCite.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_eukeqr$_0;
    }
  });
  KatydidCite.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidCite',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidCode(phrasingContent, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    KatydidHtmlElementImpl.call(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    defineContent(phrasingContent.withNoAddedRestrictions_bflrjy$(this));
    this.freeze_0();
    this.nodeName_7379u5$_0 = 'CODE';
  }
  Object.defineProperty(KatydidCode.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_7379u5$_0;
    }
  });
  KatydidCode.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidCode',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidComment(_nodeValue, key) {
    KatydidNodeImpl.call(this, key);
    this.freeze_0();
    this.nodeName_bldudl$_0 = '#comment';
    this.nodeValue = _nodeValue;
  }
  Object.defineProperty(KatydidComment.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_bldudl$_0;
    }
  });
  KatydidComment.prototype.createDomNode_2xapuv$ = function (document, parentDomNode, followingDomChild) {
    var childComment = document.createComment(this.nodeValue);
    this.establish_b3w3xb$(childComment);
    parentDomNode.insertBefore(childComment, followingDomChild);
  };
  KatydidComment.prototype.establishAttributes_b3w3xb$ = function (domElement) {
  };
  KatydidComment.prototype.freezeAttributes = function () {
  };
  KatydidComment.prototype.patchAttributes_jeu6e6$ = function (domElement, priorElement) {
    if (!Kotlin.isType(domElement, Comment)) {
      var message = 'DOM node expected to be comment.';
      throw IllegalArgumentException_init(message.toString());
    }
    if (!Kotlin.isType(priorElement, KatydidComment)) {
      throw IllegalArgumentException_init('Katydid-VDOM node expected to be Katydid-VDOM comment.');
    }
    if (!equals(this.nodeValue, priorElement.nodeValue)) {
      domElement.nodeValue = this.nodeValue;
    }
  };
  KatydidComment.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidComment',
    interfaces: [KatydidNodeImpl]
  };
  function KatydidData(phrasingContent, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, value, defineContent) {
    KatydidHtmlElementImpl.call(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    this.setAttribute_jyasbz$('value', value);
    defineContent(phrasingContent.withNoAddedRestrictions_bflrjy$(this));
    this.freeze_0();
    this.nodeName_7kvmds$_0 = 'DATA';
  }
  Object.defineProperty(KatydidData.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_7kvmds$_0;
    }
  });
  KatydidData.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidData',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidDfn(phrasingContent, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    KatydidHtmlElementImpl.call(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    phrasingContent.contentRestrictions.confirmDfnAllowed();
    defineContent(phrasingContent.withDfnNotAllowed_bflrjy$(this));
    this.freeze_0();
    this.nodeName_4h629w$_0 = 'DFN';
  }
  Object.defineProperty(KatydidDfn.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_4h629w$_0;
    }
  });
  KatydidDfn.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidDfn',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidEm(phrasingContent, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    KatydidHtmlElementImpl.call(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    defineContent(phrasingContent.withNoAddedRestrictions_bflrjy$(this));
    this.freeze_0();
    this.nodeName_9omzou$_0 = 'EM';
  }
  Object.defineProperty(KatydidEm.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_9omzou$_0;
    }
  });
  KatydidEm.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidEm',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidI(phrasingContent, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    KatydidHtmlElementImpl.call(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    defineContent(phrasingContent.withNoAddedRestrictions_bflrjy$(this));
    this.freeze_0();
    this.nodeName_b4uy4h$_0 = 'I';
  }
  Object.defineProperty(KatydidI.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_b4uy4h$_0;
    }
  });
  KatydidI.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidI',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidKbd(phrasingContent, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    KatydidHtmlElementImpl.call(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    defineContent(phrasingContent.withNoAddedRestrictions_bflrjy$(this));
    this.freeze_0();
    this.nodeName_oywe4b$_0 = 'KBD';
  }
  Object.defineProperty(KatydidKbd.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_oywe4b$_0;
    }
  });
  KatydidKbd.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidKbd',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidMark(phrasingContent, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    KatydidHtmlElementImpl.call(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    defineContent(phrasingContent.withNoAddedRestrictions_bflrjy$(this));
    this.freeze_0();
    this.nodeName_t4knfx$_0 = 'MARK';
  }
  Object.defineProperty(KatydidMark.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_t4knfx$_0;
    }
  });
  KatydidMark.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidMark',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidQ(phrasingContent, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    KatydidHtmlElementImpl.call(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    defineContent(phrasingContent.withNoAddedRestrictions_bflrjy$(this));
    this.freeze_0();
    this.nodeName_dio4af$_0 = 'Q';
  }
  Object.defineProperty(KatydidQ.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_dio4af$_0;
    }
  });
  KatydidQ.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidQ',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidS(phrasingContent, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    KatydidHtmlElementImpl.call(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    defineContent(phrasingContent.withNoAddedRestrictions_bflrjy$(this));
    this.freeze_0();
    this.nodeName_1x9ved$_0 = 'S';
  }
  Object.defineProperty(KatydidS.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_1x9ved$_0;
    }
  });
  KatydidS.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidS',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidSamp(phrasingContent, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    KatydidHtmlElementImpl.call(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    defineContent(phrasingContent.withNoAddedRestrictions_bflrjy$(this));
    this.freeze_0();
    this.nodeName_pgrpqh$_0 = 'SAMP';
  }
  Object.defineProperty(KatydidSamp.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_pgrpqh$_0;
    }
  });
  KatydidSamp.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidSamp',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidSmall(phrasingContent, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    KatydidHtmlElementImpl.call(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    defineContent(phrasingContent.withNoAddedRestrictions_bflrjy$(this));
    this.freeze_0();
    this.nodeName_tyjoh$_0 = 'SMALL';
  }
  Object.defineProperty(KatydidSmall.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_tyjoh$_0;
    }
  });
  KatydidSmall.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidSmall',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidSpan(phrasingContent, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    KatydidHtmlElementImpl.call(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    defineContent(phrasingContent.withNoAddedRestrictions_bflrjy$(this));
    this.freeze_0();
    this.nodeName_6lk6ts$_0 = 'SPAN';
  }
  Object.defineProperty(KatydidSpan.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_6lk6ts$_0;
    }
  });
  KatydidSpan.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidSpan',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidStrong(phrasingContent, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    KatydidHtmlElementImpl.call(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    defineContent(phrasingContent.withNoAddedRestrictions_bflrjy$(this));
    this.freeze_0();
    this.nodeName_aad0kj$_0 = 'STRONG';
  }
  Object.defineProperty(KatydidStrong.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_aad0kj$_0;
    }
  });
  KatydidStrong.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidStrong',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidSub(phrasingContent, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    KatydidHtmlElementImpl.call(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    defineContent(phrasingContent.withNoAddedRestrictions_bflrjy$(this));
    this.freeze_0();
    this.nodeName_ytkoa0$_0 = 'SUB';
  }
  Object.defineProperty(KatydidSub.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_ytkoa0$_0;
    }
  });
  KatydidSub.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidSub',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidSup(phrasingContent, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    KatydidHtmlElementImpl.call(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    defineContent(phrasingContent.withNoAddedRestrictions_bflrjy$(this));
    this.freeze_0();
    this.nodeName_oox00q$_0 = 'SUP';
  }
  Object.defineProperty(KatydidSup.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_oox00q$_0;
    }
  });
  KatydidSup.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidSup',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidText(nodeValue, key) {
    KatydidNodeImpl.call(this, key);
    this.nodeValue = nodeValue;
    this.freeze_0();
    this.nodeName_6kc2tp$_0 = '#text';
  }
  Object.defineProperty(KatydidText.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_6kc2tp$_0;
    }
  });
  KatydidText.prototype.createDomNode_2xapuv$ = function (document, parentDomNode, followingDomChild) {
    var childText = document.createTextNode(this.nodeValue);
    this.establish_b3w3xb$(childText);
    parentDomNode.insertBefore(childText, followingDomChild);
  };
  KatydidText.prototype.establishAttributes_b3w3xb$ = function (domElement) {
  };
  KatydidText.prototype.freezeAttributes = function () {
  };
  KatydidText.prototype.patchAttributes_jeu6e6$ = function (domElement, priorElement) {
    if (!Kotlin.isType(domElement, Text)) {
      var message = 'DOM node expected to be text.';
      throw IllegalArgumentException_init(message.toString());
    }
    if (!Kotlin.isType(priorElement, KatydidText)) {
      throw IllegalArgumentException_init('Katydid-VDOM node expected to be Katydid-VDOM text.');
    }
    if (!equals(this.nodeValue, priorElement.nodeValue)) {
      domElement.nodeValue = this.nodeValue;
    }
  };
  KatydidText.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidText',
    interfaces: [KatydidNodeImpl]
  };
  function KatydidTime() {
    this.nodeName_tv90vh$_0 = 'TIME';
  }
  Object.defineProperty(KatydidTime.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_tv90vh$_0;
    }
  });
  KatydidTime.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidTime',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidTime_init(phrasingContent, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent, $this) {
    $this = $this || Object.create(KatydidTime.prototype);
    KatydidHtmlElementImpl.call($this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    KatydidTime.call($this);
    defineContent(phrasingContent.textContent_bflrjy$($this));
    $this.freeze_0();
    return $this;
  }
  function KatydidTime_init_0(phrasingContent, selector, key, accesskey, contenteditable, datetime, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent, $this) {
    $this = $this || Object.create(KatydidTime.prototype);
    KatydidHtmlElementImpl.call($this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    KatydidTime.call($this);
    $this.setDateTimeAttribute_qhpdwr$('datetime', datetime);
    defineContent(phrasingContent.withNoAddedRestrictions_bflrjy$($this));
    $this.freeze_0();
    return $this;
  }
  function KatydidU(phrasingContent, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    KatydidHtmlElementImpl.call(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    defineContent(phrasingContent.withNoAddedRestrictions_bflrjy$(this));
    this.freeze_0();
    this.nodeName_9o4dhp$_0 = 'U';
  }
  Object.defineProperty(KatydidU.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_9o4dhp$_0;
    }
  });
  KatydidU.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidU',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidVar(phrasingContent, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) {
    KatydidHtmlElementImpl.call(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    defineContent(phrasingContent.withNoAddedRestrictions_bflrjy$(this));
    this.freeze_0();
    this.nodeName_ohjy7$_0 = 'VAR';
  }
  Object.defineProperty(KatydidVar.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_ohjy7$_0;
    }
  });
  KatydidVar.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidVar',
    interfaces: [KatydidHtmlElementImpl]
  };
  function KatydidWbr(phrasingContent, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineAttributes) {
    KatydidHtmlElementImpl.call(this, selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate);
    defineAttributes(phrasingContent.attributesContent_bflrjy$(this));
    this.freeze_0();
    this.nodeName_21cee9$_0 = 'WBR';
  }
  Object.defineProperty(KatydidWbr.prototype, 'nodeName', {
    get: function () {
      return this.nodeName_21cee9$_0;
    }
  });
  KatydidWbr.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidWbr',
    interfaces: [KatydidHtmlElementImpl]
  };
  function UnusedMap() {
  }
  Object.defineProperty(UnusedMap.prototype, 'entries', {
    get: function () {
      throw UnsupportedOperationException_init('Attempted to use unused map.');
    }
  });
  Object.defineProperty(UnusedMap.prototype, 'keys', {
    get: function () {
      throw UnsupportedOperationException_init('Attempted to use unused map.');
    }
  });
  Object.defineProperty(UnusedMap.prototype, 'size', {
    get: function () {
      throw UnsupportedOperationException_init('Attempted to use unused map.');
    }
  });
  Object.defineProperty(UnusedMap.prototype, 'values', {
    get: function () {
      throw UnsupportedOperationException_init('Attempted to use unused map.');
    }
  });
  UnusedMap.prototype.clear = function () {
    throw UnsupportedOperationException_init('Attempted to use unused map.');
  };
  UnusedMap.prototype.containsKey_11rb$ = function (key) {
    throw UnsupportedOperationException_init('Attempted to use unused map.');
  };
  UnusedMap.prototype.containsValue_11rc$ = function (value) {
    throw UnsupportedOperationException_init('Attempted to use unused map.');
  };
  UnusedMap.prototype.get_11rb$ = function (key) {
    throw UnsupportedOperationException_init('Attempted to use unused map.');
  };
  UnusedMap.prototype.isEmpty = function () {
    throw UnsupportedOperationException_init('Attempted to use unused map.');
  };
  UnusedMap.prototype.put_xwzc9p$ = function (key, value) {
    throw UnsupportedOperationException_init('Attempted to use unused map.');
  };
  UnusedMap.prototype.putAll_a2k3zr$ = function (from) {
    throw UnsupportedOperationException_init('Attempted to use unused map.');
  };
  UnusedMap.prototype.remove_11rb$ = function (key) {
    throw UnsupportedOperationException_init('Attempted to use unused map.');
  };
  UnusedMap.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'UnusedMap',
    interfaces: [MutableMap]
  };
  function UnusedSet() {
  }
  Object.defineProperty(UnusedSet.prototype, 'size', {
    get: function () {
      throw UnsupportedOperationException_init('Attempted to use unused set.');
    }
  });
  UnusedSet.prototype.add_11rb$ = function (element) {
    throw UnsupportedOperationException_init('Attempted to use unused set.');
  };
  UnusedSet.prototype.addAll_brywnq$ = function (elements) {
    throw UnsupportedOperationException_init('Attempted to use unused set.');
  };
  UnusedSet.prototype.clear = function () {
    throw UnsupportedOperationException_init('Attempted to use unused set.');
  };
  UnusedSet.prototype.contains_11rb$ = function (element) {
    throw UnsupportedOperationException_init('Attempted to use unused set.');
  };
  UnusedSet.prototype.containsAll_brywnq$ = function (elements) {
    throw UnsupportedOperationException_init('Attempted to use unused set.');
  };
  UnusedSet.prototype.isEmpty = function () {
    throw UnsupportedOperationException_init('Attempted to use unused set.');
  };
  UnusedSet.prototype.iterator = function () {
    throw UnsupportedOperationException_init('Attempted to use unused set.');
  };
  UnusedSet.prototype.remove_11rb$ = function (element) {
    throw UnsupportedOperationException_init('Attempted to use unused set.');
  };
  UnusedSet.prototype.removeAll_brywnq$ = function (elements) {
    throw UnsupportedOperationException_init('Attempted to use unused set.');
  };
  UnusedSet.prototype.retainAll_brywnq$ = function (elements) {
    throw UnsupportedOperationException_init('Attempted to use unused set.');
  };
  UnusedSet.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'UnusedSet',
    interfaces: [MutableSet]
  };
  function KatydidLifecycleImpl() {
  }
  KatydidLifecycleImpl.prototype.build_f7u8rf$ = function (domElement, katydidElement) {
    var tmp$;
    var document = ensureNotNull(domElement.ownerDocument);
    var root = document.createElement(katydidElement.nodeName);
    (Kotlin.isType(tmp$ = katydidElement, KatydidHtmlElementImpl) ? tmp$ : throwCCE()).establish_b3w3xb$(root);
    var parent = ensureNotNull(domElement.parentNode);
    parent.insertBefore(root, domElement);
    parent.removeChild(domElement);
  };
  KatydidLifecycleImpl.prototype.patch_9em544$ = function (oldKatydidElement, newKatydidElement) {
    var tmp$, tmp$_0;
    (Kotlin.isType(tmp$ = newKatydidElement, KatydidHtmlElementImpl) ? tmp$ : throwCCE()).patch_x5x0wf$(Kotlin.isType(tmp$_0 = oldKatydidElement, KatydidHtmlElementImpl) ? tmp$_0 : throwCCE());
  };
  KatydidLifecycleImpl.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidLifecycleImpl',
    interfaces: [KatydidLifecycle]
  };
  function KatydidApplicationCycle(newApplicationState, commandsToExecute) {
    if (commandsToExecute === void 0) {
      commandsToExecute = emptyList();
    }
    this.newApplicationState = newApplicationState;
    this.commandsToExecute = commandsToExecute;
  }
  KatydidApplicationCycle.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidApplicationCycle',
    interfaces: []
  };
  KatydidApplicationCycle.prototype.component1 = function () {
    return this.newApplicationState;
  };
  KatydidApplicationCycle.prototype.component2 = function () {
    return this.commandsToExecute;
  };
  KatydidApplicationCycle.prototype.copy_8ju7wx$ = function (newApplicationState, commandsToExecute) {
    return new KatydidApplicationCycle(newApplicationState === void 0 ? this.newApplicationState : newApplicationState, commandsToExecute === void 0 ? this.commandsToExecute : commandsToExecute);
  };
  KatydidApplicationCycle.prototype.toString = function () {
    return 'KatydidApplicationCycle(newApplicationState=' + Kotlin.toString(this.newApplicationState) + (', commandsToExecute=' + Kotlin.toString(this.commandsToExecute)) + ')';
  };
  KatydidApplicationCycle.prototype.hashCode = function () {
    var result = 0;
    result = result * 31 + Kotlin.hashCode(this.newApplicationState) | 0;
    result = result * 31 + Kotlin.hashCode(this.commandsToExecute) | 0;
    return result;
  };
  KatydidApplicationCycle.prototype.equals = function (other) {
    return this === other || (other !== null && (typeof other === 'object' && (Object.getPrototypeOf(this) === Object.getPrototypeOf(other) && (Kotlin.equals(this.newApplicationState, other.newApplicationState) && Kotlin.equals(this.commandsToExecute, other.commandsToExecute)))));
  };
  function KatydidApplication() {
  }
  KatydidApplication.$metadata$ = {
    kind: Kind_INTERFACE,
    simpleName: 'KatydidApplication',
    interfaces: []
  };
  function runApplication$lambda$lambda($receiver) {
    return Unit;
  }
  function runApplication$lambda($receiver) {
    $receiver.div_6zr3om$('#application', void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, runApplication$lambda$lambda);
    return Unit;
  }
  function runApplication$dispatch$lambda$lambda(closure$application, closure$appState) {
    return function ($receiver) {
      closure$application.view_11rb$(closure$appState.v)($receiver);
      return Unit;
    };
  }
  function runApplication$dispatch$lambda(closure$queuedMessages, closure$application, closure$appState, closure$appVdomNode, closure$dispatch, closure$lifecycle) {
    return function () {
      var tmp$, tmp$_0;
      var queuedCommands = ArrayList_init();
      tmp$ = closure$queuedMessages.iterator();
      while (tmp$.hasNext()) {
        var queuedMessage = tmp$.next();
        var updateResult = closure$application.update_xwzc9p$(closure$appState.v, queuedMessage);
        closure$appState.v = updateResult.newApplicationState;
        queuedCommands.addAll_brywnq$(updateResult.commandsToExecute);
      }
      closure$queuedMessages.clear();
      var oldAppVdomNode = closure$appVdomNode.v;
      closure$appVdomNode.v = katydid(getCallableRef('dispatch', function (messages) {
        return closure$dispatch(messages), Unit;
      }), runApplication$dispatch$lambda$lambda(closure$application, closure$appState));
      closure$lifecycle.patch_9em544$(oldAppVdomNode, closure$appVdomNode.v);
      tmp$_0 = queuedCommands.iterator();
      while (tmp$_0.hasNext()) {
        var cmd = tmp$_0.next();
        cmd(getCallableRef('dispatch', function (messages) {
          return closure$dispatch(messages), Unit;
        }));
      }
      return Unit;
    };
  }
  function runApplication$dispatch(closure$queuedMessages, closure$application, closure$appState, closure$appVdomNode, closure$lifecycle) {
    return function closure$dispatch(messages) {
      var processingNeeded = closure$queuedMessages.isEmpty();
      addAll(closure$queuedMessages, messages);
      if (processingNeeded) {
        window.setTimeout(runApplication$dispatch$lambda(closure$queuedMessages, closure$application, closure$appState, closure$appVdomNode, closure$dispatch, closure$lifecycle), 0);
      }
    };
  }
  function runApplication$lambda_0(closure$application, closure$appState) {
    return function ($receiver) {
      closure$application.view_11rb$(closure$appState.v)($receiver);
      return Unit;
    };
  }
  function runApplication(applicationDomId, application) {
    var tmp$;
    var tmp$_0 = application.initialize();
    var appState = {v: tmp$_0.component1()}
    , initialCommands = tmp$_0.component2();
    var lifecycle = makeKatydidLifecycle();
    var appVdomNode = {v: katydid(void 0, runApplication$lambda)};
    var queuedMessages = ArrayList_init();
    var dispatch = runApplication$dispatch(queuedMessages, application, appState, appVdomNode, lifecycle);
    appVdomNode.v = katydid(getCallableRef('dispatch', function (messages) {
      return dispatch(messages), Unit;
    }), runApplication$lambda_0(application, appState));
    var appElement = ensureNotNull(document.getElementById(applicationDomId));
    lifecycle.build_f7u8rf$(appElement, appVdomNode.v);
    tmp$ = initialCommands.iterator();
    while (tmp$.hasNext()) {
      var cmd = tmp$.next();
      cmd(getCallableRef('dispatch', function (messages) {
        return dispatch(messages), Unit;
      }));
    }
  }
  function katydid$lambda(it) {
    return Unit;
  }
  function katydid(dispatchMessages, defineContent) {
    if (dispatchMessages === void 0)
      dispatchMessages = katydid$lambda;
    var tmp$;
    var pseudoParentElement = new KatydidAppPseudoNode();
    pseudoParentElement.fill_2syken$(dispatchMessages, defineContent);
    return Kotlin.isType(tmp$ = pseudoParentElement.soleChildNode, KatydidHtmlElementImpl) ? tmp$ : throwCCE();
  }
  function katydidComponent(builder, defineContent) {
    return defineContent(builder);
  }
  function katydidListItemsComponent(builder, defineContent) {
    return defineContent(builder);
  }
  function katydidListItemsComponent_0(builder, defineContent) {
    return defineContent(builder);
  }
  function katydidPhrasingComponent(builder, defineContent) {
    return defineContent(builder);
  }
  function makeKatydidLifecycle() {
    return new KatydidLifecycleImpl();
  }
  function KatydidLifecycle() {
  }
  KatydidLifecycle.$metadata$ = {
    kind: Kind_INTERFACE,
    simpleName: 'KatydidLifecycle',
    interfaces: []
  };
  function KatydidDetailsFlowContentBuilder() {
  }
  KatydidDetailsFlowContentBuilder.prototype.summary_qckjfy$ = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) : this.summary_qckjfy$$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent);
  };
  KatydidDetailsFlowContentBuilder.prototype.summaryHeading_8h2c3u$ = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) : this.summaryHeading_8h2c3u$$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent);
  };
  KatydidDetailsFlowContentBuilder.$metadata$ = {
    kind: Kind_INTERFACE,
    simpleName: 'KatydidDetailsFlowContentBuilder',
    interfaces: [KatydidFlowContentBuilder]
  };
  function KatydidAttributesContentBuilder() {
  }
  KatydidAttributesContentBuilder.$metadata$ = {
    kind: Kind_INTERFACE,
    simpleName: 'KatydidAttributesContentBuilder',
    interfaces: []
  };
  function KatydidContentBuilderDsl() {
  }
  KatydidContentBuilderDsl.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidContentBuilderDsl',
    interfaces: [Annotation]
  };
  function KatydidEmbeddedContentBuilder() {
  }
  KatydidEmbeddedContentBuilder.prototype.audio_if4zjc$ = function (selector, key, accesskey, autoplay, contenteditable, controls, crossorigin, dir, draggable, hidden, lang, loop, muted, preload, spellcheck, src, style, tabindex, title, translate, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (autoplay === void 0)
      autoplay = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (controls === void 0)
      controls = null;
    if (crossorigin === void 0)
      crossorigin = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (loop === void 0)
      loop = null;
    if (muted === void 0)
      muted = null;
    if (preload === void 0)
      preload = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (src === void 0)
      src = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    callback$default ? callback$default(selector, key, accesskey, autoplay, contenteditable, controls, crossorigin, dir, draggable, hidden, lang, loop, muted, preload, spellcheck, src, style, tabindex, title, translate, defineContent) : this.audio_if4zjc$$default(selector, key, accesskey, autoplay, contenteditable, controls, crossorigin, dir, draggable, hidden, lang, loop, muted, preload, spellcheck, src, style, tabindex, title, translate, defineContent);
  };
  KatydidEmbeddedContentBuilder.prototype.canvas_ablpy6$ = function (selector, key, accesskey, contenteditable, dir, draggable, height, hidden, lang, spellcheck, style, tabindex, title, translate, width, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (height === void 0)
      height = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    if (width === void 0)
      width = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, draggable, height, hidden, lang, spellcheck, style, tabindex, title, translate, width, defineContent) : this.canvas_ablpy6$$default(selector, key, accesskey, contenteditable, dir, draggable, height, hidden, lang, spellcheck, style, tabindex, title, translate, width, defineContent);
  };
  KatydidEmbeddedContentBuilder.prototype.embed_nx0pss$ = function (selector, key, accesskey, contenteditable, dir, draggable, height, hidden, lang, spellcheck, src, style, tabindex, title, translate, type, width, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (height === void 0)
      height = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    if (type === void 0)
      type = null;
    if (width === void 0)
      width = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, draggable, height, hidden, lang, spellcheck, src, style, tabindex, title, translate, type, width, defineContent) : this.embed_nx0pss$$default(selector, key, accesskey, contenteditable, dir, draggable, height, hidden, lang, spellcheck, src, style, tabindex, title, translate, type, width, defineContent);
  };
  KatydidEmbeddedContentBuilder.prototype.iframe_6rhnbj$ = function (selector, key, accesskey, allowfullscreen, allowpaymentrequest, contenteditable, dir, draggable, height, hidden, lang, name, referrerpolicy, sandbox, spellcheck, src, srcdoc, style, tabindex, title, translate, width, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (allowfullscreen === void 0)
      allowfullscreen = null;
    if (allowpaymentrequest === void 0)
      allowpaymentrequest = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (height === void 0)
      height = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (name === void 0)
      name = null;
    if (referrerpolicy === void 0)
      referrerpolicy = null;
    if (sandbox === void 0)
      sandbox = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (srcdoc === void 0)
      srcdoc = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    if (width === void 0)
      width = null;
    callback$default ? callback$default(selector, key, accesskey, allowfullscreen, allowpaymentrequest, contenteditable, dir, draggable, height, hidden, lang, name, referrerpolicy, sandbox, spellcheck, src, srcdoc, style, tabindex, title, translate, width, defineContent) : this.iframe_6rhnbj$$default(selector, key, accesskey, allowfullscreen, allowpaymentrequest, contenteditable, dir, draggable, height, hidden, lang, name, referrerpolicy, sandbox, spellcheck, src, srcdoc, style, tabindex, title, translate, width, defineContent);
  };
  KatydidEmbeddedContentBuilder.prototype.img_fdnnaq$ = function (selector, key, accesskey, alt, contenteditable, crossorigin, dir, draggable, height, hidden, ismap, lang, referrerpolicy, sizes, spellcheck, src, srcset, style, tabindex, title, translate, usemap, width, defineAttributes, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (crossorigin === void 0)
      crossorigin = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (height === void 0)
      height = null;
    if (hidden === void 0)
      hidden = null;
    if (ismap === void 0)
      ismap = null;
    if (lang === void 0)
      lang = null;
    if (referrerpolicy === void 0)
      referrerpolicy = null;
    if (sizes === void 0)
      sizes = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (srcset === void 0)
      srcset = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    if (usemap === void 0)
      usemap = null;
    if (width === void 0)
      width = null;
    callback$default ? callback$default(selector, key, accesskey, alt, contenteditable, crossorigin, dir, draggable, height, hidden, ismap, lang, referrerpolicy, sizes, spellcheck, src, srcset, style, tabindex, title, translate, usemap, width, defineAttributes) : this.img_fdnnaq$$default(selector, key, accesskey, alt, contenteditable, crossorigin, dir, draggable, height, hidden, ismap, lang, referrerpolicy, sizes, spellcheck, src, srcset, style, tabindex, title, translate, usemap, width, defineAttributes);
  };
  KatydidEmbeddedContentBuilder.prototype.object_ggcu0x$ = function (selector, key, accesskey, contenteditable, data, dir, draggable, form, height, hidden, lang, name, spellcheck, style, tabindex, title, translate, type, typemustmatch, width, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (data === void 0)
      data = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (form === void 0)
      form = null;
    if (height === void 0)
      height = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (name === void 0)
      name = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    if (type === void 0)
      type = null;
    if (typemustmatch === void 0)
      typemustmatch = null;
    if (width === void 0)
      width = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, data, dir, draggable, form, height, hidden, lang, name, spellcheck, style, tabindex, title, translate, type, typemustmatch, width, defineContent) : this.object_ggcu0x$$default(selector, key, accesskey, contenteditable, data, dir, draggable, form, height, hidden, lang, name, spellcheck, style, tabindex, title, translate, type, typemustmatch, width, defineContent);
  };
  KatydidEmbeddedContentBuilder.prototype.picture_r7gn0k$ = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) : this.picture_r7gn0k$$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent);
  };
  KatydidEmbeddedContentBuilder.prototype.video_n6slad$ = function (selector, key, accesskey, autoplay, contenteditable, controls, crossorigin, dir, draggable, height, hidden, lang, loop, muted, poster, preload, spellcheck, src, style, tabindex, title, translate, width, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (autoplay === void 0)
      autoplay = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (controls === void 0)
      controls = null;
    if (crossorigin === void 0)
      crossorigin = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (height === void 0)
      height = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (loop === void 0)
      loop = null;
    if (muted === void 0)
      muted = null;
    if (poster === void 0)
      poster = null;
    if (preload === void 0)
      preload = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (src === void 0)
      src = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    if (width === void 0)
      width = null;
    callback$default ? callback$default(selector, key, accesskey, autoplay, contenteditable, controls, crossorigin, dir, draggable, height, hidden, lang, loop, muted, poster, preload, spellcheck, src, style, tabindex, title, translate, width, defineContent) : this.video_n6slad$$default(selector, key, accesskey, autoplay, contenteditable, controls, crossorigin, dir, draggable, height, hidden, lang, loop, muted, poster, preload, spellcheck, src, style, tabindex, title, translate, width, defineContent);
  };
  KatydidEmbeddedContentBuilder.$metadata$ = {
    kind: Kind_INTERFACE,
    simpleName: 'KatydidEmbeddedContentBuilder',
    interfaces: [KatydidAttributesContentBuilder]
  };
  function KatydidFlowContentBuilder() {
  }
  KatydidFlowContentBuilder.prototype.a_3jwxqy$ = function (selector, key, accesskey, contenteditable, dir, download, draggable, hidden, href, hreflang, lang, rel, rev, spellcheck, style, tabindex, target, title, translate, type, contentType, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (download === void 0)
      download = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (href === void 0)
      href = null;
    if (hreflang === void 0)
      hreflang = null;
    if (lang === void 0)
      lang = null;
    if (rel === void 0)
      rel = null;
    if (rev === void 0)
      rev = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (target === void 0)
      target = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    if (type === void 0)
      type = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, download, draggable, hidden, href, hreflang, lang, rel, rev, spellcheck, style, tabindex, target, title, translate, type, contentType, defineContent) : this.a_3jwxqy$$default(selector, key, accesskey, contenteditable, dir, download, draggable, hidden, href, hreflang, lang, rel, rev, spellcheck, style, tabindex, target, title, translate, type, contentType, defineContent);
  };
  KatydidFlowContentBuilder.prototype.address_6zr3om$ = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) : this.address_6zr3om$$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent);
  };
  KatydidFlowContentBuilder.prototype.audio_tp0mfx$ = function (selector, key, accesskey, autoplay, contenteditable, controls, crossorigin, dir, draggable, hidden, lang, loop, muted, preload, spellcheck, src, style, tabindex, title, translate, contentType, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (autoplay === void 0)
      autoplay = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (controls === void 0)
      controls = null;
    if (crossorigin === void 0)
      crossorigin = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (loop === void 0)
      loop = null;
    if (muted === void 0)
      muted = null;
    if (preload === void 0)
      preload = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (src === void 0)
      src = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    callback$default ? callback$default(selector, key, accesskey, autoplay, contenteditable, controls, crossorigin, dir, draggable, hidden, lang, loop, muted, preload, spellcheck, src, style, tabindex, title, translate, contentType, defineContent) : this.audio_tp0mfx$$default(selector, key, accesskey, autoplay, contenteditable, controls, crossorigin, dir, draggable, hidden, lang, loop, muted, preload, spellcheck, src, style, tabindex, title, translate, contentType, defineContent);
  };
  KatydidFlowContentBuilder.prototype.blockquote_rfnrw3$ = function (selector, key, accesskey, cite, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (cite === void 0)
      cite = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    callback$default ? callback$default(selector, key, accesskey, cite, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) : this.blockquote_rfnrw3$$default(selector, key, accesskey, cite, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent);
  };
  KatydidFlowContentBuilder.prototype.canvas_p01gpz$ = function (selector, key, accesskey, contenteditable, dir, draggable, height, hidden, lang, spellcheck, style, tabindex, title, translate, width, contentType, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (height === void 0)
      height = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    if (width === void 0)
      width = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, draggable, height, hidden, lang, spellcheck, style, tabindex, title, translate, width, contentType, defineContent) : this.canvas_p01gpz$$default(selector, key, accesskey, contenteditable, dir, draggable, height, hidden, lang, spellcheck, style, tabindex, title, translate, width, contentType, defineContent);
  };
  KatydidFlowContentBuilder.prototype.details_k8gqqw$ = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, open, spellcheck, style, tabindex, title, translate, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (open === void 0)
      open = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, open, spellcheck, style, tabindex, title, translate, defineContent) : this.details_k8gqqw$$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, open, spellcheck, style, tabindex, title, translate, defineContent);
  };
  KatydidFlowContentBuilder.prototype.dialog_rmrn7i$ = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, open, spellcheck, style, tabindex, title, translate, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (open === void 0)
      open = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, open, spellcheck, style, tabindex, title, translate, defineContent) : this.dialog_rmrn7i$$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, open, spellcheck, style, tabindex, title, translate, defineContent);
  };
  KatydidFlowContentBuilder.prototype.del_pat60j$ = function (selector, key, accesskey, cite, contenteditable, datetime, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, contentType, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (cite === void 0)
      cite = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (datetime === void 0)
      datetime = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    callback$default ? callback$default(selector, key, accesskey, cite, contenteditable, datetime, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, contentType, defineContent) : this.del_pat60j$$default(selector, key, accesskey, cite, contenteditable, datetime, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, contentType, defineContent);
  };
  KatydidFlowContentBuilder.prototype.div_6zr3om$ = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) : this.div_6zr3om$$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent);
  };
  KatydidFlowContentBuilder.prototype.dl_a7rbte$ = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) : this.dl_a7rbte$$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent);
  };
  KatydidFlowContentBuilder.prototype.fieldset_wkcbaa$ = function (selector, key, accesskey, contenteditable, dir, disabled, draggable, form, hidden, lang, name, spellcheck, style, tabindex, title, translate, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (disabled === void 0)
      disabled = null;
    if (draggable === void 0)
      draggable = null;
    if (form === void 0)
      form = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (name === void 0)
      name = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, disabled, draggable, form, hidden, lang, name, spellcheck, style, tabindex, title, translate, defineContent) : this.fieldset_wkcbaa$$default(selector, key, accesskey, contenteditable, dir, disabled, draggable, form, hidden, lang, name, spellcheck, style, tabindex, title, translate, defineContent);
  };
  KatydidFlowContentBuilder.prototype.figCaption_6zr3om$ = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) : this.figCaption_6zr3om$$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent);
  };
  KatydidFlowContentBuilder.prototype.figure_6zr3om$ = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) : this.figure_6zr3om$$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent);
  };
  KatydidFlowContentBuilder.prototype.footer_6zr3om$ = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) : this.footer_6zr3om$$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent);
  };
  KatydidFlowContentBuilder.prototype.form_roosm5$ = function (selector, key, acceptCharset, accesskey, action, autocomplete, contenteditable, dir, draggable, enctype, hidden, lang, method, name, novalidate, spellcheck, style, tabindex, target, title, translate, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (acceptCharset === void 0)
      acceptCharset = null;
    if (accesskey === void 0)
      accesskey = null;
    if (action === void 0)
      action = null;
    if (autocomplete === void 0)
      autocomplete = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (enctype === void 0)
      enctype = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (method === void 0)
      method = null;
    if (name === void 0)
      name = null;
    if (novalidate === void 0)
      novalidate = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (target === void 0)
      target = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    callback$default ? callback$default(selector, key, acceptCharset, accesskey, action, autocomplete, contenteditable, dir, draggable, enctype, hidden, lang, method, name, novalidate, spellcheck, style, tabindex, target, title, translate, defineContent) : this.form_roosm5$$default(selector, key, acceptCharset, accesskey, action, autocomplete, contenteditable, dir, draggable, enctype, hidden, lang, method, name, novalidate, spellcheck, style, tabindex, target, title, translate, defineContent);
  };
  KatydidFlowContentBuilder.prototype.header_6zr3om$ = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) : this.header_6zr3om$$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent);
  };
  KatydidFlowContentBuilder.prototype.hr_9mj9vz$ = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineAttributes, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineAttributes) : this.hr_9mj9vz$$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineAttributes);
  };
  KatydidFlowContentBuilder.prototype.ins_pat60j$ = function (selector, key, accesskey, cite, contenteditable, datetime, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, contentType, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (cite === void 0)
      cite = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (datetime === void 0)
      datetime = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    callback$default ? callback$default(selector, key, accesskey, cite, contenteditable, datetime, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, contentType, defineContent) : this.ins_pat60j$$default(selector, key, accesskey, cite, contenteditable, datetime, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, contentType, defineContent);
  };
  KatydidFlowContentBuilder.prototype.legend_qckjfy$ = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) : this.legend_qckjfy$$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent);
  };
  KatydidFlowContentBuilder.prototype.main_6zr3om$ = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) : this.main_6zr3om$$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent);
  };
  KatydidFlowContentBuilder.prototype.map_io1brw$ = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, name, spellcheck, style, tabindex, title, translate, contentType, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (name === void 0)
      name = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, name, spellcheck, style, tabindex, title, translate, contentType, defineContent) : this.map_io1brw$$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, name, spellcheck, style, tabindex, title, translate, contentType, defineContent);
  };
  KatydidFlowContentBuilder.prototype.object_649euk$ = function (selector, key, accesskey, contenteditable, data, dir, draggable, form, height, hidden, lang, name, spellcheck, style, tabindex, title, translate, type, typemustmatch, width, contentType, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (data === void 0)
      data = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (form === void 0)
      form = null;
    if (height === void 0)
      height = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (name === void 0)
      name = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    if (type === void 0)
      type = null;
    if (typemustmatch === void 0)
      typemustmatch = null;
    if (width === void 0)
      width = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, data, dir, draggable, form, height, hidden, lang, name, spellcheck, style, tabindex, title, translate, type, typemustmatch, width, contentType, defineContent) : this.object_649euk$$default(selector, key, accesskey, contenteditable, data, dir, draggable, form, height, hidden, lang, name, spellcheck, style, tabindex, title, translate, type, typemustmatch, width, contentType, defineContent);
  };
  KatydidFlowContentBuilder.prototype.ol_5bxxpo$ = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, reversed, spellcheck, start, style, tabindex, title, translate, type, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (reversed === void 0)
      reversed = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (start === void 0)
      start = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    if (type === void 0)
      type = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, reversed, spellcheck, start, style, tabindex, title, translate, type, defineContent) : this.ol_5bxxpo$$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, reversed, spellcheck, start, style, tabindex, title, translate, type, defineContent);
  };
  KatydidFlowContentBuilder.prototype.p_qckjfy$ = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) : this.p_qckjfy$$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent);
  };
  KatydidFlowContentBuilder.prototype.pre_qckjfy$ = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) : this.pre_qckjfy$$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent);
  };
  KatydidFlowContentBuilder.prototype.table_55vzb3$ = function (selector, key, accesskey, border, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (border === void 0)
      border = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    callback$default ? callback$default(selector, key, accesskey, border, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) : this.table_55vzb3$$default(selector, key, accesskey, border, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent);
  };
  KatydidFlowContentBuilder.prototype.ul_hxau5b$ = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) : this.ul_hxau5b$$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent);
  };
  KatydidFlowContentBuilder.prototype.video_hpee3a$ = function (selector, key, accesskey, autoplay, contenteditable, controls, crossorigin, dir, draggable, height, hidden, lang, loop, muted, poster, preload, spellcheck, src, style, tabindex, title, translate, width, contentType, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (autoplay === void 0)
      autoplay = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (controls === void 0)
      controls = null;
    if (crossorigin === void 0)
      crossorigin = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (height === void 0)
      height = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (loop === void 0)
      loop = null;
    if (muted === void 0)
      muted = null;
    if (poster === void 0)
      poster = null;
    if (preload === void 0)
      preload = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (src === void 0)
      src = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    if (width === void 0)
      width = null;
    callback$default ? callback$default(selector, key, accesskey, autoplay, contenteditable, controls, crossorigin, dir, draggable, height, hidden, lang, loop, muted, poster, preload, spellcheck, src, style, tabindex, title, translate, width, contentType, defineContent) : this.video_hpee3a$$default(selector, key, accesskey, autoplay, contenteditable, controls, crossorigin, dir, draggable, height, hidden, lang, loop, muted, poster, preload, spellcheck, src, style, tabindex, title, translate, width, contentType, defineContent);
  };
  KatydidFlowContentBuilder.$metadata$ = {
    kind: Kind_INTERFACE,
    simpleName: 'KatydidFlowContentBuilder',
    interfaces: [KatydidSectioningContentBuilder, KatydidHeadingContentBuilder, KatydidPhrasingContentBuilder]
  };
  function KatydidHeadingContentBuilder() {
  }
  KatydidHeadingContentBuilder.prototype.h1_qckjfy$ = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) : this.h1_qckjfy$$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent);
  };
  KatydidHeadingContentBuilder.prototype.h2_qckjfy$ = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) : this.h2_qckjfy$$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent);
  };
  KatydidHeadingContentBuilder.prototype.h3_qckjfy$ = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) : this.h3_qckjfy$$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent);
  };
  KatydidHeadingContentBuilder.prototype.h4_qckjfy$ = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) : this.h4_qckjfy$$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent);
  };
  KatydidHeadingContentBuilder.prototype.h5_qckjfy$ = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) : this.h5_qckjfy$$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent);
  };
  KatydidHeadingContentBuilder.prototype.h6_qckjfy$ = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) : this.h6_qckjfy$$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent);
  };
  KatydidHeadingContentBuilder.$metadata$ = {
    kind: Kind_INTERFACE,
    simpleName: 'KatydidHeadingContentBuilder',
    interfaces: [KatydidAttributesContentBuilder]
  };
  function KatydidPhrasingContentBuilder() {
  }
  KatydidPhrasingContentBuilder.prototype.a_ncyfe7$ = function (selector, key, accesskey, contenteditable, dir, download, draggable, hidden, href, hreflang, lang, rel, rev, spellcheck, style, tabindex, target, title, translate, type, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (download === void 0)
      download = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (href === void 0)
      href = null;
    if (hreflang === void 0)
      hreflang = null;
    if (lang === void 0)
      lang = null;
    if (rel === void 0)
      rel = null;
    if (rev === void 0)
      rev = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (target === void 0)
      target = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    if (type === void 0)
      type = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, download, draggable, hidden, href, hreflang, lang, rel, rev, spellcheck, style, tabindex, target, title, translate, type, defineContent) : this.a_ncyfe7$$default(selector, key, accesskey, contenteditable, dir, download, draggable, hidden, href, hreflang, lang, rel, rev, spellcheck, style, tabindex, target, title, translate, type, defineContent);
  };
  KatydidPhrasingContentBuilder.prototype.abbr_qckjfy$ = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) : this.abbr_qckjfy$$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent);
  };
  KatydidPhrasingContentBuilder.prototype.area_ys14xf$ = function (selector, key, accesskey, alt, contenteditable, coords, dir, download, draggable, hidden, href, hreflang, lang, referrerpolicy, rel, spellcheck, shape, style, tabindex, target, title, translate, type, defineAttributes, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (alt === void 0)
      alt = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (coords === void 0)
      coords = null;
    if (dir === void 0)
      dir = null;
    if (download === void 0)
      download = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (href === void 0)
      href = null;
    if (hreflang === void 0)
      hreflang = null;
    if (lang === void 0)
      lang = null;
    if (referrerpolicy === void 0)
      referrerpolicy = null;
    if (rel === void 0)
      rel = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (shape === void 0)
      shape = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (target === void 0)
      target = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    if (type === void 0)
      type = null;
    callback$default ? callback$default(selector, key, accesskey, alt, contenteditable, coords, dir, download, draggable, hidden, href, hreflang, lang, referrerpolicy, rel, spellcheck, shape, style, tabindex, target, title, translate, type, defineAttributes) : this.area_ys14xf$$default(selector, key, accesskey, alt, contenteditable, coords, dir, download, draggable, hidden, href, hreflang, lang, referrerpolicy, rel, spellcheck, shape, style, tabindex, target, title, translate, type, defineAttributes);
  };
  KatydidPhrasingContentBuilder.prototype.audio_z5y2od$ = function (selector, key, accesskey, autoplay, contenteditable, controls, crossorigin, dir, draggable, hidden, lang, loop, muted, preload, spellcheck, src, style, tabindex, title, translate, contentType, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (autoplay === void 0)
      autoplay = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (controls === void 0)
      controls = null;
    if (crossorigin === void 0)
      crossorigin = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (loop === void 0)
      loop = null;
    if (muted === void 0)
      muted = null;
    if (preload === void 0)
      preload = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (src === void 0)
      src = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    callback$default ? callback$default(selector, key, accesskey, autoplay, contenteditable, controls, crossorigin, dir, draggable, hidden, lang, loop, muted, preload, spellcheck, src, style, tabindex, title, translate, contentType, defineContent) : this.audio_z5y2od$$default(selector, key, accesskey, autoplay, contenteditable, controls, crossorigin, dir, draggable, hidden, lang, loop, muted, preload, spellcheck, src, style, tabindex, title, translate, contentType, defineContent);
  };
  KatydidPhrasingContentBuilder.prototype.b_qckjfy$ = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) : this.b_qckjfy$$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent);
  };
  KatydidPhrasingContentBuilder.prototype.bdi_g2kg67$ = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) : this.bdi_g2kg67$$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent);
  };
  KatydidPhrasingContentBuilder.prototype.bdo_g2kg67$ = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) : this.bdo_g2kg67$$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent);
  };
  KatydidPhrasingContentBuilder.prototype.br_9mj9vz$ = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineAttributes, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineAttributes) : this.br_9mj9vz$$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineAttributes);
  };
  KatydidPhrasingContentBuilder.prototype.button_2lxa1r$ = function (selector, key, accesskey, autofocus, contenteditable, dir, disabled, draggable, form, formaction, formenctype, formmethod, formnovalidate, formtarget, hidden, lang, name, spellcheck, style, tabindex, title, translate, type, value, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (autofocus === void 0)
      autofocus = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (disabled === void 0)
      disabled = null;
    if (draggable === void 0)
      draggable = null;
    if (form === void 0)
      form = null;
    if (formaction === void 0)
      formaction = null;
    if (formenctype === void 0)
      formenctype = null;
    if (formmethod === void 0)
      formmethod = null;
    if (formnovalidate === void 0)
      formnovalidate = null;
    if (formtarget === void 0)
      formtarget = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (name === void 0)
      name = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    if (type === void 0)
      type = EButtonType$button_getInstance();
    if (value === void 0)
      value = null;
    callback$default ? callback$default(selector, key, accesskey, autofocus, contenteditable, dir, disabled, draggable, form, formaction, formenctype, formmethod, formnovalidate, formtarget, hidden, lang, name, spellcheck, style, tabindex, title, translate, type, value, defineContent) : this.button_2lxa1r$$default(selector, key, accesskey, autofocus, contenteditable, dir, disabled, draggable, form, formaction, formenctype, formmethod, formnovalidate, formtarget, hidden, lang, name, spellcheck, style, tabindex, title, translate, type, value, defineContent);
  };
  KatydidPhrasingContentBuilder.prototype.canvas_zeuq1z$ = function (selector, key, accesskey, contenteditable, dir, draggable, height, hidden, lang, spellcheck, style, tabindex, title, translate, width, contentType, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (height === void 0)
      height = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    if (width === void 0)
      width = null;
    if (contentType === void 0)
      contentType = PhrasingContent_getInstance();
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, draggable, height, hidden, lang, spellcheck, style, tabindex, title, translate, width, contentType, defineContent) : this.canvas_zeuq1z$$default(selector, key, accesskey, contenteditable, dir, draggable, height, hidden, lang, spellcheck, style, tabindex, title, translate, width, contentType, defineContent);
  };
  KatydidPhrasingContentBuilder.prototype.cite_qckjfy$ = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) : this.cite_qckjfy$$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent);
  };
  KatydidPhrasingContentBuilder.prototype.code_qckjfy$ = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) : this.code_qckjfy$$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent);
  };
  KatydidPhrasingContentBuilder.prototype.comment_4w9ihe$ = function (nodeValue, key, callback$default) {
    if (key === void 0)
      key = null;
    callback$default ? callback$default(nodeValue, key) : this.comment_4w9ihe$$default(nodeValue, key);
  };
  KatydidPhrasingContentBuilder.prototype.data_cn0i2o$ = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, value, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, value, defineContent) : this.data_cn0i2o$$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, value, defineContent);
  };
  KatydidPhrasingContentBuilder.prototype.datalist_csvf3w$ = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) : this.datalist_csvf3w$$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent);
  };
  KatydidPhrasingContentBuilder.prototype.datalist_zf5udj$ = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, contentType, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, contentType, defineContent) : this.datalist_zf5udj$$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, contentType, defineContent);
  };
  KatydidPhrasingContentBuilder.prototype.del_smchxe$ = function (selector, key, accesskey, cite, contenteditable, datetime, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (cite === void 0)
      cite = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (datetime === void 0)
      datetime = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    callback$default ? callback$default(selector, key, accesskey, cite, contenteditable, datetime, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) : this.del_smchxe$$default(selector, key, accesskey, cite, contenteditable, datetime, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent);
  };
  KatydidPhrasingContentBuilder.prototype.dfn_qckjfy$ = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) : this.dfn_qckjfy$$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent);
  };
  KatydidPhrasingContentBuilder.prototype.em_qckjfy$ = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) : this.em_qckjfy$$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent);
  };
  KatydidPhrasingContentBuilder.prototype.i_qckjfy$ = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) : this.i_qckjfy$$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent);
  };
  KatydidPhrasingContentBuilder.prototype.inputButton_kk2d6s$ = function (selector, key, accesskey, contenteditable, dir, disabled, draggable, form, hidden, lang, name, spellcheck, style, tabindex, title, translate, value, defineAttributes, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (disabled === void 0)
      disabled = null;
    if (draggable === void 0)
      draggable = null;
    if (form === void 0)
      form = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (name === void 0)
      name = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    if (value === void 0)
      value = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, disabled, draggable, form, hidden, lang, name, spellcheck, style, tabindex, title, translate, value, defineAttributes) : this.inputButton_kk2d6s$$default(selector, key, accesskey, contenteditable, dir, disabled, draggable, form, hidden, lang, name, spellcheck, style, tabindex, title, translate, value, defineAttributes);
  };
  KatydidPhrasingContentBuilder.prototype.inputCheckbox_5idhkk$ = function (selector, key, accesskey, autofocus, checked, contenteditable, dir, disabled, draggable, form, hidden, lang, name, required, spellcheck, style, tabindex, title, translate, value, defineAttributes, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (autofocus === void 0)
      autofocus = null;
    if (checked === void 0)
      checked = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (disabled === void 0)
      disabled = null;
    if (draggable === void 0)
      draggable = null;
    if (form === void 0)
      form = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (name === void 0)
      name = null;
    if (required === void 0)
      required = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    if (value === void 0)
      value = null;
    callback$default ? callback$default(selector, key, accesskey, autofocus, checked, contenteditable, dir, disabled, draggable, form, hidden, lang, name, required, spellcheck, style, tabindex, title, translate, value, defineAttributes) : this.inputCheckbox_5idhkk$$default(selector, key, accesskey, autofocus, checked, contenteditable, dir, disabled, draggable, form, hidden, lang, name, required, spellcheck, style, tabindex, title, translate, value, defineAttributes);
  };
  KatydidPhrasingContentBuilder.prototype.inputColor_9zybug$ = function (selector, key, accesskey, autocomplete, autofocus, contenteditable, dir, disabled, draggable, form, hidden, lang, list, name, spellcheck, style, tabindex, title, translate, value, defineAttributes, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (autocomplete === void 0)
      autocomplete = null;
    if (autofocus === void 0)
      autofocus = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (disabled === void 0)
      disabled = null;
    if (draggable === void 0)
      draggable = null;
    if (form === void 0)
      form = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (list === void 0)
      list = null;
    if (name === void 0)
      name = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    if (value === void 0)
      value = null;
    callback$default ? callback$default(selector, key, accesskey, autocomplete, autofocus, contenteditable, dir, disabled, draggable, form, hidden, lang, list, name, spellcheck, style, tabindex, title, translate, value, defineAttributes) : this.inputColor_9zybug$$default(selector, key, accesskey, autocomplete, autofocus, contenteditable, dir, disabled, draggable, form, hidden, lang, list, name, spellcheck, style, tabindex, title, translate, value, defineAttributes);
  };
  KatydidPhrasingContentBuilder.prototype.inputDate_3kgd4t$ = function (selector, key, accesskey, autocomplete, autofocus, contenteditable, dir, disabled, draggable, form, hidden, lang, list, max, min, name, readonly, required, spellcheck, step, style, tabindex, title, translate, value, defineAttributes, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (autocomplete === void 0)
      autocomplete = null;
    if (autofocus === void 0)
      autofocus = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (disabled === void 0)
      disabled = null;
    if (draggable === void 0)
      draggable = null;
    if (form === void 0)
      form = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (list === void 0)
      list = null;
    if (max === void 0)
      max = null;
    if (min === void 0)
      min = null;
    if (name === void 0)
      name = null;
    if (readonly === void 0)
      readonly = null;
    if (required === void 0)
      required = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (step === void 0)
      step = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    if (value === void 0)
      value = null;
    callback$default ? callback$default(selector, key, accesskey, autocomplete, autofocus, contenteditable, dir, disabled, draggable, form, hidden, lang, list, max, min, name, readonly, required, spellcheck, step, style, tabindex, title, translate, value, defineAttributes) : this.inputDate_3kgd4t$$default(selector, key, accesskey, autocomplete, autofocus, contenteditable, dir, disabled, draggable, form, hidden, lang, list, max, min, name, readonly, required, spellcheck, step, style, tabindex, title, translate, value, defineAttributes);
  };
  KatydidPhrasingContentBuilder.prototype.inputDateTimeLocal_3kgd4t$ = function (selector, key, accesskey, autocomplete, autofocus, contenteditable, dir, disabled, draggable, form, hidden, lang, list, max, min, name, readonly, required, spellcheck, step, style, tabindex, title, translate, value, defineAttributes, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (autocomplete === void 0)
      autocomplete = null;
    if (autofocus === void 0)
      autofocus = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (disabled === void 0)
      disabled = null;
    if (draggable === void 0)
      draggable = null;
    if (form === void 0)
      form = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (list === void 0)
      list = null;
    if (max === void 0)
      max = null;
    if (min === void 0)
      min = null;
    if (name === void 0)
      name = null;
    if (readonly === void 0)
      readonly = null;
    if (required === void 0)
      required = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (step === void 0)
      step = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    if (value === void 0)
      value = null;
    callback$default ? callback$default(selector, key, accesskey, autocomplete, autofocus, contenteditable, dir, disabled, draggable, form, hidden, lang, list, max, min, name, readonly, required, spellcheck, step, style, tabindex, title, translate, value, defineAttributes) : this.inputDateTimeLocal_3kgd4t$$default(selector, key, accesskey, autocomplete, autofocus, contenteditable, dir, disabled, draggable, form, hidden, lang, list, max, min, name, readonly, required, spellcheck, step, style, tabindex, title, translate, value, defineAttributes);
  };
  KatydidPhrasingContentBuilder.prototype.inputEmail_44r9ep$ = function (selector, key, accesskey, autocomplete, autofocus, contenteditable, dir, disabled, draggable, form, hidden, lang, list, maxlength, minlength, multiple, name, pattern, placeholder, readonly, required, size, spellcheck, style, tabindex, title, translate, value, defineAttributes, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (autocomplete === void 0)
      autocomplete = null;
    if (autofocus === void 0)
      autofocus = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (disabled === void 0)
      disabled = null;
    if (draggable === void 0)
      draggable = null;
    if (form === void 0)
      form = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (list === void 0)
      list = null;
    if (maxlength === void 0)
      maxlength = null;
    if (minlength === void 0)
      minlength = null;
    if (multiple === void 0)
      multiple = null;
    if (name === void 0)
      name = null;
    if (pattern === void 0)
      pattern = null;
    if (placeholder === void 0)
      placeholder = null;
    if (readonly === void 0)
      readonly = null;
    if (required === void 0)
      required = null;
    if (size === void 0)
      size = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    if (value === void 0)
      value = null;
    callback$default ? callback$default(selector, key, accesskey, autocomplete, autofocus, contenteditable, dir, disabled, draggable, form, hidden, lang, list, maxlength, minlength, multiple, name, pattern, placeholder, readonly, required, size, spellcheck, style, tabindex, title, translate, value, defineAttributes) : this.inputEmail_44r9ep$$default(selector, key, accesskey, autocomplete, autofocus, contenteditable, dir, disabled, draggable, form, hidden, lang, list, maxlength, minlength, multiple, name, pattern, placeholder, readonly, required, size, spellcheck, style, tabindex, title, translate, value, defineAttributes);
  };
  KatydidPhrasingContentBuilder.prototype.inputFile_8v4l2x$ = function (selector, key, accept, accesskey, autofocus, contenteditable, dir, disabled, draggable, form, hidden, lang, multiple, name, required, spellcheck, style, tabindex, title, translate, value, defineAttributes, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accept === void 0)
      accept = null;
    if (accesskey === void 0)
      accesskey = null;
    if (autofocus === void 0)
      autofocus = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (disabled === void 0)
      disabled = null;
    if (draggable === void 0)
      draggable = null;
    if (form === void 0)
      form = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (multiple === void 0)
      multiple = null;
    if (name === void 0)
      name = null;
    if (required === void 0)
      required = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    if (value === void 0)
      value = null;
    callback$default ? callback$default(selector, key, accept, accesskey, autofocus, contenteditable, dir, disabled, draggable, form, hidden, lang, multiple, name, required, spellcheck, style, tabindex, title, translate, value, defineAttributes) : this.inputFile_8v4l2x$$default(selector, key, accept, accesskey, autofocus, contenteditable, dir, disabled, draggable, form, hidden, lang, multiple, name, required, spellcheck, style, tabindex, title, translate, value, defineAttributes);
  };
  KatydidPhrasingContentBuilder.prototype.inputHidden_kk2d6s$ = function (selector, key, accesskey, contenteditable, dir, disabled, draggable, form, hidden, lang, name, spellcheck, style, tabindex, title, translate, value, defineAttributes, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (disabled === void 0)
      disabled = null;
    if (draggable === void 0)
      draggable = null;
    if (form === void 0)
      form = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (name === void 0)
      name = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    if (value === void 0)
      value = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, disabled, draggable, form, hidden, lang, name, spellcheck, style, tabindex, title, translate, value, defineAttributes) : this.inputHidden_kk2d6s$$default(selector, key, accesskey, contenteditable, dir, disabled, draggable, form, hidden, lang, name, spellcheck, style, tabindex, title, translate, value, defineAttributes);
  };
  KatydidPhrasingContentBuilder.prototype.inputImageButton_ojhf04$ = function (selector, key, accesskey, alt, contenteditable, dir, disabled, draggable, form, formaction, formenctype, formmethod, formnovalidate, formtarget, height, hidden, lang, name, spellcheck, src, style, tabindex, title, translate, width, defineAttributes, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (alt === void 0)
      alt = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (disabled === void 0)
      disabled = null;
    if (draggable === void 0)
      draggable = null;
    if (form === void 0)
      form = null;
    if (formaction === void 0)
      formaction = null;
    if (formenctype === void 0)
      formenctype = null;
    if (formmethod === void 0)
      formmethod = null;
    if (formnovalidate === void 0)
      formnovalidate = null;
    if (formtarget === void 0)
      formtarget = null;
    if (height === void 0)
      height = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (name === void 0)
      name = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    if (width === void 0)
      width = null;
    callback$default ? callback$default(selector, key, accesskey, alt, contenteditable, dir, disabled, draggable, form, formaction, formenctype, formmethod, formnovalidate, formtarget, height, hidden, lang, name, spellcheck, src, style, tabindex, title, translate, width, defineAttributes) : this.inputImageButton_ojhf04$$default(selector, key, accesskey, alt, contenteditable, dir, disabled, draggable, form, formaction, formenctype, formmethod, formnovalidate, formtarget, height, hidden, lang, name, spellcheck, src, style, tabindex, title, translate, width, defineAttributes);
  };
  KatydidPhrasingContentBuilder.prototype.inputMonth_3kgd4t$ = function (selector, key, accesskey, autocomplete, autofocus, contenteditable, dir, disabled, draggable, form, hidden, lang, list, max, min, name, readonly, required, spellcheck, step, style, tabindex, title, translate, value, defineAttributes, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (autocomplete === void 0)
      autocomplete = null;
    if (autofocus === void 0)
      autofocus = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (disabled === void 0)
      disabled = null;
    if (draggable === void 0)
      draggable = null;
    if (form === void 0)
      form = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (list === void 0)
      list = null;
    if (max === void 0)
      max = null;
    if (min === void 0)
      min = null;
    if (name === void 0)
      name = null;
    if (readonly === void 0)
      readonly = null;
    if (required === void 0)
      required = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (step === void 0)
      step = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    if (value === void 0)
      value = null;
    callback$default ? callback$default(selector, key, accesskey, autocomplete, autofocus, contenteditable, dir, disabled, draggable, form, hidden, lang, list, max, min, name, readonly, required, spellcheck, step, style, tabindex, title, translate, value, defineAttributes) : this.inputMonth_3kgd4t$$default(selector, key, accesskey, autocomplete, autofocus, contenteditable, dir, disabled, draggable, form, hidden, lang, list, max, min, name, readonly, required, spellcheck, step, style, tabindex, title, translate, value, defineAttributes);
  };
  KatydidPhrasingContentBuilder.prototype.inputNumber_xtj0dk$ = function (selector, key, accesskey, autocomplete, autofocus, contenteditable, dir, disabled, draggable, form, hidden, lang, list, max, min, name, placeholder, readonly, required, spellcheck, step, style, tabindex, title, translate, value, defineAttributes, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (autocomplete === void 0)
      autocomplete = null;
    if (autofocus === void 0)
      autofocus = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (disabled === void 0)
      disabled = null;
    if (draggable === void 0)
      draggable = null;
    if (form === void 0)
      form = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (list === void 0)
      list = null;
    if (max === void 0)
      max = null;
    if (min === void 0)
      min = null;
    if (name === void 0)
      name = null;
    if (placeholder === void 0)
      placeholder = null;
    if (readonly === void 0)
      readonly = null;
    if (required === void 0)
      required = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (step === void 0)
      step = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    if (value === void 0)
      value = null;
    callback$default ? callback$default(selector, key, accesskey, autocomplete, autofocus, contenteditable, dir, disabled, draggable, form, hidden, lang, list, max, min, name, placeholder, readonly, required, spellcheck, step, style, tabindex, title, translate, value, defineAttributes) : this.inputNumber_xtj0dk$$default(selector, key, accesskey, autocomplete, autofocus, contenteditable, dir, disabled, draggable, form, hidden, lang, list, max, min, name, placeholder, readonly, required, spellcheck, step, style, tabindex, title, translate, value, defineAttributes);
  };
  KatydidPhrasingContentBuilder.prototype.inputNumber_25std2$ = function (selector, key, accesskey, autocomplete, autofocus, contenteditable, dir, disabled, draggable, form, hidden, lang, list, max, min, name, placeholder, readonly, required, spellcheck, step, style, tabindex, title, translate, value, defineAttributes, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (autocomplete === void 0)
      autocomplete = null;
    if (autofocus === void 0)
      autofocus = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (disabled === void 0)
      disabled = null;
    if (draggable === void 0)
      draggable = null;
    if (form === void 0)
      form = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (list === void 0)
      list = null;
    if (max === void 0)
      max = null;
    if (min === void 0)
      min = null;
    if (name === void 0)
      name = null;
    if (placeholder === void 0)
      placeholder = null;
    if (readonly === void 0)
      readonly = null;
    if (required === void 0)
      required = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (step === void 0)
      step = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    if (value === void 0)
      value = null;
    callback$default ? callback$default(selector, key, accesskey, autocomplete, autofocus, contenteditable, dir, disabled, draggable, form, hidden, lang, list, max, min, name, placeholder, readonly, required, spellcheck, step, style, tabindex, title, translate, value, defineAttributes) : this.inputNumber_25std2$$default(selector, key, accesskey, autocomplete, autofocus, contenteditable, dir, disabled, draggable, form, hidden, lang, list, max, min, name, placeholder, readonly, required, spellcheck, step, style, tabindex, title, translate, value, defineAttributes);
  };
  KatydidPhrasingContentBuilder.prototype.inputPassword_98xs2q$ = function (selector, key, accesskey, autocomplete, autofocus, contenteditable, dir, disabled, draggable, form, hidden, lang, maxlength, minlength, name, pattern, placeholder, readonly, required, size, spellcheck, style, tabindex, title, translate, value, defineAttributes, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (autocomplete === void 0)
      autocomplete = null;
    if (autofocus === void 0)
      autofocus = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (disabled === void 0)
      disabled = null;
    if (draggable === void 0)
      draggable = null;
    if (form === void 0)
      form = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (maxlength === void 0)
      maxlength = null;
    if (minlength === void 0)
      minlength = null;
    if (name === void 0)
      name = null;
    if (pattern === void 0)
      pattern = null;
    if (placeholder === void 0)
      placeholder = null;
    if (readonly === void 0)
      readonly = null;
    if (required === void 0)
      required = null;
    if (size === void 0)
      size = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    if (value === void 0)
      value = null;
    callback$default ? callback$default(selector, key, accesskey, autocomplete, autofocus, contenteditable, dir, disabled, draggable, form, hidden, lang, maxlength, minlength, name, pattern, placeholder, readonly, required, size, spellcheck, style, tabindex, title, translate, value, defineAttributes) : this.inputPassword_98xs2q$$default(selector, key, accesskey, autocomplete, autofocus, contenteditable, dir, disabled, draggable, form, hidden, lang, maxlength, minlength, name, pattern, placeholder, readonly, required, size, spellcheck, style, tabindex, title, translate, value, defineAttributes);
  };
  KatydidPhrasingContentBuilder.prototype.inputRadioButton_5idhkk$ = function (selector, key, accesskey, autofocus, checked, contenteditable, dir, disabled, draggable, form, hidden, lang, name, required, spellcheck, style, tabindex, title, translate, value, defineAttributes, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (autofocus === void 0)
      autofocus = null;
    if (checked === void 0)
      checked = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (disabled === void 0)
      disabled = null;
    if (draggable === void 0)
      draggable = null;
    if (form === void 0)
      form = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (name === void 0)
      name = null;
    if (required === void 0)
      required = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    if (value === void 0)
      value = null;
    callback$default ? callback$default(selector, key, accesskey, autofocus, checked, contenteditable, dir, disabled, draggable, form, hidden, lang, name, required, spellcheck, style, tabindex, title, translate, value, defineAttributes) : this.inputRadioButton_5idhkk$$default(selector, key, accesskey, autofocus, checked, contenteditable, dir, disabled, draggable, form, hidden, lang, name, required, spellcheck, style, tabindex, title, translate, value, defineAttributes);
  };
  KatydidPhrasingContentBuilder.prototype.inputRange_er1tee$ = function (selector, key, accesskey, autocomplete, autofocus, contenteditable, dir, disabled, draggable, form, hidden, lang, list, max, min, name, spellcheck, step, style, tabindex, title, translate, value, defineAttributes, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (autocomplete === void 0)
      autocomplete = null;
    if (autofocus === void 0)
      autofocus = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (disabled === void 0)
      disabled = null;
    if (draggable === void 0)
      draggable = null;
    if (form === void 0)
      form = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (list === void 0)
      list = null;
    if (max === void 0)
      max = null;
    if (min === void 0)
      min = null;
    if (name === void 0)
      name = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (step === void 0)
      step = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    if (value === void 0)
      value = null;
    callback$default ? callback$default(selector, key, accesskey, autocomplete, autofocus, contenteditable, dir, disabled, draggable, form, hidden, lang, list, max, min, name, spellcheck, step, style, tabindex, title, translate, value, defineAttributes) : this.inputRange_er1tee$$default(selector, key, accesskey, autocomplete, autofocus, contenteditable, dir, disabled, draggable, form, hidden, lang, list, max, min, name, spellcheck, step, style, tabindex, title, translate, value, defineAttributes);
  };
  KatydidPhrasingContentBuilder.prototype.inputResetButton_kk2d6s$ = function (selector, key, accesskey, contenteditable, dir, disabled, draggable, form, hidden, lang, name, spellcheck, style, tabindex, title, translate, value, defineAttributes, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (disabled === void 0)
      disabled = null;
    if (draggable === void 0)
      draggable = null;
    if (form === void 0)
      form = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (name === void 0)
      name = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    if (value === void 0)
      value = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, disabled, draggable, form, hidden, lang, name, spellcheck, style, tabindex, title, translate, value, defineAttributes) : this.inputResetButton_kk2d6s$$default(selector, key, accesskey, contenteditable, dir, disabled, draggable, form, hidden, lang, name, spellcheck, style, tabindex, title, translate, value, defineAttributes);
  };
  KatydidPhrasingContentBuilder.prototype.inputSearch_y74p72$ = function (selector, key, accesskey, autocomplete, autofocus, contenteditable, dir, dirname, disabled, draggable, form, hidden, lang, list, maxlength, minlength, name, pattern, placeholder, readonly, required, size, spellcheck, style, tabindex, title, translate, value, defineAttributes, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (autocomplete === void 0)
      autocomplete = null;
    if (autofocus === void 0)
      autofocus = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (dirname === void 0)
      dirname = null;
    if (disabled === void 0)
      disabled = null;
    if (draggable === void 0)
      draggable = null;
    if (form === void 0)
      form = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (list === void 0)
      list = null;
    if (maxlength === void 0)
      maxlength = null;
    if (minlength === void 0)
      minlength = null;
    if (name === void 0)
      name = null;
    if (pattern === void 0)
      pattern = null;
    if (placeholder === void 0)
      placeholder = null;
    if (readonly === void 0)
      readonly = null;
    if (required === void 0)
      required = null;
    if (size === void 0)
      size = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    if (value === void 0)
      value = null;
    callback$default ? callback$default(selector, key, accesskey, autocomplete, autofocus, contenteditable, dir, dirname, disabled, draggable, form, hidden, lang, list, maxlength, minlength, name, pattern, placeholder, readonly, required, size, spellcheck, style, tabindex, title, translate, value, defineAttributes) : this.inputSearch_y74p72$$default(selector, key, accesskey, autocomplete, autofocus, contenteditable, dir, dirname, disabled, draggable, form, hidden, lang, list, maxlength, minlength, name, pattern, placeholder, readonly, required, size, spellcheck, style, tabindex, title, translate, value, defineAttributes);
  };
  KatydidPhrasingContentBuilder.prototype.inputSubmitButton_xi657a$ = function (selector, key, accesskey, contenteditable, dir, disabled, draggable, form, formaction, formenctype, formmethod, formnovalidate, formtarget, hidden, lang, name, spellcheck, style, tabindex, title, translate, value, defineAttributes, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (disabled === void 0)
      disabled = null;
    if (draggable === void 0)
      draggable = null;
    if (form === void 0)
      form = null;
    if (formaction === void 0)
      formaction = null;
    if (formenctype === void 0)
      formenctype = null;
    if (formmethod === void 0)
      formmethod = null;
    if (formnovalidate === void 0)
      formnovalidate = null;
    if (formtarget === void 0)
      formtarget = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (name === void 0)
      name = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    if (value === void 0)
      value = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, disabled, draggable, form, formaction, formenctype, formmethod, formnovalidate, formtarget, hidden, lang, name, spellcheck, style, tabindex, title, translate, value, defineAttributes) : this.inputSubmitButton_xi657a$$default(selector, key, accesskey, contenteditable, dir, disabled, draggable, form, formaction, formenctype, formmethod, formnovalidate, formtarget, hidden, lang, name, spellcheck, style, tabindex, title, translate, value, defineAttributes);
  };
  KatydidPhrasingContentBuilder.prototype.inputTelephone_m3bg53$ = function (selector, key, accesskey, autocomplete, autofocus, contenteditable, dir, disabled, draggable, form, hidden, lang, list, maxlength, minlength, name, pattern, placeholder, readonly, required, size, spellcheck, style, tabindex, title, translate, value, defineAttributes, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (autocomplete === void 0)
      autocomplete = null;
    if (autofocus === void 0)
      autofocus = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (disabled === void 0)
      disabled = null;
    if (draggable === void 0)
      draggable = null;
    if (form === void 0)
      form = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (list === void 0)
      list = null;
    if (maxlength === void 0)
      maxlength = null;
    if (minlength === void 0)
      minlength = null;
    if (name === void 0)
      name = null;
    if (pattern === void 0)
      pattern = null;
    if (placeholder === void 0)
      placeholder = null;
    if (readonly === void 0)
      readonly = null;
    if (required === void 0)
      required = null;
    if (size === void 0)
      size = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    if (value === void 0)
      value = null;
    callback$default ? callback$default(selector, key, accesskey, autocomplete, autofocus, contenteditable, dir, disabled, draggable, form, hidden, lang, list, maxlength, minlength, name, pattern, placeholder, readonly, required, size, spellcheck, style, tabindex, title, translate, value, defineAttributes) : this.inputTelephone_m3bg53$$default(selector, key, accesskey, autocomplete, autofocus, contenteditable, dir, disabled, draggable, form, hidden, lang, list, maxlength, minlength, name, pattern, placeholder, readonly, required, size, spellcheck, style, tabindex, title, translate, value, defineAttributes);
  };
  KatydidPhrasingContentBuilder.prototype.inputText_y74p72$ = function (selector, key, accesskey, autocomplete, autofocus, contenteditable, dir, dirname, disabled, draggable, form, hidden, lang, list, maxlength, minlength, name, pattern, placeholder, readonly, required, size, spellcheck, style, tabindex, title, translate, value, defineAttributes, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (autocomplete === void 0)
      autocomplete = null;
    if (autofocus === void 0)
      autofocus = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (dirname === void 0)
      dirname = null;
    if (disabled === void 0)
      disabled = null;
    if (draggable === void 0)
      draggable = null;
    if (form === void 0)
      form = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (list === void 0)
      list = null;
    if (maxlength === void 0)
      maxlength = null;
    if (minlength === void 0)
      minlength = null;
    if (name === void 0)
      name = null;
    if (pattern === void 0)
      pattern = null;
    if (placeholder === void 0)
      placeholder = null;
    if (readonly === void 0)
      readonly = null;
    if (required === void 0)
      required = null;
    if (size === void 0)
      size = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    if (value === void 0)
      value = null;
    callback$default ? callback$default(selector, key, accesskey, autocomplete, autofocus, contenteditable, dir, dirname, disabled, draggable, form, hidden, lang, list, maxlength, minlength, name, pattern, placeholder, readonly, required, size, spellcheck, style, tabindex, title, translate, value, defineAttributes) : this.inputText_y74p72$$default(selector, key, accesskey, autocomplete, autofocus, contenteditable, dir, dirname, disabled, draggable, form, hidden, lang, list, maxlength, minlength, name, pattern, placeholder, readonly, required, size, spellcheck, style, tabindex, title, translate, value, defineAttributes);
  };
  KatydidPhrasingContentBuilder.prototype.inputTime_629f1$ = function (selector, key, accesskey, autocomplete, autofocus, contenteditable, dir, disabled, draggable, form, hidden, lang, list, max, min, name, readonly, required, spellcheck, step, style, tabindex, title, translate, value, defineAttributes, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (autocomplete === void 0)
      autocomplete = null;
    if (autofocus === void 0)
      autofocus = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (disabled === void 0)
      disabled = null;
    if (draggable === void 0)
      draggable = null;
    if (form === void 0)
      form = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (list === void 0)
      list = null;
    if (max === void 0)
      max = null;
    if (min === void 0)
      min = null;
    if (name === void 0)
      name = null;
    if (readonly === void 0)
      readonly = null;
    if (required === void 0)
      required = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (step === void 0)
      step = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    if (value === void 0)
      value = null;
    callback$default ? callback$default(selector, key, accesskey, autocomplete, autofocus, contenteditable, dir, disabled, draggable, form, hidden, lang, list, max, min, name, readonly, required, spellcheck, step, style, tabindex, title, translate, value, defineAttributes) : this.inputTime_629f1$$default(selector, key, accesskey, autocomplete, autofocus, contenteditable, dir, disabled, draggable, form, hidden, lang, list, max, min, name, readonly, required, spellcheck, step, style, tabindex, title, translate, value, defineAttributes);
  };
  KatydidPhrasingContentBuilder.prototype.inputUrl_m3bg53$ = function (selector, key, accesskey, autocomplete, autofocus, contenteditable, dir, disabled, draggable, form, hidden, lang, list, maxlength, minlength, name, pattern, placeholder, readonly, required, size, spellcheck, style, tabindex, title, translate, value, defineAttributes, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (autocomplete === void 0)
      autocomplete = null;
    if (autofocus === void 0)
      autofocus = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (disabled === void 0)
      disabled = null;
    if (draggable === void 0)
      draggable = null;
    if (form === void 0)
      form = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (list === void 0)
      list = null;
    if (maxlength === void 0)
      maxlength = null;
    if (minlength === void 0)
      minlength = null;
    if (name === void 0)
      name = null;
    if (pattern === void 0)
      pattern = null;
    if (placeholder === void 0)
      placeholder = null;
    if (readonly === void 0)
      readonly = null;
    if (required === void 0)
      required = null;
    if (size === void 0)
      size = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    if (value === void 0)
      value = null;
    callback$default ? callback$default(selector, key, accesskey, autocomplete, autofocus, contenteditable, dir, disabled, draggable, form, hidden, lang, list, maxlength, minlength, name, pattern, placeholder, readonly, required, size, spellcheck, style, tabindex, title, translate, value, defineAttributes) : this.inputUrl_m3bg53$$default(selector, key, accesskey, autocomplete, autofocus, contenteditable, dir, disabled, draggable, form, hidden, lang, list, maxlength, minlength, name, pattern, placeholder, readonly, required, size, spellcheck, style, tabindex, title, translate, value, defineAttributes);
  };
  KatydidPhrasingContentBuilder.prototype.inputWeek_3kgd4t$ = function (selector, key, accesskey, autocomplete, autofocus, contenteditable, dir, disabled, draggable, form, hidden, lang, list, max, min, name, readonly, required, spellcheck, step, style, tabindex, title, translate, value, defineAttributes, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (autocomplete === void 0)
      autocomplete = null;
    if (autofocus === void 0)
      autofocus = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (disabled === void 0)
      disabled = null;
    if (draggable === void 0)
      draggable = null;
    if (form === void 0)
      form = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (list === void 0)
      list = null;
    if (max === void 0)
      max = null;
    if (min === void 0)
      min = null;
    if (name === void 0)
      name = null;
    if (readonly === void 0)
      readonly = null;
    if (required === void 0)
      required = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (step === void 0)
      step = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    if (value === void 0)
      value = null;
    callback$default ? callback$default(selector, key, accesskey, autocomplete, autofocus, contenteditable, dir, disabled, draggable, form, hidden, lang, list, max, min, name, readonly, required, spellcheck, step, style, tabindex, title, translate, value, defineAttributes) : this.inputWeek_3kgd4t$$default(selector, key, accesskey, autocomplete, autofocus, contenteditable, dir, disabled, draggable, form, hidden, lang, list, max, min, name, readonly, required, spellcheck, step, style, tabindex, title, translate, value, defineAttributes);
  };
  KatydidPhrasingContentBuilder.prototype.ins_smchxe$ = function (selector, key, accesskey, cite, contenteditable, datetime, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (cite === void 0)
      cite = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (datetime === void 0)
      datetime = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    callback$default ? callback$default(selector, key, accesskey, cite, contenteditable, datetime, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) : this.ins_smchxe$$default(selector, key, accesskey, cite, contenteditable, datetime, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent);
  };
  KatydidPhrasingContentBuilder.prototype.kbd_qckjfy$ = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) : this.kbd_qckjfy$$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent);
  };
  KatydidPhrasingContentBuilder.prototype.label_va30u7$ = function (selector, key, accesskey, contenteditable, dir, draggable, for_0, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (for_0 === void 0)
      for_0 = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, draggable, for_0, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) : this.label_va30u7$$default(selector, key, accesskey, contenteditable, dir, draggable, for_0, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent);
  };
  KatydidPhrasingContentBuilder.prototype.map_z0i53j$ = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, name, spellcheck, style, tabindex, title, translate, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (name === void 0)
      name = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, name, spellcheck, style, tabindex, title, translate, defineContent) : this.map_z0i53j$$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, name, spellcheck, style, tabindex, title, translate, defineContent);
  };
  KatydidPhrasingContentBuilder.prototype.mark_qckjfy$ = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) : this.mark_qckjfy$$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent);
  };
  KatydidPhrasingContentBuilder.prototype.meter_6c4h8d$ = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, high, lang, low, max, min, optimum, spellcheck, style, tabindex, title, translate, value, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (high === void 0)
      high = null;
    if (lang === void 0)
      lang = null;
    if (low === void 0)
      low = null;
    if (max === void 0)
      max = null;
    if (min === void 0)
      min = null;
    if (optimum === void 0)
      optimum = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, high, lang, low, max, min, optimum, spellcheck, style, tabindex, title, translate, value, defineContent) : this.meter_6c4h8d$$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, high, lang, low, max, min, optimum, spellcheck, style, tabindex, title, translate, value, defineContent);
  };
  KatydidPhrasingContentBuilder.prototype.meter_ujjlce$ = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, high, lang, low, max, min, optimum, spellcheck, style, tabindex, title, translate, value, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (high === void 0)
      high = null;
    if (lang === void 0)
      lang = null;
    if (low === void 0)
      low = null;
    if (min === void 0)
      min = null;
    if (optimum === void 0)
      optimum = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, high, lang, low, max, min, optimum, spellcheck, style, tabindex, title, translate, value, defineContent) : this.meter_ujjlce$$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, high, lang, low, max, min, optimum, spellcheck, style, tabindex, title, translate, value, defineContent);
  };
  KatydidPhrasingContentBuilder.prototype.object_8mhd8$ = function (selector, key, accesskey, contenteditable, data, dir, draggable, form, height, hidden, lang, name, spellcheck, style, tabindex, title, translate, type, typemustmatch, width, contentType, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (data === void 0)
      data = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (form === void 0)
      form = null;
    if (height === void 0)
      height = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (name === void 0)
      name = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    if (type === void 0)
      type = null;
    if (typemustmatch === void 0)
      typemustmatch = null;
    if (width === void 0)
      width = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, data, dir, draggable, form, height, hidden, lang, name, spellcheck, style, tabindex, title, translate, type, typemustmatch, width, contentType, defineContent) : this.object_8mhd8$$default(selector, key, accesskey, contenteditable, data, dir, draggable, form, height, hidden, lang, name, spellcheck, style, tabindex, title, translate, type, typemustmatch, width, contentType, defineContent);
  };
  KatydidPhrasingContentBuilder.prototype.output_7nyrc9$ = function (selector, key, accesskey, contenteditable, dir, disabled, draggable, for_0, form, hidden, lang, name, spellcheck, style, tabindex, title, translate, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (disabled === void 0)
      disabled = null;
    if (draggable === void 0)
      draggable = null;
    if (for_0 === void 0)
      for_0 = null;
    if (form === void 0)
      form = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (name === void 0)
      name = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, disabled, draggable, for_0, form, hidden, lang, name, spellcheck, style, tabindex, title, translate, defineContent) : this.output_7nyrc9$$default(selector, key, accesskey, contenteditable, dir, disabled, draggable, for_0, form, hidden, lang, name, spellcheck, style, tabindex, title, translate, defineContent);
  };
  KatydidPhrasingContentBuilder.prototype.progress_8ydfv4$ = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, max, spellcheck, style, tabindex, title, translate, value, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (max === void 0)
      max = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    if (value === void 0)
      value = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, max, spellcheck, style, tabindex, title, translate, value, defineContent) : this.progress_8ydfv4$$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, max, spellcheck, style, tabindex, title, translate, value, defineContent);
  };
  KatydidPhrasingContentBuilder.prototype.progress_qjij5p$ = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, max, spellcheck, style, tabindex, title, translate, value, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    if (value === void 0)
      value = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, max, spellcheck, style, tabindex, title, translate, value, defineContent) : this.progress_qjij5p$$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, max, spellcheck, style, tabindex, title, translate, value, defineContent);
  };
  KatydidPhrasingContentBuilder.prototype.q_qckjfy$ = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) : this.q_qckjfy$$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent);
  };
  KatydidPhrasingContentBuilder.prototype.ruby_sy7cla$ = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) : this.ruby_sy7cla$$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent);
  };
  KatydidPhrasingContentBuilder.prototype.s_qckjfy$ = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) : this.s_qckjfy$$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent);
  };
  KatydidPhrasingContentBuilder.prototype.samp_qckjfy$ = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) : this.samp_qckjfy$$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent);
  };
  KatydidPhrasingContentBuilder.prototype.select_7efmz3$ = function (selector, key, accesskey, autocomplete, autofocus, contenteditable, dir, disabled, draggable, form, hidden, lang, multiple, name, required, size, spellcheck, style, tabindex, title, translate, value, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (autocomplete === void 0)
      autocomplete = null;
    if (autofocus === void 0)
      autofocus = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (disabled === void 0)
      disabled = null;
    if (draggable === void 0)
      draggable = null;
    if (form === void 0)
      form = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (multiple === void 0)
      multiple = null;
    if (name === void 0)
      name = null;
    if (required === void 0)
      required = null;
    if (size === void 0)
      size = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    if (value === void 0)
      value = null;
    callback$default ? callback$default(selector, key, accesskey, autocomplete, autofocus, contenteditable, dir, disabled, draggable, form, hidden, lang, multiple, name, required, size, spellcheck, style, tabindex, title, translate, value, defineContent) : this.select_7efmz3$$default(selector, key, accesskey, autocomplete, autofocus, contenteditable, dir, disabled, draggable, form, hidden, lang, multiple, name, required, size, spellcheck, style, tabindex, title, translate, value, defineContent);
  };
  KatydidPhrasingContentBuilder.prototype.small_qckjfy$ = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) : this.small_qckjfy$$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent);
  };
  KatydidPhrasingContentBuilder.prototype.span_qckjfy$ = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) : this.span_qckjfy$$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent);
  };
  KatydidPhrasingContentBuilder.prototype.strong_qckjfy$ = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) : this.strong_qckjfy$$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent);
  };
  KatydidPhrasingContentBuilder.prototype.sub_qckjfy$ = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) : this.sub_qckjfy$$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent);
  };
  KatydidPhrasingContentBuilder.prototype.sup_qckjfy$ = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) : this.sup_qckjfy$$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent);
  };
  KatydidPhrasingContentBuilder.prototype.text_4w9ihe$ = function (nodeValue, key, callback$default) {
    if (key === void 0)
      key = null;
    callback$default ? callback$default(nodeValue, key) : this.text_4w9ihe$$default(nodeValue, key);
  };
  KatydidPhrasingContentBuilder.prototype.unaryPlus_pdl1vz$ = function ($receiver) {
    this.text_4w9ihe$($receiver);
  };
  KatydidPhrasingContentBuilder.prototype.textarea_1j30yg$ = function (selector, key, accesskey, autocomplete, autofocus, cols, contenteditable, dir, dirname, disabled, draggable, form, hidden, lang, maxlength, minlength, name, placeholder, readonly, required, rows, spellcheck, style, tabindex, title, translate, wrap, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (autocomplete === void 0)
      autocomplete = null;
    if (autofocus === void 0)
      autofocus = null;
    if (cols === void 0)
      cols = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (dirname === void 0)
      dirname = null;
    if (disabled === void 0)
      disabled = null;
    if (draggable === void 0)
      draggable = null;
    if (form === void 0)
      form = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (maxlength === void 0)
      maxlength = null;
    if (minlength === void 0)
      minlength = null;
    if (name === void 0)
      name = null;
    if (placeholder === void 0)
      placeholder = null;
    if (readonly === void 0)
      readonly = null;
    if (required === void 0)
      required = null;
    if (rows === void 0)
      rows = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    if (wrap === void 0)
      wrap = null;
    callback$default ? callback$default(selector, key, accesskey, autocomplete, autofocus, cols, contenteditable, dir, dirname, disabled, draggable, form, hidden, lang, maxlength, minlength, name, placeholder, readonly, required, rows, spellcheck, style, tabindex, title, translate, wrap, defineContent) : this.textarea_1j30yg$$default(selector, key, accesskey, autocomplete, autofocus, cols, contenteditable, dir, dirname, disabled, draggable, form, hidden, lang, maxlength, minlength, name, placeholder, readonly, required, rows, spellcheck, style, tabindex, title, translate, wrap, defineContent);
  };
  KatydidPhrasingContentBuilder.prototype.time_y9dz51$ = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) : this.time_y9dz51$$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent);
  };
  KatydidPhrasingContentBuilder.prototype.time_jigsdy$ = function (selector, key, accesskey, contenteditable, datetime, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, datetime, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) : this.time_jigsdy$$default(selector, key, accesskey, contenteditable, datetime, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent);
  };
  KatydidPhrasingContentBuilder.prototype.u_qckjfy$ = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) : this.u_qckjfy$$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent);
  };
  KatydidPhrasingContentBuilder.prototype.var_qckjfy$ = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) : this.var_qckjfy$$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent);
  };
  KatydidPhrasingContentBuilder.prototype.video_l9965i$ = function (selector, key, accesskey, autoplay, contenteditable, controls, crossorigin, dir, draggable, height, hidden, lang, loop, muted, poster, preload, spellcheck, src, style, tabindex, title, translate, width, contentType, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (autoplay === void 0)
      autoplay = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (controls === void 0)
      controls = null;
    if (crossorigin === void 0)
      crossorigin = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (height === void 0)
      height = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (loop === void 0)
      loop = null;
    if (muted === void 0)
      muted = null;
    if (poster === void 0)
      poster = null;
    if (preload === void 0)
      preload = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (src === void 0)
      src = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    if (width === void 0)
      width = null;
    callback$default ? callback$default(selector, key, accesskey, autoplay, contenteditable, controls, crossorigin, dir, draggable, height, hidden, lang, loop, muted, poster, preload, spellcheck, src, style, tabindex, title, translate, width, contentType, defineContent) : this.video_l9965i$$default(selector, key, accesskey, autoplay, contenteditable, controls, crossorigin, dir, draggable, height, hidden, lang, loop, muted, poster, preload, spellcheck, src, style, tabindex, title, translate, width, contentType, defineContent);
  };
  KatydidPhrasingContentBuilder.prototype.wbr_9mj9vz$ = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineAttributes, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineAttributes) : this.wbr_9mj9vz$$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineAttributes);
  };
  KatydidPhrasingContentBuilder.$metadata$ = {
    kind: Kind_INTERFACE,
    simpleName: 'KatydidPhrasingContentBuilder',
    interfaces: [KatydidEmbeddedContentBuilder]
  };
  function KatydidSectioningContentBuilder() {
  }
  KatydidSectioningContentBuilder.prototype.article_6zr3om$ = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) : this.article_6zr3om$$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent);
  };
  KatydidSectioningContentBuilder.prototype.aside_6zr3om$ = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) : this.aside_6zr3om$$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent);
  };
  KatydidSectioningContentBuilder.prototype.nav_6zr3om$ = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) : this.nav_6zr3om$$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent);
  };
  KatydidSectioningContentBuilder.prototype.section_6zr3om$ = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) : this.section_6zr3om$$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent);
  };
  KatydidSectioningContentBuilder.$metadata$ = {
    kind: Kind_INTERFACE,
    simpleName: 'KatydidSectioningContentBuilder',
    interfaces: [KatydidAttributesContentBuilder]
  };
  function KatydidOrderedListContentBuilder() {
  }
  KatydidOrderedListContentBuilder.prototype.comment_4w9ihe$ = function (nodeValue, key, callback$default) {
    if (key === void 0)
      key = null;
    callback$default ? callback$default(nodeValue, key) : this.comment_4w9ihe$$default(nodeValue, key);
  };
  KatydidOrderedListContentBuilder.prototype.li_wy8x0p$ = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, value, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    if (value === void 0)
      value = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, value, defineContent) : this.li_wy8x0p$$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, value, defineContent);
  };
  KatydidOrderedListContentBuilder.$metadata$ = {
    kind: Kind_INTERFACE,
    simpleName: 'KatydidOrderedListContentBuilder',
    interfaces: [KatydidAttributesContentBuilder]
  };
  function KatydidUnorderedListContentBuilder() {
  }
  KatydidUnorderedListContentBuilder.prototype.comment_4w9ihe$ = function (nodeValue, key, callback$default) {
    if (key === void 0)
      key = null;
    callback$default ? callback$default(nodeValue, key) : this.comment_4w9ihe$$default(nodeValue, key);
  };
  KatydidUnorderedListContentBuilder.prototype.li_6zr3om$ = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) : this.li_6zr3om$$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent);
  };
  KatydidUnorderedListContentBuilder.$metadata$ = {
    kind: Kind_INTERFACE,
    simpleName: 'KatydidUnorderedListContentBuilder',
    interfaces: [KatydidAttributesContentBuilder]
  };
  function KatydidMediaEmbeddedContentBuilder() {
  }
  KatydidMediaEmbeddedContentBuilder.prototype.source_7jkj91$ = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, media, sizes, spellcheck, src, srcset, style, tabindex, title, translate, type, defineAttributes, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (media === void 0)
      media = null;
    if (sizes === void 0)
      sizes = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (srcset === void 0)
      srcset = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    if (type === void 0)
      type = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, media, sizes, spellcheck, src, srcset, style, tabindex, title, translate, type, defineAttributes) : this.source_7jkj91$$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, media, sizes, spellcheck, src, srcset, style, tabindex, title, translate, type, defineAttributes);
  };
  KatydidMediaEmbeddedContentBuilder.prototype.track_o1vzoi$ = function (selector, key, accesskey, contenteditable, default_0, dir, draggable, hidden, kind, label, lang, spellcheck, src, srclang, style, tabindex, title, translate, defineAttributes, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (default_0 === void 0)
      default_0 = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (kind === void 0)
      kind = null;
    if (label === void 0)
      label = null;
    if (lang === void 0)
      lang = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (srclang === void 0)
      srclang = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, default_0, dir, draggable, hidden, kind, label, lang, spellcheck, src, srclang, style, tabindex, title, translate, defineAttributes) : this.track_o1vzoi$$default(selector, key, accesskey, contenteditable, default_0, dir, draggable, hidden, kind, label, lang, spellcheck, src, srclang, style, tabindex, title, translate, defineAttributes);
  };
  KatydidMediaEmbeddedContentBuilder.$metadata$ = {
    kind: Kind_INTERFACE,
    simpleName: 'KatydidMediaEmbeddedContentBuilder',
    interfaces: [KatydidEmbeddedContentBuilder]
  };
  function KatydidMediaFlowContentBuilder() {
  }
  KatydidMediaFlowContentBuilder.prototype.source_7jkj91$ = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, media, sizes, spellcheck, src, srcset, style, tabindex, title, translate, type, defineAttributes, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (media === void 0)
      media = null;
    if (sizes === void 0)
      sizes = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (srcset === void 0)
      srcset = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    if (type === void 0)
      type = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, media, sizes, spellcheck, src, srcset, style, tabindex, title, translate, type, defineAttributes) : this.source_7jkj91$$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, media, sizes, spellcheck, src, srcset, style, tabindex, title, translate, type, defineAttributes);
  };
  KatydidMediaFlowContentBuilder.prototype.track_o1vzoi$ = function (selector, key, accesskey, contenteditable, default_0, dir, draggable, hidden, kind, label, lang, spellcheck, src, srclang, style, tabindex, title, translate, defineAttributes, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (default_0 === void 0)
      default_0 = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (kind === void 0)
      kind = null;
    if (label === void 0)
      label = null;
    if (lang === void 0)
      lang = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (srclang === void 0)
      srclang = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, default_0, dir, draggable, hidden, kind, label, lang, spellcheck, src, srclang, style, tabindex, title, translate, defineAttributes) : this.track_o1vzoi$$default(selector, key, accesskey, contenteditable, default_0, dir, draggable, hidden, kind, label, lang, spellcheck, src, srclang, style, tabindex, title, translate, defineAttributes);
  };
  KatydidMediaFlowContentBuilder.$metadata$ = {
    kind: Kind_INTERFACE,
    simpleName: 'KatydidMediaFlowContentBuilder',
    interfaces: [KatydidFlowContentBuilder]
  };
  function KatydidMediaPhrasingContentBuilder() {
  }
  KatydidMediaPhrasingContentBuilder.prototype.source_7jkj91$ = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, media, sizes, spellcheck, src, srcset, style, tabindex, title, translate, type, defineAttributes, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (media === void 0)
      media = null;
    if (sizes === void 0)
      sizes = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (srcset === void 0)
      srcset = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    if (type === void 0)
      type = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, media, sizes, spellcheck, src, srcset, style, tabindex, title, translate, type, defineAttributes) : this.source_7jkj91$$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, media, sizes, spellcheck, src, srcset, style, tabindex, title, translate, type, defineAttributes);
  };
  KatydidMediaPhrasingContentBuilder.prototype.track_o1vzoi$ = function (selector, key, accesskey, contenteditable, default_0, dir, draggable, hidden, kind, label, lang, spellcheck, src, srclang, style, tabindex, title, translate, defineAttributes, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (default_0 === void 0)
      default_0 = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (kind === void 0)
      kind = null;
    if (label === void 0)
      label = null;
    if (lang === void 0)
      lang = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (srclang === void 0)
      srclang = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, default_0, dir, draggable, hidden, kind, label, lang, spellcheck, src, srclang, style, tabindex, title, translate, defineAttributes) : this.track_o1vzoi$$default(selector, key, accesskey, contenteditable, default_0, dir, draggable, hidden, kind, label, lang, spellcheck, src, srclang, style, tabindex, title, translate, defineAttributes);
  };
  KatydidMediaPhrasingContentBuilder.$metadata$ = {
    kind: Kind_INTERFACE,
    simpleName: 'KatydidMediaPhrasingContentBuilder',
    interfaces: [KatydidEmbeddedContentBuilder]
  };
  function KatydidPictureContentBuilder() {
  }
  KatydidPictureContentBuilder.prototype.img_1hpfln$ = function (selector, key, accesskey, alt, contenteditable, crossorigin, dir, draggable, height, hidden, ismap, lang, referrerpolicy, sizes, spellcheck, src, srcset, style, tabindex, title, translate, usemap, width, defineAttributes, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (crossorigin === void 0)
      crossorigin = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (height === void 0)
      height = null;
    if (hidden === void 0)
      hidden = null;
    if (ismap === void 0)
      ismap = null;
    if (lang === void 0)
      lang = null;
    if (referrerpolicy === void 0)
      referrerpolicy = null;
    if (sizes === void 0)
      sizes = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (src === void 0)
      src = null;
    if (srcset === void 0)
      srcset = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    if (usemap === void 0)
      usemap = null;
    if (width === void 0)
      width = null;
    callback$default ? callback$default(selector, key, accesskey, alt, contenteditable, crossorigin, dir, draggable, height, hidden, ismap, lang, referrerpolicy, sizes, spellcheck, src, srcset, style, tabindex, title, translate, usemap, width, defineAttributes) : this.img_1hpfln$$default(selector, key, accesskey, alt, contenteditable, crossorigin, dir, draggable, height, hidden, ismap, lang, referrerpolicy, sizes, spellcheck, src, srcset, style, tabindex, title, translate, usemap, width, defineAttributes);
  };
  KatydidPictureContentBuilder.prototype.source_7jkj91$ = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, media, sizes, spellcheck, src, srcset, style, tabindex, title, translate, type, defineAttributes, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (media === void 0)
      media = null;
    if (sizes === void 0)
      sizes = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (srcset === void 0)
      srcset = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    if (type === void 0)
      type = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, media, sizes, spellcheck, src, srcset, style, tabindex, title, translate, type, defineAttributes) : this.source_7jkj91$$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, media, sizes, spellcheck, src, srcset, style, tabindex, title, translate, type, defineAttributes);
  };
  KatydidPictureContentBuilder.$metadata$ = {
    kind: Kind_INTERFACE,
    simpleName: 'KatydidPictureContentBuilder',
    interfaces: [KatydidAttributesContentBuilder]
  };
  function KatydidDescriptionListContentBuilder() {
  }
  KatydidDescriptionListContentBuilder.prototype.comment_4w9ihe$ = function (nodeValue, key, callback$default) {
    if (key === void 0)
      key = null;
    callback$default ? callback$default(nodeValue, key) : this.comment_4w9ihe$$default(nodeValue, key);
  };
  KatydidDescriptionListContentBuilder.prototype.dd_6zr3om$ = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) : this.dd_6zr3om$$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent);
  };
  KatydidDescriptionListContentBuilder.prototype.div_a7rbte$ = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) : this.div_a7rbte$$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent);
  };
  KatydidDescriptionListContentBuilder.prototype.dt_6zr3om$ = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) : this.dt_6zr3om$$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent);
  };
  KatydidDescriptionListContentBuilder.$metadata$ = {
    kind: Kind_INTERFACE,
    simpleName: 'KatydidDescriptionListContentBuilder',
    interfaces: [KatydidAttributesContentBuilder]
  };
  function KatydidOptGroupContentBuilder() {
  }
  KatydidOptGroupContentBuilder.prototype.comment_4w9ihe$ = function (nodeValue, key, callback$default) {
    if (key === void 0)
      key = null;
    callback$default ? callback$default(nodeValue, key) : this.comment_4w9ihe$$default(nodeValue, key);
  };
  KatydidOptGroupContentBuilder.prototype.option_uvs23e$ = function (selector, key, accesskey, contenteditable, dir, disabled, draggable, hidden, label, lang, name, selected, spellcheck, style, tabindex, title, translate, value, defineAttributes, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (disabled === void 0)
      disabled = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (name === void 0)
      name = null;
    if (selected === void 0)
      selected = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, disabled, draggable, hidden, label, lang, name, selected, spellcheck, style, tabindex, title, translate, value, defineAttributes) : this.option_uvs23e$$default(selector, key, accesskey, contenteditable, dir, disabled, draggable, hidden, label, lang, name, selected, spellcheck, style, tabindex, title, translate, value, defineAttributes);
  };
  KatydidOptGroupContentBuilder.prototype.option_o31kud$ = function (selector, key, accesskey, contenteditable, dir, disabled, draggable, hidden, label, lang, name, selected, spellcheck, style, tabindex, title, translate, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (disabled === void 0)
      disabled = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (label === void 0)
      label = null;
    if (lang === void 0)
      lang = null;
    if (name === void 0)
      name = null;
    if (selected === void 0)
      selected = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, disabled, draggable, hidden, label, lang, name, selected, spellcheck, style, tabindex, title, translate, defineContent) : this.option_o31kud$$default(selector, key, accesskey, contenteditable, dir, disabled, draggable, hidden, label, lang, name, selected, spellcheck, style, tabindex, title, translate, defineContent);
  };
  KatydidOptGroupContentBuilder.$metadata$ = {
    kind: Kind_INTERFACE,
    simpleName: 'KatydidOptGroupContentBuilder',
    interfaces: [KatydidAttributesContentBuilder]
  };
  function KatydidSelectContentBuilder() {
  }
  KatydidSelectContentBuilder.prototype.optGroup_a8s91r$ = function (selector, key, accesskey, contenteditable, dir, disabled, draggable, hidden, label, lang, name, spellcheck, style, tabindex, title, translate, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (disabled === void 0)
      disabled = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (name === void 0)
      name = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, disabled, draggable, hidden, label, lang, name, spellcheck, style, tabindex, title, translate, defineContent) : this.optGroup_a8s91r$$default(selector, key, accesskey, contenteditable, dir, disabled, draggable, hidden, label, lang, name, spellcheck, style, tabindex, title, translate, defineContent);
  };
  KatydidSelectContentBuilder.$metadata$ = {
    kind: Kind_INTERFACE,
    simpleName: 'KatydidSelectContentBuilder',
    interfaces: [KatydidOptGroupContentBuilder]
  };
  function KatydidTextContentBuilder() {
  }
  KatydidTextContentBuilder.prototype.comment_4w9ihe$ = function (nodeValue, key, callback$default) {
    if (key === void 0)
      key = null;
    callback$default ? callback$default(nodeValue, key) : this.comment_4w9ihe$$default(nodeValue, key);
  };
  KatydidTextContentBuilder.prototype.text_4w9ihe$ = function (nodeValue, key, callback$default) {
    if (key === void 0)
      key = null;
    callback$default ? callback$default(nodeValue, key) : this.text_4w9ihe$$default(nodeValue, key);
  };
  KatydidTextContentBuilder.prototype.unaryPlus_pdl1vz$ = function ($receiver) {
    this.text_4w9ihe$($receiver);
  };
  KatydidTextContentBuilder.$metadata$ = {
    kind: Kind_INTERFACE,
    simpleName: 'KatydidTextContentBuilder',
    interfaces: [KatydidAttributesContentBuilder]
  };
  function KatydidObjectEmbeddedContentBuilder() {
  }
  KatydidObjectEmbeddedContentBuilder.prototype.param_clmic1$ = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, name, spellcheck, style, tabindex, title, translate, value, defineAttributes, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (name === void 0)
      name = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    if (value === void 0)
      value = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, name, spellcheck, style, tabindex, title, translate, value, defineAttributes) : this.param_clmic1$$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, name, spellcheck, style, tabindex, title, translate, value, defineAttributes);
  };
  KatydidObjectEmbeddedContentBuilder.$metadata$ = {
    kind: Kind_INTERFACE,
    simpleName: 'KatydidObjectEmbeddedContentBuilder',
    interfaces: [KatydidEmbeddedContentBuilder]
  };
  function KatydidObjectFlowContentBuilder() {
  }
  KatydidObjectFlowContentBuilder.prototype.param_clmic1$ = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, name, spellcheck, style, tabindex, title, translate, value, defineAttributes, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (name === void 0)
      name = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    if (value === void 0)
      value = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, name, spellcheck, style, tabindex, title, translate, value, defineAttributes) : this.param_clmic1$$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, name, spellcheck, style, tabindex, title, translate, value, defineAttributes);
  };
  KatydidObjectFlowContentBuilder.$metadata$ = {
    kind: Kind_INTERFACE,
    simpleName: 'KatydidObjectFlowContentBuilder',
    interfaces: [KatydidFlowContentBuilder]
  };
  function KatydidObjectPhrasingContentBuilder() {
  }
  KatydidObjectPhrasingContentBuilder.prototype.param_clmic1$ = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, name, spellcheck, style, tabindex, title, translate, value, defineAttributes, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (name === void 0)
      name = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    if (value === void 0)
      value = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, name, spellcheck, style, tabindex, title, translate, value, defineAttributes) : this.param_clmic1$$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, name, spellcheck, style, tabindex, title, translate, value, defineAttributes);
  };
  KatydidObjectPhrasingContentBuilder.$metadata$ = {
    kind: Kind_INTERFACE,
    simpleName: 'KatydidObjectPhrasingContentBuilder',
    interfaces: [KatydidPhrasingContentBuilder]
  };
  function KatydidRubyContentBuilder() {
  }
  KatydidRubyContentBuilder.prototype.rb_qckjfy$ = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) : this.rb_qckjfy$$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent);
  };
  KatydidRubyContentBuilder.prototype.rp_qckjfy$ = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) : this.rp_qckjfy$$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent);
  };
  KatydidRubyContentBuilder.prototype.rt_qckjfy$ = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) : this.rt_qckjfy$$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent);
  };
  KatydidRubyContentBuilder.prototype.rtc_sy7cla$ = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) : this.rtc_sy7cla$$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent);
  };
  KatydidRubyContentBuilder.$metadata$ = {
    kind: Kind_INTERFACE,
    simpleName: 'KatydidRubyContentBuilder',
    interfaces: [KatydidPhrasingContentBuilder]
  };
  function KatydidColGroupContentBuilder() {
  }
  function KatydidColGroupContentBuilder$col$lambda($receiver) {
    return Unit;
  }
  KatydidColGroupContentBuilder.prototype.col_xkd41s$ = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, span, spellcheck, style, tabindex, title, translate, defineAttributes, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (span === void 0)
      span = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    if (defineAttributes === void 0)
      defineAttributes = KatydidColGroupContentBuilder$col$lambda;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, span, spellcheck, style, tabindex, title, translate, defineAttributes) : this.col_xkd41s$$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, span, spellcheck, style, tabindex, title, translate, defineAttributes);
  };
  KatydidColGroupContentBuilder.$metadata$ = {
    kind: Kind_INTERFACE,
    simpleName: 'KatydidColGroupContentBuilder',
    interfaces: [KatydidAttributesContentBuilder]
  };
  function KatydidTableBodyContentBuilder() {
  }
  KatydidTableBodyContentBuilder.prototype.comment_4w9ihe$ = function (nodeValue, key, callback$default) {
    if (key === void 0)
      key = null;
    callback$default ? callback$default(nodeValue, key) : this.comment_4w9ihe$$default(nodeValue, key);
  };
  KatydidTableBodyContentBuilder.prototype.tr_n8e5b5$ = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) : this.tr_n8e5b5$$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent);
  };
  KatydidTableBodyContentBuilder.$metadata$ = {
    kind: Kind_INTERFACE,
    simpleName: 'KatydidTableBodyContentBuilder',
    interfaces: [KatydidAttributesContentBuilder]
  };
  function KatydidTableContentBuilder() {
  }
  KatydidTableContentBuilder.prototype.caption_6zr3om$ = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) : this.caption_6zr3om$$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent);
  };
  function KatydidTableContentBuilder$colgroup$lambda($receiver) {
    return Unit;
  }
  KatydidTableContentBuilder.prototype.colgroup_xkd41s$ = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, span, spellcheck, style, tabindex, title, translate, defineAttributes, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    if (defineAttributes === void 0)
      defineAttributes = KatydidTableContentBuilder$colgroup$lambda;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, span, spellcheck, style, tabindex, title, translate, defineAttributes) : this.colgroup_xkd41s$$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, span, spellcheck, style, tabindex, title, translate, defineAttributes);
  };
  KatydidTableContentBuilder.prototype.colgroup_lo2ydu$ = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) : this.colgroup_lo2ydu$$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent);
  };
  KatydidTableContentBuilder.prototype.comment_4w9ihe$ = function (nodeValue, key, callback$default) {
    if (key === void 0)
      key = null;
    callback$default ? callback$default(nodeValue, key) : this.comment_4w9ihe$$default(nodeValue, key);
  };
  KatydidTableContentBuilder.prototype.tbody_w9wujb$ = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) : this.tbody_w9wujb$$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent);
  };
  KatydidTableContentBuilder.prototype.tfoot_w9wujb$ = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) : this.tfoot_w9wujb$$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent);
  };
  KatydidTableContentBuilder.prototype.thead_w9wujb$ = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) : this.thead_w9wujb$$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent);
  };
  KatydidTableContentBuilder.prototype.tr_n8e5b5$ = function (selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    callback$default ? callback$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent) : this.tr_n8e5b5$$default(selector, key, accesskey, contenteditable, dir, draggable, hidden, lang, spellcheck, style, tabindex, title, translate, defineContent);
  };
  KatydidTableContentBuilder.$metadata$ = {
    kind: Kind_INTERFACE,
    simpleName: 'KatydidTableContentBuilder',
    interfaces: [KatydidAttributesContentBuilder]
  };
  function KatydidTableRowContentBuilder() {
  }
  KatydidTableRowContentBuilder.prototype.comment_4w9ihe$ = function (nodeValue, key, callback$default) {
    if (key === void 0)
      key = null;
    callback$default ? callback$default(nodeValue, key) : this.comment_4w9ihe$$default(nodeValue, key);
  };
  KatydidTableRowContentBuilder.prototype.td_iemoux$ = function (selector, key, accesskey, colspan, contenteditable, dir, draggable, headers, hidden, lang, rowspan, spellcheck, style, tabindex, title, translate, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (accesskey === void 0)
      accesskey = null;
    if (colspan === void 0)
      colspan = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (headers === void 0)
      headers = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (rowspan === void 0)
      rowspan = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    callback$default ? callback$default(selector, key, accesskey, colspan, contenteditable, dir, draggable, headers, hidden, lang, rowspan, spellcheck, style, tabindex, title, translate, defineContent) : this.td_iemoux$$default(selector, key, accesskey, colspan, contenteditable, dir, draggable, headers, hidden, lang, rowspan, spellcheck, style, tabindex, title, translate, defineContent);
  };
  KatydidTableRowContentBuilder.prototype.th_f4d2jq$ = function (selector, key, abbr, accesskey, colspan, contenteditable, dir, draggable, headers, hidden, lang, rowspan, scope, spellcheck, style, tabindex, title, translate, defineContent, callback$default) {
    if (selector === void 0)
      selector = null;
    if (key === void 0)
      key = null;
    if (abbr === void 0)
      abbr = null;
    if (accesskey === void 0)
      accesskey = null;
    if (colspan === void 0)
      colspan = null;
    if (contenteditable === void 0)
      contenteditable = null;
    if (dir === void 0)
      dir = null;
    if (draggable === void 0)
      draggable = null;
    if (headers === void 0)
      headers = null;
    if (hidden === void 0)
      hidden = null;
    if (lang === void 0)
      lang = null;
    if (rowspan === void 0)
      rowspan = null;
    if (scope === void 0)
      scope = null;
    if (spellcheck === void 0)
      spellcheck = null;
    if (style === void 0)
      style = null;
    if (tabindex === void 0)
      tabindex = null;
    if (title === void 0)
      title = null;
    if (translate === void 0)
      translate = null;
    callback$default ? callback$default(selector, key, abbr, accesskey, colspan, contenteditable, dir, draggable, headers, hidden, lang, rowspan, scope, spellcheck, style, tabindex, title, translate, defineContent) : this.th_f4d2jq$$default(selector, key, abbr, accesskey, colspan, contenteditable, dir, draggable, headers, hidden, lang, rowspan, scope, spellcheck, style, tabindex, title, translate, defineContent);
  };
  KatydidTableRowContentBuilder.$metadata$ = {
    kind: Kind_INTERFACE,
    simpleName: 'KatydidTableRowContentBuilder',
    interfaces: [KatydidAttributesContentBuilder]
  };
  function KatydidElement() {
  }
  KatydidElement.$metadata$ = {
    kind: Kind_INTERFACE,
    simpleName: 'KatydidElement',
    interfaces: [KatydidNode]
  };
  function KatydidHtmlElement() {
  }
  KatydidHtmlElement.$metadata$ = {
    kind: Kind_INTERFACE,
    simpleName: 'KatydidHtmlElement',
    interfaces: [KatydidElement]
  };
  function KatydidNode() {
  }
  KatydidNode.$metadata$ = {
    kind: Kind_INTERFACE,
    simpleName: 'KatydidNode',
    interfaces: []
  };
  function ContentType() {
  }
  ContentType.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'ContentType',
    interfaces: []
  };
  function EmbeddedContent() {
    EmbeddedContent_instance = this;
    ContentType.call(this);
  }
  EmbeddedContent.$metadata$ = {
    kind: Kind_OBJECT,
    simpleName: 'EmbeddedContent',
    interfaces: [ContentType]
  };
  var EmbeddedContent_instance = null;
  function EmbeddedContent_getInstance() {
    if (EmbeddedContent_instance === null) {
      new EmbeddedContent();
    }
    return EmbeddedContent_instance;
  }
  function FlowContent() {
    FlowContent_instance = this;
    ContentType.call(this);
  }
  FlowContent.$metadata$ = {
    kind: Kind_OBJECT,
    simpleName: 'FlowContent',
    interfaces: [ContentType]
  };
  var FlowContent_instance = null;
  function FlowContent_getInstance() {
    if (FlowContent_instance === null) {
      new FlowContent();
    }
    return FlowContent_instance;
  }
  function PhrasingContent() {
    PhrasingContent_instance = this;
    ContentType.call(this);
  }
  PhrasingContent.$metadata$ = {
    kind: Kind_OBJECT,
    simpleName: 'PhrasingContent',
    interfaces: [ContentType]
  };
  var PhrasingContent_instance = null;
  function PhrasingContent_getInstance() {
    if (PhrasingContent_instance === null) {
      new PhrasingContent();
    }
    return PhrasingContent_instance;
  }
  function EAnchorHtmlLinkType(name, ordinal, html) {
    Enum.call(this);
    this.html_s65gb0$_0 = html;
    this.name$ = name;
    this.ordinal$ = ordinal;
  }
  function EAnchorHtmlLinkType_initFields() {
    EAnchorHtmlLinkType_initFields = function () {
    };
    EAnchorHtmlLinkType$alternate_instance = new EAnchorHtmlLinkType('alternate', 0, 'alternate');
    EAnchorHtmlLinkType$author_instance = new EAnchorHtmlLinkType('author', 1, 'author');
    EAnchorHtmlLinkType$bookmark_instance = new EAnchorHtmlLinkType('bookmark', 2, 'bookmark');
    EAnchorHtmlLinkType$help_instance = new EAnchorHtmlLinkType('help', 3, 'help');
    EAnchorHtmlLinkType$license_instance = new EAnchorHtmlLinkType('license', 4, 'license');
    EAnchorHtmlLinkType$next_instance = new EAnchorHtmlLinkType('next', 5, 'next');
    EAnchorHtmlLinkType$nofollow_instance = new EAnchorHtmlLinkType('nofollow', 6, 'nofollow');
    EAnchorHtmlLinkType$noreferrer_instance = new EAnchorHtmlLinkType('noreferrer', 7, 'noreferrer');
    EAnchorHtmlLinkType$prev_instance = new EAnchorHtmlLinkType('prev', 8, 'prev');
    EAnchorHtmlLinkType$search_instance = new EAnchorHtmlLinkType('search', 9, 'search');
    EAnchorHtmlLinkType$tag_instance = new EAnchorHtmlLinkType('tag', 10, 'tag');
  }
  var EAnchorHtmlLinkType$alternate_instance;
  function EAnchorHtmlLinkType$alternate_getInstance() {
    EAnchorHtmlLinkType_initFields();
    return EAnchorHtmlLinkType$alternate_instance;
  }
  var EAnchorHtmlLinkType$author_instance;
  function EAnchorHtmlLinkType$author_getInstance() {
    EAnchorHtmlLinkType_initFields();
    return EAnchorHtmlLinkType$author_instance;
  }
  var EAnchorHtmlLinkType$bookmark_instance;
  function EAnchorHtmlLinkType$bookmark_getInstance() {
    EAnchorHtmlLinkType_initFields();
    return EAnchorHtmlLinkType$bookmark_instance;
  }
  var EAnchorHtmlLinkType$help_instance;
  function EAnchorHtmlLinkType$help_getInstance() {
    EAnchorHtmlLinkType_initFields();
    return EAnchorHtmlLinkType$help_instance;
  }
  var EAnchorHtmlLinkType$license_instance;
  function EAnchorHtmlLinkType$license_getInstance() {
    EAnchorHtmlLinkType_initFields();
    return EAnchorHtmlLinkType$license_instance;
  }
  var EAnchorHtmlLinkType$next_instance;
  function EAnchorHtmlLinkType$next_getInstance() {
    EAnchorHtmlLinkType_initFields();
    return EAnchorHtmlLinkType$next_instance;
  }
  var EAnchorHtmlLinkType$nofollow_instance;
  function EAnchorHtmlLinkType$nofollow_getInstance() {
    EAnchorHtmlLinkType_initFields();
    return EAnchorHtmlLinkType$nofollow_instance;
  }
  var EAnchorHtmlLinkType$noreferrer_instance;
  function EAnchorHtmlLinkType$noreferrer_getInstance() {
    EAnchorHtmlLinkType_initFields();
    return EAnchorHtmlLinkType$noreferrer_instance;
  }
  var EAnchorHtmlLinkType$prev_instance;
  function EAnchorHtmlLinkType$prev_getInstance() {
    EAnchorHtmlLinkType_initFields();
    return EAnchorHtmlLinkType$prev_instance;
  }
  var EAnchorHtmlLinkType$search_instance;
  function EAnchorHtmlLinkType$search_getInstance() {
    EAnchorHtmlLinkType_initFields();
    return EAnchorHtmlLinkType$search_instance;
  }
  var EAnchorHtmlLinkType$tag_instance;
  function EAnchorHtmlLinkType$tag_getInstance() {
    EAnchorHtmlLinkType_initFields();
    return EAnchorHtmlLinkType$tag_instance;
  }
  EAnchorHtmlLinkType.prototype.toHtmlString = function () {
    return this.html_s65gb0$_0;
  };
  EAnchorHtmlLinkType.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'EAnchorHtmlLinkType',
    interfaces: [Enum]
  };
  function EAnchorHtmlLinkType$values() {
    return [EAnchorHtmlLinkType$alternate_getInstance(), EAnchorHtmlLinkType$author_getInstance(), EAnchorHtmlLinkType$bookmark_getInstance(), EAnchorHtmlLinkType$help_getInstance(), EAnchorHtmlLinkType$license_getInstance(), EAnchorHtmlLinkType$next_getInstance(), EAnchorHtmlLinkType$nofollow_getInstance(), EAnchorHtmlLinkType$noreferrer_getInstance(), EAnchorHtmlLinkType$prev_getInstance(), EAnchorHtmlLinkType$search_getInstance(), EAnchorHtmlLinkType$tag_getInstance()];
  }
  EAnchorHtmlLinkType.values = EAnchorHtmlLinkType$values;
  function EAnchorHtmlLinkType$valueOf(name) {
    switch (name) {
      case 'alternate':
        return EAnchorHtmlLinkType$alternate_getInstance();
      case 'author':
        return EAnchorHtmlLinkType$author_getInstance();
      case 'bookmark':
        return EAnchorHtmlLinkType$bookmark_getInstance();
      case 'help':
        return EAnchorHtmlLinkType$help_getInstance();
      case 'license':
        return EAnchorHtmlLinkType$license_getInstance();
      case 'next':
        return EAnchorHtmlLinkType$next_getInstance();
      case 'nofollow':
        return EAnchorHtmlLinkType$nofollow_getInstance();
      case 'noreferrer':
        return EAnchorHtmlLinkType$noreferrer_getInstance();
      case 'prev':
        return EAnchorHtmlLinkType$prev_getInstance();
      case 'search':
        return EAnchorHtmlLinkType$search_getInstance();
      case 'tag':
        return EAnchorHtmlLinkType$tag_getInstance();
      default:throwISE('No enum constant o.katydid.vdom.types.EAnchorHtmlLinkType.' + name);
    }
  }
  EAnchorHtmlLinkType.valueOf_61zpoe$ = EAnchorHtmlLinkType$valueOf;
  function EAreaShape(name, ordinal, html) {
    Enum.call(this);
    this.html_q24ile$_0 = html;
    this.name$ = name;
    this.ordinal$ = ordinal;
  }
  function EAreaShape_initFields() {
    EAreaShape_initFields = function () {
    };
    EAreaShape$circle_instance = new EAreaShape('circle', 0, 'circle');
    EAreaShape$default_instance = new EAreaShape('default', 1, 'default');
    EAreaShape$poly_instance = new EAreaShape('poly', 2, 'poly');
    EAreaShape$rect_instance = new EAreaShape('rect', 3, 'rect');
  }
  var EAreaShape$circle_instance;
  function EAreaShape$circle_getInstance() {
    EAreaShape_initFields();
    return EAreaShape$circle_instance;
  }
  var EAreaShape$default_instance;
  function EAreaShape$default_getInstance() {
    EAreaShape_initFields();
    return EAreaShape$default_instance;
  }
  var EAreaShape$poly_instance;
  function EAreaShape$poly_getInstance() {
    EAreaShape_initFields();
    return EAreaShape$poly_instance;
  }
  var EAreaShape$rect_instance;
  function EAreaShape$rect_getInstance() {
    EAreaShape_initFields();
    return EAreaShape$rect_instance;
  }
  EAreaShape.prototype.toHtmlString = function () {
    return this.html_q24ile$_0;
  };
  EAreaShape.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'EAreaShape',
    interfaces: [Enum]
  };
  function EAreaShape$values() {
    return [EAreaShape$circle_getInstance(), EAreaShape$default_getInstance(), EAreaShape$poly_getInstance(), EAreaShape$rect_getInstance()];
  }
  EAreaShape.values = EAreaShape$values;
  function EAreaShape$valueOf(name) {
    switch (name) {
      case 'circle':
        return EAreaShape$circle_getInstance();
      case 'default':
        return EAreaShape$default_getInstance();
      case 'poly':
        return EAreaShape$poly_getInstance();
      case 'rect':
        return EAreaShape$rect_getInstance();
      default:throwISE('No enum constant o.katydid.vdom.types.EAreaShape.' + name);
    }
  }
  EAreaShape.valueOf_61zpoe$ = EAreaShape$valueOf;
  function EButtonType(name, ordinal, html) {
    Enum.call(this);
    this.html_5dih2c$_0 = html;
    this.name$ = name;
    this.ordinal$ = ordinal;
  }
  function EButtonType_initFields() {
    EButtonType_initFields = function () {
    };
    EButtonType$button_instance = new EButtonType('button', 0, 'button');
    EButtonType$menu_instance = new EButtonType('menu', 1, 'menu');
    EButtonType$reset_instance = new EButtonType('reset', 2, 'reset');
    EButtonType$submit_instance = new EButtonType('submit', 3, 'submit');
  }
  var EButtonType$button_instance;
  function EButtonType$button_getInstance() {
    EButtonType_initFields();
    return EButtonType$button_instance;
  }
  var EButtonType$menu_instance;
  function EButtonType$menu_getInstance() {
    EButtonType_initFields();
    return EButtonType$menu_instance;
  }
  var EButtonType$reset_instance;
  function EButtonType$reset_getInstance() {
    EButtonType_initFields();
    return EButtonType$reset_instance;
  }
  var EButtonType$submit_instance;
  function EButtonType$submit_getInstance() {
    EButtonType_initFields();
    return EButtonType$submit_instance;
  }
  EButtonType.prototype.toHtmlString = function () {
    return this.html_5dih2c$_0;
  };
  EButtonType.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'EButtonType',
    interfaces: [Enum]
  };
  function EButtonType$values() {
    return [EButtonType$button_getInstance(), EButtonType$menu_getInstance(), EButtonType$reset_getInstance(), EButtonType$submit_getInstance()];
  }
  EButtonType.values = EButtonType$values;
  function EButtonType$valueOf(name) {
    switch (name) {
      case 'button':
        return EButtonType$button_getInstance();
      case 'menu':
        return EButtonType$menu_getInstance();
      case 'reset':
        return EButtonType$reset_getInstance();
      case 'submit':
        return EButtonType$submit_getInstance();
      default:throwISE('No enum constant o.katydid.vdom.types.EButtonType.' + name);
    }
  }
  EButtonType.valueOf_61zpoe$ = EButtonType$valueOf;
  function ECorsSetting(name, ordinal, html) {
    Enum.call(this);
    this.html_ig7fvx$_0 = html;
    this.name$ = name;
    this.ordinal$ = ordinal;
  }
  function ECorsSetting_initFields() {
    ECorsSetting_initFields = function () {
    };
    ECorsSetting$anonymous_instance = new ECorsSetting('anonymous', 0, 'anonymous');
    ECorsSetting$useCredentials_instance = new ECorsSetting('useCredentials', 1, 'use-credentials');
  }
  var ECorsSetting$anonymous_instance;
  function ECorsSetting$anonymous_getInstance() {
    ECorsSetting_initFields();
    return ECorsSetting$anonymous_instance;
  }
  var ECorsSetting$useCredentials_instance;
  function ECorsSetting$useCredentials_getInstance() {
    ECorsSetting_initFields();
    return ECorsSetting$useCredentials_instance;
  }
  ECorsSetting.prototype.toHtmlString = function () {
    return this.html_ig7fvx$_0;
  };
  ECorsSetting.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'ECorsSetting',
    interfaces: [Enum]
  };
  function ECorsSetting$values() {
    return [ECorsSetting$anonymous_getInstance(), ECorsSetting$useCredentials_getInstance()];
  }
  ECorsSetting.values = ECorsSetting$values;
  function ECorsSetting$valueOf(name) {
    switch (name) {
      case 'anonymous':
        return ECorsSetting$anonymous_getInstance();
      case 'useCredentials':
        return ECorsSetting$useCredentials_getInstance();
      default:throwISE('No enum constant o.katydid.vdom.types.ECorsSetting.' + name);
    }
  }
  ECorsSetting.valueOf_61zpoe$ = ECorsSetting$valueOf;
  function EDirection(name, ordinal, html) {
    Enum.call(this);
    this.html_cnqrjr$_0 = html;
    this.name$ = name;
    this.ordinal$ = ordinal;
  }
  function EDirection_initFields() {
    EDirection_initFields = function () {
    };
    EDirection$ltr_instance = new EDirection('ltr', 0, 'ltr');
    EDirection$rtl_instance = new EDirection('rtl', 1, 'rtl');
    EDirection$auto_instance = new EDirection('auto', 2, 'auto');
  }
  var EDirection$ltr_instance;
  function EDirection$ltr_getInstance() {
    EDirection_initFields();
    return EDirection$ltr_instance;
  }
  var EDirection$rtl_instance;
  function EDirection$rtl_getInstance() {
    EDirection_initFields();
    return EDirection$rtl_instance;
  }
  var EDirection$auto_instance;
  function EDirection$auto_getInstance() {
    EDirection_initFields();
    return EDirection$auto_instance;
  }
  EDirection.prototype.toHtmlString = function () {
    return this.html_cnqrjr$_0;
  };
  EDirection.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'EDirection',
    interfaces: [Enum]
  };
  function EDirection$values() {
    return [EDirection$ltr_getInstance(), EDirection$rtl_getInstance(), EDirection$auto_getInstance()];
  }
  EDirection.values = EDirection$values;
  function EDirection$valueOf(name) {
    switch (name) {
      case 'ltr':
        return EDirection$ltr_getInstance();
      case 'rtl':
        return EDirection$rtl_getInstance();
      case 'auto':
        return EDirection$auto_getInstance();
      default:throwISE('No enum constant o.katydid.vdom.types.EDirection.' + name);
    }
  }
  EDirection.valueOf_61zpoe$ = EDirection$valueOf;
  function EFormEncodingType(name, ordinal, html) {
    Enum.call(this);
    this.html_6z3qmv$_0 = html;
    this.name$ = name;
    this.ordinal$ = ordinal;
  }
  function EFormEncodingType_initFields() {
    EFormEncodingType_initFields = function () {
    };
    EFormEncodingType$multipartFormData_instance = new EFormEncodingType('multipartFormData', 0, 'multipart/form-data');
    EFormEncodingType$textPlain_instance = new EFormEncodingType('textPlain', 1, 'text/plain');
    EFormEncodingType$wwwFormUrlEncoded_instance = new EFormEncodingType('wwwFormUrlEncoded', 2, 'application/x-www-form-urlencoded');
  }
  var EFormEncodingType$multipartFormData_instance;
  function EFormEncodingType$multipartFormData_getInstance() {
    EFormEncodingType_initFields();
    return EFormEncodingType$multipartFormData_instance;
  }
  var EFormEncodingType$textPlain_instance;
  function EFormEncodingType$textPlain_getInstance() {
    EFormEncodingType_initFields();
    return EFormEncodingType$textPlain_instance;
  }
  var EFormEncodingType$wwwFormUrlEncoded_instance;
  function EFormEncodingType$wwwFormUrlEncoded_getInstance() {
    EFormEncodingType_initFields();
    return EFormEncodingType$wwwFormUrlEncoded_instance;
  }
  EFormEncodingType.prototype.toHtmlString = function () {
    return this.html_6z3qmv$_0;
  };
  EFormEncodingType.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'EFormEncodingType',
    interfaces: [Enum]
  };
  function EFormEncodingType$values() {
    return [EFormEncodingType$multipartFormData_getInstance(), EFormEncodingType$textPlain_getInstance(), EFormEncodingType$wwwFormUrlEncoded_getInstance()];
  }
  EFormEncodingType.values = EFormEncodingType$values;
  function EFormEncodingType$valueOf(name) {
    switch (name) {
      case 'multipartFormData':
        return EFormEncodingType$multipartFormData_getInstance();
      case 'textPlain':
        return EFormEncodingType$textPlain_getInstance();
      case 'wwwFormUrlEncoded':
        return EFormEncodingType$wwwFormUrlEncoded_getInstance();
      default:throwISE('No enum constant o.katydid.vdom.types.EFormEncodingType.' + name);
    }
  }
  EFormEncodingType.valueOf_61zpoe$ = EFormEncodingType$valueOf;
  function EFormSubmissionMethod(name, ordinal, html) {
    Enum.call(this);
    this.html_ekmnt5$_0 = html;
    this.name$ = name;
    this.ordinal$ = ordinal;
  }
  function EFormSubmissionMethod_initFields() {
    EFormSubmissionMethod_initFields = function () {
    };
    EFormSubmissionMethod$get_instance = new EFormSubmissionMethod('get', 0, 'get');
    EFormSubmissionMethod$post_instance = new EFormSubmissionMethod('post', 1, 'post');
  }
  var EFormSubmissionMethod$get_instance;
  function EFormSubmissionMethod$get_getInstance() {
    EFormSubmissionMethod_initFields();
    return EFormSubmissionMethod$get_instance;
  }
  var EFormSubmissionMethod$post_instance;
  function EFormSubmissionMethod$post_getInstance() {
    EFormSubmissionMethod_initFields();
    return EFormSubmissionMethod$post_instance;
  }
  EFormSubmissionMethod.prototype.toHtmlString = function () {
    return this.html_ekmnt5$_0;
  };
  EFormSubmissionMethod.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'EFormSubmissionMethod',
    interfaces: [Enum]
  };
  function EFormSubmissionMethod$values() {
    return [EFormSubmissionMethod$get_getInstance(), EFormSubmissionMethod$post_getInstance()];
  }
  EFormSubmissionMethod.values = EFormSubmissionMethod$values;
  function EFormSubmissionMethod$valueOf(name) {
    switch (name) {
      case 'get':
        return EFormSubmissionMethod$get_getInstance();
      case 'post':
        return EFormSubmissionMethod$post_getInstance();
      default:throwISE('No enum constant o.katydid.vdom.types.EFormSubmissionMethod.' + name);
    }
  }
  EFormSubmissionMethod.valueOf_61zpoe$ = EFormSubmissionMethod$valueOf;
  function EHeadingScope(name, ordinal, html) {
    Enum.call(this);
    this.html_dgin4a$_0 = html;
    this.name$ = name;
    this.ordinal$ = ordinal;
  }
  function EHeadingScope_initFields() {
    EHeadingScope_initFields = function () {
    };
    EHeadingScope$col_instance = new EHeadingScope('col', 0, 'col');
    EHeadingScope$colgroup_instance = new EHeadingScope('colgroup', 1, 'colgroup');
    EHeadingScope$row_instance = new EHeadingScope('row', 2, 'row');
    EHeadingScope$rowgroup_instance = new EHeadingScope('rowgroup', 3, 'rowgroup');
  }
  var EHeadingScope$col_instance;
  function EHeadingScope$col_getInstance() {
    EHeadingScope_initFields();
    return EHeadingScope$col_instance;
  }
  var EHeadingScope$colgroup_instance;
  function EHeadingScope$colgroup_getInstance() {
    EHeadingScope_initFields();
    return EHeadingScope$colgroup_instance;
  }
  var EHeadingScope$row_instance;
  function EHeadingScope$row_getInstance() {
    EHeadingScope_initFields();
    return EHeadingScope$row_instance;
  }
  var EHeadingScope$rowgroup_instance;
  function EHeadingScope$rowgroup_getInstance() {
    EHeadingScope_initFields();
    return EHeadingScope$rowgroup_instance;
  }
  EHeadingScope.prototype.toHtmlString = function () {
    return this.html_dgin4a$_0;
  };
  EHeadingScope.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'EHeadingScope',
    interfaces: [Enum]
  };
  function EHeadingScope$values() {
    return [EHeadingScope$col_getInstance(), EHeadingScope$colgroup_getInstance(), EHeadingScope$row_getInstance(), EHeadingScope$rowgroup_getInstance()];
  }
  EHeadingScope.values = EHeadingScope$values;
  function EHeadingScope$valueOf(name) {
    switch (name) {
      case 'col':
        return EHeadingScope$col_getInstance();
      case 'colgroup':
        return EHeadingScope$colgroup_getInstance();
      case 'row':
        return EHeadingScope$row_getInstance();
      case 'rowgroup':
        return EHeadingScope$rowgroup_getInstance();
      default:throwISE('No enum constant o.katydid.vdom.types.EHeadingScope.' + name);
    }
  }
  EHeadingScope.valueOf_61zpoe$ = EHeadingScope$valueOf;
  function EOrderedListType(name, ordinal, html) {
    Enum.call(this);
    this.html_lqqs6p$_0 = html;
    this.name$ = name;
    this.ordinal$ = ordinal;
  }
  function EOrderedListType_initFields() {
    EOrderedListType_initFields = function () {
    };
    EOrderedListType$decimalNumbers_instance = new EOrderedListType('decimalNumbers', 0, '1');
    EOrderedListType$lowerCaseLetters_instance = new EOrderedListType('lowerCaseLetters', 1, 'a');
    EOrderedListType$upperCaseLetters_instance = new EOrderedListType('upperCaseLetters', 2, 'A');
    EOrderedListType$lowerCaseRomanNumerals_instance = new EOrderedListType('lowerCaseRomanNumerals', 3, 'i');
    EOrderedListType$upperCaseRomanNumerals_instance = new EOrderedListType('upperCaseRomanNumerals', 4, 'I');
  }
  var EOrderedListType$decimalNumbers_instance;
  function EOrderedListType$decimalNumbers_getInstance() {
    EOrderedListType_initFields();
    return EOrderedListType$decimalNumbers_instance;
  }
  var EOrderedListType$lowerCaseLetters_instance;
  function EOrderedListType$lowerCaseLetters_getInstance() {
    EOrderedListType_initFields();
    return EOrderedListType$lowerCaseLetters_instance;
  }
  var EOrderedListType$upperCaseLetters_instance;
  function EOrderedListType$upperCaseLetters_getInstance() {
    EOrderedListType_initFields();
    return EOrderedListType$upperCaseLetters_instance;
  }
  var EOrderedListType$lowerCaseRomanNumerals_instance;
  function EOrderedListType$lowerCaseRomanNumerals_getInstance() {
    EOrderedListType_initFields();
    return EOrderedListType$lowerCaseRomanNumerals_instance;
  }
  var EOrderedListType$upperCaseRomanNumerals_instance;
  function EOrderedListType$upperCaseRomanNumerals_getInstance() {
    EOrderedListType_initFields();
    return EOrderedListType$upperCaseRomanNumerals_instance;
  }
  EOrderedListType.prototype.toHtmlString = function () {
    return this.html_lqqs6p$_0;
  };
  EOrderedListType.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'EOrderedListType',
    interfaces: [Enum]
  };
  function EOrderedListType$values() {
    return [EOrderedListType$decimalNumbers_getInstance(), EOrderedListType$lowerCaseLetters_getInstance(), EOrderedListType$upperCaseLetters_getInstance(), EOrderedListType$lowerCaseRomanNumerals_getInstance(), EOrderedListType$upperCaseRomanNumerals_getInstance()];
  }
  EOrderedListType.values = EOrderedListType$values;
  function EOrderedListType$valueOf(name) {
    switch (name) {
      case 'decimalNumbers':
        return EOrderedListType$decimalNumbers_getInstance();
      case 'lowerCaseLetters':
        return EOrderedListType$lowerCaseLetters_getInstance();
      case 'upperCaseLetters':
        return EOrderedListType$upperCaseLetters_getInstance();
      case 'lowerCaseRomanNumerals':
        return EOrderedListType$lowerCaseRomanNumerals_getInstance();
      case 'upperCaseRomanNumerals':
        return EOrderedListType$upperCaseRomanNumerals_getInstance();
      default:throwISE('No enum constant o.katydid.vdom.types.EOrderedListType.' + name);
    }
  }
  EOrderedListType.valueOf_61zpoe$ = EOrderedListType$valueOf;
  function EPreloadHint(name, ordinal, html) {
    Enum.call(this);
    this.html_qxcxty$_0 = html;
    this.name$ = name;
    this.ordinal$ = ordinal;
  }
  function EPreloadHint_initFields() {
    EPreloadHint_initFields = function () {
    };
    EPreloadHint$auto_instance = new EPreloadHint('auto', 0, 'auto');
    EPreloadHint$metadata_instance = new EPreloadHint('metadata', 1, 'metadata');
    EPreloadHint$none_instance = new EPreloadHint('none', 2, 'none');
  }
  var EPreloadHint$auto_instance;
  function EPreloadHint$auto_getInstance() {
    EPreloadHint_initFields();
    return EPreloadHint$auto_instance;
  }
  var EPreloadHint$metadata_instance;
  function EPreloadHint$metadata_getInstance() {
    EPreloadHint_initFields();
    return EPreloadHint$metadata_instance;
  }
  var EPreloadHint$none_instance;
  function EPreloadHint$none_getInstance() {
    EPreloadHint_initFields();
    return EPreloadHint$none_instance;
  }
  EPreloadHint.prototype.toHtmlString = function () {
    return this.html_qxcxty$_0;
  };
  EPreloadHint.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'EPreloadHint',
    interfaces: [Enum]
  };
  function EPreloadHint$values() {
    return [EPreloadHint$auto_getInstance(), EPreloadHint$metadata_getInstance(), EPreloadHint$none_getInstance()];
  }
  EPreloadHint.values = EPreloadHint$values;
  function EPreloadHint$valueOf(name) {
    switch (name) {
      case 'auto':
        return EPreloadHint$auto_getInstance();
      case 'metadata':
        return EPreloadHint$metadata_getInstance();
      case 'none':
        return EPreloadHint$none_getInstance();
      default:throwISE('No enum constant o.katydid.vdom.types.EPreloadHint.' + name);
    }
  }
  EPreloadHint.valueOf_61zpoe$ = EPreloadHint$valueOf;
  function EReferrerPolicy(name, ordinal, html) {
    Enum.call(this);
    this.html_fvd3d5$_0 = html;
    this.name$ = name;
    this.ordinal$ = ordinal;
  }
  function EReferrerPolicy_initFields() {
    EReferrerPolicy_initFields = function () {
    };
    EReferrerPolicy$noReferrer_instance = new EReferrerPolicy('noReferrer', 0, 'no-referrer');
    EReferrerPolicy$noReferrerWhenDowngrade_instance = new EReferrerPolicy('noReferrerWhenDowngrade', 1, 'no-referrer-when-downgrade');
    EReferrerPolicy$origin_instance = new EReferrerPolicy('origin', 2, 'origin');
    EReferrerPolicy$originWhenCrossOrigin_instance = new EReferrerPolicy('originWhenCrossOrigin', 3, 'origin-when-cross-origin');
    EReferrerPolicy$sameOrigin_instance = new EReferrerPolicy('sameOrigin', 4, 'same-origin');
    EReferrerPolicy$strictOrigin_instance = new EReferrerPolicy('strictOrigin', 5, 'strict-origin');
    EReferrerPolicy$strictOriginWhenCrossOrigin_instance = new EReferrerPolicy('strictOriginWhenCrossOrigin', 6, 'strict-origin-when-cross-origin');
    EReferrerPolicy$unsafeUrl_instance = new EReferrerPolicy('unsafeUrl', 7, 'unsafe-url');
  }
  var EReferrerPolicy$noReferrer_instance;
  function EReferrerPolicy$noReferrer_getInstance() {
    EReferrerPolicy_initFields();
    return EReferrerPolicy$noReferrer_instance;
  }
  var EReferrerPolicy$noReferrerWhenDowngrade_instance;
  function EReferrerPolicy$noReferrerWhenDowngrade_getInstance() {
    EReferrerPolicy_initFields();
    return EReferrerPolicy$noReferrerWhenDowngrade_instance;
  }
  var EReferrerPolicy$origin_instance;
  function EReferrerPolicy$origin_getInstance() {
    EReferrerPolicy_initFields();
    return EReferrerPolicy$origin_instance;
  }
  var EReferrerPolicy$originWhenCrossOrigin_instance;
  function EReferrerPolicy$originWhenCrossOrigin_getInstance() {
    EReferrerPolicy_initFields();
    return EReferrerPolicy$originWhenCrossOrigin_instance;
  }
  var EReferrerPolicy$sameOrigin_instance;
  function EReferrerPolicy$sameOrigin_getInstance() {
    EReferrerPolicy_initFields();
    return EReferrerPolicy$sameOrigin_instance;
  }
  var EReferrerPolicy$strictOrigin_instance;
  function EReferrerPolicy$strictOrigin_getInstance() {
    EReferrerPolicy_initFields();
    return EReferrerPolicy$strictOrigin_instance;
  }
  var EReferrerPolicy$strictOriginWhenCrossOrigin_instance;
  function EReferrerPolicy$strictOriginWhenCrossOrigin_getInstance() {
    EReferrerPolicy_initFields();
    return EReferrerPolicy$strictOriginWhenCrossOrigin_instance;
  }
  var EReferrerPolicy$unsafeUrl_instance;
  function EReferrerPolicy$unsafeUrl_getInstance() {
    EReferrerPolicy_initFields();
    return EReferrerPolicy$unsafeUrl_instance;
  }
  EReferrerPolicy.prototype.toHtmlString = function () {
    return this.html_fvd3d5$_0;
  };
  EReferrerPolicy.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'EReferrerPolicy',
    interfaces: [Enum]
  };
  function EReferrerPolicy$values() {
    return [EReferrerPolicy$noReferrer_getInstance(), EReferrerPolicy$noReferrerWhenDowngrade_getInstance(), EReferrerPolicy$origin_getInstance(), EReferrerPolicy$originWhenCrossOrigin_getInstance(), EReferrerPolicy$sameOrigin_getInstance(), EReferrerPolicy$strictOrigin_getInstance(), EReferrerPolicy$strictOriginWhenCrossOrigin_getInstance(), EReferrerPolicy$unsafeUrl_getInstance()];
  }
  EReferrerPolicy.values = EReferrerPolicy$values;
  function EReferrerPolicy$valueOf(name) {
    switch (name) {
      case 'noReferrer':
        return EReferrerPolicy$noReferrer_getInstance();
      case 'noReferrerWhenDowngrade':
        return EReferrerPolicy$noReferrerWhenDowngrade_getInstance();
      case 'origin':
        return EReferrerPolicy$origin_getInstance();
      case 'originWhenCrossOrigin':
        return EReferrerPolicy$originWhenCrossOrigin_getInstance();
      case 'sameOrigin':
        return EReferrerPolicy$sameOrigin_getInstance();
      case 'strictOrigin':
        return EReferrerPolicy$strictOrigin_getInstance();
      case 'strictOriginWhenCrossOrigin':
        return EReferrerPolicy$strictOriginWhenCrossOrigin_getInstance();
      case 'unsafeUrl':
        return EReferrerPolicy$unsafeUrl_getInstance();
      default:throwISE('No enum constant o.katydid.vdom.types.EReferrerPolicy.' + name);
    }
  }
  EReferrerPolicy.valueOf_61zpoe$ = EReferrerPolicy$valueOf;
  function ESandboxOption(name, ordinal, html) {
    Enum.call(this);
    this.html_3mk38m$_0 = html;
    this.name$ = name;
    this.ordinal$ = ordinal;
  }
  function ESandboxOption_initFields() {
    ESandboxOption_initFields = function () {
    };
    ESandboxOption$allowForms_instance = new ESandboxOption('allowForms', 0, 'allow-forms');
    ESandboxOption$allowPointerLock_instance = new ESandboxOption('allowPointerLock', 1, 'allow-pointer-lock');
    ESandboxOption$allowPopups_instance = new ESandboxOption('allowPopups', 2, 'allow-popups');
    ESandboxOption$allowPresentation_instance = new ESandboxOption('allowPresentation', 3, 'allow-presentation');
    ESandboxOption$allowSameOrigin_instance = new ESandboxOption('allowSameOrigin', 4, 'allow-same-origin');
    ESandboxOption$allowScripts_instance = new ESandboxOption('allowScripts', 5, 'allow-scripts');
    ESandboxOption$allowTopNavigation_instance = new ESandboxOption('allowTopNavigation', 6, 'allow-top-navigation');
  }
  var ESandboxOption$allowForms_instance;
  function ESandboxOption$allowForms_getInstance() {
    ESandboxOption_initFields();
    return ESandboxOption$allowForms_instance;
  }
  var ESandboxOption$allowPointerLock_instance;
  function ESandboxOption$allowPointerLock_getInstance() {
    ESandboxOption_initFields();
    return ESandboxOption$allowPointerLock_instance;
  }
  var ESandboxOption$allowPopups_instance;
  function ESandboxOption$allowPopups_getInstance() {
    ESandboxOption_initFields();
    return ESandboxOption$allowPopups_instance;
  }
  var ESandboxOption$allowPresentation_instance;
  function ESandboxOption$allowPresentation_getInstance() {
    ESandboxOption_initFields();
    return ESandboxOption$allowPresentation_instance;
  }
  var ESandboxOption$allowSameOrigin_instance;
  function ESandboxOption$allowSameOrigin_getInstance() {
    ESandboxOption_initFields();
    return ESandboxOption$allowSameOrigin_instance;
  }
  var ESandboxOption$allowScripts_instance;
  function ESandboxOption$allowScripts_getInstance() {
    ESandboxOption_initFields();
    return ESandboxOption$allowScripts_instance;
  }
  var ESandboxOption$allowTopNavigation_instance;
  function ESandboxOption$allowTopNavigation_getInstance() {
    ESandboxOption_initFields();
    return ESandboxOption$allowTopNavigation_instance;
  }
  ESandboxOption.prototype.toHtmlString = function () {
    return this.html_3mk38m$_0;
  };
  ESandboxOption.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'ESandboxOption',
    interfaces: [Enum]
  };
  function ESandboxOption$values() {
    return [ESandboxOption$allowForms_getInstance(), ESandboxOption$allowPointerLock_getInstance(), ESandboxOption$allowPopups_getInstance(), ESandboxOption$allowPresentation_getInstance(), ESandboxOption$allowSameOrigin_getInstance(), ESandboxOption$allowScripts_getInstance(), ESandboxOption$allowTopNavigation_getInstance()];
  }
  ESandboxOption.values = ESandboxOption$values;
  function ESandboxOption$valueOf(name) {
    switch (name) {
      case 'allowForms':
        return ESandboxOption$allowForms_getInstance();
      case 'allowPointerLock':
        return ESandboxOption$allowPointerLock_getInstance();
      case 'allowPopups':
        return ESandboxOption$allowPopups_getInstance();
      case 'allowPresentation':
        return ESandboxOption$allowPresentation_getInstance();
      case 'allowSameOrigin':
        return ESandboxOption$allowSameOrigin_getInstance();
      case 'allowScripts':
        return ESandboxOption$allowScripts_getInstance();
      case 'allowTopNavigation':
        return ESandboxOption$allowTopNavigation_getInstance();
      default:throwISE('No enum constant o.katydid.vdom.types.ESandboxOption.' + name);
    }
  }
  ESandboxOption.valueOf_61zpoe$ = ESandboxOption$valueOf;
  function ETrackKind(name, ordinal, html) {
    Enum.call(this);
    this.html_wxl0xj$_0 = html;
    this.name$ = name;
    this.ordinal$ = ordinal;
  }
  function ETrackKind_initFields() {
    ETrackKind_initFields = function () {
    };
    ETrackKind$captions_instance = new ETrackKind('captions', 0, 'captions');
    ETrackKind$chapters_instance = new ETrackKind('chapters', 1, 'chapters');
    ETrackKind$descriptions_instance = new ETrackKind('descriptions', 2, 'descriptions');
    ETrackKind$metadata_instance = new ETrackKind('metadata', 3, 'metadata');
    ETrackKind$subtitles_instance = new ETrackKind('subtitles', 4, 'subtitles');
  }
  var ETrackKind$captions_instance;
  function ETrackKind$captions_getInstance() {
    ETrackKind_initFields();
    return ETrackKind$captions_instance;
  }
  var ETrackKind$chapters_instance;
  function ETrackKind$chapters_getInstance() {
    ETrackKind_initFields();
    return ETrackKind$chapters_instance;
  }
  var ETrackKind$descriptions_instance;
  function ETrackKind$descriptions_getInstance() {
    ETrackKind_initFields();
    return ETrackKind$descriptions_instance;
  }
  var ETrackKind$metadata_instance;
  function ETrackKind$metadata_getInstance() {
    ETrackKind_initFields();
    return ETrackKind$metadata_instance;
  }
  var ETrackKind$subtitles_instance;
  function ETrackKind$subtitles_getInstance() {
    ETrackKind_initFields();
    return ETrackKind$subtitles_instance;
  }
  ETrackKind.prototype.toHtmlString = function () {
    return this.html_wxl0xj$_0;
  };
  ETrackKind.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'ETrackKind',
    interfaces: [Enum]
  };
  function ETrackKind$values() {
    return [ETrackKind$captions_getInstance(), ETrackKind$chapters_getInstance(), ETrackKind$descriptions_getInstance(), ETrackKind$metadata_getInstance(), ETrackKind$subtitles_getInstance()];
  }
  ETrackKind.values = ETrackKind$values;
  function ETrackKind$valueOf(name) {
    switch (name) {
      case 'captions':
        return ETrackKind$captions_getInstance();
      case 'chapters':
        return ETrackKind$chapters_getInstance();
      case 'descriptions':
        return ETrackKind$descriptions_getInstance();
      case 'metadata':
        return ETrackKind$metadata_getInstance();
      case 'subtitles':
        return ETrackKind$subtitles_getInstance();
      default:throwISE('No enum constant o.katydid.vdom.types.ETrackKind.' + name);
    }
  }
  ETrackKind.valueOf_61zpoe$ = ETrackKind$valueOf;
  function EWrapType(name, ordinal, html) {
    Enum.call(this);
    this.html_u35gak$_0 = html;
    this.name$ = name;
    this.ordinal$ = ordinal;
  }
  function EWrapType_initFields() {
    EWrapType_initFields = function () {
    };
    EWrapType$hard_instance = new EWrapType('hard', 0, 'hard');
    EWrapType$soft_instance = new EWrapType('soft', 1, 'soft');
  }
  var EWrapType$hard_instance;
  function EWrapType$hard_getInstance() {
    EWrapType_initFields();
    return EWrapType$hard_instance;
  }
  var EWrapType$soft_instance;
  function EWrapType$soft_getInstance() {
    EWrapType_initFields();
    return EWrapType$soft_instance;
  }
  EWrapType.prototype.toHtmlString = function () {
    return this.html_u35gak$_0;
  };
  EWrapType.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'EWrapType',
    interfaces: [Enum]
  };
  function EWrapType$values() {
    return [EWrapType$hard_getInstance(), EWrapType$soft_getInstance()];
  }
  EWrapType.values = EWrapType$values;
  function EWrapType$valueOf(name) {
    switch (name) {
      case 'hard':
        return EWrapType$hard_getInstance();
      case 'soft':
        return EWrapType$soft_getInstance();
      default:throwISE('No enum constant o.katydid.vdom.types.EWrapType.' + name);
    }
  }
  EWrapType.valueOf_61zpoe$ = EWrapType$valueOf;
  function EventCancellationException() {
    RuntimeException_init(this);
    this.name = 'EventCancellationException';
  }
  EventCancellationException.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'EventCancellationException',
    interfaces: [RuntimeException]
  };
  function MimeType(type, subtype, parameters) {
    MimeType$Companion_getInstance();
    if (parameters === void 0) {
      parameters = emptyMap();
    }
    this.type = type;
    this.subtype = subtype;
    this.parameters = parameters;
    if (!!(this.type.length === 0)) {
      var message = 'MIME type cannot be empty.';
      throw IllegalArgumentException_init(message.toString());
    }
    if (!!(this.subtype.length === 0)) {
      var message_0 = 'MIME subtype cannot be empty.';
      throw IllegalArgumentException_init(message_0.toString());
    }
  }
  MimeType.prototype.toString = function () {
    var tmp$;
    var result = this.type + '/' + this.subtype;
    tmp$ = this.parameters.entries.iterator();
    while (tmp$.hasNext()) {
      var tmp$_0 = tmp$.next();
      var key = tmp$_0.key;
      var value = tmp$_0.value;
      result += '; ' + key + '=' + value;
    }
    return result;
  };
  function MimeType$Companion() {
    MimeType$Companion_instance = this;
  }
  MimeType$Companion.prototype.fromString_61zpoe$ = function (mimeType) {
    var tmp$;
    var slashSplit = split(mimeType, ['/']);
    if (!(slashSplit.size === 2)) {
      var message = "Expected one '/' in MIME type '" + mimeType + "'.";
      throw IllegalArgumentException_init(message.toString());
    }
    var type = slashSplit.get_za3lpa$(0);
    if (!!(type.length === 0)) {
      var message_0 = "Type cannot be empty in MIME type '" + mimeType + "'.";
      throw IllegalArgumentException_init(message_0.toString());
    }
    var semicolonSplit = split(slashSplit.get_za3lpa$(1), [';']);
    var subtype = semicolonSplit.get_za3lpa$(0);
    if (!!(subtype.length === 0)) {
      var message_1 = "Subtype cannot be empty in MIME type '" + mimeType + "'.";
      throw IllegalArgumentException_init(message_1.toString());
    }
    var parameters = LinkedHashMap_init();
    tmp$ = semicolonSplit.size;
    for (var i = 1; i < tmp$; i++) {
      var equalsSplit = split(semicolonSplit.get_za3lpa$(i), ['=']);
      if (!(equalsSplit.size === 2)) {
        var message_2 = "Expected one '=' in MIME type parameter '" + mimeType + "'.";
        throw IllegalArgumentException_init(message_2.toString());
      }
      var key = equalsSplit.get_za3lpa$(0);
      var value = equalsSplit.get_za3lpa$(1);
      parameters.put_xwzc9p$(key, value);
    }
    return new MimeType(type, subtype, parameters);
  };
  MimeType$Companion.$metadata$ = {
    kind: Kind_OBJECT,
    simpleName: 'Companion',
    interfaces: []
  };
  var MimeType$Companion_instance = null;
  function MimeType$Companion_getInstance() {
    if (MimeType$Companion_instance === null) {
      new MimeType$Companion();
    }
    return MimeType$Companion_instance;
  }
  MimeType.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'MimeType',
    interfaces: []
  };
  function removeAttributeAndProperty($receiver, key) {
    $receiver.removeAttribute(key);
    $receiver[key] = null;
  }
  function setAttributeAndProperty($receiver, key, value) {
    $receiver.setAttribute(key, value);
    $receiver[key] = value;
  }
  function setBooleanAttributeAndProperty($receiver, key) {
    $receiver.setAttribute(key, '');
    $receiver[key] = true;
  }
  function formatHtmlDateTime(datetime) {
    return datetime.toISOString();
  }
  function formatHtmlTime(time) {
    return split(time.toISOString(), ['T']).get_za3lpa$(1);
  }
  var package$i = _.i || (_.i = {});
  var package$katydid = package$i.katydid || (package$i.katydid = {});
  var package$vdom = package$katydid.vdom || (package$katydid.vdom = {});
  var package$builders = package$vdom.builders || (package$vdom.builders = {});
  var package$details = package$builders.details || (package$builders.details = {});
  package$details.KatydidDetailsContentRestrictions = KatydidDetailsContentRestrictions;
  package$details.KatydidDetailsFlowContentBuilderImpl = KatydidDetailsFlowContentBuilderImpl;
  package$builders.KatydidAttributesContentBuilderImpl = KatydidAttributesContentBuilderImpl;
  package$builders.KatydidContentRestrictions_init = KatydidContentRestrictions_init;
  package$builders.KatydidContentRestrictions_init_wr4zx4$ = KatydidContentRestrictions_init_0;
  package$builders.KatydidContentRestrictions = KatydidContentRestrictions;
  package$builders.KatydidEmbeddedContentBuilderImpl = KatydidEmbeddedContentBuilderImpl;
  package$builders.KatydidFlowContentBuilderImpl = KatydidFlowContentBuilderImpl;
  package$builders.KatydidPhrasingContentBuilderImpl = KatydidPhrasingContentBuilderImpl;
  var package$lists = package$builders.lists || (package$builders.lists = {});
  package$lists.KatydidOrderedListContentBuilderImpl = KatydidOrderedListContentBuilderImpl;
  package$lists.KatydidUnorderedListContentBuilderImpl = KatydidUnorderedListContentBuilderImpl;
  var package$media = package$builders.media || (package$builders.media = {});
  package$media.KatydidMediaContentRestrictions = KatydidMediaContentRestrictions;
  package$media.KatydidMediaEmbeddedContentBuilderImpl = KatydidMediaEmbeddedContentBuilderImpl;
  package$media.KatydidMediaFlowContentBuilderImpl = KatydidMediaFlowContentBuilderImpl;
  package$media.KatydidMediaPhrasingContentBuilderImpl = KatydidMediaPhrasingContentBuilderImpl;
  package$media.KatydidPictureContentBuilderImpl = KatydidPictureContentBuilderImpl;
  package$media.KatydidPictureContentRestrictions = KatydidPictureContentRestrictions;
  var package$miscellaneous = package$builders.miscellaneous || (package$builders.miscellaneous = {});
  package$miscellaneous.KatydidDescriptionListContentBuilderImpl = KatydidDescriptionListContentBuilderImpl;
  package$miscellaneous.KatydidOptGroupContentBuilderImpl = KatydidOptGroupContentBuilderImpl;
  package$miscellaneous.KatydidSelectContentBuilderImpl = KatydidSelectContentBuilderImpl;
  package$miscellaneous.KatydidTextContentBuilderImpl = KatydidTextContentBuilderImpl;
  var package$objects = package$builders.objects || (package$builders.objects = {});
  package$objects.KatydidObjectEmbeddedContentBuilderImpl = KatydidObjectEmbeddedContentBuilderImpl;
  package$objects.KatydidObjectFlowContentBuilderImpl = KatydidObjectFlowContentBuilderImpl;
  package$objects.KatydidObjectPhrasingContentBuilderImpl = KatydidObjectPhrasingContentBuilderImpl;
  var package$ruby = package$builders.ruby || (package$builders.ruby = {});
  package$ruby.KatydidRubyContentBuilderImpl = KatydidRubyContentBuilderImpl;
  var package$tables = package$builders.tables || (package$builders.tables = {});
  package$tables.KatydidColGroupContentBuilderImpl = KatydidColGroupContentBuilderImpl;
  package$tables.KatydidTableBodyContentBuilderImpl = KatydidTableBodyContentBuilderImpl;
  package$tables.KatydidTableContentBuilderImpl = KatydidTableContentBuilderImpl;
  package$tables.KatydidTableContentRestrictions = KatydidTableContentRestrictions;
  package$tables.KatydidTableRowContentBuilderImpl = KatydidTableRowContentBuilderImpl;
  var package$elements = package$vdom.elements || (package$vdom.elements = {});
  var package$application = package$elements.application || (package$elements.application = {});
  package$application.KatydidAppPseudoNode = KatydidAppPseudoNode;
  var package$edits = package$elements.edits || (package$elements.edits = {});
  package$edits.KatydidDel_init_up947y$ = KatydidDel_init;
  package$edits.KatydidDel_init_gs0lx$ = KatydidDel_init_0;
  package$edits.KatydidDel = KatydidDel;
  package$edits.KatydidIns_init_up947y$ = KatydidIns_init;
  package$edits.KatydidIns_init_gs0lx$ = KatydidIns_init_0;
  package$edits.KatydidIns = KatydidIns;
  var package$embedded = package$elements.embedded || (package$elements.embedded = {});
  package$embedded.KatydidArea = KatydidArea;
  package$embedded.KatydidAudio_init_gnb0ma$ = KatydidAudio_init;
  package$embedded.KatydidAudio_init_rq8w2q$ = KatydidAudio_init_0;
  package$embedded.KatydidAudio_init_t1arfm$ = KatydidAudio_init_1;
  package$embedded.KatydidAudio = KatydidAudio;
  package$embedded.KatydidEmbed = KatydidEmbed;
  package$embedded.KatydidIframe = KatydidIframe;
  package$embedded.KatydidImg_init_w045hw$ = KatydidImg_init;
  package$embedded.KatydidImg_init_5aczk7$ = KatydidImg_init_0;
  package$embedded.KatydidImg = KatydidImg;
  package$embedded.KatydidMap_init_sfgi6l$ = KatydidMap_init;
  package$embedded.KatydidMap_init_7nywhy$ = KatydidMap_init_0;
  package$embedded.KatydidMap = KatydidMap;
  package$embedded.KatydidObject_init_54l41x$ = KatydidObject_init;
  package$embedded.KatydidObject_init_eahlfp$ = KatydidObject_init_0;
  package$embedded.KatydidObject_init_b9w7uj$ = KatydidObject_init_1;
  package$embedded.KatydidObject = KatydidObject;
  package$embedded.KatydidParam_init_6f628e$ = KatydidParam_init;
  package$embedded.KatydidParam_init_l49r02$ = KatydidParam_init_0;
  package$embedded.KatydidParam_init_msoge2$ = KatydidParam_init_1;
  package$embedded.KatydidParam = KatydidParam;
  package$embedded.KatydidPicture = KatydidPicture;
  package$embedded.KatydidSource_init_9lhfox$ = KatydidSource_init;
  package$embedded.KatydidSource_init_rgf44r$ = KatydidSource_init_0;
  package$embedded.KatydidSource_init_x8ku8z$ = KatydidSource_init_1;
  package$embedded.KatydidSource_init_e1bnrz$ = KatydidSource_init_2;
  package$embedded.KatydidSource = KatydidSource;
  package$embedded.KatydidTrack_init_szserm$ = KatydidTrack_init;
  package$embedded.KatydidTrack_init_6ik42m$ = KatydidTrack_init_0;
  package$embedded.KatydidTrack_init_xalt6$ = KatydidTrack_init_1;
  package$embedded.KatydidTrack = KatydidTrack;
  package$embedded.KatydidVideo_init_14kknf$ = KatydidVideo_init;
  package$embedded.KatydidVideo_init_nnblc3$ = KatydidVideo_init_0;
  package$embedded.KatydidVideo_init_w26g4z$ = KatydidVideo_init_1;
  package$embedded.KatydidVideo = KatydidVideo;
  var package$forms = package$elements.forms || (package$elements.forms = {});
  package$forms.KatydidButton = KatydidButton;
  package$forms.KatydidDataList_init_57pjmq$ = KatydidDataList_init;
  package$forms.KatydidDataList_init_k7bxb1$ = KatydidDataList_init_0;
  package$forms.KatydidDataList = KatydidDataList;
  package$forms.KatydidFieldSet = KatydidFieldSet;
  package$forms.KatydidForm = KatydidForm;
  package$forms.KatydidInputButton = KatydidInputButton;
  package$forms.KatydidInputCheckbox = KatydidInputCheckbox;
  package$forms.KatydidInputColor = KatydidInputColor;
  package$forms.KatydidInputDate = KatydidInputDate;
  package$forms.KatydidInputDateTimeLocal = KatydidInputDateTimeLocal;
  package$forms.KatydidInputEmail = KatydidInputEmail;
  package$forms.KatydidInputFile = KatydidInputFile;
  package$forms.KatydidInputHidden = KatydidInputHidden;
  package$forms.KatydidInputImageButton = KatydidInputImageButton;
  package$forms.KatydidInputMonth = KatydidInputMonth;
  package$forms.KatydidInputNumber_init_4aktdo$ = KatydidInputNumber_init;
  package$forms.KatydidInputNumber_init_t5stje$ = KatydidInputNumber_init_0;
  package$forms.KatydidInputNumber = KatydidInputNumber;
  package$forms.KatydidInputPassword = KatydidInputPassword;
  package$forms.KatydidInputRadioButton = KatydidInputRadioButton;
  package$forms.KatydidInputRange = KatydidInputRange;
  package$forms.KatydidInputResetButton = KatydidInputResetButton;
  package$forms.KatydidInputSearch = KatydidInputSearch;
  package$forms.KatydidInputSubmitButton = KatydidInputSubmitButton;
  package$forms.KatydidInputTelephone = KatydidInputTelephone;
  package$forms.KatydidInputText = KatydidInputText;
  package$forms.KatydidInputTime = KatydidInputTime;
  package$forms.KatydidInputUrl = KatydidInputUrl;
  package$forms.KatydidInputWeek = KatydidInputWeek;
  package$forms.KatydidLabel = KatydidLabel;
  package$forms.KatydidLegend = KatydidLegend;
  package$forms.KatydidMeter_init_6ptknz$ = KatydidMeter_init;
  package$forms.KatydidMeter_init_q6vfyw$ = KatydidMeter_init_0;
  package$forms.KatydidMeter = KatydidMeter;
  package$forms.KatydidOptGroup = KatydidOptGroup;
  package$forms.KatydidOption_init_nkf7mw$ = KatydidOption_init;
  package$forms.KatydidOption_init_qbbbk9$ = KatydidOption_init_0;
  package$forms.KatydidOption = KatydidOption;
  package$forms.KatydidOutput = KatydidOutput;
  package$forms.KatydidProgress_init_hiat4m$ = KatydidProgress_init;
  package$forms.KatydidProgress_init_91nlep$ = KatydidProgress_init_0;
  package$forms.KatydidProgress = KatydidProgress;
  package$forms.KatydidSelect = KatydidSelect;
  package$forms.KatydidTextArea = KatydidTextArea;
  var package$grouping = package$elements.grouping || (package$elements.grouping = {});
  package$grouping.KatydidAddress = KatydidAddress;
  package$grouping.KatydidBlockQuote = KatydidBlockQuote;
  package$grouping.KatydidDd = KatydidDd;
  package$grouping.KatydidDiv_init_ftnq6g$ = KatydidDiv_init;
  package$grouping.KatydidDiv_init_lcf2r0$ = KatydidDiv_init_0;
  package$grouping.KatydidDiv = KatydidDiv;
  package$grouping.KatydidDl = KatydidDl;
  package$grouping.KatydidDt = KatydidDt;
  package$grouping.KatydidFigCaption = KatydidFigCaption;
  package$grouping.KatydidFigure = KatydidFigure;
  package$grouping.KatydidHr = KatydidHr;
  package$grouping.KatydidLi_init_n0mox1$ = KatydidLi_init;
  package$grouping.KatydidLi_init_55mpf7$ = KatydidLi_init_0;
  package$grouping.KatydidLi = KatydidLi;
  package$grouping.KatydidMain = KatydidMain;
  package$grouping.KatydidOl = KatydidOl;
  package$grouping.KatydidP = KatydidP;
  package$grouping.KatydidPre = KatydidPre;
  package$grouping.KatydidUl = KatydidUl;
  var package$interactive = package$elements.interactive || (package$elements.interactive = {});
  package$interactive.KatydidDetails = KatydidDetails;
  package$interactive.KatydidDialog = KatydidDialog;
  package$interactive.KatydidSummary_init_l9crg$ = KatydidSummary_init;
  package$interactive.KatydidSummary_init_u8rcb1$ = KatydidSummary_init_0;
  package$interactive.KatydidSummary = KatydidSummary;
  package$elements.KatydidElementImpl_init_ltg95f$ = KatydidElementImpl_init_0;
  package$elements.KatydidElementImpl = KatydidElementImpl;
  package$elements.KatydidHtmlElementImpl = KatydidHtmlElementImpl;
  package$elements.KatydidNodeImpl = KatydidNodeImpl;
  var package$ruby_0 = package$elements.ruby || (package$elements.ruby = {});
  package$ruby_0.KatydidRb = KatydidRb;
  package$ruby_0.KatydidRp = KatydidRp;
  package$ruby_0.KatydidRt = KatydidRt;
  package$ruby_0.KatydidRtc = KatydidRtc;
  package$ruby_0.KatydidRuby = KatydidRuby;
  var package$scripting = package$elements.scripting || (package$elements.scripting = {});
  package$scripting.KatydidCanvas_init_s0pgtk$ = KatydidCanvas_init;
  package$scripting.KatydidCanvas_init_o4p4wo$ = KatydidCanvas_init_0;
  package$scripting.KatydidCanvas_init_r0x6ag$ = KatydidCanvas_init_1;
  package$scripting.KatydidCanvas = KatydidCanvas;
  var package$sections = package$elements.sections || (package$elements.sections = {});
  package$sections.KatydidArticle = KatydidArticle;
  package$sections.KatydidAside = KatydidAside;
  package$sections.KatydidFooter = KatydidFooter;
  package$sections.KatydidH1 = KatydidH1;
  package$sections.KatydidH2 = KatydidH2;
  package$sections.KatydidH3 = KatydidH3;
  package$sections.KatydidH4 = KatydidH4;
  package$sections.KatydidH5 = KatydidH5;
  package$sections.KatydidH6 = KatydidH6;
  package$sections.KatydidHeader = KatydidHeader;
  package$sections.KatydidNav = KatydidNav;
  package$sections.KatydidSection = KatydidSection;
  var package$tabular = package$elements.tabular || (package$elements.tabular = {});
  package$tabular.KatydidCaption = KatydidCaption;
  package$tabular.KatydidCol = KatydidCol;
  package$tabular.KatydidColGroup_init_f1cjbq$ = KatydidColGroup_init;
  package$tabular.KatydidColGroup_init_4hm1u$ = KatydidColGroup_init_0;
  package$tabular.KatydidColGroup = KatydidColGroup;
  package$tabular.KatydidTable = KatydidTable;
  package$tabular.KatydidTBody = KatydidTBody;
  package$tabular.KatydidTd = KatydidTd;
  package$tabular.KatydidTFoot = KatydidTFoot;
  package$tabular.KatydidTh = KatydidTh;
  package$tabular.KatydidTHead = KatydidTHead;
  package$tabular.KatydidTr_init_mj8fcn$ = KatydidTr_init;
  package$tabular.KatydidTr_init_fhfhfd$ = KatydidTr_init_0;
  package$tabular.KatydidTr = KatydidTr;
  var package$text = package$elements.text || (package$elements.text = {});
  package$text.KatydidA_init_n3urt7$ = KatydidA_init;
  package$text.KatydidA_init_f9h397$ = KatydidA_init_0;
  package$text.KatydidA = KatydidA;
  package$text.KatydidAbbr = KatydidAbbr;
  package$text.KatydidB = KatydidB;
  package$text.KatydidBdi = KatydidBdi;
  package$text.KatydidBdo = KatydidBdo;
  package$text.KatydidBr = KatydidBr;
  package$text.KatydidCite = KatydidCite;
  package$text.KatydidCode = KatydidCode;
  package$text.KatydidComment = KatydidComment;
  package$text.KatydidData = KatydidData;
  package$text.KatydidDfn = KatydidDfn;
  package$text.KatydidEm = KatydidEm;
  package$text.KatydidI = KatydidI;
  package$text.KatydidKbd = KatydidKbd;
  package$text.KatydidMark = KatydidMark;
  package$text.KatydidQ = KatydidQ;
  package$text.KatydidS = KatydidS;
  package$text.KatydidSamp = KatydidSamp;
  package$text.KatydidSmall = KatydidSmall;
  package$text.KatydidSpan = KatydidSpan;
  package$text.KatydidStrong = KatydidStrong;
  package$text.KatydidSub = KatydidSub;
  package$text.KatydidSup = KatydidSup;
  package$text.KatydidText = KatydidText;
  package$text.KatydidTime_init_5vu1c1$ = KatydidTime_init;
  package$text.KatydidTime_init_s6316$ = KatydidTime_init_0;
  package$text.KatydidTime = KatydidTime;
  package$text.KatydidU = KatydidU;
  package$text.KatydidVar = KatydidVar;
  package$text.KatydidWbr = KatydidWbr;
  var package$infrastructure = package$vdom.infrastructure || (package$vdom.infrastructure = {});
  package$infrastructure.UnusedMap = UnusedMap;
  package$infrastructure.UnusedSet = UnusedSet;
  var package$lifecycle = package$vdom.lifecycle || (package$vdom.lifecycle = {});
  package$lifecycle.KatydidLifecycleImpl = KatydidLifecycleImpl;
  var package$js = _.js || (_.js = {});
  var package$katydid_0 = package$js.katydid || (package$js.katydid = {});
  var package$vdom_0 = package$katydid_0.vdom || (package$katydid_0.vdom = {});
  var package$api = package$vdom_0.api || (package$vdom_0.api = {});
  package$api.KatydidApplicationCycle = KatydidApplicationCycle;
  package$api.KatydidApplication = KatydidApplication;
  package$api.runApplication_8b6ioz$ = runApplication;
  var package$o = _.o || (_.o = {});
  var package$katydid_1 = package$o.katydid || (package$o.katydid = {});
  var package$vdom_1 = package$katydid_1.vdom || (package$katydid_1.vdom = {});
  var package$application_0 = package$vdom_1.application || (package$vdom_1.application = {});
  package$application_0.katydid_fujzwl$ = katydid;
  package$application_0.katydidComponent_6brk4z$ = katydidComponent;
  package$application_0.katydidListItemsComponent_ywnv0f$ = katydidListItemsComponent;
  package$application_0.katydidListItemsComponent_wiibtr$ = katydidListItemsComponent_0;
  package$application_0.katydidPhrasingComponent_h6115v$ = katydidPhrasingComponent;
  package$application_0.makeKatydidLifecycle_287e2$ = makeKatydidLifecycle;
  package$application_0.KatydidLifecycle = KatydidLifecycle;
  var package$builders_0 = package$vdom_1.builders || (package$vdom_1.builders = {});
  var package$details_0 = package$builders_0.details || (package$builders_0.details = {});
  package$details_0.KatydidDetailsFlowContentBuilder = KatydidDetailsFlowContentBuilder;
  package$builders_0.KatydidAttributesContentBuilder = KatydidAttributesContentBuilder;
  package$builders_0.KatydidContentBuilderDsl = KatydidContentBuilderDsl;
  package$builders_0.KatydidEmbeddedContentBuilder = KatydidEmbeddedContentBuilder;
  package$builders_0.KatydidFlowContentBuilder = KatydidFlowContentBuilder;
  package$builders_0.KatydidHeadingContentBuilder = KatydidHeadingContentBuilder;
  package$builders_0.KatydidPhrasingContentBuilder = KatydidPhrasingContentBuilder;
  package$builders_0.KatydidSectioningContentBuilder = KatydidSectioningContentBuilder;
  var package$lists_0 = package$builders_0.lists || (package$builders_0.lists = {});
  package$lists_0.KatydidOrderedListContentBuilder = KatydidOrderedListContentBuilder;
  package$lists_0.KatydidUnorderedListContentBuilder = KatydidUnorderedListContentBuilder;
  var package$media_0 = package$builders_0.media || (package$builders_0.media = {});
  package$media_0.KatydidMediaEmbeddedContentBuilder = KatydidMediaEmbeddedContentBuilder;
  package$media_0.KatydidMediaFlowContentBuilder = KatydidMediaFlowContentBuilder;
  package$media_0.KatydidMediaPhrasingContentBuilder = KatydidMediaPhrasingContentBuilder;
  package$media_0.KatydidPictureContentBuilder = KatydidPictureContentBuilder;
  var package$miscellaneous_0 = package$builders_0.miscellaneous || (package$builders_0.miscellaneous = {});
  package$miscellaneous_0.KatydidDescriptionListContentBuilder = KatydidDescriptionListContentBuilder;
  package$miscellaneous_0.KatydidOptGroupContentBuilder = KatydidOptGroupContentBuilder;
  package$miscellaneous_0.KatydidSelectContentBuilder = KatydidSelectContentBuilder;
  package$miscellaneous_0.KatydidTextContentBuilder = KatydidTextContentBuilder;
  var package$objects_0 = package$builders_0.objects || (package$builders_0.objects = {});
  package$objects_0.KatydidObjectEmbeddedContentBuilder = KatydidObjectEmbeddedContentBuilder;
  package$objects_0.KatydidObjectFlowContentBuilder = KatydidObjectFlowContentBuilder;
  package$objects_0.KatydidObjectPhrasingContentBuilder = KatydidObjectPhrasingContentBuilder;
  var package$ruby_1 = package$builders_0.ruby || (package$builders_0.ruby = {});
  package$ruby_1.KatydidRubyContentBuilder = KatydidRubyContentBuilder;
  var package$tables_0 = package$builders_0.tables || (package$builders_0.tables = {});
  package$tables_0.KatydidColGroupContentBuilder = KatydidColGroupContentBuilder;
  package$tables_0.KatydidTableBodyContentBuilder = KatydidTableBodyContentBuilder;
  package$tables_0.KatydidTableContentBuilder = KatydidTableContentBuilder;
  package$tables_0.KatydidTableRowContentBuilder = KatydidTableRowContentBuilder;
  var package$elements_0 = package$vdom_1.elements || (package$vdom_1.elements = {});
  package$elements_0.KatydidElement = KatydidElement;
  package$elements_0.KatydidHtmlElement = KatydidHtmlElement;
  package$elements_0.KatydidNode = KatydidNode;
  var package$types = package$vdom_1.types || (package$vdom_1.types = {});
  package$types.ContentType = ContentType;
  Object.defineProperty(package$types, 'EmbeddedContent', {
    get: EmbeddedContent_getInstance
  });
  Object.defineProperty(package$types, 'FlowContent', {
    get: FlowContent_getInstance
  });
  Object.defineProperty(package$types, 'PhrasingContent', {
    get: PhrasingContent_getInstance
  });
  Object.defineProperty(EAnchorHtmlLinkType, 'alternate', {
    get: EAnchorHtmlLinkType$alternate_getInstance
  });
  Object.defineProperty(EAnchorHtmlLinkType, 'author', {
    get: EAnchorHtmlLinkType$author_getInstance
  });
  Object.defineProperty(EAnchorHtmlLinkType, 'bookmark', {
    get: EAnchorHtmlLinkType$bookmark_getInstance
  });
  Object.defineProperty(EAnchorHtmlLinkType, 'help', {
    get: EAnchorHtmlLinkType$help_getInstance
  });
  Object.defineProperty(EAnchorHtmlLinkType, 'license', {
    get: EAnchorHtmlLinkType$license_getInstance
  });
  Object.defineProperty(EAnchorHtmlLinkType, 'next', {
    get: EAnchorHtmlLinkType$next_getInstance
  });
  Object.defineProperty(EAnchorHtmlLinkType, 'nofollow', {
    get: EAnchorHtmlLinkType$nofollow_getInstance
  });
  Object.defineProperty(EAnchorHtmlLinkType, 'noreferrer', {
    get: EAnchorHtmlLinkType$noreferrer_getInstance
  });
  Object.defineProperty(EAnchorHtmlLinkType, 'prev', {
    get: EAnchorHtmlLinkType$prev_getInstance
  });
  Object.defineProperty(EAnchorHtmlLinkType, 'search', {
    get: EAnchorHtmlLinkType$search_getInstance
  });
  Object.defineProperty(EAnchorHtmlLinkType, 'tag', {
    get: EAnchorHtmlLinkType$tag_getInstance
  });
  package$types.EAnchorHtmlLinkType = EAnchorHtmlLinkType;
  Object.defineProperty(EAreaShape, 'circle', {
    get: EAreaShape$circle_getInstance
  });
  Object.defineProperty(EAreaShape, 'default', {
    get: EAreaShape$default_getInstance
  });
  Object.defineProperty(EAreaShape, 'poly', {
    get: EAreaShape$poly_getInstance
  });
  Object.defineProperty(EAreaShape, 'rect', {
    get: EAreaShape$rect_getInstance
  });
  package$types.EAreaShape = EAreaShape;
  Object.defineProperty(EButtonType, 'button', {
    get: EButtonType$button_getInstance
  });
  Object.defineProperty(EButtonType, 'menu', {
    get: EButtonType$menu_getInstance
  });
  Object.defineProperty(EButtonType, 'reset', {
    get: EButtonType$reset_getInstance
  });
  Object.defineProperty(EButtonType, 'submit', {
    get: EButtonType$submit_getInstance
  });
  package$types.EButtonType = EButtonType;
  Object.defineProperty(ECorsSetting, 'anonymous', {
    get: ECorsSetting$anonymous_getInstance
  });
  Object.defineProperty(ECorsSetting, 'useCredentials', {
    get: ECorsSetting$useCredentials_getInstance
  });
  package$types.ECorsSetting = ECorsSetting;
  Object.defineProperty(EDirection, 'ltr', {
    get: EDirection$ltr_getInstance
  });
  Object.defineProperty(EDirection, 'rtl', {
    get: EDirection$rtl_getInstance
  });
  Object.defineProperty(EDirection, 'auto', {
    get: EDirection$auto_getInstance
  });
  package$types.EDirection = EDirection;
  Object.defineProperty(EFormEncodingType, 'multipartFormData', {
    get: EFormEncodingType$multipartFormData_getInstance
  });
  Object.defineProperty(EFormEncodingType, 'textPlain', {
    get: EFormEncodingType$textPlain_getInstance
  });
  Object.defineProperty(EFormEncodingType, 'wwwFormUrlEncoded', {
    get: EFormEncodingType$wwwFormUrlEncoded_getInstance
  });
  package$types.EFormEncodingType = EFormEncodingType;
  Object.defineProperty(EFormSubmissionMethod, 'get', {
    get: EFormSubmissionMethod$get_getInstance
  });
  Object.defineProperty(EFormSubmissionMethod, 'post', {
    get: EFormSubmissionMethod$post_getInstance
  });
  package$types.EFormSubmissionMethod = EFormSubmissionMethod;
  Object.defineProperty(EHeadingScope, 'col', {
    get: EHeadingScope$col_getInstance
  });
  Object.defineProperty(EHeadingScope, 'colgroup', {
    get: EHeadingScope$colgroup_getInstance
  });
  Object.defineProperty(EHeadingScope, 'row', {
    get: EHeadingScope$row_getInstance
  });
  Object.defineProperty(EHeadingScope, 'rowgroup', {
    get: EHeadingScope$rowgroup_getInstance
  });
  package$types.EHeadingScope = EHeadingScope;
  Object.defineProperty(EOrderedListType, 'decimalNumbers', {
    get: EOrderedListType$decimalNumbers_getInstance
  });
  Object.defineProperty(EOrderedListType, 'lowerCaseLetters', {
    get: EOrderedListType$lowerCaseLetters_getInstance
  });
  Object.defineProperty(EOrderedListType, 'upperCaseLetters', {
    get: EOrderedListType$upperCaseLetters_getInstance
  });
  Object.defineProperty(EOrderedListType, 'lowerCaseRomanNumerals', {
    get: EOrderedListType$lowerCaseRomanNumerals_getInstance
  });
  Object.defineProperty(EOrderedListType, 'upperCaseRomanNumerals', {
    get: EOrderedListType$upperCaseRomanNumerals_getInstance
  });
  package$types.EOrderedListType = EOrderedListType;
  Object.defineProperty(EPreloadHint, 'auto', {
    get: EPreloadHint$auto_getInstance
  });
  Object.defineProperty(EPreloadHint, 'metadata', {
    get: EPreloadHint$metadata_getInstance
  });
  Object.defineProperty(EPreloadHint, 'none', {
    get: EPreloadHint$none_getInstance
  });
  package$types.EPreloadHint = EPreloadHint;
  Object.defineProperty(EReferrerPolicy, 'noReferrer', {
    get: EReferrerPolicy$noReferrer_getInstance
  });
  Object.defineProperty(EReferrerPolicy, 'noReferrerWhenDowngrade', {
    get: EReferrerPolicy$noReferrerWhenDowngrade_getInstance
  });
  Object.defineProperty(EReferrerPolicy, 'origin', {
    get: EReferrerPolicy$origin_getInstance
  });
  Object.defineProperty(EReferrerPolicy, 'originWhenCrossOrigin', {
    get: EReferrerPolicy$originWhenCrossOrigin_getInstance
  });
  Object.defineProperty(EReferrerPolicy, 'sameOrigin', {
    get: EReferrerPolicy$sameOrigin_getInstance
  });
  Object.defineProperty(EReferrerPolicy, 'strictOrigin', {
    get: EReferrerPolicy$strictOrigin_getInstance
  });
  Object.defineProperty(EReferrerPolicy, 'strictOriginWhenCrossOrigin', {
    get: EReferrerPolicy$strictOriginWhenCrossOrigin_getInstance
  });
  Object.defineProperty(EReferrerPolicy, 'unsafeUrl', {
    get: EReferrerPolicy$unsafeUrl_getInstance
  });
  package$types.EReferrerPolicy = EReferrerPolicy;
  Object.defineProperty(ESandboxOption, 'allowForms', {
    get: ESandboxOption$allowForms_getInstance
  });
  Object.defineProperty(ESandboxOption, 'allowPointerLock', {
    get: ESandboxOption$allowPointerLock_getInstance
  });
  Object.defineProperty(ESandboxOption, 'allowPopups', {
    get: ESandboxOption$allowPopups_getInstance
  });
  Object.defineProperty(ESandboxOption, 'allowPresentation', {
    get: ESandboxOption$allowPresentation_getInstance
  });
  Object.defineProperty(ESandboxOption, 'allowSameOrigin', {
    get: ESandboxOption$allowSameOrigin_getInstance
  });
  Object.defineProperty(ESandboxOption, 'allowScripts', {
    get: ESandboxOption$allowScripts_getInstance
  });
  Object.defineProperty(ESandboxOption, 'allowTopNavigation', {
    get: ESandboxOption$allowTopNavigation_getInstance
  });
  package$types.ESandboxOption = ESandboxOption;
  Object.defineProperty(ETrackKind, 'captions', {
    get: ETrackKind$captions_getInstance
  });
  Object.defineProperty(ETrackKind, 'chapters', {
    get: ETrackKind$chapters_getInstance
  });
  Object.defineProperty(ETrackKind, 'descriptions', {
    get: ETrackKind$descriptions_getInstance
  });
  Object.defineProperty(ETrackKind, 'metadata', {
    get: ETrackKind$metadata_getInstance
  });
  Object.defineProperty(ETrackKind, 'subtitles', {
    get: ETrackKind$subtitles_getInstance
  });
  package$types.ETrackKind = ETrackKind;
  Object.defineProperty(EWrapType, 'hard', {
    get: EWrapType$hard_getInstance
  });
  Object.defineProperty(EWrapType, 'soft', {
    get: EWrapType$soft_getInstance
  });
  package$types.EWrapType = EWrapType;
  package$types.EventCancellationException = EventCancellationException;
  Object.defineProperty(MimeType, 'Companion', {
    get: MimeType$Companion_getInstance
  });
  package$types.MimeType = MimeType;
  var package$x = _.x || (_.x = {});
  var package$katydid_2 = package$x.katydid || (package$x.katydid = {});
  var package$vdom_2 = package$katydid_2.vdom || (package$katydid_2.vdom = {});
  var package$dom = package$vdom_2.dom || (package$vdom_2.dom = {});
  package$dom.removeAttributeAndProperty_46n0ku$ = removeAttributeAndProperty;
  package$dom.setAttributeAndProperty_ek5kg0$ = setAttributeAndProperty;
  package$dom.setBooleanAttributeAndProperty_46n0ku$ = setBooleanAttributeAndProperty;
  var package$types_0 = package$vdom_2.types || (package$vdom_2.types = {});
  package$types_0.formatHtmlDateTime_qjzqsm$ = formatHtmlDateTime;
  package$types_0.formatHtmlTime_qjzqsm$ = formatHtmlTime;
  KatydidEmbeddedContentBuilderImpl.prototype.audio_if4zjc$ = KatydidEmbeddedContentBuilder.prototype.audio_if4zjc$;
  KatydidEmbeddedContentBuilderImpl.prototype.canvas_ablpy6$ = KatydidEmbeddedContentBuilder.prototype.canvas_ablpy6$;
  KatydidEmbeddedContentBuilderImpl.prototype.embed_nx0pss$ = KatydidEmbeddedContentBuilder.prototype.embed_nx0pss$;
  KatydidEmbeddedContentBuilderImpl.prototype.iframe_6rhnbj$ = KatydidEmbeddedContentBuilder.prototype.iframe_6rhnbj$;
  KatydidEmbeddedContentBuilderImpl.prototype.img_fdnnaq$ = KatydidEmbeddedContentBuilder.prototype.img_fdnnaq$;
  KatydidEmbeddedContentBuilderImpl.prototype.object_ggcu0x$ = KatydidEmbeddedContentBuilder.prototype.object_ggcu0x$;
  KatydidEmbeddedContentBuilderImpl.prototype.picture_r7gn0k$ = KatydidEmbeddedContentBuilder.prototype.picture_r7gn0k$;
  KatydidEmbeddedContentBuilderImpl.prototype.video_n6slad$ = KatydidEmbeddedContentBuilder.prototype.video_n6slad$;
  KatydidPhrasingContentBuilder.prototype.audio_if4zjc$ = KatydidEmbeddedContentBuilder.prototype.audio_if4zjc$;
  KatydidPhrasingContentBuilder.prototype.canvas_ablpy6$ = KatydidEmbeddedContentBuilder.prototype.canvas_ablpy6$;
  KatydidPhrasingContentBuilder.prototype.object_ggcu0x$ = KatydidEmbeddedContentBuilder.prototype.object_ggcu0x$;
  KatydidPhrasingContentBuilder.prototype.video_n6slad$ = KatydidEmbeddedContentBuilder.prototype.video_n6slad$;
  KatydidPhrasingContentBuilder.prototype.embed_nx0pss$ = KatydidEmbeddedContentBuilder.prototype.embed_nx0pss$;
  KatydidPhrasingContentBuilder.prototype.iframe_6rhnbj$ = KatydidEmbeddedContentBuilder.prototype.iframe_6rhnbj$;
  KatydidPhrasingContentBuilder.prototype.img_fdnnaq$ = KatydidEmbeddedContentBuilder.prototype.img_fdnnaq$;
  KatydidPhrasingContentBuilder.prototype.picture_r7gn0k$ = KatydidEmbeddedContentBuilder.prototype.picture_r7gn0k$;
  KatydidPhrasingContentBuilderImpl.prototype.comment_4w9ihe$$default = KatydidEmbeddedContentBuilderImpl.prototype.comment_4w9ihe$;
  KatydidPhrasingContentBuilderImpl.prototype.comment_4w9ihe$ = KatydidPhrasingContentBuilder.prototype.comment_4w9ihe$;
  KatydidPhrasingContentBuilderImpl.prototype.unaryPlus_pdl1vz$ = KatydidPhrasingContentBuilder.prototype.unaryPlus_pdl1vz$;
  KatydidPhrasingContentBuilderImpl.prototype.a_ncyfe7$ = KatydidPhrasingContentBuilder.prototype.a_ncyfe7$;
  KatydidPhrasingContentBuilderImpl.prototype.abbr_qckjfy$ = KatydidPhrasingContentBuilder.prototype.abbr_qckjfy$;
  KatydidPhrasingContentBuilderImpl.prototype.area_ys14xf$ = KatydidPhrasingContentBuilder.prototype.area_ys14xf$;
  KatydidPhrasingContentBuilderImpl.prototype.audio_z5y2od$ = KatydidPhrasingContentBuilder.prototype.audio_z5y2od$;
  KatydidPhrasingContentBuilderImpl.prototype.b_qckjfy$ = KatydidPhrasingContentBuilder.prototype.b_qckjfy$;
  KatydidPhrasingContentBuilderImpl.prototype.bdi_g2kg67$ = KatydidPhrasingContentBuilder.prototype.bdi_g2kg67$;
  KatydidPhrasingContentBuilderImpl.prototype.bdo_g2kg67$ = KatydidPhrasingContentBuilder.prototype.bdo_g2kg67$;
  KatydidPhrasingContentBuilderImpl.prototype.br_9mj9vz$ = KatydidPhrasingContentBuilder.prototype.br_9mj9vz$;
  KatydidPhrasingContentBuilderImpl.prototype.button_2lxa1r$ = KatydidPhrasingContentBuilder.prototype.button_2lxa1r$;
  KatydidPhrasingContentBuilderImpl.prototype.canvas_zeuq1z$ = KatydidPhrasingContentBuilder.prototype.canvas_zeuq1z$;
  KatydidPhrasingContentBuilderImpl.prototype.cite_qckjfy$ = KatydidPhrasingContentBuilder.prototype.cite_qckjfy$;
  KatydidPhrasingContentBuilderImpl.prototype.code_qckjfy$ = KatydidPhrasingContentBuilder.prototype.code_qckjfy$;
  KatydidPhrasingContentBuilderImpl.prototype.data_cn0i2o$ = KatydidPhrasingContentBuilder.prototype.data_cn0i2o$;
  KatydidPhrasingContentBuilderImpl.prototype.datalist_csvf3w$ = KatydidPhrasingContentBuilder.prototype.datalist_csvf3w$;
  KatydidPhrasingContentBuilderImpl.prototype.datalist_zf5udj$ = KatydidPhrasingContentBuilder.prototype.datalist_zf5udj$;
  KatydidPhrasingContentBuilderImpl.prototype.del_smchxe$ = KatydidPhrasingContentBuilder.prototype.del_smchxe$;
  KatydidPhrasingContentBuilderImpl.prototype.dfn_qckjfy$ = KatydidPhrasingContentBuilder.prototype.dfn_qckjfy$;
  KatydidPhrasingContentBuilderImpl.prototype.em_qckjfy$ = KatydidPhrasingContentBuilder.prototype.em_qckjfy$;
  KatydidPhrasingContentBuilderImpl.prototype.i_qckjfy$ = KatydidPhrasingContentBuilder.prototype.i_qckjfy$;
  KatydidPhrasingContentBuilderImpl.prototype.inputButton_kk2d6s$ = KatydidPhrasingContentBuilder.prototype.inputButton_kk2d6s$;
  KatydidPhrasingContentBuilderImpl.prototype.inputCheckbox_5idhkk$ = KatydidPhrasingContentBuilder.prototype.inputCheckbox_5idhkk$;
  KatydidPhrasingContentBuilderImpl.prototype.inputColor_9zybug$ = KatydidPhrasingContentBuilder.prototype.inputColor_9zybug$;
  KatydidPhrasingContentBuilderImpl.prototype.inputDate_3kgd4t$ = KatydidPhrasingContentBuilder.prototype.inputDate_3kgd4t$;
  KatydidPhrasingContentBuilderImpl.prototype.inputDateTimeLocal_3kgd4t$ = KatydidPhrasingContentBuilder.prototype.inputDateTimeLocal_3kgd4t$;
  KatydidPhrasingContentBuilderImpl.prototype.inputEmail_44r9ep$ = KatydidPhrasingContentBuilder.prototype.inputEmail_44r9ep$;
  KatydidPhrasingContentBuilderImpl.prototype.inputFile_8v4l2x$ = KatydidPhrasingContentBuilder.prototype.inputFile_8v4l2x$;
  KatydidPhrasingContentBuilderImpl.prototype.inputHidden_kk2d6s$ = KatydidPhrasingContentBuilder.prototype.inputHidden_kk2d6s$;
  KatydidPhrasingContentBuilderImpl.prototype.inputImageButton_ojhf04$ = KatydidPhrasingContentBuilder.prototype.inputImageButton_ojhf04$;
  KatydidPhrasingContentBuilderImpl.prototype.inputMonth_3kgd4t$ = KatydidPhrasingContentBuilder.prototype.inputMonth_3kgd4t$;
  KatydidPhrasingContentBuilderImpl.prototype.inputNumber_xtj0dk$ = KatydidPhrasingContentBuilder.prototype.inputNumber_xtj0dk$;
  KatydidPhrasingContentBuilderImpl.prototype.inputNumber_25std2$ = KatydidPhrasingContentBuilder.prototype.inputNumber_25std2$;
  KatydidPhrasingContentBuilderImpl.prototype.inputPassword_98xs2q$ = KatydidPhrasingContentBuilder.prototype.inputPassword_98xs2q$;
  KatydidPhrasingContentBuilderImpl.prototype.inputRadioButton_5idhkk$ = KatydidPhrasingContentBuilder.prototype.inputRadioButton_5idhkk$;
  KatydidPhrasingContentBuilderImpl.prototype.inputRange_er1tee$ = KatydidPhrasingContentBuilder.prototype.inputRange_er1tee$;
  KatydidPhrasingContentBuilderImpl.prototype.inputResetButton_kk2d6s$ = KatydidPhrasingContentBuilder.prototype.inputResetButton_kk2d6s$;
  KatydidPhrasingContentBuilderImpl.prototype.inputSearch_y74p72$ = KatydidPhrasingContentBuilder.prototype.inputSearch_y74p72$;
  KatydidPhrasingContentBuilderImpl.prototype.inputSubmitButton_xi657a$ = KatydidPhrasingContentBuilder.prototype.inputSubmitButton_xi657a$;
  KatydidPhrasingContentBuilderImpl.prototype.inputTelephone_m3bg53$ = KatydidPhrasingContentBuilder.prototype.inputTelephone_m3bg53$;
  KatydidPhrasingContentBuilderImpl.prototype.inputText_y74p72$ = KatydidPhrasingContentBuilder.prototype.inputText_y74p72$;
  KatydidPhrasingContentBuilderImpl.prototype.inputTime_629f1$ = KatydidPhrasingContentBuilder.prototype.inputTime_629f1$;
  KatydidPhrasingContentBuilderImpl.prototype.inputUrl_m3bg53$ = KatydidPhrasingContentBuilder.prototype.inputUrl_m3bg53$;
  KatydidPhrasingContentBuilderImpl.prototype.inputWeek_3kgd4t$ = KatydidPhrasingContentBuilder.prototype.inputWeek_3kgd4t$;
  KatydidPhrasingContentBuilderImpl.prototype.ins_smchxe$ = KatydidPhrasingContentBuilder.prototype.ins_smchxe$;
  KatydidPhrasingContentBuilderImpl.prototype.kbd_qckjfy$ = KatydidPhrasingContentBuilder.prototype.kbd_qckjfy$;
  KatydidPhrasingContentBuilderImpl.prototype.label_va30u7$ = KatydidPhrasingContentBuilder.prototype.label_va30u7$;
  KatydidPhrasingContentBuilderImpl.prototype.map_z0i53j$ = KatydidPhrasingContentBuilder.prototype.map_z0i53j$;
  KatydidPhrasingContentBuilderImpl.prototype.mark_qckjfy$ = KatydidPhrasingContentBuilder.prototype.mark_qckjfy$;
  KatydidPhrasingContentBuilderImpl.prototype.meter_6c4h8d$ = KatydidPhrasingContentBuilder.prototype.meter_6c4h8d$;
  KatydidPhrasingContentBuilderImpl.prototype.meter_ujjlce$ = KatydidPhrasingContentBuilder.prototype.meter_ujjlce$;
  KatydidPhrasingContentBuilderImpl.prototype.object_8mhd8$ = KatydidPhrasingContentBuilder.prototype.object_8mhd8$;
  KatydidPhrasingContentBuilderImpl.prototype.output_7nyrc9$ = KatydidPhrasingContentBuilder.prototype.output_7nyrc9$;
  KatydidPhrasingContentBuilderImpl.prototype.progress_8ydfv4$ = KatydidPhrasingContentBuilder.prototype.progress_8ydfv4$;
  KatydidPhrasingContentBuilderImpl.prototype.progress_qjij5p$ = KatydidPhrasingContentBuilder.prototype.progress_qjij5p$;
  KatydidPhrasingContentBuilderImpl.prototype.q_qckjfy$ = KatydidPhrasingContentBuilder.prototype.q_qckjfy$;
  KatydidPhrasingContentBuilderImpl.prototype.ruby_sy7cla$ = KatydidPhrasingContentBuilder.prototype.ruby_sy7cla$;
  KatydidPhrasingContentBuilderImpl.prototype.s_qckjfy$ = KatydidPhrasingContentBuilder.prototype.s_qckjfy$;
  KatydidPhrasingContentBuilderImpl.prototype.samp_qckjfy$ = KatydidPhrasingContentBuilder.prototype.samp_qckjfy$;
  KatydidPhrasingContentBuilderImpl.prototype.select_7efmz3$ = KatydidPhrasingContentBuilder.prototype.select_7efmz3$;
  KatydidPhrasingContentBuilderImpl.prototype.small_qckjfy$ = KatydidPhrasingContentBuilder.prototype.small_qckjfy$;
  KatydidPhrasingContentBuilderImpl.prototype.span_qckjfy$ = KatydidPhrasingContentBuilder.prototype.span_qckjfy$;
  KatydidPhrasingContentBuilderImpl.prototype.strong_qckjfy$ = KatydidPhrasingContentBuilder.prototype.strong_qckjfy$;
  KatydidPhrasingContentBuilderImpl.prototype.sub_qckjfy$ = KatydidPhrasingContentBuilder.prototype.sub_qckjfy$;
  KatydidPhrasingContentBuilderImpl.prototype.sup_qckjfy$ = KatydidPhrasingContentBuilder.prototype.sup_qckjfy$;
  KatydidPhrasingContentBuilderImpl.prototype.text_4w9ihe$ = KatydidPhrasingContentBuilder.prototype.text_4w9ihe$;
  KatydidPhrasingContentBuilderImpl.prototype.textarea_1j30yg$ = KatydidPhrasingContentBuilder.prototype.textarea_1j30yg$;
  KatydidPhrasingContentBuilderImpl.prototype.time_y9dz51$ = KatydidPhrasingContentBuilder.prototype.time_y9dz51$;
  KatydidPhrasingContentBuilderImpl.prototype.time_jigsdy$ = KatydidPhrasingContentBuilder.prototype.time_jigsdy$;
  KatydidPhrasingContentBuilderImpl.prototype.u_qckjfy$ = KatydidPhrasingContentBuilder.prototype.u_qckjfy$;
  KatydidPhrasingContentBuilderImpl.prototype.var_qckjfy$ = KatydidPhrasingContentBuilder.prototype.var_qckjfy$;
  KatydidPhrasingContentBuilderImpl.prototype.video_l9965i$ = KatydidPhrasingContentBuilder.prototype.video_l9965i$;
  KatydidPhrasingContentBuilderImpl.prototype.wbr_9mj9vz$ = KatydidPhrasingContentBuilder.prototype.wbr_9mj9vz$;
  KatydidFlowContentBuilder.prototype.unaryPlus_pdl1vz$ = KatydidPhrasingContentBuilder.prototype.unaryPlus_pdl1vz$;
  KatydidFlowContentBuilder.prototype.a_ncyfe7$ = KatydidPhrasingContentBuilder.prototype.a_ncyfe7$;
  KatydidFlowContentBuilder.prototype.audio_z5y2od$ = KatydidPhrasingContentBuilder.prototype.audio_z5y2od$;
  KatydidFlowContentBuilder.prototype.audio_if4zjc$ = KatydidPhrasingContentBuilder.prototype.audio_if4zjc$;
  KatydidFlowContentBuilder.prototype.canvas_zeuq1z$ = KatydidPhrasingContentBuilder.prototype.canvas_zeuq1z$;
  KatydidFlowContentBuilder.prototype.canvas_ablpy6$ = KatydidPhrasingContentBuilder.prototype.canvas_ablpy6$;
  KatydidFlowContentBuilder.prototype.del_smchxe$ = KatydidPhrasingContentBuilder.prototype.del_smchxe$;
  KatydidFlowContentBuilder.prototype.ins_smchxe$ = KatydidPhrasingContentBuilder.prototype.ins_smchxe$;
  KatydidFlowContentBuilder.prototype.map_z0i53j$ = KatydidPhrasingContentBuilder.prototype.map_z0i53j$;
  KatydidFlowContentBuilder.prototype.object_8mhd8$ = KatydidPhrasingContentBuilder.prototype.object_8mhd8$;
  KatydidFlowContentBuilder.prototype.object_ggcu0x$ = KatydidPhrasingContentBuilder.prototype.object_ggcu0x$;
  KatydidFlowContentBuilder.prototype.video_l9965i$ = KatydidPhrasingContentBuilder.prototype.video_l9965i$;
  KatydidFlowContentBuilder.prototype.video_n6slad$ = KatydidPhrasingContentBuilder.prototype.video_n6slad$;
  KatydidFlowContentBuilder.prototype.abbr_qckjfy$ = KatydidPhrasingContentBuilder.prototype.abbr_qckjfy$;
  KatydidFlowContentBuilder.prototype.area_ys14xf$ = KatydidPhrasingContentBuilder.prototype.area_ys14xf$;
  KatydidFlowContentBuilder.prototype.b_qckjfy$ = KatydidPhrasingContentBuilder.prototype.b_qckjfy$;
  KatydidFlowContentBuilder.prototype.bdi_g2kg67$ = KatydidPhrasingContentBuilder.prototype.bdi_g2kg67$;
  KatydidFlowContentBuilder.prototype.bdo_g2kg67$ = KatydidPhrasingContentBuilder.prototype.bdo_g2kg67$;
  KatydidFlowContentBuilder.prototype.br_9mj9vz$ = KatydidPhrasingContentBuilder.prototype.br_9mj9vz$;
  KatydidFlowContentBuilder.prototype.button_2lxa1r$ = KatydidPhrasingContentBuilder.prototype.button_2lxa1r$;
  KatydidFlowContentBuilder.prototype.cite_qckjfy$ = KatydidPhrasingContentBuilder.prototype.cite_qckjfy$;
  KatydidFlowContentBuilder.prototype.code_qckjfy$ = KatydidPhrasingContentBuilder.prototype.code_qckjfy$;
  KatydidFlowContentBuilder.prototype.comment_4w9ihe$ = KatydidPhrasingContentBuilder.prototype.comment_4w9ihe$;
  KatydidFlowContentBuilder.prototype.data_cn0i2o$ = KatydidPhrasingContentBuilder.prototype.data_cn0i2o$;
  KatydidFlowContentBuilder.prototype.datalist_csvf3w$ = KatydidPhrasingContentBuilder.prototype.datalist_csvf3w$;
  KatydidFlowContentBuilder.prototype.datalist_zf5udj$ = KatydidPhrasingContentBuilder.prototype.datalist_zf5udj$;
  KatydidFlowContentBuilder.prototype.dfn_qckjfy$ = KatydidPhrasingContentBuilder.prototype.dfn_qckjfy$;
  KatydidFlowContentBuilder.prototype.em_qckjfy$ = KatydidPhrasingContentBuilder.prototype.em_qckjfy$;
  KatydidFlowContentBuilder.prototype.i_qckjfy$ = KatydidPhrasingContentBuilder.prototype.i_qckjfy$;
  KatydidFlowContentBuilder.prototype.inputButton_kk2d6s$ = KatydidPhrasingContentBuilder.prototype.inputButton_kk2d6s$;
  KatydidFlowContentBuilder.prototype.inputCheckbox_5idhkk$ = KatydidPhrasingContentBuilder.prototype.inputCheckbox_5idhkk$;
  KatydidFlowContentBuilder.prototype.inputColor_9zybug$ = KatydidPhrasingContentBuilder.prototype.inputColor_9zybug$;
  KatydidFlowContentBuilder.prototype.inputDate_3kgd4t$ = KatydidPhrasingContentBuilder.prototype.inputDate_3kgd4t$;
  KatydidFlowContentBuilder.prototype.inputDateTimeLocal_3kgd4t$ = KatydidPhrasingContentBuilder.prototype.inputDateTimeLocal_3kgd4t$;
  KatydidFlowContentBuilder.prototype.inputEmail_44r9ep$ = KatydidPhrasingContentBuilder.prototype.inputEmail_44r9ep$;
  KatydidFlowContentBuilder.prototype.inputFile_8v4l2x$ = KatydidPhrasingContentBuilder.prototype.inputFile_8v4l2x$;
  KatydidFlowContentBuilder.prototype.inputHidden_kk2d6s$ = KatydidPhrasingContentBuilder.prototype.inputHidden_kk2d6s$;
  KatydidFlowContentBuilder.prototype.inputImageButton_ojhf04$ = KatydidPhrasingContentBuilder.prototype.inputImageButton_ojhf04$;
  KatydidFlowContentBuilder.prototype.inputMonth_3kgd4t$ = KatydidPhrasingContentBuilder.prototype.inputMonth_3kgd4t$;
  KatydidFlowContentBuilder.prototype.inputNumber_xtj0dk$ = KatydidPhrasingContentBuilder.prototype.inputNumber_xtj0dk$;
  KatydidFlowContentBuilder.prototype.inputNumber_25std2$ = KatydidPhrasingContentBuilder.prototype.inputNumber_25std2$;
  KatydidFlowContentBuilder.prototype.inputPassword_98xs2q$ = KatydidPhrasingContentBuilder.prototype.inputPassword_98xs2q$;
  KatydidFlowContentBuilder.prototype.inputRadioButton_5idhkk$ = KatydidPhrasingContentBuilder.prototype.inputRadioButton_5idhkk$;
  KatydidFlowContentBuilder.prototype.inputRange_er1tee$ = KatydidPhrasingContentBuilder.prototype.inputRange_er1tee$;
  KatydidFlowContentBuilder.prototype.inputResetButton_kk2d6s$ = KatydidPhrasingContentBuilder.prototype.inputResetButton_kk2d6s$;
  KatydidFlowContentBuilder.prototype.inputSearch_y74p72$ = KatydidPhrasingContentBuilder.prototype.inputSearch_y74p72$;
  KatydidFlowContentBuilder.prototype.inputSubmitButton_xi657a$ = KatydidPhrasingContentBuilder.prototype.inputSubmitButton_xi657a$;
  KatydidFlowContentBuilder.prototype.inputTelephone_m3bg53$ = KatydidPhrasingContentBuilder.prototype.inputTelephone_m3bg53$;
  KatydidFlowContentBuilder.prototype.inputText_y74p72$ = KatydidPhrasingContentBuilder.prototype.inputText_y74p72$;
  KatydidFlowContentBuilder.prototype.inputTime_629f1$ = KatydidPhrasingContentBuilder.prototype.inputTime_629f1$;
  KatydidFlowContentBuilder.prototype.inputUrl_m3bg53$ = KatydidPhrasingContentBuilder.prototype.inputUrl_m3bg53$;
  KatydidFlowContentBuilder.prototype.inputWeek_3kgd4t$ = KatydidPhrasingContentBuilder.prototype.inputWeek_3kgd4t$;
  KatydidFlowContentBuilder.prototype.kbd_qckjfy$ = KatydidPhrasingContentBuilder.prototype.kbd_qckjfy$;
  KatydidFlowContentBuilder.prototype.label_va30u7$ = KatydidPhrasingContentBuilder.prototype.label_va30u7$;
  KatydidFlowContentBuilder.prototype.mark_qckjfy$ = KatydidPhrasingContentBuilder.prototype.mark_qckjfy$;
  KatydidFlowContentBuilder.prototype.meter_6c4h8d$ = KatydidPhrasingContentBuilder.prototype.meter_6c4h8d$;
  KatydidFlowContentBuilder.prototype.meter_ujjlce$ = KatydidPhrasingContentBuilder.prototype.meter_ujjlce$;
  KatydidFlowContentBuilder.prototype.output_7nyrc9$ = KatydidPhrasingContentBuilder.prototype.output_7nyrc9$;
  KatydidFlowContentBuilder.prototype.progress_8ydfv4$ = KatydidPhrasingContentBuilder.prototype.progress_8ydfv4$;
  KatydidFlowContentBuilder.prototype.progress_qjij5p$ = KatydidPhrasingContentBuilder.prototype.progress_qjij5p$;
  KatydidFlowContentBuilder.prototype.q_qckjfy$ = KatydidPhrasingContentBuilder.prototype.q_qckjfy$;
  KatydidFlowContentBuilder.prototype.ruby_sy7cla$ = KatydidPhrasingContentBuilder.prototype.ruby_sy7cla$;
  KatydidFlowContentBuilder.prototype.s_qckjfy$ = KatydidPhrasingContentBuilder.prototype.s_qckjfy$;
  KatydidFlowContentBuilder.prototype.samp_qckjfy$ = KatydidPhrasingContentBuilder.prototype.samp_qckjfy$;
  KatydidFlowContentBuilder.prototype.select_7efmz3$ = KatydidPhrasingContentBuilder.prototype.select_7efmz3$;
  KatydidFlowContentBuilder.prototype.small_qckjfy$ = KatydidPhrasingContentBuilder.prototype.small_qckjfy$;
  KatydidFlowContentBuilder.prototype.span_qckjfy$ = KatydidPhrasingContentBuilder.prototype.span_qckjfy$;
  KatydidFlowContentBuilder.prototype.strong_qckjfy$ = KatydidPhrasingContentBuilder.prototype.strong_qckjfy$;
  KatydidFlowContentBuilder.prototype.sub_qckjfy$ = KatydidPhrasingContentBuilder.prototype.sub_qckjfy$;
  KatydidFlowContentBuilder.prototype.sup_qckjfy$ = KatydidPhrasingContentBuilder.prototype.sup_qckjfy$;
  KatydidFlowContentBuilder.prototype.text_4w9ihe$ = KatydidPhrasingContentBuilder.prototype.text_4w9ihe$;
  KatydidFlowContentBuilder.prototype.textarea_1j30yg$ = KatydidPhrasingContentBuilder.prototype.textarea_1j30yg$;
  KatydidFlowContentBuilder.prototype.time_y9dz51$ = KatydidPhrasingContentBuilder.prototype.time_y9dz51$;
  KatydidFlowContentBuilder.prototype.time_jigsdy$ = KatydidPhrasingContentBuilder.prototype.time_jigsdy$;
  KatydidFlowContentBuilder.prototype.u_qckjfy$ = KatydidPhrasingContentBuilder.prototype.u_qckjfy$;
  KatydidFlowContentBuilder.prototype.var_qckjfy$ = KatydidPhrasingContentBuilder.prototype.var_qckjfy$;
  KatydidFlowContentBuilder.prototype.wbr_9mj9vz$ = KatydidPhrasingContentBuilder.prototype.wbr_9mj9vz$;
  KatydidFlowContentBuilder.prototype.embed_nx0pss$ = KatydidPhrasingContentBuilder.prototype.embed_nx0pss$;
  KatydidFlowContentBuilder.prototype.iframe_6rhnbj$ = KatydidPhrasingContentBuilder.prototype.iframe_6rhnbj$;
  KatydidFlowContentBuilder.prototype.img_fdnnaq$ = KatydidPhrasingContentBuilder.prototype.img_fdnnaq$;
  KatydidFlowContentBuilder.prototype.picture_r7gn0k$ = KatydidPhrasingContentBuilder.prototype.picture_r7gn0k$;
  KatydidFlowContentBuilder.prototype.h1_qckjfy$ = KatydidHeadingContentBuilder.prototype.h1_qckjfy$;
  KatydidFlowContentBuilder.prototype.h2_qckjfy$ = KatydidHeadingContentBuilder.prototype.h2_qckjfy$;
  KatydidFlowContentBuilder.prototype.h3_qckjfy$ = KatydidHeadingContentBuilder.prototype.h3_qckjfy$;
  KatydidFlowContentBuilder.prototype.h4_qckjfy$ = KatydidHeadingContentBuilder.prototype.h4_qckjfy$;
  KatydidFlowContentBuilder.prototype.h5_qckjfy$ = KatydidHeadingContentBuilder.prototype.h5_qckjfy$;
  KatydidFlowContentBuilder.prototype.h6_qckjfy$ = KatydidHeadingContentBuilder.prototype.h6_qckjfy$;
  KatydidFlowContentBuilder.prototype.article_6zr3om$ = KatydidSectioningContentBuilder.prototype.article_6zr3om$;
  KatydidFlowContentBuilder.prototype.aside_6zr3om$ = KatydidSectioningContentBuilder.prototype.aside_6zr3om$;
  KatydidFlowContentBuilder.prototype.nav_6zr3om$ = KatydidSectioningContentBuilder.prototype.nav_6zr3om$;
  KatydidFlowContentBuilder.prototype.section_6zr3om$ = KatydidSectioningContentBuilder.prototype.section_6zr3om$;
  KatydidFlowContentBuilderImpl.prototype.a_3jwxqy$ = KatydidFlowContentBuilder.prototype.a_3jwxqy$;
  KatydidFlowContentBuilderImpl.prototype.address_6zr3om$ = KatydidFlowContentBuilder.prototype.address_6zr3om$;
  KatydidFlowContentBuilderImpl.prototype.article_6zr3om$ = KatydidFlowContentBuilder.prototype.article_6zr3om$;
  KatydidFlowContentBuilderImpl.prototype.aside_6zr3om$ = KatydidFlowContentBuilder.prototype.aside_6zr3om$;
  KatydidFlowContentBuilderImpl.prototype.audio_tp0mfx$ = KatydidFlowContentBuilder.prototype.audio_tp0mfx$;
  KatydidFlowContentBuilderImpl.prototype.blockquote_rfnrw3$ = KatydidFlowContentBuilder.prototype.blockquote_rfnrw3$;
  KatydidFlowContentBuilderImpl.prototype.canvas_p01gpz$ = KatydidFlowContentBuilder.prototype.canvas_p01gpz$;
  KatydidFlowContentBuilderImpl.prototype.del_pat60j$ = KatydidFlowContentBuilder.prototype.del_pat60j$;
  KatydidFlowContentBuilderImpl.prototype.details_k8gqqw$ = KatydidFlowContentBuilder.prototype.details_k8gqqw$;
  KatydidFlowContentBuilderImpl.prototype.dialog_rmrn7i$ = KatydidFlowContentBuilder.prototype.dialog_rmrn7i$;
  KatydidFlowContentBuilderImpl.prototype.div_6zr3om$ = KatydidFlowContentBuilder.prototype.div_6zr3om$;
  KatydidFlowContentBuilderImpl.prototype.dl_a7rbte$ = KatydidFlowContentBuilder.prototype.dl_a7rbte$;
  KatydidFlowContentBuilderImpl.prototype.fieldset_wkcbaa$ = KatydidFlowContentBuilder.prototype.fieldset_wkcbaa$;
  KatydidFlowContentBuilderImpl.prototype.figCaption_6zr3om$ = KatydidFlowContentBuilder.prototype.figCaption_6zr3om$;
  KatydidFlowContentBuilderImpl.prototype.figure_6zr3om$ = KatydidFlowContentBuilder.prototype.figure_6zr3om$;
  KatydidFlowContentBuilderImpl.prototype.footer_6zr3om$ = KatydidFlowContentBuilder.prototype.footer_6zr3om$;
  KatydidFlowContentBuilderImpl.prototype.form_roosm5$ = KatydidFlowContentBuilder.prototype.form_roosm5$;
  KatydidFlowContentBuilderImpl.prototype.h1_qckjfy$ = KatydidFlowContentBuilder.prototype.h1_qckjfy$;
  KatydidFlowContentBuilderImpl.prototype.h2_qckjfy$ = KatydidFlowContentBuilder.prototype.h2_qckjfy$;
  KatydidFlowContentBuilderImpl.prototype.h3_qckjfy$ = KatydidFlowContentBuilder.prototype.h3_qckjfy$;
  KatydidFlowContentBuilderImpl.prototype.h4_qckjfy$ = KatydidFlowContentBuilder.prototype.h4_qckjfy$;
  KatydidFlowContentBuilderImpl.prototype.h5_qckjfy$ = KatydidFlowContentBuilder.prototype.h5_qckjfy$;
  KatydidFlowContentBuilderImpl.prototype.h6_qckjfy$ = KatydidFlowContentBuilder.prototype.h6_qckjfy$;
  KatydidFlowContentBuilderImpl.prototype.header_6zr3om$ = KatydidFlowContentBuilder.prototype.header_6zr3om$;
  KatydidFlowContentBuilderImpl.prototype.hr_9mj9vz$ = KatydidFlowContentBuilder.prototype.hr_9mj9vz$;
  KatydidFlowContentBuilderImpl.prototype.ins_pat60j$ = KatydidFlowContentBuilder.prototype.ins_pat60j$;
  KatydidFlowContentBuilderImpl.prototype.legend_qckjfy$ = KatydidFlowContentBuilder.prototype.legend_qckjfy$;
  KatydidFlowContentBuilderImpl.prototype.main_6zr3om$ = KatydidFlowContentBuilder.prototype.main_6zr3om$;
  KatydidFlowContentBuilderImpl.prototype.map_io1brw$ = KatydidFlowContentBuilder.prototype.map_io1brw$;
  KatydidFlowContentBuilderImpl.prototype.nav_6zr3om$ = KatydidFlowContentBuilder.prototype.nav_6zr3om$;
  KatydidFlowContentBuilderImpl.prototype.object_649euk$ = KatydidFlowContentBuilder.prototype.object_649euk$;
  KatydidFlowContentBuilderImpl.prototype.ol_5bxxpo$ = KatydidFlowContentBuilder.prototype.ol_5bxxpo$;
  KatydidFlowContentBuilderImpl.prototype.p_qckjfy$ = KatydidFlowContentBuilder.prototype.p_qckjfy$;
  KatydidFlowContentBuilderImpl.prototype.pre_qckjfy$ = KatydidFlowContentBuilder.prototype.pre_qckjfy$;
  KatydidFlowContentBuilderImpl.prototype.section_6zr3om$ = KatydidFlowContentBuilder.prototype.section_6zr3om$;
  KatydidFlowContentBuilderImpl.prototype.table_55vzb3$ = KatydidFlowContentBuilder.prototype.table_55vzb3$;
  KatydidFlowContentBuilderImpl.prototype.ul_hxau5b$ = KatydidFlowContentBuilder.prototype.ul_hxau5b$;
  KatydidFlowContentBuilderImpl.prototype.video_hpee3a$ = KatydidFlowContentBuilder.prototype.video_hpee3a$;
  KatydidDetailsFlowContentBuilder.prototype.unaryPlus_pdl1vz$ = KatydidFlowContentBuilder.prototype.unaryPlus_pdl1vz$;
  KatydidDetailsFlowContentBuilder.prototype.a_3jwxqy$ = KatydidFlowContentBuilder.prototype.a_3jwxqy$;
  KatydidDetailsFlowContentBuilder.prototype.a_ncyfe7$ = KatydidFlowContentBuilder.prototype.a_ncyfe7$;
  KatydidDetailsFlowContentBuilder.prototype.address_6zr3om$ = KatydidFlowContentBuilder.prototype.address_6zr3om$;
  KatydidDetailsFlowContentBuilder.prototype.audio_tp0mfx$ = KatydidFlowContentBuilder.prototype.audio_tp0mfx$;
  KatydidDetailsFlowContentBuilder.prototype.audio_z5y2od$ = KatydidFlowContentBuilder.prototype.audio_z5y2od$;
  KatydidDetailsFlowContentBuilder.prototype.audio_if4zjc$ = KatydidFlowContentBuilder.prototype.audio_if4zjc$;
  KatydidDetailsFlowContentBuilder.prototype.blockquote_rfnrw3$ = KatydidFlowContentBuilder.prototype.blockquote_rfnrw3$;
  KatydidDetailsFlowContentBuilder.prototype.canvas_p01gpz$ = KatydidFlowContentBuilder.prototype.canvas_p01gpz$;
  KatydidDetailsFlowContentBuilder.prototype.canvas_zeuq1z$ = KatydidFlowContentBuilder.prototype.canvas_zeuq1z$;
  KatydidDetailsFlowContentBuilder.prototype.canvas_ablpy6$ = KatydidFlowContentBuilder.prototype.canvas_ablpy6$;
  KatydidDetailsFlowContentBuilder.prototype.details_k8gqqw$ = KatydidFlowContentBuilder.prototype.details_k8gqqw$;
  KatydidDetailsFlowContentBuilder.prototype.dialog_rmrn7i$ = KatydidFlowContentBuilder.prototype.dialog_rmrn7i$;
  KatydidDetailsFlowContentBuilder.prototype.del_pat60j$ = KatydidFlowContentBuilder.prototype.del_pat60j$;
  KatydidDetailsFlowContentBuilder.prototype.del_smchxe$ = KatydidFlowContentBuilder.prototype.del_smchxe$;
  KatydidDetailsFlowContentBuilder.prototype.div_6zr3om$ = KatydidFlowContentBuilder.prototype.div_6zr3om$;
  KatydidDetailsFlowContentBuilder.prototype.dl_a7rbte$ = KatydidFlowContentBuilder.prototype.dl_a7rbte$;
  KatydidDetailsFlowContentBuilder.prototype.fieldset_wkcbaa$ = KatydidFlowContentBuilder.prototype.fieldset_wkcbaa$;
  KatydidDetailsFlowContentBuilder.prototype.figCaption_6zr3om$ = KatydidFlowContentBuilder.prototype.figCaption_6zr3om$;
  KatydidDetailsFlowContentBuilder.prototype.figure_6zr3om$ = KatydidFlowContentBuilder.prototype.figure_6zr3om$;
  KatydidDetailsFlowContentBuilder.prototype.footer_6zr3om$ = KatydidFlowContentBuilder.prototype.footer_6zr3om$;
  KatydidDetailsFlowContentBuilder.prototype.form_roosm5$ = KatydidFlowContentBuilder.prototype.form_roosm5$;
  KatydidDetailsFlowContentBuilder.prototype.header_6zr3om$ = KatydidFlowContentBuilder.prototype.header_6zr3om$;
  KatydidDetailsFlowContentBuilder.prototype.hr_9mj9vz$ = KatydidFlowContentBuilder.prototype.hr_9mj9vz$;
  KatydidDetailsFlowContentBuilder.prototype.ins_pat60j$ = KatydidFlowContentBuilder.prototype.ins_pat60j$;
  KatydidDetailsFlowContentBuilder.prototype.ins_smchxe$ = KatydidFlowContentBuilder.prototype.ins_smchxe$;
  KatydidDetailsFlowContentBuilder.prototype.legend_qckjfy$ = KatydidFlowContentBuilder.prototype.legend_qckjfy$;
  KatydidDetailsFlowContentBuilder.prototype.main_6zr3om$ = KatydidFlowContentBuilder.prototype.main_6zr3om$;
  KatydidDetailsFlowContentBuilder.prototype.map_io1brw$ = KatydidFlowContentBuilder.prototype.map_io1brw$;
  KatydidDetailsFlowContentBuilder.prototype.map_z0i53j$ = KatydidFlowContentBuilder.prototype.map_z0i53j$;
  KatydidDetailsFlowContentBuilder.prototype.object_649euk$ = KatydidFlowContentBuilder.prototype.object_649euk$;
  KatydidDetailsFlowContentBuilder.prototype.object_8mhd8$ = KatydidFlowContentBuilder.prototype.object_8mhd8$;
  KatydidDetailsFlowContentBuilder.prototype.object_ggcu0x$ = KatydidFlowContentBuilder.prototype.object_ggcu0x$;
  KatydidDetailsFlowContentBuilder.prototype.ol_5bxxpo$ = KatydidFlowContentBuilder.prototype.ol_5bxxpo$;
  KatydidDetailsFlowContentBuilder.prototype.p_qckjfy$ = KatydidFlowContentBuilder.prototype.p_qckjfy$;
  KatydidDetailsFlowContentBuilder.prototype.pre_qckjfy$ = KatydidFlowContentBuilder.prototype.pre_qckjfy$;
  KatydidDetailsFlowContentBuilder.prototype.table_55vzb3$ = KatydidFlowContentBuilder.prototype.table_55vzb3$;
  KatydidDetailsFlowContentBuilder.prototype.ul_hxau5b$ = KatydidFlowContentBuilder.prototype.ul_hxau5b$;
  KatydidDetailsFlowContentBuilder.prototype.video_hpee3a$ = KatydidFlowContentBuilder.prototype.video_hpee3a$;
  KatydidDetailsFlowContentBuilder.prototype.video_l9965i$ = KatydidFlowContentBuilder.prototype.video_l9965i$;
  KatydidDetailsFlowContentBuilder.prototype.video_n6slad$ = KatydidFlowContentBuilder.prototype.video_n6slad$;
  KatydidDetailsFlowContentBuilder.prototype.abbr_qckjfy$ = KatydidFlowContentBuilder.prototype.abbr_qckjfy$;
  KatydidDetailsFlowContentBuilder.prototype.area_ys14xf$ = KatydidFlowContentBuilder.prototype.area_ys14xf$;
  KatydidDetailsFlowContentBuilder.prototype.b_qckjfy$ = KatydidFlowContentBuilder.prototype.b_qckjfy$;
  KatydidDetailsFlowContentBuilder.prototype.bdi_g2kg67$ = KatydidFlowContentBuilder.prototype.bdi_g2kg67$;
  KatydidDetailsFlowContentBuilder.prototype.bdo_g2kg67$ = KatydidFlowContentBuilder.prototype.bdo_g2kg67$;
  KatydidDetailsFlowContentBuilder.prototype.br_9mj9vz$ = KatydidFlowContentBuilder.prototype.br_9mj9vz$;
  KatydidDetailsFlowContentBuilder.prototype.button_2lxa1r$ = KatydidFlowContentBuilder.prototype.button_2lxa1r$;
  KatydidDetailsFlowContentBuilder.prototype.cite_qckjfy$ = KatydidFlowContentBuilder.prototype.cite_qckjfy$;
  KatydidDetailsFlowContentBuilder.prototype.code_qckjfy$ = KatydidFlowContentBuilder.prototype.code_qckjfy$;
  KatydidDetailsFlowContentBuilder.prototype.comment_4w9ihe$ = KatydidFlowContentBuilder.prototype.comment_4w9ihe$;
  KatydidDetailsFlowContentBuilder.prototype.data_cn0i2o$ = KatydidFlowContentBuilder.prototype.data_cn0i2o$;
  KatydidDetailsFlowContentBuilder.prototype.datalist_csvf3w$ = KatydidFlowContentBuilder.prototype.datalist_csvf3w$;
  KatydidDetailsFlowContentBuilder.prototype.datalist_zf5udj$ = KatydidFlowContentBuilder.prototype.datalist_zf5udj$;
  KatydidDetailsFlowContentBuilder.prototype.dfn_qckjfy$ = KatydidFlowContentBuilder.prototype.dfn_qckjfy$;
  KatydidDetailsFlowContentBuilder.prototype.em_qckjfy$ = KatydidFlowContentBuilder.prototype.em_qckjfy$;
  KatydidDetailsFlowContentBuilder.prototype.i_qckjfy$ = KatydidFlowContentBuilder.prototype.i_qckjfy$;
  KatydidDetailsFlowContentBuilder.prototype.inputButton_kk2d6s$ = KatydidFlowContentBuilder.prototype.inputButton_kk2d6s$;
  KatydidDetailsFlowContentBuilder.prototype.inputCheckbox_5idhkk$ = KatydidFlowContentBuilder.prototype.inputCheckbox_5idhkk$;
  KatydidDetailsFlowContentBuilder.prototype.inputColor_9zybug$ = KatydidFlowContentBuilder.prototype.inputColor_9zybug$;
  KatydidDetailsFlowContentBuilder.prototype.inputDate_3kgd4t$ = KatydidFlowContentBuilder.prototype.inputDate_3kgd4t$;
  KatydidDetailsFlowContentBuilder.prototype.inputDateTimeLocal_3kgd4t$ = KatydidFlowContentBuilder.prototype.inputDateTimeLocal_3kgd4t$;
  KatydidDetailsFlowContentBuilder.prototype.inputEmail_44r9ep$ = KatydidFlowContentBuilder.prototype.inputEmail_44r9ep$;
  KatydidDetailsFlowContentBuilder.prototype.inputFile_8v4l2x$ = KatydidFlowContentBuilder.prototype.inputFile_8v4l2x$;
  KatydidDetailsFlowContentBuilder.prototype.inputHidden_kk2d6s$ = KatydidFlowContentBuilder.prototype.inputHidden_kk2d6s$;
  KatydidDetailsFlowContentBuilder.prototype.inputImageButton_ojhf04$ = KatydidFlowContentBuilder.prototype.inputImageButton_ojhf04$;
  KatydidDetailsFlowContentBuilder.prototype.inputMonth_3kgd4t$ = KatydidFlowContentBuilder.prototype.inputMonth_3kgd4t$;
  KatydidDetailsFlowContentBuilder.prototype.inputNumber_xtj0dk$ = KatydidFlowContentBuilder.prototype.inputNumber_xtj0dk$;
  KatydidDetailsFlowContentBuilder.prototype.inputNumber_25std2$ = KatydidFlowContentBuilder.prototype.inputNumber_25std2$;
  KatydidDetailsFlowContentBuilder.prototype.inputPassword_98xs2q$ = KatydidFlowContentBuilder.prototype.inputPassword_98xs2q$;
  KatydidDetailsFlowContentBuilder.prototype.inputRadioButton_5idhkk$ = KatydidFlowContentBuilder.prototype.inputRadioButton_5idhkk$;
  KatydidDetailsFlowContentBuilder.prototype.inputRange_er1tee$ = KatydidFlowContentBuilder.prototype.inputRange_er1tee$;
  KatydidDetailsFlowContentBuilder.prototype.inputResetButton_kk2d6s$ = KatydidFlowContentBuilder.prototype.inputResetButton_kk2d6s$;
  KatydidDetailsFlowContentBuilder.prototype.inputSearch_y74p72$ = KatydidFlowContentBuilder.prototype.inputSearch_y74p72$;
  KatydidDetailsFlowContentBuilder.prototype.inputSubmitButton_xi657a$ = KatydidFlowContentBuilder.prototype.inputSubmitButton_xi657a$;
  KatydidDetailsFlowContentBuilder.prototype.inputTelephone_m3bg53$ = KatydidFlowContentBuilder.prototype.inputTelephone_m3bg53$;
  KatydidDetailsFlowContentBuilder.prototype.inputText_y74p72$ = KatydidFlowContentBuilder.prototype.inputText_y74p72$;
  KatydidDetailsFlowContentBuilder.prototype.inputTime_629f1$ = KatydidFlowContentBuilder.prototype.inputTime_629f1$;
  KatydidDetailsFlowContentBuilder.prototype.inputUrl_m3bg53$ = KatydidFlowContentBuilder.prototype.inputUrl_m3bg53$;
  KatydidDetailsFlowContentBuilder.prototype.inputWeek_3kgd4t$ = KatydidFlowContentBuilder.prototype.inputWeek_3kgd4t$;
  KatydidDetailsFlowContentBuilder.prototype.kbd_qckjfy$ = KatydidFlowContentBuilder.prototype.kbd_qckjfy$;
  KatydidDetailsFlowContentBuilder.prototype.label_va30u7$ = KatydidFlowContentBuilder.prototype.label_va30u7$;
  KatydidDetailsFlowContentBuilder.prototype.mark_qckjfy$ = KatydidFlowContentBuilder.prototype.mark_qckjfy$;
  KatydidDetailsFlowContentBuilder.prototype.meter_6c4h8d$ = KatydidFlowContentBuilder.prototype.meter_6c4h8d$;
  KatydidDetailsFlowContentBuilder.prototype.meter_ujjlce$ = KatydidFlowContentBuilder.prototype.meter_ujjlce$;
  KatydidDetailsFlowContentBuilder.prototype.output_7nyrc9$ = KatydidFlowContentBuilder.prototype.output_7nyrc9$;
  KatydidDetailsFlowContentBuilder.prototype.progress_8ydfv4$ = KatydidFlowContentBuilder.prototype.progress_8ydfv4$;
  KatydidDetailsFlowContentBuilder.prototype.progress_qjij5p$ = KatydidFlowContentBuilder.prototype.progress_qjij5p$;
  KatydidDetailsFlowContentBuilder.prototype.q_qckjfy$ = KatydidFlowContentBuilder.prototype.q_qckjfy$;
  KatydidDetailsFlowContentBuilder.prototype.ruby_sy7cla$ = KatydidFlowContentBuilder.prototype.ruby_sy7cla$;
  KatydidDetailsFlowContentBuilder.prototype.s_qckjfy$ = KatydidFlowContentBuilder.prototype.s_qckjfy$;
  KatydidDetailsFlowContentBuilder.prototype.samp_qckjfy$ = KatydidFlowContentBuilder.prototype.samp_qckjfy$;
  KatydidDetailsFlowContentBuilder.prototype.select_7efmz3$ = KatydidFlowContentBuilder.prototype.select_7efmz3$;
  KatydidDetailsFlowContentBuilder.prototype.small_qckjfy$ = KatydidFlowContentBuilder.prototype.small_qckjfy$;
  KatydidDetailsFlowContentBuilder.prototype.span_qckjfy$ = KatydidFlowContentBuilder.prototype.span_qckjfy$;
  KatydidDetailsFlowContentBuilder.prototype.strong_qckjfy$ = KatydidFlowContentBuilder.prototype.strong_qckjfy$;
  KatydidDetailsFlowContentBuilder.prototype.sub_qckjfy$ = KatydidFlowContentBuilder.prototype.sub_qckjfy$;
  KatydidDetailsFlowContentBuilder.prototype.sup_qckjfy$ = KatydidFlowContentBuilder.prototype.sup_qckjfy$;
  KatydidDetailsFlowContentBuilder.prototype.text_4w9ihe$ = KatydidFlowContentBuilder.prototype.text_4w9ihe$;
  KatydidDetailsFlowContentBuilder.prototype.textarea_1j30yg$ = KatydidFlowContentBuilder.prototype.textarea_1j30yg$;
  KatydidDetailsFlowContentBuilder.prototype.time_y9dz51$ = KatydidFlowContentBuilder.prototype.time_y9dz51$;
  KatydidDetailsFlowContentBuilder.prototype.time_jigsdy$ = KatydidFlowContentBuilder.prototype.time_jigsdy$;
  KatydidDetailsFlowContentBuilder.prototype.u_qckjfy$ = KatydidFlowContentBuilder.prototype.u_qckjfy$;
  KatydidDetailsFlowContentBuilder.prototype.var_qckjfy$ = KatydidFlowContentBuilder.prototype.var_qckjfy$;
  KatydidDetailsFlowContentBuilder.prototype.wbr_9mj9vz$ = KatydidFlowContentBuilder.prototype.wbr_9mj9vz$;
  KatydidDetailsFlowContentBuilder.prototype.embed_nx0pss$ = KatydidFlowContentBuilder.prototype.embed_nx0pss$;
  KatydidDetailsFlowContentBuilder.prototype.iframe_6rhnbj$ = KatydidFlowContentBuilder.prototype.iframe_6rhnbj$;
  KatydidDetailsFlowContentBuilder.prototype.img_fdnnaq$ = KatydidFlowContentBuilder.prototype.img_fdnnaq$;
  KatydidDetailsFlowContentBuilder.prototype.picture_r7gn0k$ = KatydidFlowContentBuilder.prototype.picture_r7gn0k$;
  KatydidDetailsFlowContentBuilder.prototype.h1_qckjfy$ = KatydidFlowContentBuilder.prototype.h1_qckjfy$;
  KatydidDetailsFlowContentBuilder.prototype.h2_qckjfy$ = KatydidFlowContentBuilder.prototype.h2_qckjfy$;
  KatydidDetailsFlowContentBuilder.prototype.h3_qckjfy$ = KatydidFlowContentBuilder.prototype.h3_qckjfy$;
  KatydidDetailsFlowContentBuilder.prototype.h4_qckjfy$ = KatydidFlowContentBuilder.prototype.h4_qckjfy$;
  KatydidDetailsFlowContentBuilder.prototype.h5_qckjfy$ = KatydidFlowContentBuilder.prototype.h5_qckjfy$;
  KatydidDetailsFlowContentBuilder.prototype.h6_qckjfy$ = KatydidFlowContentBuilder.prototype.h6_qckjfy$;
  KatydidDetailsFlowContentBuilder.prototype.article_6zr3om$ = KatydidFlowContentBuilder.prototype.article_6zr3om$;
  KatydidDetailsFlowContentBuilder.prototype.aside_6zr3om$ = KatydidFlowContentBuilder.prototype.aside_6zr3om$;
  KatydidDetailsFlowContentBuilder.prototype.nav_6zr3om$ = KatydidFlowContentBuilder.prototype.nav_6zr3om$;
  KatydidDetailsFlowContentBuilder.prototype.section_6zr3om$ = KatydidFlowContentBuilder.prototype.section_6zr3om$;
  KatydidDetailsFlowContentBuilderImpl.prototype.summary_qckjfy$ = KatydidDetailsFlowContentBuilder.prototype.summary_qckjfy$;
  KatydidDetailsFlowContentBuilderImpl.prototype.summaryHeading_8h2c3u$ = KatydidDetailsFlowContentBuilder.prototype.summaryHeading_8h2c3u$;
  KatydidOrderedListContentBuilderImpl.prototype.comment_4w9ihe$ = KatydidOrderedListContentBuilder.prototype.comment_4w9ihe$;
  KatydidOrderedListContentBuilderImpl.prototype.li_wy8x0p$ = KatydidOrderedListContentBuilder.prototype.li_wy8x0p$;
  KatydidUnorderedListContentBuilderImpl.prototype.comment_4w9ihe$ = KatydidUnorderedListContentBuilder.prototype.comment_4w9ihe$;
  KatydidUnorderedListContentBuilderImpl.prototype.li_6zr3om$ = KatydidUnorderedListContentBuilder.prototype.li_6zr3om$;
  KatydidMediaEmbeddedContentBuilder.prototype.audio_if4zjc$ = KatydidEmbeddedContentBuilder.prototype.audio_if4zjc$;
  KatydidMediaEmbeddedContentBuilder.prototype.canvas_ablpy6$ = KatydidEmbeddedContentBuilder.prototype.canvas_ablpy6$;
  KatydidMediaEmbeddedContentBuilder.prototype.embed_nx0pss$ = KatydidEmbeddedContentBuilder.prototype.embed_nx0pss$;
  KatydidMediaEmbeddedContentBuilder.prototype.iframe_6rhnbj$ = KatydidEmbeddedContentBuilder.prototype.iframe_6rhnbj$;
  KatydidMediaEmbeddedContentBuilder.prototype.img_fdnnaq$ = KatydidEmbeddedContentBuilder.prototype.img_fdnnaq$;
  KatydidMediaEmbeddedContentBuilder.prototype.object_ggcu0x$ = KatydidEmbeddedContentBuilder.prototype.object_ggcu0x$;
  KatydidMediaEmbeddedContentBuilder.prototype.picture_r7gn0k$ = KatydidEmbeddedContentBuilder.prototype.picture_r7gn0k$;
  KatydidMediaEmbeddedContentBuilder.prototype.video_n6slad$ = KatydidEmbeddedContentBuilder.prototype.video_n6slad$;
  KatydidMediaEmbeddedContentBuilderImpl.prototype.source_7jkj91$ = KatydidMediaEmbeddedContentBuilder.prototype.source_7jkj91$;
  KatydidMediaEmbeddedContentBuilderImpl.prototype.track_o1vzoi$ = KatydidMediaEmbeddedContentBuilder.prototype.track_o1vzoi$;
  KatydidMediaFlowContentBuilder.prototype.unaryPlus_pdl1vz$ = KatydidFlowContentBuilder.prototype.unaryPlus_pdl1vz$;
  KatydidMediaFlowContentBuilder.prototype.a_3jwxqy$ = KatydidFlowContentBuilder.prototype.a_3jwxqy$;
  KatydidMediaFlowContentBuilder.prototype.a_ncyfe7$ = KatydidFlowContentBuilder.prototype.a_ncyfe7$;
  KatydidMediaFlowContentBuilder.prototype.address_6zr3om$ = KatydidFlowContentBuilder.prototype.address_6zr3om$;
  KatydidMediaFlowContentBuilder.prototype.audio_tp0mfx$ = KatydidFlowContentBuilder.prototype.audio_tp0mfx$;
  KatydidMediaFlowContentBuilder.prototype.audio_z5y2od$ = KatydidFlowContentBuilder.prototype.audio_z5y2od$;
  KatydidMediaFlowContentBuilder.prototype.audio_if4zjc$ = KatydidFlowContentBuilder.prototype.audio_if4zjc$;
  KatydidMediaFlowContentBuilder.prototype.blockquote_rfnrw3$ = KatydidFlowContentBuilder.prototype.blockquote_rfnrw3$;
  KatydidMediaFlowContentBuilder.prototype.canvas_p01gpz$ = KatydidFlowContentBuilder.prototype.canvas_p01gpz$;
  KatydidMediaFlowContentBuilder.prototype.canvas_zeuq1z$ = KatydidFlowContentBuilder.prototype.canvas_zeuq1z$;
  KatydidMediaFlowContentBuilder.prototype.canvas_ablpy6$ = KatydidFlowContentBuilder.prototype.canvas_ablpy6$;
  KatydidMediaFlowContentBuilder.prototype.details_k8gqqw$ = KatydidFlowContentBuilder.prototype.details_k8gqqw$;
  KatydidMediaFlowContentBuilder.prototype.dialog_rmrn7i$ = KatydidFlowContentBuilder.prototype.dialog_rmrn7i$;
  KatydidMediaFlowContentBuilder.prototype.del_pat60j$ = KatydidFlowContentBuilder.prototype.del_pat60j$;
  KatydidMediaFlowContentBuilder.prototype.del_smchxe$ = KatydidFlowContentBuilder.prototype.del_smchxe$;
  KatydidMediaFlowContentBuilder.prototype.div_6zr3om$ = KatydidFlowContentBuilder.prototype.div_6zr3om$;
  KatydidMediaFlowContentBuilder.prototype.dl_a7rbte$ = KatydidFlowContentBuilder.prototype.dl_a7rbte$;
  KatydidMediaFlowContentBuilder.prototype.fieldset_wkcbaa$ = KatydidFlowContentBuilder.prototype.fieldset_wkcbaa$;
  KatydidMediaFlowContentBuilder.prototype.figCaption_6zr3om$ = KatydidFlowContentBuilder.prototype.figCaption_6zr3om$;
  KatydidMediaFlowContentBuilder.prototype.figure_6zr3om$ = KatydidFlowContentBuilder.prototype.figure_6zr3om$;
  KatydidMediaFlowContentBuilder.prototype.footer_6zr3om$ = KatydidFlowContentBuilder.prototype.footer_6zr3om$;
  KatydidMediaFlowContentBuilder.prototype.form_roosm5$ = KatydidFlowContentBuilder.prototype.form_roosm5$;
  KatydidMediaFlowContentBuilder.prototype.header_6zr3om$ = KatydidFlowContentBuilder.prototype.header_6zr3om$;
  KatydidMediaFlowContentBuilder.prototype.hr_9mj9vz$ = KatydidFlowContentBuilder.prototype.hr_9mj9vz$;
  KatydidMediaFlowContentBuilder.prototype.ins_pat60j$ = KatydidFlowContentBuilder.prototype.ins_pat60j$;
  KatydidMediaFlowContentBuilder.prototype.ins_smchxe$ = KatydidFlowContentBuilder.prototype.ins_smchxe$;
  KatydidMediaFlowContentBuilder.prototype.legend_qckjfy$ = KatydidFlowContentBuilder.prototype.legend_qckjfy$;
  KatydidMediaFlowContentBuilder.prototype.main_6zr3om$ = KatydidFlowContentBuilder.prototype.main_6zr3om$;
  KatydidMediaFlowContentBuilder.prototype.map_io1brw$ = KatydidFlowContentBuilder.prototype.map_io1brw$;
  KatydidMediaFlowContentBuilder.prototype.map_z0i53j$ = KatydidFlowContentBuilder.prototype.map_z0i53j$;
  KatydidMediaFlowContentBuilder.prototype.object_649euk$ = KatydidFlowContentBuilder.prototype.object_649euk$;
  KatydidMediaFlowContentBuilder.prototype.object_8mhd8$ = KatydidFlowContentBuilder.prototype.object_8mhd8$;
  KatydidMediaFlowContentBuilder.prototype.object_ggcu0x$ = KatydidFlowContentBuilder.prototype.object_ggcu0x$;
  KatydidMediaFlowContentBuilder.prototype.ol_5bxxpo$ = KatydidFlowContentBuilder.prototype.ol_5bxxpo$;
  KatydidMediaFlowContentBuilder.prototype.p_qckjfy$ = KatydidFlowContentBuilder.prototype.p_qckjfy$;
  KatydidMediaFlowContentBuilder.prototype.pre_qckjfy$ = KatydidFlowContentBuilder.prototype.pre_qckjfy$;
  KatydidMediaFlowContentBuilder.prototype.table_55vzb3$ = KatydidFlowContentBuilder.prototype.table_55vzb3$;
  KatydidMediaFlowContentBuilder.prototype.ul_hxau5b$ = KatydidFlowContentBuilder.prototype.ul_hxau5b$;
  KatydidMediaFlowContentBuilder.prototype.video_hpee3a$ = KatydidFlowContentBuilder.prototype.video_hpee3a$;
  KatydidMediaFlowContentBuilder.prototype.video_l9965i$ = KatydidFlowContentBuilder.prototype.video_l9965i$;
  KatydidMediaFlowContentBuilder.prototype.video_n6slad$ = KatydidFlowContentBuilder.prototype.video_n6slad$;
  KatydidMediaFlowContentBuilder.prototype.abbr_qckjfy$ = KatydidFlowContentBuilder.prototype.abbr_qckjfy$;
  KatydidMediaFlowContentBuilder.prototype.area_ys14xf$ = KatydidFlowContentBuilder.prototype.area_ys14xf$;
  KatydidMediaFlowContentBuilder.prototype.b_qckjfy$ = KatydidFlowContentBuilder.prototype.b_qckjfy$;
  KatydidMediaFlowContentBuilder.prototype.bdi_g2kg67$ = KatydidFlowContentBuilder.prototype.bdi_g2kg67$;
  KatydidMediaFlowContentBuilder.prototype.bdo_g2kg67$ = KatydidFlowContentBuilder.prototype.bdo_g2kg67$;
  KatydidMediaFlowContentBuilder.prototype.br_9mj9vz$ = KatydidFlowContentBuilder.prototype.br_9mj9vz$;
  KatydidMediaFlowContentBuilder.prototype.button_2lxa1r$ = KatydidFlowContentBuilder.prototype.button_2lxa1r$;
  KatydidMediaFlowContentBuilder.prototype.cite_qckjfy$ = KatydidFlowContentBuilder.prototype.cite_qckjfy$;
  KatydidMediaFlowContentBuilder.prototype.code_qckjfy$ = KatydidFlowContentBuilder.prototype.code_qckjfy$;
  KatydidMediaFlowContentBuilder.prototype.comment_4w9ihe$ = KatydidFlowContentBuilder.prototype.comment_4w9ihe$;
  KatydidMediaFlowContentBuilder.prototype.data_cn0i2o$ = KatydidFlowContentBuilder.prototype.data_cn0i2o$;
  KatydidMediaFlowContentBuilder.prototype.datalist_csvf3w$ = KatydidFlowContentBuilder.prototype.datalist_csvf3w$;
  KatydidMediaFlowContentBuilder.prototype.datalist_zf5udj$ = KatydidFlowContentBuilder.prototype.datalist_zf5udj$;
  KatydidMediaFlowContentBuilder.prototype.dfn_qckjfy$ = KatydidFlowContentBuilder.prototype.dfn_qckjfy$;
  KatydidMediaFlowContentBuilder.prototype.em_qckjfy$ = KatydidFlowContentBuilder.prototype.em_qckjfy$;
  KatydidMediaFlowContentBuilder.prototype.i_qckjfy$ = KatydidFlowContentBuilder.prototype.i_qckjfy$;
  KatydidMediaFlowContentBuilder.prototype.inputButton_kk2d6s$ = KatydidFlowContentBuilder.prototype.inputButton_kk2d6s$;
  KatydidMediaFlowContentBuilder.prototype.inputCheckbox_5idhkk$ = KatydidFlowContentBuilder.prototype.inputCheckbox_5idhkk$;
  KatydidMediaFlowContentBuilder.prototype.inputColor_9zybug$ = KatydidFlowContentBuilder.prototype.inputColor_9zybug$;
  KatydidMediaFlowContentBuilder.prototype.inputDate_3kgd4t$ = KatydidFlowContentBuilder.prototype.inputDate_3kgd4t$;
  KatydidMediaFlowContentBuilder.prototype.inputDateTimeLocal_3kgd4t$ = KatydidFlowContentBuilder.prototype.inputDateTimeLocal_3kgd4t$;
  KatydidMediaFlowContentBuilder.prototype.inputEmail_44r9ep$ = KatydidFlowContentBuilder.prototype.inputEmail_44r9ep$;
  KatydidMediaFlowContentBuilder.prototype.inputFile_8v4l2x$ = KatydidFlowContentBuilder.prototype.inputFile_8v4l2x$;
  KatydidMediaFlowContentBuilder.prototype.inputHidden_kk2d6s$ = KatydidFlowContentBuilder.prototype.inputHidden_kk2d6s$;
  KatydidMediaFlowContentBuilder.prototype.inputImageButton_ojhf04$ = KatydidFlowContentBuilder.prototype.inputImageButton_ojhf04$;
  KatydidMediaFlowContentBuilder.prototype.inputMonth_3kgd4t$ = KatydidFlowContentBuilder.prototype.inputMonth_3kgd4t$;
  KatydidMediaFlowContentBuilder.prototype.inputNumber_xtj0dk$ = KatydidFlowContentBuilder.prototype.inputNumber_xtj0dk$;
  KatydidMediaFlowContentBuilder.prototype.inputNumber_25std2$ = KatydidFlowContentBuilder.prototype.inputNumber_25std2$;
  KatydidMediaFlowContentBuilder.prototype.inputPassword_98xs2q$ = KatydidFlowContentBuilder.prototype.inputPassword_98xs2q$;
  KatydidMediaFlowContentBuilder.prototype.inputRadioButton_5idhkk$ = KatydidFlowContentBuilder.prototype.inputRadioButton_5idhkk$;
  KatydidMediaFlowContentBuilder.prototype.inputRange_er1tee$ = KatydidFlowContentBuilder.prototype.inputRange_er1tee$;
  KatydidMediaFlowContentBuilder.prototype.inputResetButton_kk2d6s$ = KatydidFlowContentBuilder.prototype.inputResetButton_kk2d6s$;
  KatydidMediaFlowContentBuilder.prototype.inputSearch_y74p72$ = KatydidFlowContentBuilder.prototype.inputSearch_y74p72$;
  KatydidMediaFlowContentBuilder.prototype.inputSubmitButton_xi657a$ = KatydidFlowContentBuilder.prototype.inputSubmitButton_xi657a$;
  KatydidMediaFlowContentBuilder.prototype.inputTelephone_m3bg53$ = KatydidFlowContentBuilder.prototype.inputTelephone_m3bg53$;
  KatydidMediaFlowContentBuilder.prototype.inputText_y74p72$ = KatydidFlowContentBuilder.prototype.inputText_y74p72$;
  KatydidMediaFlowContentBuilder.prototype.inputTime_629f1$ = KatydidFlowContentBuilder.prototype.inputTime_629f1$;
  KatydidMediaFlowContentBuilder.prototype.inputUrl_m3bg53$ = KatydidFlowContentBuilder.prototype.inputUrl_m3bg53$;
  KatydidMediaFlowContentBuilder.prototype.inputWeek_3kgd4t$ = KatydidFlowContentBuilder.prototype.inputWeek_3kgd4t$;
  KatydidMediaFlowContentBuilder.prototype.kbd_qckjfy$ = KatydidFlowContentBuilder.prototype.kbd_qckjfy$;
  KatydidMediaFlowContentBuilder.prototype.label_va30u7$ = KatydidFlowContentBuilder.prototype.label_va30u7$;
  KatydidMediaFlowContentBuilder.prototype.mark_qckjfy$ = KatydidFlowContentBuilder.prototype.mark_qckjfy$;
  KatydidMediaFlowContentBuilder.prototype.meter_6c4h8d$ = KatydidFlowContentBuilder.prototype.meter_6c4h8d$;
  KatydidMediaFlowContentBuilder.prototype.meter_ujjlce$ = KatydidFlowContentBuilder.prototype.meter_ujjlce$;
  KatydidMediaFlowContentBuilder.prototype.output_7nyrc9$ = KatydidFlowContentBuilder.prototype.output_7nyrc9$;
  KatydidMediaFlowContentBuilder.prototype.progress_8ydfv4$ = KatydidFlowContentBuilder.prototype.progress_8ydfv4$;
  KatydidMediaFlowContentBuilder.prototype.progress_qjij5p$ = KatydidFlowContentBuilder.prototype.progress_qjij5p$;
  KatydidMediaFlowContentBuilder.prototype.q_qckjfy$ = KatydidFlowContentBuilder.prototype.q_qckjfy$;
  KatydidMediaFlowContentBuilder.prototype.ruby_sy7cla$ = KatydidFlowContentBuilder.prototype.ruby_sy7cla$;
  KatydidMediaFlowContentBuilder.prototype.s_qckjfy$ = KatydidFlowContentBuilder.prototype.s_qckjfy$;
  KatydidMediaFlowContentBuilder.prototype.samp_qckjfy$ = KatydidFlowContentBuilder.prototype.samp_qckjfy$;
  KatydidMediaFlowContentBuilder.prototype.select_7efmz3$ = KatydidFlowContentBuilder.prototype.select_7efmz3$;
  KatydidMediaFlowContentBuilder.prototype.small_qckjfy$ = KatydidFlowContentBuilder.prototype.small_qckjfy$;
  KatydidMediaFlowContentBuilder.prototype.span_qckjfy$ = KatydidFlowContentBuilder.prototype.span_qckjfy$;
  KatydidMediaFlowContentBuilder.prototype.strong_qckjfy$ = KatydidFlowContentBuilder.prototype.strong_qckjfy$;
  KatydidMediaFlowContentBuilder.prototype.sub_qckjfy$ = KatydidFlowContentBuilder.prototype.sub_qckjfy$;
  KatydidMediaFlowContentBuilder.prototype.sup_qckjfy$ = KatydidFlowContentBuilder.prototype.sup_qckjfy$;
  KatydidMediaFlowContentBuilder.prototype.text_4w9ihe$ = KatydidFlowContentBuilder.prototype.text_4w9ihe$;
  KatydidMediaFlowContentBuilder.prototype.textarea_1j30yg$ = KatydidFlowContentBuilder.prototype.textarea_1j30yg$;
  KatydidMediaFlowContentBuilder.prototype.time_y9dz51$ = KatydidFlowContentBuilder.prototype.time_y9dz51$;
  KatydidMediaFlowContentBuilder.prototype.time_jigsdy$ = KatydidFlowContentBuilder.prototype.time_jigsdy$;
  KatydidMediaFlowContentBuilder.prototype.u_qckjfy$ = KatydidFlowContentBuilder.prototype.u_qckjfy$;
  KatydidMediaFlowContentBuilder.prototype.var_qckjfy$ = KatydidFlowContentBuilder.prototype.var_qckjfy$;
  KatydidMediaFlowContentBuilder.prototype.wbr_9mj9vz$ = KatydidFlowContentBuilder.prototype.wbr_9mj9vz$;
  KatydidMediaFlowContentBuilder.prototype.embed_nx0pss$ = KatydidFlowContentBuilder.prototype.embed_nx0pss$;
  KatydidMediaFlowContentBuilder.prototype.iframe_6rhnbj$ = KatydidFlowContentBuilder.prototype.iframe_6rhnbj$;
  KatydidMediaFlowContentBuilder.prototype.img_fdnnaq$ = KatydidFlowContentBuilder.prototype.img_fdnnaq$;
  KatydidMediaFlowContentBuilder.prototype.picture_r7gn0k$ = KatydidFlowContentBuilder.prototype.picture_r7gn0k$;
  KatydidMediaFlowContentBuilder.prototype.h1_qckjfy$ = KatydidFlowContentBuilder.prototype.h1_qckjfy$;
  KatydidMediaFlowContentBuilder.prototype.h2_qckjfy$ = KatydidFlowContentBuilder.prototype.h2_qckjfy$;
  KatydidMediaFlowContentBuilder.prototype.h3_qckjfy$ = KatydidFlowContentBuilder.prototype.h3_qckjfy$;
  KatydidMediaFlowContentBuilder.prototype.h4_qckjfy$ = KatydidFlowContentBuilder.prototype.h4_qckjfy$;
  KatydidMediaFlowContentBuilder.prototype.h5_qckjfy$ = KatydidFlowContentBuilder.prototype.h5_qckjfy$;
  KatydidMediaFlowContentBuilder.prototype.h6_qckjfy$ = KatydidFlowContentBuilder.prototype.h6_qckjfy$;
  KatydidMediaFlowContentBuilder.prototype.article_6zr3om$ = KatydidFlowContentBuilder.prototype.article_6zr3om$;
  KatydidMediaFlowContentBuilder.prototype.aside_6zr3om$ = KatydidFlowContentBuilder.prototype.aside_6zr3om$;
  KatydidMediaFlowContentBuilder.prototype.nav_6zr3om$ = KatydidFlowContentBuilder.prototype.nav_6zr3om$;
  KatydidMediaFlowContentBuilder.prototype.section_6zr3om$ = KatydidFlowContentBuilder.prototype.section_6zr3om$;
  KatydidMediaFlowContentBuilderImpl.prototype.source_7jkj91$ = KatydidMediaFlowContentBuilder.prototype.source_7jkj91$;
  KatydidMediaFlowContentBuilderImpl.prototype.track_o1vzoi$ = KatydidMediaFlowContentBuilder.prototype.track_o1vzoi$;
  KatydidMediaPhrasingContentBuilder.prototype.audio_if4zjc$ = KatydidEmbeddedContentBuilder.prototype.audio_if4zjc$;
  KatydidMediaPhrasingContentBuilder.prototype.canvas_ablpy6$ = KatydidEmbeddedContentBuilder.prototype.canvas_ablpy6$;
  KatydidMediaPhrasingContentBuilder.prototype.embed_nx0pss$ = KatydidEmbeddedContentBuilder.prototype.embed_nx0pss$;
  KatydidMediaPhrasingContentBuilder.prototype.iframe_6rhnbj$ = KatydidEmbeddedContentBuilder.prototype.iframe_6rhnbj$;
  KatydidMediaPhrasingContentBuilder.prototype.img_fdnnaq$ = KatydidEmbeddedContentBuilder.prototype.img_fdnnaq$;
  KatydidMediaPhrasingContentBuilder.prototype.object_ggcu0x$ = KatydidEmbeddedContentBuilder.prototype.object_ggcu0x$;
  KatydidMediaPhrasingContentBuilder.prototype.picture_r7gn0k$ = KatydidEmbeddedContentBuilder.prototype.picture_r7gn0k$;
  KatydidMediaPhrasingContentBuilder.prototype.video_n6slad$ = KatydidEmbeddedContentBuilder.prototype.video_n6slad$;
  KatydidMediaPhrasingContentBuilderImpl.prototype.source_7jkj91$ = KatydidMediaPhrasingContentBuilder.prototype.source_7jkj91$;
  KatydidMediaPhrasingContentBuilderImpl.prototype.track_o1vzoi$ = KatydidMediaPhrasingContentBuilder.prototype.track_o1vzoi$;
  KatydidPictureContentBuilderImpl.prototype.img_1hpfln$ = KatydidPictureContentBuilder.prototype.img_1hpfln$;
  KatydidPictureContentBuilderImpl.prototype.source_7jkj91$ = KatydidPictureContentBuilder.prototype.source_7jkj91$;
  KatydidDescriptionListContentBuilderImpl.prototype.comment_4w9ihe$ = KatydidDescriptionListContentBuilder.prototype.comment_4w9ihe$;
  KatydidDescriptionListContentBuilderImpl.prototype.dd_6zr3om$ = KatydidDescriptionListContentBuilder.prototype.dd_6zr3om$;
  KatydidDescriptionListContentBuilderImpl.prototype.div_a7rbte$ = KatydidDescriptionListContentBuilder.prototype.div_a7rbte$;
  KatydidDescriptionListContentBuilderImpl.prototype.dt_6zr3om$ = KatydidDescriptionListContentBuilder.prototype.dt_6zr3om$;
  KatydidOptGroupContentBuilderImpl.prototype.comment_4w9ihe$ = KatydidOptGroupContentBuilder.prototype.comment_4w9ihe$;
  KatydidOptGroupContentBuilderImpl.prototype.option_uvs23e$ = KatydidOptGroupContentBuilder.prototype.option_uvs23e$;
  KatydidOptGroupContentBuilderImpl.prototype.option_o31kud$ = KatydidOptGroupContentBuilder.prototype.option_o31kud$;
  KatydidSelectContentBuilder.prototype.comment_4w9ihe$ = KatydidOptGroupContentBuilder.prototype.comment_4w9ihe$;
  KatydidSelectContentBuilder.prototype.option_uvs23e$ = KatydidOptGroupContentBuilder.prototype.option_uvs23e$;
  KatydidSelectContentBuilder.prototype.option_o31kud$ = KatydidOptGroupContentBuilder.prototype.option_o31kud$;
  KatydidSelectContentBuilderImpl.prototype.optGroup_a8s91r$ = KatydidSelectContentBuilder.prototype.optGroup_a8s91r$;
  KatydidTextContentBuilderImpl.prototype.unaryPlus_pdl1vz$ = KatydidTextContentBuilder.prototype.unaryPlus_pdl1vz$;
  KatydidTextContentBuilderImpl.prototype.comment_4w9ihe$ = KatydidTextContentBuilder.prototype.comment_4w9ihe$;
  KatydidTextContentBuilderImpl.prototype.text_4w9ihe$ = KatydidTextContentBuilder.prototype.text_4w9ihe$;
  KatydidObjectEmbeddedContentBuilder.prototype.audio_if4zjc$ = KatydidEmbeddedContentBuilder.prototype.audio_if4zjc$;
  KatydidObjectEmbeddedContentBuilder.prototype.canvas_ablpy6$ = KatydidEmbeddedContentBuilder.prototype.canvas_ablpy6$;
  KatydidObjectEmbeddedContentBuilder.prototype.embed_nx0pss$ = KatydidEmbeddedContentBuilder.prototype.embed_nx0pss$;
  KatydidObjectEmbeddedContentBuilder.prototype.iframe_6rhnbj$ = KatydidEmbeddedContentBuilder.prototype.iframe_6rhnbj$;
  KatydidObjectEmbeddedContentBuilder.prototype.img_fdnnaq$ = KatydidEmbeddedContentBuilder.prototype.img_fdnnaq$;
  KatydidObjectEmbeddedContentBuilder.prototype.object_ggcu0x$ = KatydidEmbeddedContentBuilder.prototype.object_ggcu0x$;
  KatydidObjectEmbeddedContentBuilder.prototype.picture_r7gn0k$ = KatydidEmbeddedContentBuilder.prototype.picture_r7gn0k$;
  KatydidObjectEmbeddedContentBuilder.prototype.video_n6slad$ = KatydidEmbeddedContentBuilder.prototype.video_n6slad$;
  KatydidObjectEmbeddedContentBuilderImpl.prototype.param_clmic1$ = KatydidObjectEmbeddedContentBuilder.prototype.param_clmic1$;
  KatydidObjectFlowContentBuilder.prototype.unaryPlus_pdl1vz$ = KatydidFlowContentBuilder.prototype.unaryPlus_pdl1vz$;
  KatydidObjectFlowContentBuilder.prototype.a_3jwxqy$ = KatydidFlowContentBuilder.prototype.a_3jwxqy$;
  KatydidObjectFlowContentBuilder.prototype.a_ncyfe7$ = KatydidFlowContentBuilder.prototype.a_ncyfe7$;
  KatydidObjectFlowContentBuilder.prototype.address_6zr3om$ = KatydidFlowContentBuilder.prototype.address_6zr3om$;
  KatydidObjectFlowContentBuilder.prototype.audio_tp0mfx$ = KatydidFlowContentBuilder.prototype.audio_tp0mfx$;
  KatydidObjectFlowContentBuilder.prototype.audio_z5y2od$ = KatydidFlowContentBuilder.prototype.audio_z5y2od$;
  KatydidObjectFlowContentBuilder.prototype.audio_if4zjc$ = KatydidFlowContentBuilder.prototype.audio_if4zjc$;
  KatydidObjectFlowContentBuilder.prototype.blockquote_rfnrw3$ = KatydidFlowContentBuilder.prototype.blockquote_rfnrw3$;
  KatydidObjectFlowContentBuilder.prototype.canvas_p01gpz$ = KatydidFlowContentBuilder.prototype.canvas_p01gpz$;
  KatydidObjectFlowContentBuilder.prototype.canvas_zeuq1z$ = KatydidFlowContentBuilder.prototype.canvas_zeuq1z$;
  KatydidObjectFlowContentBuilder.prototype.canvas_ablpy6$ = KatydidFlowContentBuilder.prototype.canvas_ablpy6$;
  KatydidObjectFlowContentBuilder.prototype.details_k8gqqw$ = KatydidFlowContentBuilder.prototype.details_k8gqqw$;
  KatydidObjectFlowContentBuilder.prototype.dialog_rmrn7i$ = KatydidFlowContentBuilder.prototype.dialog_rmrn7i$;
  KatydidObjectFlowContentBuilder.prototype.del_pat60j$ = KatydidFlowContentBuilder.prototype.del_pat60j$;
  KatydidObjectFlowContentBuilder.prototype.del_smchxe$ = KatydidFlowContentBuilder.prototype.del_smchxe$;
  KatydidObjectFlowContentBuilder.prototype.div_6zr3om$ = KatydidFlowContentBuilder.prototype.div_6zr3om$;
  KatydidObjectFlowContentBuilder.prototype.dl_a7rbte$ = KatydidFlowContentBuilder.prototype.dl_a7rbte$;
  KatydidObjectFlowContentBuilder.prototype.fieldset_wkcbaa$ = KatydidFlowContentBuilder.prototype.fieldset_wkcbaa$;
  KatydidObjectFlowContentBuilder.prototype.figCaption_6zr3om$ = KatydidFlowContentBuilder.prototype.figCaption_6zr3om$;
  KatydidObjectFlowContentBuilder.prototype.figure_6zr3om$ = KatydidFlowContentBuilder.prototype.figure_6zr3om$;
  KatydidObjectFlowContentBuilder.prototype.footer_6zr3om$ = KatydidFlowContentBuilder.prototype.footer_6zr3om$;
  KatydidObjectFlowContentBuilder.prototype.form_roosm5$ = KatydidFlowContentBuilder.prototype.form_roosm5$;
  KatydidObjectFlowContentBuilder.prototype.header_6zr3om$ = KatydidFlowContentBuilder.prototype.header_6zr3om$;
  KatydidObjectFlowContentBuilder.prototype.hr_9mj9vz$ = KatydidFlowContentBuilder.prototype.hr_9mj9vz$;
  KatydidObjectFlowContentBuilder.prototype.ins_pat60j$ = KatydidFlowContentBuilder.prototype.ins_pat60j$;
  KatydidObjectFlowContentBuilder.prototype.ins_smchxe$ = KatydidFlowContentBuilder.prototype.ins_smchxe$;
  KatydidObjectFlowContentBuilder.prototype.legend_qckjfy$ = KatydidFlowContentBuilder.prototype.legend_qckjfy$;
  KatydidObjectFlowContentBuilder.prototype.main_6zr3om$ = KatydidFlowContentBuilder.prototype.main_6zr3om$;
  KatydidObjectFlowContentBuilder.prototype.map_io1brw$ = KatydidFlowContentBuilder.prototype.map_io1brw$;
  KatydidObjectFlowContentBuilder.prototype.map_z0i53j$ = KatydidFlowContentBuilder.prototype.map_z0i53j$;
  KatydidObjectFlowContentBuilder.prototype.object_649euk$ = KatydidFlowContentBuilder.prototype.object_649euk$;
  KatydidObjectFlowContentBuilder.prototype.object_8mhd8$ = KatydidFlowContentBuilder.prototype.object_8mhd8$;
  KatydidObjectFlowContentBuilder.prototype.object_ggcu0x$ = KatydidFlowContentBuilder.prototype.object_ggcu0x$;
  KatydidObjectFlowContentBuilder.prototype.ol_5bxxpo$ = KatydidFlowContentBuilder.prototype.ol_5bxxpo$;
  KatydidObjectFlowContentBuilder.prototype.p_qckjfy$ = KatydidFlowContentBuilder.prototype.p_qckjfy$;
  KatydidObjectFlowContentBuilder.prototype.pre_qckjfy$ = KatydidFlowContentBuilder.prototype.pre_qckjfy$;
  KatydidObjectFlowContentBuilder.prototype.table_55vzb3$ = KatydidFlowContentBuilder.prototype.table_55vzb3$;
  KatydidObjectFlowContentBuilder.prototype.ul_hxau5b$ = KatydidFlowContentBuilder.prototype.ul_hxau5b$;
  KatydidObjectFlowContentBuilder.prototype.video_hpee3a$ = KatydidFlowContentBuilder.prototype.video_hpee3a$;
  KatydidObjectFlowContentBuilder.prototype.video_l9965i$ = KatydidFlowContentBuilder.prototype.video_l9965i$;
  KatydidObjectFlowContentBuilder.prototype.video_n6slad$ = KatydidFlowContentBuilder.prototype.video_n6slad$;
  KatydidObjectFlowContentBuilder.prototype.abbr_qckjfy$ = KatydidFlowContentBuilder.prototype.abbr_qckjfy$;
  KatydidObjectFlowContentBuilder.prototype.area_ys14xf$ = KatydidFlowContentBuilder.prototype.area_ys14xf$;
  KatydidObjectFlowContentBuilder.prototype.b_qckjfy$ = KatydidFlowContentBuilder.prototype.b_qckjfy$;
  KatydidObjectFlowContentBuilder.prototype.bdi_g2kg67$ = KatydidFlowContentBuilder.prototype.bdi_g2kg67$;
  KatydidObjectFlowContentBuilder.prototype.bdo_g2kg67$ = KatydidFlowContentBuilder.prototype.bdo_g2kg67$;
  KatydidObjectFlowContentBuilder.prototype.br_9mj9vz$ = KatydidFlowContentBuilder.prototype.br_9mj9vz$;
  KatydidObjectFlowContentBuilder.prototype.button_2lxa1r$ = KatydidFlowContentBuilder.prototype.button_2lxa1r$;
  KatydidObjectFlowContentBuilder.prototype.cite_qckjfy$ = KatydidFlowContentBuilder.prototype.cite_qckjfy$;
  KatydidObjectFlowContentBuilder.prototype.code_qckjfy$ = KatydidFlowContentBuilder.prototype.code_qckjfy$;
  KatydidObjectFlowContentBuilder.prototype.comment_4w9ihe$ = KatydidFlowContentBuilder.prototype.comment_4w9ihe$;
  KatydidObjectFlowContentBuilder.prototype.data_cn0i2o$ = KatydidFlowContentBuilder.prototype.data_cn0i2o$;
  KatydidObjectFlowContentBuilder.prototype.datalist_csvf3w$ = KatydidFlowContentBuilder.prototype.datalist_csvf3w$;
  KatydidObjectFlowContentBuilder.prototype.datalist_zf5udj$ = KatydidFlowContentBuilder.prototype.datalist_zf5udj$;
  KatydidObjectFlowContentBuilder.prototype.dfn_qckjfy$ = KatydidFlowContentBuilder.prototype.dfn_qckjfy$;
  KatydidObjectFlowContentBuilder.prototype.em_qckjfy$ = KatydidFlowContentBuilder.prototype.em_qckjfy$;
  KatydidObjectFlowContentBuilder.prototype.i_qckjfy$ = KatydidFlowContentBuilder.prototype.i_qckjfy$;
  KatydidObjectFlowContentBuilder.prototype.inputButton_kk2d6s$ = KatydidFlowContentBuilder.prototype.inputButton_kk2d6s$;
  KatydidObjectFlowContentBuilder.prototype.inputCheckbox_5idhkk$ = KatydidFlowContentBuilder.prototype.inputCheckbox_5idhkk$;
  KatydidObjectFlowContentBuilder.prototype.inputColor_9zybug$ = KatydidFlowContentBuilder.prototype.inputColor_9zybug$;
  KatydidObjectFlowContentBuilder.prototype.inputDate_3kgd4t$ = KatydidFlowContentBuilder.prototype.inputDate_3kgd4t$;
  KatydidObjectFlowContentBuilder.prototype.inputDateTimeLocal_3kgd4t$ = KatydidFlowContentBuilder.prototype.inputDateTimeLocal_3kgd4t$;
  KatydidObjectFlowContentBuilder.prototype.inputEmail_44r9ep$ = KatydidFlowContentBuilder.prototype.inputEmail_44r9ep$;
  KatydidObjectFlowContentBuilder.prototype.inputFile_8v4l2x$ = KatydidFlowContentBuilder.prototype.inputFile_8v4l2x$;
  KatydidObjectFlowContentBuilder.prototype.inputHidden_kk2d6s$ = KatydidFlowContentBuilder.prototype.inputHidden_kk2d6s$;
  KatydidObjectFlowContentBuilder.prototype.inputImageButton_ojhf04$ = KatydidFlowContentBuilder.prototype.inputImageButton_ojhf04$;
  KatydidObjectFlowContentBuilder.prototype.inputMonth_3kgd4t$ = KatydidFlowContentBuilder.prototype.inputMonth_3kgd4t$;
  KatydidObjectFlowContentBuilder.prototype.inputNumber_xtj0dk$ = KatydidFlowContentBuilder.prototype.inputNumber_xtj0dk$;
  KatydidObjectFlowContentBuilder.prototype.inputNumber_25std2$ = KatydidFlowContentBuilder.prototype.inputNumber_25std2$;
  KatydidObjectFlowContentBuilder.prototype.inputPassword_98xs2q$ = KatydidFlowContentBuilder.prototype.inputPassword_98xs2q$;
  KatydidObjectFlowContentBuilder.prototype.inputRadioButton_5idhkk$ = KatydidFlowContentBuilder.prototype.inputRadioButton_5idhkk$;
  KatydidObjectFlowContentBuilder.prototype.inputRange_er1tee$ = KatydidFlowContentBuilder.prototype.inputRange_er1tee$;
  KatydidObjectFlowContentBuilder.prototype.inputResetButton_kk2d6s$ = KatydidFlowContentBuilder.prototype.inputResetButton_kk2d6s$;
  KatydidObjectFlowContentBuilder.prototype.inputSearch_y74p72$ = KatydidFlowContentBuilder.prototype.inputSearch_y74p72$;
  KatydidObjectFlowContentBuilder.prototype.inputSubmitButton_xi657a$ = KatydidFlowContentBuilder.prototype.inputSubmitButton_xi657a$;
  KatydidObjectFlowContentBuilder.prototype.inputTelephone_m3bg53$ = KatydidFlowContentBuilder.prototype.inputTelephone_m3bg53$;
  KatydidObjectFlowContentBuilder.prototype.inputText_y74p72$ = KatydidFlowContentBuilder.prototype.inputText_y74p72$;
  KatydidObjectFlowContentBuilder.prototype.inputTime_629f1$ = KatydidFlowContentBuilder.prototype.inputTime_629f1$;
  KatydidObjectFlowContentBuilder.prototype.inputUrl_m3bg53$ = KatydidFlowContentBuilder.prototype.inputUrl_m3bg53$;
  KatydidObjectFlowContentBuilder.prototype.inputWeek_3kgd4t$ = KatydidFlowContentBuilder.prototype.inputWeek_3kgd4t$;
  KatydidObjectFlowContentBuilder.prototype.kbd_qckjfy$ = KatydidFlowContentBuilder.prototype.kbd_qckjfy$;
  KatydidObjectFlowContentBuilder.prototype.label_va30u7$ = KatydidFlowContentBuilder.prototype.label_va30u7$;
  KatydidObjectFlowContentBuilder.prototype.mark_qckjfy$ = KatydidFlowContentBuilder.prototype.mark_qckjfy$;
  KatydidObjectFlowContentBuilder.prototype.meter_6c4h8d$ = KatydidFlowContentBuilder.prototype.meter_6c4h8d$;
  KatydidObjectFlowContentBuilder.prototype.meter_ujjlce$ = KatydidFlowContentBuilder.prototype.meter_ujjlce$;
  KatydidObjectFlowContentBuilder.prototype.output_7nyrc9$ = KatydidFlowContentBuilder.prototype.output_7nyrc9$;
  KatydidObjectFlowContentBuilder.prototype.progress_8ydfv4$ = KatydidFlowContentBuilder.prototype.progress_8ydfv4$;
  KatydidObjectFlowContentBuilder.prototype.progress_qjij5p$ = KatydidFlowContentBuilder.prototype.progress_qjij5p$;
  KatydidObjectFlowContentBuilder.prototype.q_qckjfy$ = KatydidFlowContentBuilder.prototype.q_qckjfy$;
  KatydidObjectFlowContentBuilder.prototype.ruby_sy7cla$ = KatydidFlowContentBuilder.prototype.ruby_sy7cla$;
  KatydidObjectFlowContentBuilder.prototype.s_qckjfy$ = KatydidFlowContentBuilder.prototype.s_qckjfy$;
  KatydidObjectFlowContentBuilder.prototype.samp_qckjfy$ = KatydidFlowContentBuilder.prototype.samp_qckjfy$;
  KatydidObjectFlowContentBuilder.prototype.select_7efmz3$ = KatydidFlowContentBuilder.prototype.select_7efmz3$;
  KatydidObjectFlowContentBuilder.prototype.small_qckjfy$ = KatydidFlowContentBuilder.prototype.small_qckjfy$;
  KatydidObjectFlowContentBuilder.prototype.span_qckjfy$ = KatydidFlowContentBuilder.prototype.span_qckjfy$;
  KatydidObjectFlowContentBuilder.prototype.strong_qckjfy$ = KatydidFlowContentBuilder.prototype.strong_qckjfy$;
  KatydidObjectFlowContentBuilder.prototype.sub_qckjfy$ = KatydidFlowContentBuilder.prototype.sub_qckjfy$;
  KatydidObjectFlowContentBuilder.prototype.sup_qckjfy$ = KatydidFlowContentBuilder.prototype.sup_qckjfy$;
  KatydidObjectFlowContentBuilder.prototype.text_4w9ihe$ = KatydidFlowContentBuilder.prototype.text_4w9ihe$;
  KatydidObjectFlowContentBuilder.prototype.textarea_1j30yg$ = KatydidFlowContentBuilder.prototype.textarea_1j30yg$;
  KatydidObjectFlowContentBuilder.prototype.time_y9dz51$ = KatydidFlowContentBuilder.prototype.time_y9dz51$;
  KatydidObjectFlowContentBuilder.prototype.time_jigsdy$ = KatydidFlowContentBuilder.prototype.time_jigsdy$;
  KatydidObjectFlowContentBuilder.prototype.u_qckjfy$ = KatydidFlowContentBuilder.prototype.u_qckjfy$;
  KatydidObjectFlowContentBuilder.prototype.var_qckjfy$ = KatydidFlowContentBuilder.prototype.var_qckjfy$;
  KatydidObjectFlowContentBuilder.prototype.wbr_9mj9vz$ = KatydidFlowContentBuilder.prototype.wbr_9mj9vz$;
  KatydidObjectFlowContentBuilder.prototype.embed_nx0pss$ = KatydidFlowContentBuilder.prototype.embed_nx0pss$;
  KatydidObjectFlowContentBuilder.prototype.iframe_6rhnbj$ = KatydidFlowContentBuilder.prototype.iframe_6rhnbj$;
  KatydidObjectFlowContentBuilder.prototype.img_fdnnaq$ = KatydidFlowContentBuilder.prototype.img_fdnnaq$;
  KatydidObjectFlowContentBuilder.prototype.picture_r7gn0k$ = KatydidFlowContentBuilder.prototype.picture_r7gn0k$;
  KatydidObjectFlowContentBuilder.prototype.h1_qckjfy$ = KatydidFlowContentBuilder.prototype.h1_qckjfy$;
  KatydidObjectFlowContentBuilder.prototype.h2_qckjfy$ = KatydidFlowContentBuilder.prototype.h2_qckjfy$;
  KatydidObjectFlowContentBuilder.prototype.h3_qckjfy$ = KatydidFlowContentBuilder.prototype.h3_qckjfy$;
  KatydidObjectFlowContentBuilder.prototype.h4_qckjfy$ = KatydidFlowContentBuilder.prototype.h4_qckjfy$;
  KatydidObjectFlowContentBuilder.prototype.h5_qckjfy$ = KatydidFlowContentBuilder.prototype.h5_qckjfy$;
  KatydidObjectFlowContentBuilder.prototype.h6_qckjfy$ = KatydidFlowContentBuilder.prototype.h6_qckjfy$;
  KatydidObjectFlowContentBuilder.prototype.article_6zr3om$ = KatydidFlowContentBuilder.prototype.article_6zr3om$;
  KatydidObjectFlowContentBuilder.prototype.aside_6zr3om$ = KatydidFlowContentBuilder.prototype.aside_6zr3om$;
  KatydidObjectFlowContentBuilder.prototype.nav_6zr3om$ = KatydidFlowContentBuilder.prototype.nav_6zr3om$;
  KatydidObjectFlowContentBuilder.prototype.section_6zr3om$ = KatydidFlowContentBuilder.prototype.section_6zr3om$;
  KatydidObjectFlowContentBuilderImpl.prototype.param_clmic1$ = KatydidObjectFlowContentBuilder.prototype.param_clmic1$;
  KatydidObjectPhrasingContentBuilder.prototype.unaryPlus_pdl1vz$ = KatydidPhrasingContentBuilder.prototype.unaryPlus_pdl1vz$;
  KatydidObjectPhrasingContentBuilder.prototype.a_ncyfe7$ = KatydidPhrasingContentBuilder.prototype.a_ncyfe7$;
  KatydidObjectPhrasingContentBuilder.prototype.abbr_qckjfy$ = KatydidPhrasingContentBuilder.prototype.abbr_qckjfy$;
  KatydidObjectPhrasingContentBuilder.prototype.area_ys14xf$ = KatydidPhrasingContentBuilder.prototype.area_ys14xf$;
  KatydidObjectPhrasingContentBuilder.prototype.audio_z5y2od$ = KatydidPhrasingContentBuilder.prototype.audio_z5y2od$;
  KatydidObjectPhrasingContentBuilder.prototype.audio_if4zjc$ = KatydidPhrasingContentBuilder.prototype.audio_if4zjc$;
  KatydidObjectPhrasingContentBuilder.prototype.b_qckjfy$ = KatydidPhrasingContentBuilder.prototype.b_qckjfy$;
  KatydidObjectPhrasingContentBuilder.prototype.bdi_g2kg67$ = KatydidPhrasingContentBuilder.prototype.bdi_g2kg67$;
  KatydidObjectPhrasingContentBuilder.prototype.bdo_g2kg67$ = KatydidPhrasingContentBuilder.prototype.bdo_g2kg67$;
  KatydidObjectPhrasingContentBuilder.prototype.br_9mj9vz$ = KatydidPhrasingContentBuilder.prototype.br_9mj9vz$;
  KatydidObjectPhrasingContentBuilder.prototype.button_2lxa1r$ = KatydidPhrasingContentBuilder.prototype.button_2lxa1r$;
  KatydidObjectPhrasingContentBuilder.prototype.canvas_zeuq1z$ = KatydidPhrasingContentBuilder.prototype.canvas_zeuq1z$;
  KatydidObjectPhrasingContentBuilder.prototype.canvas_ablpy6$ = KatydidPhrasingContentBuilder.prototype.canvas_ablpy6$;
  KatydidObjectPhrasingContentBuilder.prototype.cite_qckjfy$ = KatydidPhrasingContentBuilder.prototype.cite_qckjfy$;
  KatydidObjectPhrasingContentBuilder.prototype.code_qckjfy$ = KatydidPhrasingContentBuilder.prototype.code_qckjfy$;
  KatydidObjectPhrasingContentBuilder.prototype.comment_4w9ihe$ = KatydidPhrasingContentBuilder.prototype.comment_4w9ihe$;
  KatydidObjectPhrasingContentBuilder.prototype.data_cn0i2o$ = KatydidPhrasingContentBuilder.prototype.data_cn0i2o$;
  KatydidObjectPhrasingContentBuilder.prototype.datalist_csvf3w$ = KatydidPhrasingContentBuilder.prototype.datalist_csvf3w$;
  KatydidObjectPhrasingContentBuilder.prototype.datalist_zf5udj$ = KatydidPhrasingContentBuilder.prototype.datalist_zf5udj$;
  KatydidObjectPhrasingContentBuilder.prototype.del_smchxe$ = KatydidPhrasingContentBuilder.prototype.del_smchxe$;
  KatydidObjectPhrasingContentBuilder.prototype.dfn_qckjfy$ = KatydidPhrasingContentBuilder.prototype.dfn_qckjfy$;
  KatydidObjectPhrasingContentBuilder.prototype.em_qckjfy$ = KatydidPhrasingContentBuilder.prototype.em_qckjfy$;
  KatydidObjectPhrasingContentBuilder.prototype.i_qckjfy$ = KatydidPhrasingContentBuilder.prototype.i_qckjfy$;
  KatydidObjectPhrasingContentBuilder.prototype.inputButton_kk2d6s$ = KatydidPhrasingContentBuilder.prototype.inputButton_kk2d6s$;
  KatydidObjectPhrasingContentBuilder.prototype.inputCheckbox_5idhkk$ = KatydidPhrasingContentBuilder.prototype.inputCheckbox_5idhkk$;
  KatydidObjectPhrasingContentBuilder.prototype.inputColor_9zybug$ = KatydidPhrasingContentBuilder.prototype.inputColor_9zybug$;
  KatydidObjectPhrasingContentBuilder.prototype.inputDate_3kgd4t$ = KatydidPhrasingContentBuilder.prototype.inputDate_3kgd4t$;
  KatydidObjectPhrasingContentBuilder.prototype.inputDateTimeLocal_3kgd4t$ = KatydidPhrasingContentBuilder.prototype.inputDateTimeLocal_3kgd4t$;
  KatydidObjectPhrasingContentBuilder.prototype.inputEmail_44r9ep$ = KatydidPhrasingContentBuilder.prototype.inputEmail_44r9ep$;
  KatydidObjectPhrasingContentBuilder.prototype.inputFile_8v4l2x$ = KatydidPhrasingContentBuilder.prototype.inputFile_8v4l2x$;
  KatydidObjectPhrasingContentBuilder.prototype.inputHidden_kk2d6s$ = KatydidPhrasingContentBuilder.prototype.inputHidden_kk2d6s$;
  KatydidObjectPhrasingContentBuilder.prototype.inputImageButton_ojhf04$ = KatydidPhrasingContentBuilder.prototype.inputImageButton_ojhf04$;
  KatydidObjectPhrasingContentBuilder.prototype.inputMonth_3kgd4t$ = KatydidPhrasingContentBuilder.prototype.inputMonth_3kgd4t$;
  KatydidObjectPhrasingContentBuilder.prototype.inputNumber_xtj0dk$ = KatydidPhrasingContentBuilder.prototype.inputNumber_xtj0dk$;
  KatydidObjectPhrasingContentBuilder.prototype.inputNumber_25std2$ = KatydidPhrasingContentBuilder.prototype.inputNumber_25std2$;
  KatydidObjectPhrasingContentBuilder.prototype.inputPassword_98xs2q$ = KatydidPhrasingContentBuilder.prototype.inputPassword_98xs2q$;
  KatydidObjectPhrasingContentBuilder.prototype.inputRadioButton_5idhkk$ = KatydidPhrasingContentBuilder.prototype.inputRadioButton_5idhkk$;
  KatydidObjectPhrasingContentBuilder.prototype.inputRange_er1tee$ = KatydidPhrasingContentBuilder.prototype.inputRange_er1tee$;
  KatydidObjectPhrasingContentBuilder.prototype.inputResetButton_kk2d6s$ = KatydidPhrasingContentBuilder.prototype.inputResetButton_kk2d6s$;
  KatydidObjectPhrasingContentBuilder.prototype.inputSearch_y74p72$ = KatydidPhrasingContentBuilder.prototype.inputSearch_y74p72$;
  KatydidObjectPhrasingContentBuilder.prototype.inputSubmitButton_xi657a$ = KatydidPhrasingContentBuilder.prototype.inputSubmitButton_xi657a$;
  KatydidObjectPhrasingContentBuilder.prototype.inputTelephone_m3bg53$ = KatydidPhrasingContentBuilder.prototype.inputTelephone_m3bg53$;
  KatydidObjectPhrasingContentBuilder.prototype.inputText_y74p72$ = KatydidPhrasingContentBuilder.prototype.inputText_y74p72$;
  KatydidObjectPhrasingContentBuilder.prototype.inputTime_629f1$ = KatydidPhrasingContentBuilder.prototype.inputTime_629f1$;
  KatydidObjectPhrasingContentBuilder.prototype.inputUrl_m3bg53$ = KatydidPhrasingContentBuilder.prototype.inputUrl_m3bg53$;
  KatydidObjectPhrasingContentBuilder.prototype.inputWeek_3kgd4t$ = KatydidPhrasingContentBuilder.prototype.inputWeek_3kgd4t$;
  KatydidObjectPhrasingContentBuilder.prototype.ins_smchxe$ = KatydidPhrasingContentBuilder.prototype.ins_smchxe$;
  KatydidObjectPhrasingContentBuilder.prototype.kbd_qckjfy$ = KatydidPhrasingContentBuilder.prototype.kbd_qckjfy$;
  KatydidObjectPhrasingContentBuilder.prototype.label_va30u7$ = KatydidPhrasingContentBuilder.prototype.label_va30u7$;
  KatydidObjectPhrasingContentBuilder.prototype.map_z0i53j$ = KatydidPhrasingContentBuilder.prototype.map_z0i53j$;
  KatydidObjectPhrasingContentBuilder.prototype.mark_qckjfy$ = KatydidPhrasingContentBuilder.prototype.mark_qckjfy$;
  KatydidObjectPhrasingContentBuilder.prototype.meter_6c4h8d$ = KatydidPhrasingContentBuilder.prototype.meter_6c4h8d$;
  KatydidObjectPhrasingContentBuilder.prototype.meter_ujjlce$ = KatydidPhrasingContentBuilder.prototype.meter_ujjlce$;
  KatydidObjectPhrasingContentBuilder.prototype.object_8mhd8$ = KatydidPhrasingContentBuilder.prototype.object_8mhd8$;
  KatydidObjectPhrasingContentBuilder.prototype.object_ggcu0x$ = KatydidPhrasingContentBuilder.prototype.object_ggcu0x$;
  KatydidObjectPhrasingContentBuilder.prototype.output_7nyrc9$ = KatydidPhrasingContentBuilder.prototype.output_7nyrc9$;
  KatydidObjectPhrasingContentBuilder.prototype.progress_8ydfv4$ = KatydidPhrasingContentBuilder.prototype.progress_8ydfv4$;
  KatydidObjectPhrasingContentBuilder.prototype.progress_qjij5p$ = KatydidPhrasingContentBuilder.prototype.progress_qjij5p$;
  KatydidObjectPhrasingContentBuilder.prototype.q_qckjfy$ = KatydidPhrasingContentBuilder.prototype.q_qckjfy$;
  KatydidObjectPhrasingContentBuilder.prototype.ruby_sy7cla$ = KatydidPhrasingContentBuilder.prototype.ruby_sy7cla$;
  KatydidObjectPhrasingContentBuilder.prototype.s_qckjfy$ = KatydidPhrasingContentBuilder.prototype.s_qckjfy$;
  KatydidObjectPhrasingContentBuilder.prototype.samp_qckjfy$ = KatydidPhrasingContentBuilder.prototype.samp_qckjfy$;
  KatydidObjectPhrasingContentBuilder.prototype.select_7efmz3$ = KatydidPhrasingContentBuilder.prototype.select_7efmz3$;
  KatydidObjectPhrasingContentBuilder.prototype.small_qckjfy$ = KatydidPhrasingContentBuilder.prototype.small_qckjfy$;
  KatydidObjectPhrasingContentBuilder.prototype.span_qckjfy$ = KatydidPhrasingContentBuilder.prototype.span_qckjfy$;
  KatydidObjectPhrasingContentBuilder.prototype.strong_qckjfy$ = KatydidPhrasingContentBuilder.prototype.strong_qckjfy$;
  KatydidObjectPhrasingContentBuilder.prototype.sub_qckjfy$ = KatydidPhrasingContentBuilder.prototype.sub_qckjfy$;
  KatydidObjectPhrasingContentBuilder.prototype.sup_qckjfy$ = KatydidPhrasingContentBuilder.prototype.sup_qckjfy$;
  KatydidObjectPhrasingContentBuilder.prototype.text_4w9ihe$ = KatydidPhrasingContentBuilder.prototype.text_4w9ihe$;
  KatydidObjectPhrasingContentBuilder.prototype.textarea_1j30yg$ = KatydidPhrasingContentBuilder.prototype.textarea_1j30yg$;
  KatydidObjectPhrasingContentBuilder.prototype.time_y9dz51$ = KatydidPhrasingContentBuilder.prototype.time_y9dz51$;
  KatydidObjectPhrasingContentBuilder.prototype.time_jigsdy$ = KatydidPhrasingContentBuilder.prototype.time_jigsdy$;
  KatydidObjectPhrasingContentBuilder.prototype.u_qckjfy$ = KatydidPhrasingContentBuilder.prototype.u_qckjfy$;
  KatydidObjectPhrasingContentBuilder.prototype.var_qckjfy$ = KatydidPhrasingContentBuilder.prototype.var_qckjfy$;
  KatydidObjectPhrasingContentBuilder.prototype.video_l9965i$ = KatydidPhrasingContentBuilder.prototype.video_l9965i$;
  KatydidObjectPhrasingContentBuilder.prototype.video_n6slad$ = KatydidPhrasingContentBuilder.prototype.video_n6slad$;
  KatydidObjectPhrasingContentBuilder.prototype.wbr_9mj9vz$ = KatydidPhrasingContentBuilder.prototype.wbr_9mj9vz$;
  KatydidObjectPhrasingContentBuilder.prototype.embed_nx0pss$ = KatydidPhrasingContentBuilder.prototype.embed_nx0pss$;
  KatydidObjectPhrasingContentBuilder.prototype.iframe_6rhnbj$ = KatydidPhrasingContentBuilder.prototype.iframe_6rhnbj$;
  KatydidObjectPhrasingContentBuilder.prototype.img_fdnnaq$ = KatydidPhrasingContentBuilder.prototype.img_fdnnaq$;
  KatydidObjectPhrasingContentBuilder.prototype.picture_r7gn0k$ = KatydidPhrasingContentBuilder.prototype.picture_r7gn0k$;
  KatydidObjectPhrasingContentBuilderImpl.prototype.param_clmic1$ = KatydidObjectPhrasingContentBuilder.prototype.param_clmic1$;
  KatydidRubyContentBuilder.prototype.unaryPlus_pdl1vz$ = KatydidPhrasingContentBuilder.prototype.unaryPlus_pdl1vz$;
  KatydidRubyContentBuilder.prototype.a_ncyfe7$ = KatydidPhrasingContentBuilder.prototype.a_ncyfe7$;
  KatydidRubyContentBuilder.prototype.abbr_qckjfy$ = KatydidPhrasingContentBuilder.prototype.abbr_qckjfy$;
  KatydidRubyContentBuilder.prototype.area_ys14xf$ = KatydidPhrasingContentBuilder.prototype.area_ys14xf$;
  KatydidRubyContentBuilder.prototype.audio_z5y2od$ = KatydidPhrasingContentBuilder.prototype.audio_z5y2od$;
  KatydidRubyContentBuilder.prototype.audio_if4zjc$ = KatydidPhrasingContentBuilder.prototype.audio_if4zjc$;
  KatydidRubyContentBuilder.prototype.b_qckjfy$ = KatydidPhrasingContentBuilder.prototype.b_qckjfy$;
  KatydidRubyContentBuilder.prototype.bdi_g2kg67$ = KatydidPhrasingContentBuilder.prototype.bdi_g2kg67$;
  KatydidRubyContentBuilder.prototype.bdo_g2kg67$ = KatydidPhrasingContentBuilder.prototype.bdo_g2kg67$;
  KatydidRubyContentBuilder.prototype.br_9mj9vz$ = KatydidPhrasingContentBuilder.prototype.br_9mj9vz$;
  KatydidRubyContentBuilder.prototype.button_2lxa1r$ = KatydidPhrasingContentBuilder.prototype.button_2lxa1r$;
  KatydidRubyContentBuilder.prototype.canvas_zeuq1z$ = KatydidPhrasingContentBuilder.prototype.canvas_zeuq1z$;
  KatydidRubyContentBuilder.prototype.canvas_ablpy6$ = KatydidPhrasingContentBuilder.prototype.canvas_ablpy6$;
  KatydidRubyContentBuilder.prototype.cite_qckjfy$ = KatydidPhrasingContentBuilder.prototype.cite_qckjfy$;
  KatydidRubyContentBuilder.prototype.code_qckjfy$ = KatydidPhrasingContentBuilder.prototype.code_qckjfy$;
  KatydidRubyContentBuilder.prototype.comment_4w9ihe$ = KatydidPhrasingContentBuilder.prototype.comment_4w9ihe$;
  KatydidRubyContentBuilder.prototype.data_cn0i2o$ = KatydidPhrasingContentBuilder.prototype.data_cn0i2o$;
  KatydidRubyContentBuilder.prototype.datalist_csvf3w$ = KatydidPhrasingContentBuilder.prototype.datalist_csvf3w$;
  KatydidRubyContentBuilder.prototype.datalist_zf5udj$ = KatydidPhrasingContentBuilder.prototype.datalist_zf5udj$;
  KatydidRubyContentBuilder.prototype.del_smchxe$ = KatydidPhrasingContentBuilder.prototype.del_smchxe$;
  KatydidRubyContentBuilder.prototype.dfn_qckjfy$ = KatydidPhrasingContentBuilder.prototype.dfn_qckjfy$;
  KatydidRubyContentBuilder.prototype.em_qckjfy$ = KatydidPhrasingContentBuilder.prototype.em_qckjfy$;
  KatydidRubyContentBuilder.prototype.i_qckjfy$ = KatydidPhrasingContentBuilder.prototype.i_qckjfy$;
  KatydidRubyContentBuilder.prototype.inputButton_kk2d6s$ = KatydidPhrasingContentBuilder.prototype.inputButton_kk2d6s$;
  KatydidRubyContentBuilder.prototype.inputCheckbox_5idhkk$ = KatydidPhrasingContentBuilder.prototype.inputCheckbox_5idhkk$;
  KatydidRubyContentBuilder.prototype.inputColor_9zybug$ = KatydidPhrasingContentBuilder.prototype.inputColor_9zybug$;
  KatydidRubyContentBuilder.prototype.inputDate_3kgd4t$ = KatydidPhrasingContentBuilder.prototype.inputDate_3kgd4t$;
  KatydidRubyContentBuilder.prototype.inputDateTimeLocal_3kgd4t$ = KatydidPhrasingContentBuilder.prototype.inputDateTimeLocal_3kgd4t$;
  KatydidRubyContentBuilder.prototype.inputEmail_44r9ep$ = KatydidPhrasingContentBuilder.prototype.inputEmail_44r9ep$;
  KatydidRubyContentBuilder.prototype.inputFile_8v4l2x$ = KatydidPhrasingContentBuilder.prototype.inputFile_8v4l2x$;
  KatydidRubyContentBuilder.prototype.inputHidden_kk2d6s$ = KatydidPhrasingContentBuilder.prototype.inputHidden_kk2d6s$;
  KatydidRubyContentBuilder.prototype.inputImageButton_ojhf04$ = KatydidPhrasingContentBuilder.prototype.inputImageButton_ojhf04$;
  KatydidRubyContentBuilder.prototype.inputMonth_3kgd4t$ = KatydidPhrasingContentBuilder.prototype.inputMonth_3kgd4t$;
  KatydidRubyContentBuilder.prototype.inputNumber_xtj0dk$ = KatydidPhrasingContentBuilder.prototype.inputNumber_xtj0dk$;
  KatydidRubyContentBuilder.prototype.inputNumber_25std2$ = KatydidPhrasingContentBuilder.prototype.inputNumber_25std2$;
  KatydidRubyContentBuilder.prototype.inputPassword_98xs2q$ = KatydidPhrasingContentBuilder.prototype.inputPassword_98xs2q$;
  KatydidRubyContentBuilder.prototype.inputRadioButton_5idhkk$ = KatydidPhrasingContentBuilder.prototype.inputRadioButton_5idhkk$;
  KatydidRubyContentBuilder.prototype.inputRange_er1tee$ = KatydidPhrasingContentBuilder.prototype.inputRange_er1tee$;
  KatydidRubyContentBuilder.prototype.inputResetButton_kk2d6s$ = KatydidPhrasingContentBuilder.prototype.inputResetButton_kk2d6s$;
  KatydidRubyContentBuilder.prototype.inputSearch_y74p72$ = KatydidPhrasingContentBuilder.prototype.inputSearch_y74p72$;
  KatydidRubyContentBuilder.prototype.inputSubmitButton_xi657a$ = KatydidPhrasingContentBuilder.prototype.inputSubmitButton_xi657a$;
  KatydidRubyContentBuilder.prototype.inputTelephone_m3bg53$ = KatydidPhrasingContentBuilder.prototype.inputTelephone_m3bg53$;
  KatydidRubyContentBuilder.prototype.inputText_y74p72$ = KatydidPhrasingContentBuilder.prototype.inputText_y74p72$;
  KatydidRubyContentBuilder.prototype.inputTime_629f1$ = KatydidPhrasingContentBuilder.prototype.inputTime_629f1$;
  KatydidRubyContentBuilder.prototype.inputUrl_m3bg53$ = KatydidPhrasingContentBuilder.prototype.inputUrl_m3bg53$;
  KatydidRubyContentBuilder.prototype.inputWeek_3kgd4t$ = KatydidPhrasingContentBuilder.prototype.inputWeek_3kgd4t$;
  KatydidRubyContentBuilder.prototype.ins_smchxe$ = KatydidPhrasingContentBuilder.prototype.ins_smchxe$;
  KatydidRubyContentBuilder.prototype.kbd_qckjfy$ = KatydidPhrasingContentBuilder.prototype.kbd_qckjfy$;
  KatydidRubyContentBuilder.prototype.label_va30u7$ = KatydidPhrasingContentBuilder.prototype.label_va30u7$;
  KatydidRubyContentBuilder.prototype.map_z0i53j$ = KatydidPhrasingContentBuilder.prototype.map_z0i53j$;
  KatydidRubyContentBuilder.prototype.mark_qckjfy$ = KatydidPhrasingContentBuilder.prototype.mark_qckjfy$;
  KatydidRubyContentBuilder.prototype.meter_6c4h8d$ = KatydidPhrasingContentBuilder.prototype.meter_6c4h8d$;
  KatydidRubyContentBuilder.prototype.meter_ujjlce$ = KatydidPhrasingContentBuilder.prototype.meter_ujjlce$;
  KatydidRubyContentBuilder.prototype.object_8mhd8$ = KatydidPhrasingContentBuilder.prototype.object_8mhd8$;
  KatydidRubyContentBuilder.prototype.object_ggcu0x$ = KatydidPhrasingContentBuilder.prototype.object_ggcu0x$;
  KatydidRubyContentBuilder.prototype.output_7nyrc9$ = KatydidPhrasingContentBuilder.prototype.output_7nyrc9$;
  KatydidRubyContentBuilder.prototype.progress_8ydfv4$ = KatydidPhrasingContentBuilder.prototype.progress_8ydfv4$;
  KatydidRubyContentBuilder.prototype.progress_qjij5p$ = KatydidPhrasingContentBuilder.prototype.progress_qjij5p$;
  KatydidRubyContentBuilder.prototype.q_qckjfy$ = KatydidPhrasingContentBuilder.prototype.q_qckjfy$;
  KatydidRubyContentBuilder.prototype.ruby_sy7cla$ = KatydidPhrasingContentBuilder.prototype.ruby_sy7cla$;
  KatydidRubyContentBuilder.prototype.s_qckjfy$ = KatydidPhrasingContentBuilder.prototype.s_qckjfy$;
  KatydidRubyContentBuilder.prototype.samp_qckjfy$ = KatydidPhrasingContentBuilder.prototype.samp_qckjfy$;
  KatydidRubyContentBuilder.prototype.select_7efmz3$ = KatydidPhrasingContentBuilder.prototype.select_7efmz3$;
  KatydidRubyContentBuilder.prototype.small_qckjfy$ = KatydidPhrasingContentBuilder.prototype.small_qckjfy$;
  KatydidRubyContentBuilder.prototype.span_qckjfy$ = KatydidPhrasingContentBuilder.prototype.span_qckjfy$;
  KatydidRubyContentBuilder.prototype.strong_qckjfy$ = KatydidPhrasingContentBuilder.prototype.strong_qckjfy$;
  KatydidRubyContentBuilder.prototype.sub_qckjfy$ = KatydidPhrasingContentBuilder.prototype.sub_qckjfy$;
  KatydidRubyContentBuilder.prototype.sup_qckjfy$ = KatydidPhrasingContentBuilder.prototype.sup_qckjfy$;
  KatydidRubyContentBuilder.prototype.text_4w9ihe$ = KatydidPhrasingContentBuilder.prototype.text_4w9ihe$;
  KatydidRubyContentBuilder.prototype.textarea_1j30yg$ = KatydidPhrasingContentBuilder.prototype.textarea_1j30yg$;
  KatydidRubyContentBuilder.prototype.time_y9dz51$ = KatydidPhrasingContentBuilder.prototype.time_y9dz51$;
  KatydidRubyContentBuilder.prototype.time_jigsdy$ = KatydidPhrasingContentBuilder.prototype.time_jigsdy$;
  KatydidRubyContentBuilder.prototype.u_qckjfy$ = KatydidPhrasingContentBuilder.prototype.u_qckjfy$;
  KatydidRubyContentBuilder.prototype.var_qckjfy$ = KatydidPhrasingContentBuilder.prototype.var_qckjfy$;
  KatydidRubyContentBuilder.prototype.video_l9965i$ = KatydidPhrasingContentBuilder.prototype.video_l9965i$;
  KatydidRubyContentBuilder.prototype.video_n6slad$ = KatydidPhrasingContentBuilder.prototype.video_n6slad$;
  KatydidRubyContentBuilder.prototype.wbr_9mj9vz$ = KatydidPhrasingContentBuilder.prototype.wbr_9mj9vz$;
  KatydidRubyContentBuilder.prototype.embed_nx0pss$ = KatydidPhrasingContentBuilder.prototype.embed_nx0pss$;
  KatydidRubyContentBuilder.prototype.iframe_6rhnbj$ = KatydidPhrasingContentBuilder.prototype.iframe_6rhnbj$;
  KatydidRubyContentBuilder.prototype.img_fdnnaq$ = KatydidPhrasingContentBuilder.prototype.img_fdnnaq$;
  KatydidRubyContentBuilder.prototype.picture_r7gn0k$ = KatydidPhrasingContentBuilder.prototype.picture_r7gn0k$;
  KatydidRubyContentBuilderImpl.prototype.rb_qckjfy$ = KatydidRubyContentBuilder.prototype.rb_qckjfy$;
  KatydidRubyContentBuilderImpl.prototype.rp_qckjfy$ = KatydidRubyContentBuilder.prototype.rp_qckjfy$;
  KatydidRubyContentBuilderImpl.prototype.rt_qckjfy$ = KatydidRubyContentBuilder.prototype.rt_qckjfy$;
  KatydidRubyContentBuilderImpl.prototype.rtc_sy7cla$ = KatydidRubyContentBuilder.prototype.rtc_sy7cla$;
  KatydidColGroupContentBuilderImpl.prototype.col_xkd41s$ = KatydidColGroupContentBuilder.prototype.col_xkd41s$;
  KatydidTableBodyContentBuilderImpl.prototype.comment_4w9ihe$ = KatydidTableBodyContentBuilder.prototype.comment_4w9ihe$;
  KatydidTableBodyContentBuilderImpl.prototype.tr_n8e5b5$ = KatydidTableBodyContentBuilder.prototype.tr_n8e5b5$;
  KatydidTableContentBuilderImpl.prototype.caption_6zr3om$ = KatydidTableContentBuilder.prototype.caption_6zr3om$;
  KatydidTableContentBuilderImpl.prototype.colgroup_xkd41s$ = KatydidTableContentBuilder.prototype.colgroup_xkd41s$;
  KatydidTableContentBuilderImpl.prototype.colgroup_lo2ydu$ = KatydidTableContentBuilder.prototype.colgroup_lo2ydu$;
  KatydidTableContentBuilderImpl.prototype.comment_4w9ihe$ = KatydidTableContentBuilder.prototype.comment_4w9ihe$;
  KatydidTableContentBuilderImpl.prototype.tbody_w9wujb$ = KatydidTableContentBuilder.prototype.tbody_w9wujb$;
  KatydidTableContentBuilderImpl.prototype.tfoot_w9wujb$ = KatydidTableContentBuilder.prototype.tfoot_w9wujb$;
  KatydidTableContentBuilderImpl.prototype.thead_w9wujb$ = KatydidTableContentBuilder.prototype.thead_w9wujb$;
  KatydidTableContentBuilderImpl.prototype.tr_n8e5b5$ = KatydidTableContentBuilder.prototype.tr_n8e5b5$;
  KatydidTableRowContentBuilderImpl.prototype.comment_4w9ihe$ = KatydidTableRowContentBuilder.prototype.comment_4w9ihe$;
  KatydidTableRowContentBuilderImpl.prototype.td_iemoux$ = KatydidTableRowContentBuilder.prototype.td_iemoux$;
  KatydidTableRowContentBuilderImpl.prototype.th_f4d2jq$ = KatydidTableRowContentBuilder.prototype.th_f4d2jq$;
  Kotlin.defineModule('Katydid-VDOM-JS', _);
  return _;
}(typeof this['Katydid-VDOM-JS'] === 'undefined' ? {} : this['Katydid-VDOM-JS'], kotlin);

//# sourceMappingURL=Katydid-VDOM-JS.js.map
