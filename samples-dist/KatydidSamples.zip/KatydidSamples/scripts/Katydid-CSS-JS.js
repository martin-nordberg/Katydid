if (typeof kotlin === 'undefined') {
  throw new Error("Error loading module 'Katydid-CSS-JS'. Its dependency 'kotlin' was not found. Please, check whether 'kotlin' is loaded prior to 'Katydid-CSS-JS'.");
}
this['Katydid-CSS-JS'] = function (_, Kotlin) {
  'use strict';
  var abs = Kotlin.kotlin.math.abs_za3lpa$;
  var numberToInt = Kotlin.numberToInt;
  var Kind_CLASS = Kotlin.Kind.CLASS;
  var Math_0 = Math;
  var equals = Kotlin.equals;
  var drop = Kotlin.kotlin.text.drop_6ic1pp$;
  var toBoxedChar = Kotlin.toBoxedChar;
  var IllegalArgumentException_init = Kotlin.kotlin.IllegalArgumentException_init_pdl1vj$;
  var arrayListOf = Kotlin.kotlin.collections.arrayListOf_i5x0yv$;
  var HashMap_init = Kotlin.kotlin.collections.HashMap_init_q3lmfv$;
  var Kind_OBJECT = Kotlin.Kind.OBJECT;
  var NotImplementedError_init = Kotlin.kotlin.NotImplementedError;
  var LinkedHashMap_init = Kotlin.kotlin.collections.LinkedHashMap_init_q3lmfv$;
  var endsWith = Kotlin.kotlin.text.endsWith_7epoxm$;
  var replace = Kotlin.kotlin.text.replace_680rmw$;
  var joinToString = Kotlin.kotlin.collections.joinToString_fmv235$;
  var ArrayList_init = Kotlin.kotlin.collections.ArrayList_init_287e2$;
  var collectionSizeOrDefault = Kotlin.kotlin.collections.collectionSizeOrDefault_ba2ldo$;
  var ArrayList_init_0 = Kotlin.kotlin.collections.ArrayList_init_ww73n8$;
  var startsWith = Kotlin.kotlin.text.startsWith_7epoxm$;
  var contains = Kotlin.kotlin.text.contains_li3zpu$;
  var throwCCE = Kotlin.throwCCE;
  var split = Kotlin.kotlin.text.split_ip8yn$;
  var reversed = Kotlin.kotlin.collections.reversed_7wnvza$;
  var StringBuilder = Kotlin.kotlin.text.StringBuilder;
  var append = Kotlin.kotlin.text.append_4v9nlb$;
  var trim = Kotlin.kotlin.text.trim_gw00vp$;
  var emptyList = Kotlin.kotlin.collections.emptyList_287e2$;
  var Regex_init = Kotlin.kotlin.text.Regex_init_61zpoe$;
  var UnsupportedOperationException_init = Kotlin.kotlin.UnsupportedOperationException_init_pdl1vj$;
  var Kind_INTERFACE = Kotlin.Kind.INTERFACE;
  var hashCode = Kotlin.hashCode;
  var takeLast = Kotlin.kotlin.text.takeLast_6ic1pp$;
  var dropLast = Kotlin.kotlin.text.dropLast_6ic1pp$;
  var numberToDouble = Kotlin.numberToDouble;
  var toDouble = Kotlin.kotlin.text.toDouble_pdl1vz$;
  var Enum = Kotlin.kotlin.Enum;
  var throwISE = Kotlin.throwISE;
  var joinToString_0 = Kotlin.kotlin.collections.joinToString_cgipc5$;
  var toString = Kotlin.toString;
  var Annotation = Kotlin.kotlin.Annotation;
  var trimEnd = Kotlin.kotlin.text.trimEnd_wqw3xr$;
  KatydidAbstractStyleRuleImpl.prototype = Object.create(KatydidCompositeCssRuleImpl.prototype);
  KatydidAbstractStyleRuleImpl.prototype.constructor = KatydidAbstractStyleRuleImpl;
  KatydidMediaAtRuleImpl.prototype = Object.create(KatydidCompositeCssRuleImpl.prototype);
  KatydidMediaAtRuleImpl.prototype.constructor = KatydidMediaAtRuleImpl;
  KatydidPlaceholderRuleImpl.prototype = Object.create(KatydidAbstractStyleRuleImpl.prototype);
  KatydidPlaceholderRuleImpl.prototype.constructor = KatydidPlaceholderRuleImpl;
  KatydidStyleRuleImpl.prototype = Object.create(KatydidAbstractStyleRuleImpl.prototype);
  KatydidStyleRuleImpl.prototype.constructor = KatydidStyleRuleImpl;
  KatydidStyleSheetImpl.prototype = Object.create(KatydidCompositeCssRuleImpl.prototype);
  KatydidStyleSheetImpl.prototype.constructor = KatydidStyleSheetImpl;
  LengthUnit.prototype = Object.create(Enum.prototype);
  LengthUnit.prototype.constructor = LengthUnit;
  EAlignmentBaseline.prototype = Object.create(Enum.prototype);
  EAlignmentBaseline.prototype.constructor = EAlignmentBaseline;
  EAttachment.prototype = Object.create(Enum.prototype);
  EAttachment.prototype.constructor = EAttachment;
  EAuto.prototype = Object.create(Enum.prototype);
  EAuto.prototype.constructor = EAuto;
  EBackgroundPosition.prototype = Object.create(Enum.prototype);
  EBackgroundPosition.prototype.constructor = EBackgroundPosition;
  EBaselineShift.prototype = Object.create(Enum.prototype);
  EBaselineShift.prototype.constructor = EBaselineShift;
  EBorderCollapse.prototype = Object.create(Enum.prototype);
  EBorderCollapse.prototype.constructor = EBorderCollapse;
  EBoxSize$minContent.prototype = Object.create(EBoxSize.prototype);
  EBoxSize$minContent.prototype.constructor = EBoxSize$minContent;
  EBoxSize$maxContent.prototype = Object.create(EBoxSize.prototype);
  EBoxSize$maxContent.prototype.constructor = EBoxSize$maxContent;
  EBoxSize$fitContent.prototype = Object.create(EBoxSize.prototype);
  EBoxSize$fitContent.prototype.constructor = EBoxSize$fitContent;
  EBoxSizing.prototype = Object.create(Enum.prototype);
  EBoxSizing.prototype.constructor = EBoxSizing;
  ECaptionSide.prototype = Object.create(Enum.prototype);
  ECaptionSide.prototype.constructor = ECaptionSide;
  EClear.prototype = Object.create(Enum.prototype);
  EClear.prototype.constructor = EClear;
  EContent$none.prototype = Object.create(EContent.prototype);
  EContent$none.prototype.constructor = EContent$none;
  EContent$normal.prototype = Object.create(EContent.prototype);
  EContent$normal.prototype.constructor = EContent$normal;
  EContent$openQuote.prototype = Object.create(EContent.prototype);
  EContent$openQuote.prototype.constructor = EContent$openQuote;
  EContent$closeQuote.prototype = Object.create(EContent.prototype);
  EContent$closeQuote.prototype.constructor = EContent$closeQuote;
  EContent$noOpenQuote.prototype = Object.create(EContent.prototype);
  EContent$noOpenQuote.prototype.constructor = EContent$noOpenQuote;
  EContent$noCloseQuote.prototype = Object.create(EContent.prototype);
  EContent$noCloseQuote.prototype.constructor = EContent$noCloseQuote;
  EContent$attr.prototype = Object.create(EContent.prototype);
  EContent$attr.prototype.constructor = EContent$attr;
  EContent$url.prototype = Object.create(EContent.prototype);
  EContent$url.prototype.constructor = EContent$url;
  ECursor.prototype = Object.create(Enum.prototype);
  ECursor.prototype.constructor = ECursor;
  EDisplay.prototype = Object.create(Enum.prototype);
  EDisplay.prototype.constructor = EDisplay;
  EEmptyCells.prototype = Object.create(Enum.prototype);
  EEmptyCells.prototype.constructor = EEmptyCells;
  EFloat.prototype = Object.create(Enum.prototype);
  EFloat.prototype.constructor = EFloat;
  EFontSize.prototype = Object.create(Enum.prototype);
  EFontSize.prototype.constructor = EFontSize;
  EFontStyle.prototype = Object.create(Enum.prototype);
  EFontStyle.prototype.constructor = EFontStyle;
  EFontVariant.prototype = Object.create(Enum.prototype);
  EFontVariant.prototype.constructor = EFontVariant;
  EFontWeight.prototype = Object.create(Enum.prototype);
  EFontWeight.prototype.constructor = EFontWeight;
  EImage$none.prototype = Object.create(EImage.prototype);
  EImage$none.prototype.constructor = EImage$none;
  EImage$url.prototype = Object.create(EImage.prototype);
  EImage$url.prototype.constructor = EImage$url;
  EImage$image.prototype = Object.create(EImage.prototype);
  EImage$image.prototype.constructor = EImage$image;
  ELineStyle.prototype = Object.create(Enum.prototype);
  ELineStyle.prototype.constructor = ELineStyle;
  ELineWidth.prototype = Object.create(Enum.prototype);
  ELineWidth.prototype.constructor = ELineWidth;
  EListStylePosition.prototype = Object.create(Enum.prototype);
  EListStylePosition.prototype.constructor = EListStylePosition;
  EListStyleType.prototype = Object.create(Enum.prototype);
  EListStyleType.prototype.constructor = EListStyleType;
  ENone.prototype = Object.create(Enum.prototype);
  ENone.prototype.constructor = ENone;
  ENormal.prototype = Object.create(Enum.prototype);
  ENormal.prototype.constructor = ENormal;
  EOutlineColor.prototype = Object.create(Enum.prototype);
  EOutlineColor.prototype.constructor = EOutlineColor;
  EOverflow.prototype = Object.create(Enum.prototype);
  EOverflow.prototype.constructor = EOverflow;
  EOverflowWrap.prototype = Object.create(Enum.prototype);
  EOverflowWrap.prototype.constructor = EOverflowWrap;
  EPageBreak.prototype = Object.create(Enum.prototype);
  EPageBreak.prototype.constructor = EPageBreak;
  EPageBreakInside.prototype = Object.create(Enum.prototype);
  EPageBreakInside.prototype.constructor = EPageBreakInside;
  EPosition.prototype = Object.create(Enum.prototype);
  EPosition.prototype.constructor = EPosition;
  ERepeatStyle.prototype = Object.create(Enum.prototype);
  ERepeatStyle.prototype.constructor = ERepeatStyle;
  EResize.prototype = Object.create(Enum.prototype);
  EResize.prototype.constructor = EResize;
  ETableLayout.prototype = Object.create(Enum.prototype);
  ETableLayout.prototype.constructor = ETableLayout;
  ETextAlign.prototype = Object.create(Enum.prototype);
  ETextAlign.prototype.constructor = ETextAlign;
  ETextDecorationLine.prototype = Object.create(Enum.prototype);
  ETextDecorationLine.prototype.constructor = ETextDecorationLine;
  ETextDecorationStyle.prototype = Object.create(Enum.prototype);
  ETextDecorationStyle.prototype.constructor = ETextDecorationStyle;
  ETextJustify.prototype = Object.create(Enum.prototype);
  ETextJustify.prototype.constructor = ETextJustify;
  ETextOverflow.prototype = Object.create(Enum.prototype);
  ETextOverflow.prototype.constructor = ETextOverflow;
  ETextTransform.prototype = Object.create(Enum.prototype);
  ETextTransform.prototype.constructor = ETextTransform;
  EUnicodeBidi.prototype = Object.create(Enum.prototype);
  EUnicodeBidi.prototype.constructor = EUnicodeBidi;
  EVisibility.prototype = Object.create(Enum.prototype);
  EVisibility.prototype.constructor = EVisibility;
  EWhiteSpace.prototype = Object.create(Enum.prototype);
  EWhiteSpace.prototype.constructor = EWhiteSpace;
  function HslColor(itsHue, itsSaturation, itsLightness, itsAlpha) {
    this.myHue_0 = (itsHue % 360 + 360 | 0) % 360;
    this.mySaturation_0 = itsSaturation < 0 ? 0.0 : itsSaturation > 1 ? 1.0 : itsSaturation;
    this.myLightness_0 = itsLightness < 0 ? 0.0 : itsLightness > 1 ? 1.0 : itsLightness;
    this.myAlpha_0 = itsAlpha < 0 ? 0.0 : itsAlpha > 1 ? 1.0 : itsAlpha;
    this.myRgbColor_0 = null;
    var tmp$;
    var x = 2 * this.myLightness_0 - 1;
    var c = (1 - Math_0.abs(x)) * this.mySaturation_0;
    var x_0 = c * (1 - abs((this.myHue_0 / 60 | 0) % 2 - 1 | 0) | 0);
    var m = this.myLightness_0 - c / 2;
    var ic = numberToInt((c + m) * 255 + 0.49);
    var ix = numberToInt((x_0 + m) * 255 + 0.49);
    var iz = numberToInt(m * 255 + 0.49);
    if (this.myHue_0 < 60) {
      tmp$ = RgbColor_init(ic, ix, iz, this.myAlpha_0);
    }
     else if (this.myHue_0 < 120) {
      tmp$ = RgbColor_init(ix, ic, iz, this.myAlpha_0);
    }
     else if (this.myHue_0 < 180) {
      tmp$ = RgbColor_init(iz, ic, ix, this.myAlpha_0);
    }
     else if (this.myHue_0 < 240) {
      tmp$ = RgbColor_init(iz, ix, ic, this.myAlpha_0);
    }
     else if (this.myHue_0 < 300) {
      tmp$ = RgbColor_init(ix, iz, ic, this.myAlpha_0);
    }
     else {
      tmp$ = RgbColor_init(ic, iz, ix, this.myAlpha_0);
    }
    this.myRgbColor_0 = tmp$;
  }
  HslColor.prototype.equals = function (other) {
    if (Kotlin.isType(other, HslColor)) {
      return this.myAlpha_0 === other.myAlpha_0 && this.myHue_0 === other.myHue_0 && this.mySaturation_0 === other.mySaturation_0 && this.myLightness_0 === other.myLightness_0;
    }
    if (Kotlin.isType(other, RgbColor)) {
      return this.myRgbColor_0.equals(other);
    }
    return false;
  };
  HslColor.prototype.hashCode = function () {
    return this.myRgbColor_0.hashCode();
  };
  HslColor.prototype.opacified_mx4ult$ = function (alphaIncrement) {
    return new HslColor(this.myHue_0, this.mySaturation_0, this.myLightness_0, this.myAlpha_0 + alphaIncrement);
  };
  HslColor.prototype.toString = function () {
    var saturationStr = makeDecimalString(this.mySaturation_0);
    var lightnessStr = makeDecimalString(this.myLightness_0);
    var alphaStr = makeDecimalString(this.myAlpha_0);
    if (this.myAlpha_0 < 1) {
      return 'hsla(' + this.myHue_0 + ',' + saturationStr + ',' + lightnessStr + ',' + alphaStr + ')';
    }
    return 'hsl(' + this.myHue_0 + ',' + saturationStr + ',' + lightnessStr + ')';
  };
  HslColor.prototype.toHslColor = function () {
    return this;
  };
  HslColor.prototype.toRgbColor = function () {
    return this.myRgbColor_0;
  };
  HslColor.prototype.transparentized_mx4ult$ = function (alphaDecrement) {
    return new HslColor(this.myHue_0, this.mySaturation_0, this.myLightness_0, this.myAlpha_0 - alphaDecrement);
  };
  HslColor.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'HslColor',
    interfaces: [Color]
  };
  function RgbColor(itsRedByte, itsGreenByte, itsBlueByte, itsAlpha, itsColorName) {
    RgbColor$Companion_getInstance();
    if (itsColorName === void 0)
      itsColorName = null;
    this.myRedByte_0 = itsRedByte < 0 ? 0 : itsRedByte > 255 ? 255 : itsRedByte;
    this.myGreenByte_0 = itsGreenByte < 0 ? 0 : itsGreenByte > 255 ? 255 : itsGreenByte;
    this.myBlueByte_0 = itsBlueByte < 0 ? 0 : itsBlueByte > 255 ? 255 : itsBlueByte;
    this.myAlpha_0 = itsAlpha < 0 ? 0.0 : itsAlpha > 1 ? 1.0 : itsAlpha;
    this.myColorName_0 = itsColorName;
    if (this.myColorName_0 != null && !RgbColor$Companion_getInstance().namedColorsByHashCode_0.containsKey_11rb$(this.hashCode())) {
      RgbColor$Companion_getInstance().namedColorsByHashCode_0.put_xwzc9p$(this.hashCode(), this);
    }
  }
  RgbColor.prototype.equals = function (other) {
    if (Kotlin.isType(other, RgbColor)) {
      return this.myAlpha_0 === other.myAlpha_0 && this.myRedByte_0 === other.myRedByte_0 && this.myGreenByte_0 === other.myGreenByte_0 && this.myBlueByte_0 === other.myBlueByte_0;
    }
    if (Kotlin.isType(other, HslColor)) {
      return equals(this.toHslColor(), other);
    }
    return false;
  };
  RgbColor.prototype.hashCode = function () {
    return (this.myRedByte_0 << 24) + (this.myGreenByte_0 << 16) + (this.myBlueByte_0 << 8) + numberToInt(this.myAlpha_0 * 255) | 0;
  };
  RgbColor.prototype.opacified_mx4ult$ = function (alphaIncrement) {
    return RgbColor_init(this.myRedByte_0, this.myGreenByte_0, this.myBlueByte_0, this.myAlpha_0 + alphaIncrement);
  };
  RgbColor.prototype.toString = function () {
    if (this.myColorName_0 != null) {
      return this.myColorName_0;
    }
    if (this.myAlpha_0 < 1.0) {
      var alphaStr = makeDecimalString(this.myAlpha_0);
      return 'rgba(' + this.myRedByte_0 + ',' + this.myGreenByte_0 + ',' + this.myBlueByte_0 + ',' + alphaStr + ')';
    }
    return '#' + RgbColor$Companion_getInstance().HEX_STRINGS_0.get_za3lpa$(this.myRedByte_0) + RgbColor$Companion_getInstance().HEX_STRINGS_0.get_za3lpa$(this.myGreenByte_0) + RgbColor$Companion_getInstance().HEX_STRINGS_0.get_za3lpa$(this.myBlueByte_0);
  };
  RgbColor.prototype.toHslColor = function () {
    throw new NotImplementedError_init('An operation is not implemented: ' + 'not yet implemented');
  };
  RgbColor.prototype.toRgbColor = function () {
    return this;
  };
  RgbColor.prototype.transparentized_mx4ult$ = function (alphaDecrement) {
    return RgbColor_init(this.myRedByte_0, this.myGreenByte_0, this.myBlueByte_0, this.myAlpha_0 - alphaDecrement);
  };
  function RgbColor$Companion() {
    RgbColor$Companion_instance = this;
    this.HEX_STRINGS_0 = arrayListOf(['00', '01', '02', '03', '04', '05', '06', '07', '08', '09', '0A', '0B', '0C', '0D', '0E', '0F', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '1A', '1B', '1C', '1D', '1E', '1F', '20', '21', '22', '23', '24', '25', '26', '27', '28', '29', '2A', '2B', '2C', '2D', '2E', '2F', '30', '31', '32', '33', '34', '35', '36', '37', '38', '39', '3A', '3B', '3C', '3D', '3E', '3F', '40', '41', '42', '43', '44', '45', '46', '47', '48', '49', '4A', '4B', '4C', '4D', '4E', '4F', '50', '51', '52', '53', '54', '55', '56', '57', '58', '59', '5A', '5B', '5C', '5D', '5E', '5F', '60', '61', '62', '63', '64', '65', '66', '67', '68', '69', '6A', '6B', '6C', '6D', '6E', '6F', '70', '71', '72', '73', '74', '75', '76', '77', '78', '79', '7A', '7B', '7C', '7D', '7E', '7F', '80', '81', '82', '83', '84', '85', '86', '87', '88', '89', '8A', '8B', '8C', '8D', '8E', '8F', '90', '91', '92', '93', '94', '95', '96', '97', '98', '99', '9A', '9B', '9C', '9D', '9E', '9F', 'A0', 'A1', 'A2', 'A3', 'A4', 'A5', 'A6', 'A7', 'A8', 'A9', 'AA', 'AB', 'AC', 'AD', 'AE', 'AF', 'B0', 'B1', 'B2', 'B3', 'B4', 'B5', 'B6', 'B7', 'B8', 'B9', 'BA', 'BB', 'BC', 'BD', 'BE', 'BF', 'C0', 'C1', 'C2', 'C3', 'C4', 'C5', 'C6', 'C7', 'C8', 'C9', 'CA', 'CB', 'CC', 'CD', 'CE', 'CF', 'D0', 'D1', 'D2', 'D3', 'D4', 'D5', 'D6', 'D7', 'D8', 'D9', 'DA', 'DB', 'DC', 'DD', 'DE', 'DF', 'E0', 'E1', 'E2', 'E3', 'E4', 'E5', 'E6', 'E7', 'E8', 'E9', 'EA', 'EB', 'EC', 'ED', 'EE', 'EF', 'F0', 'F1', 'F2', 'F3', 'F4', 'F5', 'F6', 'F7', 'F8', 'F9', 'FA', 'FB', 'FC', 'FD', 'FE', 'FF']);
    this.INV_HEX_STRINGS_0 = null;
    this.namedColorsByHashCode_0 = HashMap_init();
    var inv = LinkedHashMap_init();
    for (var index = 0; index <= 255; index++) {
      var key = this.HEX_STRINGS_0.get_za3lpa$(index);
      inv.put_xwzc9p$(key, index);
    }
    this.INV_HEX_STRINGS_0 = inv;
  }
  RgbColor$Companion.prototype.fromHex_61zpoe$ = function (_s) {
    var tmp$;
    var s = (_s.charCodeAt(0) === 35 ? drop(_s, 1) : _s).toUpperCase();
    switch (s.length) {
      case 1:
        var b = this.parseShortHandByte_0(s.charCodeAt(0));
        tmp$ = rgba(0, 0, b, 1.0);
        break;
      case 2:
        var g = this.parseShortHandByte_0(s.charCodeAt(0));
        var b_0 = this.parseShortHandByte_0(s.charCodeAt(1));
        tmp$ = rgba(0, g, b_0, 1.0);
        break;
      case 3:
        var r = this.parseShortHandByte_0(s.charCodeAt(0));
        var g_0 = this.parseShortHandByte_0(s.charCodeAt(1));
        var b_1 = this.parseShortHandByte_0(s.charCodeAt(2));
        tmp$ = rgba(r, g_0, b_1, 1.0);
        break;
      case 4:
        var r_0 = this.parseShortHandByte_0(s.charCodeAt(0));
        var g_1 = this.parseShortHandByte_0(s.charCodeAt(1));
        var b_2 = this.parseShortHandByte_0(s.charCodeAt(2));
        var a = this.parseShortHandByte_0(s.charCodeAt(3));
        tmp$ = rgba(r_0, g_1, b_2, (a + 0.49) / 255.0);
        break;
      case 5:
        var r_1 = this.parseByte_0('0' + String.fromCharCode(toBoxedChar(s.charCodeAt(0))));
        var g_2 = this.parseByte_0(s.substring(1, 3));
        var b_3 = this.parseByte_0(s.substring(3, 5));
        tmp$ = rgba(r_1, g_2, b_3, 1.0);
        break;
      case 6:
        var r_2 = this.parseByte_0(s.substring(0, 2));
        var g_3 = this.parseByte_0(s.substring(2, 4));
        var b_4 = this.parseByte_0(s.substring(4, 6));
        tmp$ = rgba(r_2, g_3, b_4, 1.0);
        break;
      case 7:
        var r_3 = this.parseByte_0('0' + String.fromCharCode(toBoxedChar(s.charCodeAt(0))));
        var g_4 = this.parseByte_0(s.substring(1, 3));
        var b_5 = this.parseByte_0(s.substring(3, 5));
        var a_0 = this.parseByte_0(s.substring(5, 7));
        tmp$ = rgba(r_3, g_4, b_5, (a_0 + 0.49) / 255);
        break;
      case 8:
        var r_4 = this.parseByte_0(s.substring(0, 2));
        var g_5 = this.parseByte_0(s.substring(2, 4));
        var b_6 = this.parseByte_0(s.substring(4, 6));
        var a_1 = this.parseByte_0(s.substring(6, 8));
        tmp$ = rgba(r_4, g_5, b_6, (a_1 + 0.49) / 255);
        break;
      default:tmp$ = null;
        break;
    }
    return tmp$;
  };
  RgbColor$Companion.prototype.getNamedColorByHashCode_za3lpa$ = function (hashCode) {
    return this.namedColorsByHashCode_0.get_11rb$(hashCode);
  };
  RgbColor$Companion.prototype.parseByte_0 = function (byteStr) {
    var tmp$;
    tmp$ = this.INV_HEX_STRINGS_0.get_11rb$(byteStr);
    if (tmp$ == null) {
      throw IllegalArgumentException_init("Invalid hex byte: '" + byteStr + "'.");
    }
    return tmp$;
  };
  RgbColor$Companion.prototype.parseShortHandByte_0 = function (byteChar) {
    switch (byteChar) {
      case 48:
        return 0;
      case 49:
        return 17;
      case 50:
        return 34;
      case 51:
        return 51;
      case 52:
        return 68;
      case 53:
        return 85;
      case 54:
        return 102;
      case 55:
        return 119;
      case 56:
        return 136;
      case 57:
        return 153;
      case 65:
        return 170;
      case 66:
        return 187;
      case 67:
        return 204;
      case 68:
        return 221;
      case 69:
        return 238;
      case 70:
        return 255;
      default:throw IllegalArgumentException_init("Invalid hex byte shorthand: '" + String.fromCharCode(byteChar) + "'.");
    }
  };
  RgbColor$Companion.$metadata$ = {
    kind: Kind_OBJECT,
    simpleName: 'Companion',
    interfaces: []
  };
  var RgbColor$Companion_instance = null;
  function RgbColor$Companion_getInstance() {
    if (RgbColor$Companion_instance === null) {
      new RgbColor$Companion();
    }
    return RgbColor$Companion_instance;
  }
  RgbColor.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'RgbColor',
    interfaces: [Color]
  };
  function RgbColor_init(itsRed, itsGreen, itsBlue, itsAlpha, $this) {
    $this = $this || Object.create(RgbColor.prototype);
    RgbColor.call($this, itsRed, itsGreen, itsBlue, itsAlpha, null);
    return $this;
  }
  function RgbColor_init_0(itsRedFraction, itsGreenFraction, itsBlueFraction, itsAlpha, $this) {
    if (itsAlpha === void 0)
      itsAlpha = 1.0;
    $this = $this || Object.create(RgbColor.prototype);
    RgbColor.call($this, numberToInt(itsRedFraction * 255 + 0.49), numberToInt(itsGreenFraction * 255 + 0.49), numberToInt(itsBlueFraction * 255 + 0.49), itsAlpha, null);
    return $this;
  }
  function KatydidStyleImpl() {
    this.myProperties_0 = ArrayList_init();
    this.properties_p41ieg$_0 = this.myProperties_0;
  }
  Object.defineProperty(KatydidStyleImpl.prototype, 'important', {
    get: function () {
      if (!(this.properties.size > 0)) {
        var message = 'Set a property before making it important.';
        throw IllegalArgumentException_init(message.toString());
      }
      if (!!endsWith(this.properties.get_za3lpa$(this.properties.size - 1 | 0), '!important')) {
        var message_0 = 'Last property already set to important.';
        throw IllegalArgumentException_init(message_0.toString());
      }
      this.myProperties_0.set_wxm5ur$(this.myProperties_0.size - 1 | 0, this.myProperties_0.get_za3lpa$(this.myProperties_0.size - 1 | 0) + ' !important');
    }
  });
  Object.defineProperty(KatydidStyleImpl.prototype, 'isNotEmpty', {
    get: function () {
      return !this.properties.isEmpty();
    }
  });
  Object.defineProperty(KatydidStyleImpl.prototype, 'properties', {
    get: function () {
      return this.properties_p41ieg$_0;
    }
  });
  KatydidStyleImpl.prototype.include_2f4f17$ = function (style) {
    var tmp$;
    tmp$ = style.properties.iterator();
    while (tmp$.hasNext()) {
      var property = tmp$.next();
      this.myProperties_0.add_11rb$(property);
    }
  };
  KatydidStyleImpl.prototype.inherit_61zpoe$ = function (key) {
    this.setProperty_puj7f4$(key, 'inherit');
  };
  KatydidStyleImpl.prototype.setBoxProperty_hto8b4$$default = function (key, top, right, bottom, left) {
    var css = top.toString();
    if (!equals(right, top) || !equals(bottom, top) || !equals(left, right)) {
      css += ' ' + right;
    }
    if (!equals(bottom, top) || !equals(left, right)) {
      css += ' ' + bottom;
    }
    if (!equals(left, right)) {
      css += ' ' + left;
    }
    this.setProperty_puj7f4$(key, css);
  };
  KatydidStyleImpl.prototype.setProperty_puj7f4$ = function (key, value) {
    this.myProperties_0.add_11rb$(key + ': ' + value);
  };
  KatydidStyleImpl.prototype.setXyProperty_l8dco4$$default = function (key, x, y) {
    var css = x.toString();
    if (!equals(x, y)) {
      css += ' ' + y;
    }
    this.setProperty_puj7f4$(key, css);
  };
  KatydidStyleImpl.prototype.setStringProperty_puj7f4$ = function (key, value) {
    var cssValue = replace(value, '"', '\\"');
    cssValue = replace(cssValue, '\n', '\\A');
    this.setProperty_puj7f4$(key, '"' + cssValue + '"');
  };
  KatydidStyleImpl.prototype.toCssString_puj7f4$$default = function (indent, whitespace) {
    var $receiver = this.properties;
    var destination = ArrayList_init_0(collectionSizeOrDefault($receiver, 10));
    var tmp$;
    tmp$ = $receiver.iterator();
    while (tmp$.hasNext()) {
      var item = tmp$.next();
      destination.add_11rb$(indent + item);
    }
    return joinToString(destination, ';' + whitespace) + ';';
  };
  KatydidStyleImpl.prototype.toString = function () {
    return this.toCssString_puj7f4$('', ' ');
  };
  KatydidStyleImpl.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidStyleImpl',
    interfaces: [KatydidStyle]
  };
  function KatydidAbstractStyleRuleImpl(itsParent) {
    KatydidCompositeCssRuleImpl.call(this);
    this.$delegate_d27hti$_0 = new KatydidStyleImpl();
    this.myNestedRules_0 = ArrayList_init();
    this.mySelectors_0 = ArrayList_init();
    this.nestedRules_32ga5a$_0 = this.myNestedRules_0;
    this.parent_dzv5yk$_0 = itsParent;
    this.selectors_8be2vx$ = this.mySelectors_0;
  }
  Object.defineProperty(KatydidAbstractStyleRuleImpl.prototype, 'fullSelectors', {
    get: function () {
      var tmp$, tmp$_0;
      if (this.parent.fullSelectors.isEmpty()) {
        var $receiver = this.mySelectors_0;
        var destination = ArrayList_init();
        var tmp$_1;
        tmp$_1 = $receiver.iterator();
        while (tmp$_1.hasNext()) {
          var element = tmp$_1.next();
          if (!startsWith(element, '%'))
            destination.add_11rb$(element);
        }
        return destination;
      }
      var result = ArrayList_init();
      tmp$ = this.parent.fullSelectors.iterator();
      while (tmp$.hasNext()) {
        var outerSelector = tmp$.next();
        tmp$_0 = this.mySelectors_0.iterator();
        while (tmp$_0.hasNext()) {
          var selector = tmp$_0.next();
          if (startsWith(selector, '%')) {
            continue;
          }
          var fullSelector = outerSelector;
          if (contains(selector, '&')) {
            fullSelector = replace(selector, '&', fullSelector);
          }
           else {
            if (outerSelector.length > 0) {
              fullSelector += ' ';
            }
            fullSelector += selector;
          }
          result.add_11rb$(fullSelector);
        }
      }
      return result;
    }
  });
  Object.defineProperty(KatydidAbstractStyleRuleImpl.prototype, 'nestedRules', {
    get: function () {
      return this.nestedRules_32ga5a$_0;
    }
  });
  Object.defineProperty(KatydidAbstractStyleRuleImpl.prototype, 'parent', {
    get: function () {
      return this.parent_dzv5yk$_0;
    }
  });
  KatydidAbstractStyleRuleImpl.prototype.addNestedRule_c8c58$ = function (nestedRule) {
    this.myNestedRules_0.add_11rb$(nestedRule);
  };
  KatydidAbstractStyleRuleImpl.prototype.addNestedRules_3qoj17$ = function (addedNestedRules) {
    this.myNestedRules_0.addAll_brywnq$(addedNestedRules);
  };
  KatydidAbstractStyleRuleImpl.prototype.addSelectors_uy07ue$ = function (addedSelectors) {
    this.mySelectors_0.addAll_brywnq$(addedSelectors);
    this.afterAddSelectors_jfy1ql$(addedSelectors);
  };
  KatydidAbstractStyleRuleImpl.prototype.afterAddSelectors_jfy1ql$ = function (addedSelectors) {
  };
  KatydidAbstractStyleRuleImpl.prototype.invoke_k851pc$ = function ($receiver, build) {
    var result = new KatydidStyleRuleImpl(this);
    result.prependSelectors_y4putb$($receiver);
    this.myNestedRules_0.add_11rb$(result);
    build(result);
    return result;
  };
  KatydidAbstractStyleRuleImpl.prototype.or_rjktp$ = function ($receiver, that) {
    return $receiver + ', ' + that;
  };
  KatydidAbstractStyleRuleImpl.prototype.or_68i6bt$ = function ($receiver, styleRule) {
    var tmp$;
    (Kotlin.isType(tmp$ = styleRule, KatydidStyleRuleImpl) ? tmp$ : throwCCE()).prependSelectors_y4putb$($receiver);
    return styleRule;
  };
  KatydidAbstractStyleRuleImpl.prototype.prependSelectors_y4putb$ = function (compoundSelector) {
    var tmp$;
    var $receiver = split(compoundSelector, [',']);
    var destination = ArrayList_init_0(collectionSizeOrDefault($receiver, 10));
    var tmp$_0;
    tmp$_0 = $receiver.iterator();
    while (tmp$_0.hasNext()) {
      var item = tmp$_0.next();
      var tmp$_1;
      destination.add_11rb$(trim(Kotlin.isCharSequence(tmp$_1 = item) ? tmp$_1 : throwCCE()).toString());
    }
    tmp$ = reversed(destination).iterator();
    while (tmp$.hasNext()) {
      var selector = tmp$.next();
      this.mySelectors_0.add_wxm5ur$(0, selector);
    }
  };
  KatydidAbstractStyleRuleImpl.prototype.toCssString_za3lpa$$default = function (indent) {
    var tmp$;
    var result = new StringBuilder('');
    var spaces = '                    '.substring(0, indent);
    var finalSelectors = this.fullSelectors;
    var tmp$_0 = this.isNotEmpty;
    if (tmp$_0) {
      tmp$_0 = !finalSelectors.isEmpty();
    }
    if (tmp$_0) {
      result.append_gw00v9$(spaces);
      result.append_gw00v9$(joinToString(finalSelectors, ',' + '\n' + spaces));
      result.append_gw00v9$(' {\n');
      append(result, [this.toCssString_puj7f4$(spaces + '    '), '\n']);
      result.append_gw00v9$(spaces);
      result.append_gw00v9$('}\n\n');
    }
    tmp$ = this.myNestedRules_0.iterator();
    while (tmp$.hasNext()) {
      var rule = tmp$.next();
      result.append_gw00v9$(rule.toCssString_za3lpa$(indent));
    }
    return result.toString();
  };
  Object.defineProperty(KatydidAbstractStyleRuleImpl.prototype, 'important', {
    get: function () {
      return this.$delegate_d27hti$_0.important;
    }
  });
  Object.defineProperty(KatydidAbstractStyleRuleImpl.prototype, 'isNotEmpty', {
    get: function () {
      return this.$delegate_d27hti$_0.isNotEmpty;
    }
  });
  Object.defineProperty(KatydidAbstractStyleRuleImpl.prototype, 'properties', {
    get: function () {
      return this.$delegate_d27hti$_0.properties;
    }
  });
  KatydidAbstractStyleRuleImpl.prototype.include_2f4f17$ = function (style) {
    return this.$delegate_d27hti$_0.include_2f4f17$(style);
  };
  KatydidAbstractStyleRuleImpl.prototype.inherit_61zpoe$ = function (key) {
    return this.$delegate_d27hti$_0.inherit_61zpoe$(key);
  };
  KatydidAbstractStyleRuleImpl.prototype.setBoxProperty_hto8b4$$default = function (key, top, right, bottom, left) {
    return this.$delegate_d27hti$_0.setBoxProperty_hto8b4$$default(key, top, right, bottom, left);
  };
  KatydidAbstractStyleRuleImpl.prototype.setProperty_puj7f4$ = function (key, value) {
    return this.$delegate_d27hti$_0.setProperty_puj7f4$(key, value);
  };
  KatydidAbstractStyleRuleImpl.prototype.setStringProperty_puj7f4$ = function (key, value) {
    return this.$delegate_d27hti$_0.setStringProperty_puj7f4$(key, value);
  };
  KatydidAbstractStyleRuleImpl.prototype.setXyProperty_l8dco4$$default = function (key, x, y) {
    return this.$delegate_d27hti$_0.setXyProperty_l8dco4$$default(key, x, y);
  };
  KatydidAbstractStyleRuleImpl.prototype.toCssString_puj7f4$$default = function (indent, whitespace) {
    return this.$delegate_d27hti$_0.toCssString_puj7f4$$default(indent, whitespace);
  };
  KatydidAbstractStyleRuleImpl.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidAbstractStyleRuleImpl',
    interfaces: [KatydidAbstractStyleRule, KatydidStyle, KatydidCompositeCssRuleImpl]
  };
  function KatydidCharSetAtRuleImpl(itsParent, itsCharacterSet) {
    this.characterSet_88fz2l$_0 = itsCharacterSet;
    this.parent_yk0zzw$_0 = itsParent;
    if (!this.parent.nestedRules.isEmpty()) {
      var message = 'A @charset at-rule must be the first rule in a style sheet.';
      throw IllegalArgumentException_init(message.toString());
    }
  }
  Object.defineProperty(KatydidCharSetAtRuleImpl.prototype, 'characterSet', {
    get: function () {
      return this.characterSet_88fz2l$_0;
    }
  });
  Object.defineProperty(KatydidCharSetAtRuleImpl.prototype, 'parent', {
    get: function () {
      return this.parent_yk0zzw$_0;
    }
  });
  KatydidCharSetAtRuleImpl.prototype.copy_zf0q0v$ = function (parentOfCopy) {
    var tmp$;
    return new KatydidCharSetAtRuleImpl(Kotlin.isType(tmp$ = parentOfCopy, KatydidCompositeCssRuleImpl) ? tmp$ : throwCCE(), this.characterSet);
  };
  KatydidCharSetAtRuleImpl.prototype.toCssString_za3lpa$$default = function (indent) {
    return '@charset ' + '"' + this.characterSet + '"' + ';' + '\n' + '\n';
  };
  KatydidCharSetAtRuleImpl.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidCharSetAtRuleImpl',
    interfaces: [KatydidCharSetAtRule]
  };
  function KatydidCompositeCssRuleImpl() {
  }
  KatydidCompositeCssRuleImpl.prototype.copy_zf0q0v$ = function (parentOfCopy) {
    var tmp$;
    return this.copy_3mce49$(Kotlin.isType(tmp$ = parentOfCopy, KatydidCompositeCssRuleImpl) ? tmp$ : throwCCE());
  };
  KatydidCompositeCssRuleImpl.prototype.findPlaceholder_y4putb$ = function (placeholderName) {
    var tmp$;
    tmp$ = this.nestedRules.iterator();
    while (tmp$.hasNext()) {
      var rule = tmp$.next();
      if (Kotlin.isType(rule, KatydidPlaceholderRuleImpl) && equals(rule.name, placeholderName)) {
        return rule;
      }
    }
    return null;
  };
  KatydidCompositeCssRuleImpl.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidCompositeCssRuleImpl',
    interfaces: [KatydidCompositeCssRule]
  };
  function KatydidMediaAtRuleImpl(itsParent, itsCondition) {
    KatydidCompositeCssRuleImpl.call(this);
    this.myNestedRules_0 = ArrayList_init();
    this.condition_vjsx5x$_0 = itsCondition;
    this.fullSelectors_52q5e9$_0 = emptyList();
    this.nestedRules_r0kbxm$_0 = this.myNestedRules_0;
    this.parent_p80w50$_0 = itsParent;
  }
  Object.defineProperty(KatydidMediaAtRuleImpl.prototype, 'condition', {
    get: function () {
      return this.condition_vjsx5x$_0;
    }
  });
  Object.defineProperty(KatydidMediaAtRuleImpl.prototype, 'fullSelectors', {
    get: function () {
      return this.fullSelectors_52q5e9$_0;
    }
  });
  Object.defineProperty(KatydidMediaAtRuleImpl.prototype, 'nestedRules', {
    get: function () {
      return this.nestedRules_r0kbxm$_0;
    }
  });
  Object.defineProperty(KatydidMediaAtRuleImpl.prototype, 'parent', {
    get: function () {
      return this.parent_p80w50$_0;
    }
  });
  KatydidMediaAtRuleImpl.prototype.addNestedRule_0 = function (nestedRule) {
    this.myNestedRules_0.add_11rb$(nestedRule);
  };
  KatydidMediaAtRuleImpl.prototype.addNestedRules_0 = function (addedNestedRules) {
    this.myNestedRules_0.addAll_brywnq$(addedNestedRules);
  };
  KatydidMediaAtRuleImpl.prototype.copy_3mce49$ = function (parentOfCopy) {
    var result = new KatydidMediaAtRuleImpl(parentOfCopy, this.condition);
    var $receiver = this.nestedRules;
    var destination = ArrayList_init_0(collectionSizeOrDefault($receiver, 10));
    var tmp$;
    tmp$ = $receiver.iterator();
    while (tmp$.hasNext()) {
      var item = tmp$.next();
      destination.add_11rb$(item.copy_3mce49$(result));
    }
    result.addNestedRules_0(destination);
    return result;
  };
  KatydidMediaAtRuleImpl.prototype.invoke_k851pc$ = function ($receiver, build) {
    var result = new KatydidStyleRuleImpl(this);
    result.prependSelectors_y4putb$($receiver);
    this.myNestedRules_0.add_11rb$(result);
    build(result);
    return result;
  };
  KatydidMediaAtRuleImpl.prototype.or_rjktp$ = function ($receiver, that) {
    return $receiver + ', ' + that;
  };
  KatydidMediaAtRuleImpl.prototype.or_68i6bt$ = function ($receiver, styleRule) {
    var tmp$;
    (Kotlin.isType(tmp$ = styleRule, KatydidStyleRuleImpl) ? tmp$ : throwCCE()).prependSelectors_y4putb$($receiver);
    return styleRule;
  };
  KatydidMediaAtRuleImpl.prototype.placeholder_3nrwgx$ = function (name, build) {
    if (!(this.findPlaceholder_y4putb$(name) == null)) {
      var message = "Duplicate placeholder name not allowed: '" + this + "'.";
      throw IllegalArgumentException_init(message.toString());
    }
    var result = new KatydidPlaceholderRuleImpl(this, name);
    this.addNestedRule_0(result);
    build(result);
  };
  KatydidMediaAtRuleImpl.prototype.toCssString_za3lpa$$default = function (indent) {
    var tmp$;
    var result = new StringBuilder('');
    var spaces = '                    '.substring(0, indent);
    result.append_gw00v9$(spaces);
    result.append_gw00v9$('@media ');
    result.append_gw00v9$(this.condition);
    result.append_gw00v9$(' {\n\n');
    tmp$ = this.myNestedRules_0.iterator();
    while (tmp$.hasNext()) {
      var rule = tmp$.next();
      result.append_gw00v9$(rule.toCssString_za3lpa$(indent + 4 | 0));
    }
    result.append_gw00v9$(spaces);
    result.append_gw00v9$('}\n\n');
    return result.toString();
  };
  KatydidMediaAtRuleImpl.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidMediaAtRuleImpl',
    interfaces: [KatydidMediaAtRule, KatydidCompositeCssRuleImpl]
  };
  function KatydidPlaceholderRuleImpl(itsParent, itsName) {
    KatydidAbstractStyleRuleImpl.call(this, itsParent);
    this.myExtendedPlaceholders_0 = ArrayList_init();
    this.name_aw7tch$_0 = itsName;
    var $receiver = this.name;
    if (!Regex_init('%[a-zA-Z-_]+').matches_6bul2c$($receiver)) {
      var message = "Invalid placeholder name: '" + this.name + "'.";
      throw IllegalArgumentException_init(message.toString());
    }
  }
  Object.defineProperty(KatydidPlaceholderRuleImpl.prototype, 'name', {
    get: function () {
      return this.name_aw7tch$_0;
    }
  });
  KatydidPlaceholderRuleImpl.prototype.afterAddSelectors_jfy1ql$ = function (addedSelectors) {
    var tmp$;
    tmp$ = this.myExtendedPlaceholders_0.iterator();
    while (tmp$.hasNext()) {
      var placeholder = tmp$.next();
      placeholder.addSelectors_uy07ue$(addedSelectors);
    }
  };
  KatydidPlaceholderRuleImpl.prototype.copy_3mce49$ = function (parentOfCopy) {
    var result = new KatydidPlaceholderRuleImpl(parentOfCopy, this.name);
    result.addSelectors_uy07ue$(this.selectors_8be2vx$);
    result.include_2f4f17$(this);
    var $receiver = this.nestedRules;
    var destination = ArrayList_init_0(collectionSizeOrDefault($receiver, 10));
    var tmp$;
    tmp$ = $receiver.iterator();
    while (tmp$.hasNext()) {
      var item = tmp$.next();
      destination.add_11rb$(item.copy_3mce49$(result));
    }
    result.addNestedRules_3qoj17$(destination);
    return result;
  };
  KatydidPlaceholderRuleImpl.prototype.extend_vqirvp$ = function (placeholderNames) {
    var tmp$, tmp$_0;
    if (!this.properties.isEmpty()) {
      var message = 'Use of extend() must occur at the beginning of a placeholder rule.';
      throw IllegalArgumentException_init(message.toString());
    }
    for (tmp$ = 0; tmp$ !== placeholderNames.length; ++tmp$) {
      var placeholderName = placeholderNames[tmp$];
      tmp$_0 = this.parent.findPlaceholder_y4putb$(placeholderName);
      if (tmp$_0 == null) {
        throw IllegalArgumentException_init("Unknown placeholder rule to be extended: '" + placeholderName + "'.");
      }
      var placeholder = tmp$_0;
      this.myExtendedPlaceholders_0.add_11rb$(placeholder);
    }
  };
  KatydidPlaceholderRuleImpl.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidPlaceholderRuleImpl',
    interfaces: [KatydidPlaceholderRule, KatydidAbstractStyleRuleImpl]
  };
  function KatydidStyleRuleImpl(itsParent) {
    KatydidAbstractStyleRuleImpl.call(this, itsParent);
  }
  KatydidStyleRuleImpl.prototype.copy_3mce49$ = function (parentOfCopy) {
    var result = new KatydidStyleRuleImpl(parentOfCopy);
    result.addSelectors_uy07ue$(this.selectors_8be2vx$);
    result.include_2f4f17$(this);
    var $receiver = this.nestedRules;
    var destination = ArrayList_init_0(collectionSizeOrDefault($receiver, 10));
    var tmp$;
    tmp$ = $receiver.iterator();
    while (tmp$.hasNext()) {
      var item = tmp$.next();
      destination.add_11rb$(item.copy_3mce49$(result));
    }
    result.addNestedRules_3qoj17$(destination);
    return result;
  };
  KatydidStyleRuleImpl.prototype.extend_vqirvp$ = function (placeholderNames) {
    var tmp$, tmp$_0;
    if (!this.properties.isEmpty()) {
      var message = 'Use of extend() must occur at the beginning of a placeholder rule.';
      throw IllegalArgumentException_init(message.toString());
    }
    if (!this.nestedRules.isEmpty()) {
      var message_0 = 'Use of extend() must occur at the beginning of a placeholder rule.';
      throw IllegalArgumentException_init(message_0.toString());
    }
    for (tmp$ = 0; tmp$ !== placeholderNames.length; ++tmp$) {
      var placeholderName = placeholderNames[tmp$];
      tmp$_0 = this.parent.findPlaceholder_y4putb$(placeholderName);
      if (tmp$_0 == null) {
        throw IllegalArgumentException_init("Unknown placeholder rule to be extended: '" + placeholderName + "'.");
      }
      var placeholder = tmp$_0;
      placeholder.addSelectors_uy07ue$(this.selectors_8be2vx$);
    }
  };
  KatydidStyleRuleImpl.prototype.placeholder_3nrwgx$ = function (name, build) {
    if (!(this.findPlaceholder_y4putb$(name) == null)) {
      var message = "Duplicate placeholder name not allowed: '" + this + "'.";
      throw IllegalArgumentException_init(message.toString());
    }
    var result = new KatydidPlaceholderRuleImpl(this, name);
    this.addNestedRule_c8c58$(result);
    build(result);
  };
  KatydidStyleRuleImpl.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidStyleRuleImpl',
    interfaces: [KatydidStyleRule, KatydidAbstractStyleRuleImpl]
  };
  function KatydidStyleSheetImpl() {
    KatydidCompositeCssRuleImpl.call(this);
    this.fullSelectors_dq7rg4$_0 = emptyList();
    this.nestedRules_c612d5$_0 = ArrayList_init();
  }
  Object.defineProperty(KatydidStyleSheetImpl.prototype, 'fullSelectors', {
    get: function () {
      return this.fullSelectors_dq7rg4$_0;
    }
  });
  Object.defineProperty(KatydidStyleSheetImpl.prototype, 'nestedRules', {
    get: function () {
      return this.nestedRules_c612d5$_0;
    }
  });
  Object.defineProperty(KatydidStyleSheetImpl.prototype, 'parent', {
    get: function () {
      throw UnsupportedOperationException_init('A style sheet has no parent rule.');
    }
  });
  KatydidStyleSheetImpl.prototype.charset_61zpoe$ = function (characterSet) {
    var result = new KatydidCharSetAtRuleImpl(this, characterSet);
    this.nestedRules.add_11rb$(result);
    return result;
  };
  KatydidStyleSheetImpl.prototype.copy_3mce49$ = function (parentOfCopy) {
    throw UnsupportedOperationException_init('A style sheet cannot be copied inside another style rule.');
  };
  KatydidStyleSheetImpl.prototype.include_f1uy23$ = function (styleSheet) {
    var tmp$;
    tmp$ = styleSheet.nestedRules.iterator();
    while (tmp$.hasNext()) {
      var rule = tmp$.next();
      if (Kotlin.isType(rule, KatydidAbstractStyleRule)) {
        this.nestedRules.add_11rb$(rule.copy_zf0q0v$(this));
      }
       else if (Kotlin.isType(rule, KatydidCharSetAtRule) && this.nestedRules.isEmpty()) {
        this.nestedRules.add_11rb$(rule.copy_zf0q0v$(this));
      }
       else if (Kotlin.isType(rule, KatydidMediaAtRule)) {
        this.nestedRules.add_11rb$(rule.copy_zf0q0v$(this));
      }
    }
  };
  KatydidStyleSheetImpl.prototype.invoke_k851pc$ = function ($receiver, build) {
    var result = new KatydidStyleRuleImpl(this);
    result.prependSelectors_y4putb$($receiver);
    this.nestedRules.add_11rb$(result);
    build(result);
    return result;
  };
  KatydidStyleSheetImpl.prototype.media_7gtj8j$ = function (condition, build) {
    var result = new KatydidMediaAtRuleImpl(this, condition);
    this.nestedRules.add_11rb$(result);
    build(result);
    return result;
  };
  KatydidStyleSheetImpl.prototype.or_rjktp$ = function ($receiver, that) {
    return $receiver + ', ' + that;
  };
  KatydidStyleSheetImpl.prototype.or_68i6bt$ = function ($receiver, styleRule) {
    var tmp$;
    (Kotlin.isType(tmp$ = styleRule, KatydidStyleRuleImpl) ? tmp$ : throwCCE()).prependSelectors_y4putb$($receiver);
    return styleRule;
  };
  KatydidStyleSheetImpl.prototype.placeholder_3nrwgx$ = function (name, build) {
    if (!(this.findPlaceholder_y4putb$(name) == null)) {
      var message = "Duplicate placeholder name not allowed: '" + this + "'.";
      throw IllegalArgumentException_init(message.toString());
    }
    var result = new KatydidPlaceholderRuleImpl(this, name);
    this.nestedRules.add_11rb$(result);
    build(result);
    return name;
  };
  KatydidStyleSheetImpl.prototype.toCssString_za3lpa$$default = function (indent) {
    var tmp$;
    var result = new StringBuilder('');
    tmp$ = this.nestedRules.iterator();
    while (tmp$.hasNext()) {
      var rule = tmp$.next();
      result.append_gw00v9$(rule.toCssString_za3lpa$(indent));
    }
    return result.toString();
  };
  KatydidStyleSheetImpl.prototype.toString = function () {
    return this.toCssString_za3lpa$();
  };
  KatydidStyleSheetImpl.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidStyleSheetImpl',
    interfaces: [KatydidStyleSheet, KatydidCompositeCssRuleImpl]
  };
  function buildStyleElement(domElement, styleSheet) {
    domElement.innerHTML = styleSheet.toString();
  }
  function Color() {
    Color$Companion_getInstance();
  }
  function Color$Companion() {
    Color$Companion_instance = this;
  }
  Color$Companion.prototype.fromHex_61zpoe$ = function (hexColor) {
    return RgbColor$Companion_getInstance().fromHex_61zpoe$(hexColor);
  };
  Color$Companion.$metadata$ = {
    kind: Kind_OBJECT,
    simpleName: 'Companion',
    interfaces: []
  };
  var Color$Companion_instance = null;
  function Color$Companion_getInstance() {
    if (Color$Companion_instance === null) {
      new Color$Companion();
    }
    return Color$Companion_instance;
  }
  Color.$metadata$ = {
    kind: Kind_INTERFACE,
    simpleName: 'Color',
    interfaces: []
  };
  function rgb(redByte, greenByte, blueByte) {
    return rgba(redByte, greenByte, blueByte, 1.0);
  }
  function rgba(redByte, greenByte, blueByte, alpha) {
    var tmp$;
    var result = RgbColor_init(redByte, greenByte, blueByte, alpha);
    return (tmp$ = RgbColor$Companion_getInstance().getNamedColorByHashCode_za3lpa$(result.hashCode())) != null ? tmp$ : result;
  }
  function rgb_0(redFraction, greenFraction, blueFraction) {
    return rgba_0(redFraction, greenFraction, blueFraction, 1.0);
  }
  function rgba_0(redFraction, greenFraction, blueFraction, alpha) {
    var tmp$;
    var result = RgbColor_init_0(redFraction, greenFraction, blueFraction, alpha);
    return (tmp$ = RgbColor$Companion_getInstance().getNamedColorByHashCode_za3lpa$(result.hashCode())) != null ? tmp$ : result;
  }
  function hsl(hue, saturation, lightness) {
    return hsla(hue, saturation, lightness, 1.0);
  }
  function hsla(hue, saturationFraction, lightnessFraction, alpha) {
    var tmp$;
    var result = new HslColor(hue, saturationFraction, lightnessFraction, alpha);
    return (tmp$ = RgbColor$Companion_getInstance().getNamedColorByHashCode_za3lpa$(result.hashCode())) != null ? tmp$ : result;
  }
  var aliceblue;
  var antiquewhite;
  var aqua;
  var aquamarine;
  var azure;
  var beige;
  var bisque;
  var black;
  var blanchedalmond;
  var blue;
  var blueviolet;
  var brown;
  var burlywood;
  var cadetblue;
  var chartreuse;
  var chocolate;
  var coral;
  var cornflowerblue;
  var cornsilk;
  var crimson;
  var cyan;
  var darkblue;
  var darkcyan;
  var darkgoldenrod;
  var darkgray;
  var darkgreen;
  var darkgrey;
  var darkkhaki;
  var darkmagenta;
  var darkolivegreen;
  var darkorange;
  var darkorchid;
  var darkred;
  var darksalmon;
  var darkseagreen;
  var darkslateblue;
  var darkslategray;
  var darkslategrey;
  var darkturquoise;
  var darkviolet;
  var deeppink;
  var deepskyblue;
  var dimgray;
  var dimgrey;
  var dodgerblue;
  var firebrick;
  var floralwhite;
  var forestgreen;
  var fuchsia;
  var gainsboro;
  var ghostwhite;
  var gold;
  var goldenrod;
  var gray;
  var green;
  var greenyellow;
  var grey;
  var honeydew;
  var hotpink;
  var indianred;
  var indigo;
  var ivory;
  var khaki;
  var lavender;
  var lavenderblush;
  var lawngreen;
  var lemonchiffon;
  var lightblue;
  var lightcoral;
  var lightcyan;
  var lightgoldenrodyellow;
  var lightgray;
  var lightgreen;
  var lightgrey;
  var lightpink;
  var lightsalmon;
  var lightseagreen;
  var lightskyblue;
  var lightslategray;
  var lightslategrey;
  var lightsteelblue;
  var lightyellow;
  var lime;
  var limegreen;
  var linen;
  var magenta;
  var maroon;
  var mediumaquamarine;
  var mediumblue;
  var mediumorchid;
  var mediumpurple;
  var mediumseagreen;
  var mediumslateblue;
  var mediumspringgreen;
  var mediumturquoise;
  var mediumvioletred;
  var midnightblue;
  var mintcream;
  var mistyrose;
  var moccasin;
  var navajowhite;
  var navy;
  var oldlace;
  var olive;
  var olivedrab;
  var orange;
  var orangered;
  var orchid;
  var palegoldenrod;
  var palegreen;
  var paleturquoise;
  var palevioletred;
  var papayawhip;
  var peachpuff;
  var peru;
  var pink;
  var plum;
  var powderblue;
  var purple;
  var red;
  var rosybrown;
  var royalblue;
  var saddlebrown;
  var salmon;
  var sandybrown;
  var seagreen;
  var seashell;
  var sienna;
  var silver;
  var skyblue;
  var slateblue;
  var slategray;
  var slategrey;
  var snow;
  var springgreen;
  var steelblue;
  var tan;
  var teal;
  var thistle;
  var tomato;
  var transparent;
  var turquoise;
  var violet;
  var wheat;
  var white;
  var whitesmoke;
  var yellow;
  var yellowgreen;
  function useCssColorNames() {
  }
  function opacify(color, alphaIncrement) {
    return color.opacified_mx4ult$(alphaIncrement);
  }
  function transparentize(color, alphaDecrement) {
    return color.transparentized_mx4ult$(alphaDecrement);
  }
  function Length(length, unit) {
    this.length = length;
    this.unit = unit;
  }
  Object.defineProperty(Length.prototype, 'isNotNegative', {
    get: function () {
      return this.length >= 0;
    }
  });
  Length.prototype.equals = function (other) {
    if (Kotlin.isType(other, Length)) {
      return this.length === other.length && this.unit === other.unit;
    }
    return false;
  };
  Length.prototype.unaryMinus = function () {
    return new Length(-this.length, this.unit);
  };
  Length.prototype.hashCode = function () {
    var result = hashCode(this.length);
    result = (31 * result | 0) + this.unit.hashCode() | 0;
    return result;
  };
  Length.prototype.toString = function () {
    return this.length === 0.0 ? '0' : makeDecimalString(this.length) + this.unit;
  };
  Length.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'Length',
    interfaces: []
  };
  function length(s) {
    var unit = takeLast(s, 4);
    switch (unit) {
      case 'vmax':
        return new Length(toDouble(dropLast(s, 4)), LengthUnit$VIEW_PORT_MAXIMUM_01_getInstance());
      case 'vmin':
        return new Length(toDouble(dropLast(s, 4)), LengthUnit$VIEW_PORT_MINIMUM_01_getInstance());
    }
    unit = takeLast(s, 3);
    if (equals(unit, 'rem')) {
      return new Length(toDouble(dropLast(s, 3)), LengthUnit$FONT_SIZE_ROOT_ELEMENT_getInstance());
    }
    unit = takeLast(s, 2);
    switch (unit) {
      case 'px':
        return new Length(toDouble(dropLast(s, 2)), LengthUnit$PIXEL_getInstance());
      case 'pt':
        return new Length(toDouble(dropLast(s, 2)), LengthUnit$POINT_getInstance());
      case 'em':
        return new Length(toDouble(dropLast(s, 2)), LengthUnit$FONT_SIZE_ELEMENT_getInstance());
      case 'ch':
        return new Length(toDouble(dropLast(s, 2)), LengthUnit$ZERO_WIDTH_getInstance());
      case 'cm':
        return new Length(toDouble(dropLast(s, 2)), LengthUnit$CENTIMETER_getInstance());
      case 'ex':
        return new Length(toDouble(dropLast(s, 2)), LengthUnit$X_HEIGHT_getInstance());
      case 'in':
        return new Length(toDouble(dropLast(s, 2)), LengthUnit$INCH_getInstance());
      case 'mm':
        return new Length(toDouble(dropLast(s, 2)), LengthUnit$MILLIMETER_getInstance());
      case 'pc':
        return new Length(toDouble(dropLast(s, 2)), LengthUnit$PICA_getInstance());
      case 'vh':
        return new Length(toDouble(dropLast(s, 2)), LengthUnit$VIEW_PORT_HEIGHT_01_getInstance());
      case 'vw':
        return new Length(toDouble(dropLast(s, 2)), LengthUnit$VIEW_PORT_WIDTH_01_getInstance());
    }
    unit = takeLast(s, 1);
    if (equals(unit, 'Q')) {
      return new Length(toDouble(dropLast(s, 1)), LengthUnit$QUARTER_MILLIMETER_getInstance());
    }
    return new Length(toDouble(s), LengthUnit$PIXEL_getInstance());
  }
  function length_0(value) {
    if (Kotlin.isNumber(value))
      return new Length(numberToDouble(value), LengthUnit$PIXEL_getInstance());
    else if (typeof value === 'string')
      return length(value);
    else if (Kotlin.isType(value, Length))
      return value;
    else
      throw IllegalArgumentException_init("Cannot create Length from '" + value.toString() + "'.");
  }
  function get_ch($receiver) {
    return new Length(numberToDouble($receiver), LengthUnit$ZERO_WIDTH_getInstance());
  }
  function get_cm($receiver) {
    return new Length(numberToDouble($receiver), LengthUnit$CENTIMETER_getInstance());
  }
  function get_em($receiver) {
    return new Length(numberToDouble($receiver), LengthUnit$FONT_SIZE_ELEMENT_getInstance());
  }
  function get_ex($receiver) {
    return new Length(numberToDouble($receiver), LengthUnit$X_HEIGHT_getInstance());
  }
  function get_inch($receiver) {
    return new Length(numberToDouble($receiver), LengthUnit$INCH_getInstance());
  }
  function get_mm($receiver) {
    return new Length(numberToDouble($receiver), LengthUnit$MILLIMETER_getInstance());
  }
  function get_pc($receiver) {
    return new Length(numberToDouble($receiver), LengthUnit$PICA_getInstance());
  }
  function get_pt($receiver) {
    return new Length(numberToDouble($receiver), LengthUnit$POINT_getInstance());
  }
  function get_px($receiver) {
    return new Length(numberToDouble($receiver), LengthUnit$PIXEL_getInstance());
  }
  function get_Q($receiver) {
    return new Length(numberToDouble($receiver), LengthUnit$QUARTER_MILLIMETER_getInstance());
  }
  function get_rem($receiver) {
    return new Length(numberToDouble($receiver), LengthUnit$FONT_SIZE_ROOT_ELEMENT_getInstance());
  }
  function get_vh($receiver) {
    return new Length(numberToDouble($receiver), LengthUnit$VIEW_PORT_HEIGHT_01_getInstance());
  }
  function get_vmax($receiver) {
    return new Length(numberToDouble($receiver), LengthUnit$VIEW_PORT_MAXIMUM_01_getInstance());
  }
  function get_vmin($receiver) {
    return new Length(numberToDouble($receiver), LengthUnit$VIEW_PORT_MINIMUM_01_getInstance());
  }
  function get_vw($receiver) {
    return new Length(numberToDouble($receiver), LengthUnit$VIEW_PORT_WIDTH_01_getInstance());
  }
  function LengthUnit(name, ordinal, css) {
    Enum.call(this);
    this.css_eq2f94$_0 = css;
    this.name$ = name;
    this.ordinal$ = ordinal;
  }
  function LengthUnit_initFields() {
    LengthUnit_initFields = function () {
    };
    LengthUnit$CENTIMETER_instance = new LengthUnit('CENTIMETER', 0, 'cm');
    LengthUnit$FONT_SIZE_ELEMENT_instance = new LengthUnit('FONT_SIZE_ELEMENT', 1, 'em');
    LengthUnit$FONT_SIZE_ROOT_ELEMENT_instance = new LengthUnit('FONT_SIZE_ROOT_ELEMENT', 2, 'rem');
    LengthUnit$INCH_instance = new LengthUnit('INCH', 3, 'in');
    LengthUnit$MILLIMETER_instance = new LengthUnit('MILLIMETER', 4, 'mm');
    LengthUnit$PICA_instance = new LengthUnit('PICA', 5, 'pc');
    LengthUnit$PIXEL_instance = new LengthUnit('PIXEL', 6, 'px');
    LengthUnit$POINT_instance = new LengthUnit('POINT', 7, 'pt');
    LengthUnit$QUARTER_MILLIMETER_instance = new LengthUnit('QUARTER_MILLIMETER', 8, 'Q');
    LengthUnit$VIEW_PORT_HEIGHT_01_instance = new LengthUnit('VIEW_PORT_HEIGHT_01', 9, 'vh');
    LengthUnit$VIEW_PORT_MAXIMUM_01_instance = new LengthUnit('VIEW_PORT_MAXIMUM_01', 10, 'vmax');
    LengthUnit$VIEW_PORT_MINIMUM_01_instance = new LengthUnit('VIEW_PORT_MINIMUM_01', 11, 'vmin');
    LengthUnit$VIEW_PORT_WIDTH_01_instance = new LengthUnit('VIEW_PORT_WIDTH_01', 12, 'vw');
    LengthUnit$X_HEIGHT_instance = new LengthUnit('X_HEIGHT', 13, 'ex');
    LengthUnit$ZERO_WIDTH_instance = new LengthUnit('ZERO_WIDTH', 14, 'ch');
    LengthUnit$Companion_getInstance();
  }
  var LengthUnit$CENTIMETER_instance;
  function LengthUnit$CENTIMETER_getInstance() {
    LengthUnit_initFields();
    return LengthUnit$CENTIMETER_instance;
  }
  var LengthUnit$FONT_SIZE_ELEMENT_instance;
  function LengthUnit$FONT_SIZE_ELEMENT_getInstance() {
    LengthUnit_initFields();
    return LengthUnit$FONT_SIZE_ELEMENT_instance;
  }
  var LengthUnit$FONT_SIZE_ROOT_ELEMENT_instance;
  function LengthUnit$FONT_SIZE_ROOT_ELEMENT_getInstance() {
    LengthUnit_initFields();
    return LengthUnit$FONT_SIZE_ROOT_ELEMENT_instance;
  }
  var LengthUnit$INCH_instance;
  function LengthUnit$INCH_getInstance() {
    LengthUnit_initFields();
    return LengthUnit$INCH_instance;
  }
  var LengthUnit$MILLIMETER_instance;
  function LengthUnit$MILLIMETER_getInstance() {
    LengthUnit_initFields();
    return LengthUnit$MILLIMETER_instance;
  }
  var LengthUnit$PICA_instance;
  function LengthUnit$PICA_getInstance() {
    LengthUnit_initFields();
    return LengthUnit$PICA_instance;
  }
  var LengthUnit$PIXEL_instance;
  function LengthUnit$PIXEL_getInstance() {
    LengthUnit_initFields();
    return LengthUnit$PIXEL_instance;
  }
  var LengthUnit$POINT_instance;
  function LengthUnit$POINT_getInstance() {
    LengthUnit_initFields();
    return LengthUnit$POINT_instance;
  }
  var LengthUnit$QUARTER_MILLIMETER_instance;
  function LengthUnit$QUARTER_MILLIMETER_getInstance() {
    LengthUnit_initFields();
    return LengthUnit$QUARTER_MILLIMETER_instance;
  }
  var LengthUnit$VIEW_PORT_HEIGHT_01_instance;
  function LengthUnit$VIEW_PORT_HEIGHT_01_getInstance() {
    LengthUnit_initFields();
    return LengthUnit$VIEW_PORT_HEIGHT_01_instance;
  }
  var LengthUnit$VIEW_PORT_MAXIMUM_01_instance;
  function LengthUnit$VIEW_PORT_MAXIMUM_01_getInstance() {
    LengthUnit_initFields();
    return LengthUnit$VIEW_PORT_MAXIMUM_01_instance;
  }
  var LengthUnit$VIEW_PORT_MINIMUM_01_instance;
  function LengthUnit$VIEW_PORT_MINIMUM_01_getInstance() {
    LengthUnit_initFields();
    return LengthUnit$VIEW_PORT_MINIMUM_01_instance;
  }
  var LengthUnit$VIEW_PORT_WIDTH_01_instance;
  function LengthUnit$VIEW_PORT_WIDTH_01_getInstance() {
    LengthUnit_initFields();
    return LengthUnit$VIEW_PORT_WIDTH_01_instance;
  }
  var LengthUnit$X_HEIGHT_instance;
  function LengthUnit$X_HEIGHT_getInstance() {
    LengthUnit_initFields();
    return LengthUnit$X_HEIGHT_instance;
  }
  var LengthUnit$ZERO_WIDTH_instance;
  function LengthUnit$ZERO_WIDTH_getInstance() {
    LengthUnit_initFields();
    return LengthUnit$ZERO_WIDTH_instance;
  }
  LengthUnit.prototype.toString = function () {
    return this.css_eq2f94$_0;
  };
  function LengthUnit$Companion() {
    LengthUnit$Companion_instance = this;
    this.ch = LengthUnit$ZERO_WIDTH_getInstance();
    this.cm = LengthUnit$CENTIMETER_getInstance();
    this.em = LengthUnit$FONT_SIZE_ELEMENT_getInstance();
    this.ex = LengthUnit$X_HEIGHT_getInstance();
    this.in = LengthUnit$INCH_getInstance();
    this.mm = LengthUnit$MILLIMETER_getInstance();
    this.pc = LengthUnit$PICA_getInstance();
    this.px = LengthUnit$PIXEL_getInstance();
    this.pt = LengthUnit$POINT_getInstance();
    this.Q = LengthUnit$QUARTER_MILLIMETER_getInstance();
    this.rem = LengthUnit$FONT_SIZE_ROOT_ELEMENT_getInstance();
    this.vh = LengthUnit$VIEW_PORT_HEIGHT_01_getInstance();
    this.vmin = LengthUnit$VIEW_PORT_MINIMUM_01_getInstance();
    this.vmax = LengthUnit$VIEW_PORT_MAXIMUM_01_getInstance();
    this.vw = LengthUnit$VIEW_PORT_WIDTH_01_getInstance();
  }
  LengthUnit$Companion.$metadata$ = {
    kind: Kind_OBJECT,
    simpleName: 'Companion',
    interfaces: []
  };
  var LengthUnit$Companion_instance = null;
  function LengthUnit$Companion_getInstance() {
    LengthUnit_initFields();
    if (LengthUnit$Companion_instance === null) {
      new LengthUnit$Companion();
    }
    return LengthUnit$Companion_instance;
  }
  LengthUnit.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'LengthUnit',
    interfaces: [Enum]
  };
  function LengthUnit$values() {
    return [LengthUnit$CENTIMETER_getInstance(), LengthUnit$FONT_SIZE_ELEMENT_getInstance(), LengthUnit$FONT_SIZE_ROOT_ELEMENT_getInstance(), LengthUnit$INCH_getInstance(), LengthUnit$MILLIMETER_getInstance(), LengthUnit$PICA_getInstance(), LengthUnit$PIXEL_getInstance(), LengthUnit$POINT_getInstance(), LengthUnit$QUARTER_MILLIMETER_getInstance(), LengthUnit$VIEW_PORT_HEIGHT_01_getInstance(), LengthUnit$VIEW_PORT_MAXIMUM_01_getInstance(), LengthUnit$VIEW_PORT_MINIMUM_01_getInstance(), LengthUnit$VIEW_PORT_WIDTH_01_getInstance(), LengthUnit$X_HEIGHT_getInstance(), LengthUnit$ZERO_WIDTH_getInstance()];
  }
  LengthUnit.values = LengthUnit$values;
  function LengthUnit$valueOf(name) {
    switch (name) {
      case 'CENTIMETER':
        return LengthUnit$CENTIMETER_getInstance();
      case 'FONT_SIZE_ELEMENT':
        return LengthUnit$FONT_SIZE_ELEMENT_getInstance();
      case 'FONT_SIZE_ROOT_ELEMENT':
        return LengthUnit$FONT_SIZE_ROOT_ELEMENT_getInstance();
      case 'INCH':
        return LengthUnit$INCH_getInstance();
      case 'MILLIMETER':
        return LengthUnit$MILLIMETER_getInstance();
      case 'PICA':
        return LengthUnit$PICA_getInstance();
      case 'PIXEL':
        return LengthUnit$PIXEL_getInstance();
      case 'POINT':
        return LengthUnit$POINT_getInstance();
      case 'QUARTER_MILLIMETER':
        return LengthUnit$QUARTER_MILLIMETER_getInstance();
      case 'VIEW_PORT_HEIGHT_01':
        return LengthUnit$VIEW_PORT_HEIGHT_01_getInstance();
      case 'VIEW_PORT_MAXIMUM_01':
        return LengthUnit$VIEW_PORT_MAXIMUM_01_getInstance();
      case 'VIEW_PORT_MINIMUM_01':
        return LengthUnit$VIEW_PORT_MINIMUM_01_getInstance();
      case 'VIEW_PORT_WIDTH_01':
        return LengthUnit$VIEW_PORT_WIDTH_01_getInstance();
      case 'X_HEIGHT':
        return LengthUnit$X_HEIGHT_getInstance();
      case 'ZERO_WIDTH':
        return LengthUnit$ZERO_WIDTH_getInstance();
      default:throwISE('No enum constant o.katydid.css.measurements.LengthUnit.' + name);
    }
  }
  LengthUnit.valueOf_61zpoe$ = LengthUnit$valueOf;
  function Percentage(amount) {
    this.amount = amount;
  }
  Object.defineProperty(Percentage.prototype, 'isNotNegative', {
    get: function () {
      return this.amount >= 0;
    }
  });
  Percentage.prototype.equals = function (other) {
    if (Kotlin.isType(other, Percentage)) {
      return this.amount === other.amount;
    }
    return false;
  };
  Percentage.prototype.hashCode = function () {
    return hashCode(this.amount);
  };
  Percentage.prototype.toString = function () {
    return this.amount === 0.0 ? '0' : makeDecimalString(this.amount) + '%';
  };
  Percentage.prototype.unaryMinus = function () {
    return new Percentage(-this.amount);
  };
  Percentage.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'Percentage',
    interfaces: []
  };
  function percentage(s) {
    if (equals(takeLast(s, 1), '%')) {
      return new Percentage(toDouble(dropLast(s, 1)));
    }
    throw IllegalArgumentException_init('Not a valid percentage: ' + '"' + s + '"' + '.');
  }
  function percentage_0(value) {
    if (typeof value === 'string')
      return percentage(value);
    else if (Kotlin.isType(value, Percentage))
      return value;
    else
      throw IllegalArgumentException_init("Cannot create Percentage from '" + value.toString() + "'.");
  }
  function get_percent($receiver) {
    return new Percentage(numberToDouble($receiver));
  }
  function KatydidAnimationStyleBuilder(style) {
    this.style_0 = style;
  }
  KatydidAnimationStyleBuilder.prototype.name_r36pjo$ = function (value) {
    animationName(this.style_0, value);
  };
  KatydidAnimationStyleBuilder.prototype.name_61zpoe$ = function (value) {
    animationName_0(this.style_0, value);
  };
  KatydidAnimationStyleBuilder.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidAnimationStyleBuilder',
    interfaces: []
  };
  function animation($receiver, build) {
    build(new KatydidAnimationStyleBuilder($receiver));
  }
  function animationName($receiver, value) {
    $receiver.setProperty_puj7f4$('animation-name', value.toString());
  }
  function animationName_0($receiver, value) {
    $receiver.setProperty_puj7f4$('animation-name', value);
  }
  function KatydidBackgroundStyleBuilder(style) {
    this.style_0 = style;
  }
  KatydidBackgroundStyleBuilder.prototype.attachment_wcqd18$ = function (values) {
    backgroundAttachment(this.style_0, values.slice());
  };
  KatydidBackgroundStyleBuilder.prototype.color_btlm55$ = function (value) {
    backgroundColor(this.style_0, value);
  };
  KatydidBackgroundStyleBuilder.prototype.image_uetg2i$ = function (values) {
    backgroundImage(this.style_0, values.slice());
  };
  KatydidBackgroundStyleBuilder.prototype.position_yyl29g$ = function (x, xOffset, y, yOffset) {
    backgroundPosition(this.style_0, x, xOffset, y, yOffset);
  };
  KatydidBackgroundStyleBuilder.prototype.position_m3savw$ = function (x, xOffset, y, yOffset) {
    backgroundPosition_0(this.style_0, x, xOffset, y, yOffset);
  };
  KatydidBackgroundStyleBuilder.prototype.position_qeqa2i$ = function (x, y) {
    if (y === void 0)
      y = EBackgroundPosition$center_getInstance();
    backgroundPosition_1(this.style_0, x, y);
  };
  KatydidBackgroundStyleBuilder.prototype.position_n0fawn$ = function (x) {
    backgroundPosition_2(this.style_0, x);
  };
  KatydidBackgroundStyleBuilder.prototype.position_pfbe1m$ = function (x, y) {
    backgroundPosition_3(this.style_0, x, y);
  };
  KatydidBackgroundStyleBuilder.prototype.position_rtt64d$ = function (x) {
    backgroundPosition_4(this.style_0, x);
  };
  KatydidBackgroundStyleBuilder.prototype.position_9gyx3i$ = function (x, y) {
    backgroundPosition_5(this.style_0, x, y);
  };
  KatydidBackgroundStyleBuilder.prototype.repeat_8htkk3$ = function (x, y) {
    if (y === void 0)
      y = null;
    backgroundRepeat(this.style_0, x, y);
  };
  KatydidBackgroundStyleBuilder.prototype.repeat_c9d3vp$ = function (values) {
    backgroundRepeat_0(this.style_0, values.slice());
  };
  KatydidBackgroundStyleBuilder.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidBackgroundStyleBuilder',
    interfaces: []
  };
  function background($receiver, build) {
    build(new KatydidBackgroundStyleBuilder($receiver));
  }
  function backgroundAttachment$lambda(v) {
    return v.toString();
  }
  function backgroundAttachment($receiver, values) {
    $receiver.setProperty_puj7f4$('background-attachment', joinToString_0(values, ', ', void 0, void 0, void 0, void 0, backgroundAttachment$lambda));
  }
  function backgroundColor($receiver, value) {
    $receiver.setProperty_puj7f4$('background-color', value.toString());
  }
  function backgroundImage$lambda(v) {
    return v.toString();
  }
  function backgroundImage($receiver, values) {
    $receiver.setProperty_puj7f4$('background-image', joinToString_0(values, ', ', void 0, void 0, void 0, void 0, backgroundImage$lambda));
  }
  function backgroundPosition($receiver, x, xOffset, y, yOffset) {
    $receiver.setProperty_puj7f4$('background-position', x.toString() + ' ' + xOffset + ' ' + y + ' ' + yOffset);
  }
  function backgroundPosition_0($receiver, x, xOffset, y, yOffset) {
    $receiver.setProperty_puj7f4$('background-position', x.toString() + ' ' + xOffset + ' ' + y + ' ' + yOffset);
  }
  function backgroundPosition_1($receiver, x, y) {
    if (y === void 0)
      y = EBackgroundPosition$center_getInstance();
    $receiver.setProperty_puj7f4$('background-position', x.toString() + ' ' + y);
  }
  function backgroundPosition_2($receiver, x) {
    $receiver.setProperty_puj7f4$('background-position', x.toString() + ' center');
  }
  function backgroundPosition_3($receiver, x, y) {
    $receiver.setProperty_puj7f4$('background-position', x.toString() + ' ' + y);
  }
  function backgroundPosition_4($receiver, x) {
    $receiver.setProperty_puj7f4$('background-position', x.toString() + ' center');
  }
  function backgroundPosition_5($receiver, x, y) {
    $receiver.setProperty_puj7f4$('background-position', x.toString() + ' ' + y);
  }
  function backgroundRepeat($receiver, x, y) {
    if (y === void 0)
      y = null;
    if (!(x !== ERepeatStyle$repeatX_getInstance() && x !== ERepeatStyle$repeatY_getInstance() || y == null)) {
      var message = 'Background style ' + x + ' cannot be combined with a second value.';
      throw IllegalArgumentException_init(message.toString());
    }
    if (y == null) {
      $receiver.setProperty_puj7f4$('background-repeat', x.toString());
    }
     else {
      $receiver.setProperty_puj7f4$('background-repeat', x.toString() + ' ' + toString(y));
    }
  }
  function backgroundRepeat_0($receiver, values) {
    var destination = ArrayList_init_0(values.length);
    var tmp$;
    for (tmp$ = 0; tmp$ !== values.length; ++tmp$) {
      var item = values[tmp$];
      var tmp$_0 = destination.add_11rb$;
      var transform$result;
      if (!(item.first !== ERepeatStyle$repeatX_getInstance() && item.first !== ERepeatStyle$repeatY_getInstance() || item.second == null)) {
        var message = 'Background style ' + item.first + ' cannot be combined with a second value.';
        throw IllegalArgumentException_init(message.toString());
      }
      if (item.second == null) {
        transform$result = item.first.toString();
      }
       else {
        transform$result = item.first.toString() + ' ' + toString(item.second);
      }
      tmp$_0.call(destination, transform$result);
    }
    var strings = destination;
    $receiver.setProperty_puj7f4$('background-repeat', joinToString(strings, ', '));
  }
  function KatydidBorderBottomStyleBuilder(style) {
    this.style_0 = style;
  }
  KatydidBorderBottomStyleBuilder.prototype.color_btlm55$ = function (value) {
    borderBottomColor(this.style_0, value);
  };
  KatydidBorderBottomStyleBuilder.prototype.style_w2hgcf$ = function (value) {
    borderBottomStyle(this.style_0, value);
  };
  KatydidBorderBottomStyleBuilder.prototype.width_w0hq7e$ = function (value) {
    borderBottomWidth(this.style_0, value);
  };
  KatydidBorderBottomStyleBuilder.prototype.width_n0fawn$ = function (value) {
    borderBottomWidth_0(this.style_0, value);
  };
  KatydidBorderBottomStyleBuilder.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidBorderBottomStyleBuilder',
    interfaces: []
  };
  function KatydidBorderLeftStyleBuilder(style) {
    this.style_0 = style;
  }
  KatydidBorderLeftStyleBuilder.prototype.color_btlm55$ = function (value) {
    borderLeftColor(this.style_0, value);
  };
  KatydidBorderLeftStyleBuilder.prototype.style_w2hgcf$ = function (value) {
    borderLeftStyle(this.style_0, value);
  };
  KatydidBorderLeftStyleBuilder.prototype.width_w0hq7e$ = function (value) {
    borderLeftWidth(this.style_0, value);
  };
  KatydidBorderLeftStyleBuilder.prototype.width_n0fawn$ = function (value) {
    borderLeftWidth_0(this.style_0, value);
  };
  KatydidBorderLeftStyleBuilder.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidBorderLeftStyleBuilder',
    interfaces: []
  };
  function KatydidBorderRightStyleBuilder(style) {
    this.style_0 = style;
  }
  KatydidBorderRightStyleBuilder.prototype.color_btlm55$ = function (value) {
    borderRightColor(this.style_0, value);
  };
  KatydidBorderRightStyleBuilder.prototype.style_w2hgcf$ = function (value) {
    borderRightStyle(this.style_0, value);
  };
  KatydidBorderRightStyleBuilder.prototype.width_w0hq7e$ = function (value) {
    borderRightWidth(this.style_0, value);
  };
  KatydidBorderRightStyleBuilder.prototype.width_n0fawn$ = function (value) {
    borderRightWidth_0(this.style_0, value);
  };
  KatydidBorderRightStyleBuilder.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidBorderRightStyleBuilder',
    interfaces: []
  };
  function KatydidBorderTopStyleBuilder(style) {
    this.style_0 = style;
  }
  KatydidBorderTopStyleBuilder.prototype.color_btlm55$ = function (value) {
    borderTopColor(this.style_0, value);
  };
  KatydidBorderTopStyleBuilder.prototype.style_w2hgcf$ = function (value) {
    borderTopStyle(this.style_0, value);
  };
  KatydidBorderTopStyleBuilder.prototype.width_w0hq7e$ = function (value) {
    borderTopWidth(this.style_0, value);
  };
  KatydidBorderTopStyleBuilder.prototype.width_n0fawn$ = function (value) {
    borderTopWidth_0(this.style_0, value);
  };
  KatydidBorderTopStyleBuilder.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidBorderTopStyleBuilder',
    interfaces: []
  };
  function KatydidBorderStyleBuilder(style) {
    this.style_0 = style;
  }
  KatydidBorderStyleBuilder.prototype.bottom_979gdm$ = function (build) {
    build(new KatydidBorderBottomStyleBuilder(this.style_0));
  };
  KatydidBorderStyleBuilder.prototype.bottom_qjr16g$ = function (lineStyle, color) {
    if (lineStyle === void 0)
      lineStyle = null;
    if (color === void 0)
      color = null;
    borderBottom(this.style_0, lineStyle, color);
  };
  KatydidBorderStyleBuilder.prototype.bottom_u02gwy$ = function (width, lineStyle, color) {
    if (lineStyle === void 0)
      lineStyle = null;
    if (color === void 0)
      color = null;
    borderBottom_0(this.style_0, width, lineStyle, color);
  };
  KatydidBorderStyleBuilder.prototype.bottom_cqj5uz$ = function (width, lineStyle, color) {
    if (lineStyle === void 0)
      lineStyle = null;
    if (color === void 0)
      color = null;
    borderBottom_1(this.style_0, width, lineStyle, color);
  };
  KatydidBorderStyleBuilder.prototype.color_r6kar0$ = function (top, right, bottom, left) {
    if (right === void 0)
      right = top;
    if (bottom === void 0)
      bottom = top;
    if (left === void 0)
      left = right;
    borderColor(this.style_0, top, right, bottom, left);
  };
  KatydidBorderStyleBuilder.prototype.left_yf10y6$ = function (build) {
    build(new KatydidBorderLeftStyleBuilder(this.style_0));
  };
  KatydidBorderStyleBuilder.prototype.left_qjr16g$ = function (lineStyle, color) {
    if (lineStyle === void 0)
      lineStyle = null;
    if (color === void 0)
      color = null;
    borderLeft(this.style_0, lineStyle, color);
  };
  KatydidBorderStyleBuilder.prototype.left_u02gwy$ = function (width, lineStyle, color) {
    if (lineStyle === void 0)
      lineStyle = null;
    if (color === void 0)
      color = null;
    borderLeft_0(this.style_0, width, lineStyle, color);
  };
  KatydidBorderStyleBuilder.prototype.left_cqj5uz$ = function (width, lineStyle, color) {
    if (lineStyle === void 0)
      lineStyle = null;
    if (color === void 0)
      color = null;
    borderLeft_1(this.style_0, width, lineStyle, color);
  };
  KatydidBorderStyleBuilder.prototype.right_w33edf$ = function (build) {
    build(new KatydidBorderRightStyleBuilder(this.style_0));
  };
  KatydidBorderStyleBuilder.prototype.right_qjr16g$ = function (lineStyle, color) {
    if (lineStyle === void 0)
      lineStyle = null;
    if (color === void 0)
      color = null;
    borderRight(this.style_0, lineStyle, color);
  };
  KatydidBorderStyleBuilder.prototype.right_u02gwy$ = function (width, lineStyle, color) {
    if (lineStyle === void 0)
      lineStyle = null;
    if (color === void 0)
      color = null;
    borderRight_0(this.style_0, width, lineStyle, color);
  };
  KatydidBorderStyleBuilder.prototype.right_cqj5uz$ = function (width, lineStyle, color) {
    if (lineStyle === void 0)
      lineStyle = null;
    if (color === void 0)
      color = null;
    borderRight_1(this.style_0, width, lineStyle, color);
  };
  KatydidBorderStyleBuilder.prototype.style_9djfro$ = function (top, right, bottom, left) {
    if (right === void 0)
      right = top;
    if (bottom === void 0)
      bottom = top;
    if (left === void 0)
      left = right;
    borderStyle(this.style_0, top, right, bottom, left);
  };
  KatydidBorderStyleBuilder.prototype.top_m31422$ = function (build) {
    build(new KatydidBorderTopStyleBuilder(this.style_0));
  };
  KatydidBorderStyleBuilder.prototype.top_qjr16g$ = function (lineStyle, color) {
    if (lineStyle === void 0)
      lineStyle = null;
    if (color === void 0)
      color = null;
    borderTop(this.style_0, lineStyle, color);
  };
  KatydidBorderStyleBuilder.prototype.top_u02gwy$ = function (width, lineStyle, color) {
    if (lineStyle === void 0)
      lineStyle = null;
    if (color === void 0)
      color = null;
    borderTop_0(this.style_0, width, lineStyle, color);
  };
  KatydidBorderStyleBuilder.prototype.top_cqj5uz$ = function (width, lineStyle, color) {
    if (lineStyle === void 0)
      lineStyle = null;
    if (color === void 0)
      color = null;
    borderTop_1(this.style_0, width, lineStyle, color);
  };
  KatydidBorderStyleBuilder.prototype.width_tj71nw$ = function (top, right, bottom, left) {
    if (right === void 0)
      right = top;
    if (bottom === void 0)
      bottom = top;
    if (left === void 0)
      left = right;
    borderWidth(this.style_0, top, right, bottom, left);
  };
  KatydidBorderStyleBuilder.prototype.width_8rgskg$ = function (top, right, bottom, left) {
    if (right === void 0)
      right = top;
    if (bottom === void 0)
      bottom = top;
    if (left === void 0)
      left = right;
    borderWidth_0(this.style_0, top, right, bottom, left);
  };
  KatydidBorderStyleBuilder.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidBorderStyleBuilder',
    interfaces: []
  };
  function border($receiver, build) {
    build(new KatydidBorderStyleBuilder($receiver));
  }
  function border_0($receiver, style, color) {
    if (style === void 0)
      style = null;
    if (color === void 0)
      color = null;
    setBorderProperty($receiver, 'border', '', style, color);
  }
  function border_1($receiver, width, style, color) {
    if (style === void 0)
      style = null;
    if (color === void 0)
      color = null;
    setBorderProperty($receiver, 'border', width, style, color);
  }
  function border_2($receiver, width, style, color) {
    if (style === void 0)
      style = null;
    if (color === void 0)
      color = null;
    setBorderProperty($receiver, 'border', width, style, color);
  }
  function borderBottom($receiver, style, color) {
    if (style === void 0)
      style = null;
    if (color === void 0)
      color = null;
    setBorderProperty($receiver, 'border-bottom', '', style, color);
  }
  function borderBottom_0($receiver, width, style, color) {
    if (style === void 0)
      style = null;
    if (color === void 0)
      color = null;
    setBorderProperty($receiver, 'border-bottom', width, style, color);
  }
  function borderBottom_1($receiver, width, style, color) {
    if (style === void 0)
      style = null;
    if (color === void 0)
      color = null;
    setBorderProperty($receiver, 'border-bottom', width, style, color);
  }
  function borderBottomColor($receiver, value) {
    $receiver.setProperty_puj7f4$('border-bottom-color', value.toString());
  }
  function borderBottomStyle($receiver, value) {
    $receiver.setProperty_puj7f4$('border-bottom-style', value.toString());
  }
  function borderBottomWidth($receiver, value) {
    $receiver.setProperty_puj7f4$('border-bottom-width', value.toString());
  }
  function borderBottomWidth_0($receiver, value) {
    $receiver.setProperty_puj7f4$('border-bottom-width', value.toString());
  }
  function borderColor($receiver, top, right, bottom, left) {
    if (right === void 0)
      right = top;
    if (bottom === void 0)
      bottom = top;
    if (left === void 0)
      left = right;
    $receiver.setBoxProperty_hto8b4$('border-color', top, right, bottom, left);
  }
  function borderLeft($receiver, style, color) {
    if (style === void 0)
      style = null;
    if (color === void 0)
      color = null;
    setBorderProperty($receiver, 'border-left', '', style, color);
  }
  function borderLeft_0($receiver, width, style, color) {
    if (style === void 0)
      style = null;
    if (color === void 0)
      color = null;
    setBorderProperty($receiver, 'border-left', width, style, color);
  }
  function borderLeft_1($receiver, width, style, color) {
    if (style === void 0)
      style = null;
    if (color === void 0)
      color = null;
    setBorderProperty($receiver, 'border-left', width, style, color);
  }
  function borderLeftColor($receiver, value) {
    $receiver.setProperty_puj7f4$('border-left-color', value.toString());
  }
  function borderLeftStyle($receiver, value) {
    $receiver.setProperty_puj7f4$('border-left-style', value.toString());
  }
  function borderLeftWidth($receiver, value) {
    $receiver.setProperty_puj7f4$('border-left-width', value.toString());
  }
  function borderLeftWidth_0($receiver, value) {
    $receiver.setProperty_puj7f4$('border-left-width', value.toString());
  }
  function borderRight($receiver, style, color) {
    if (style === void 0)
      style = null;
    if (color === void 0)
      color = null;
    setBorderProperty($receiver, 'border-right', '', style, color);
  }
  function borderRight_0($receiver, width, style, color) {
    if (style === void 0)
      style = null;
    if (color === void 0)
      color = null;
    setBorderProperty($receiver, 'border-right', width, style, color);
  }
  function borderRight_1($receiver, width, style, color) {
    if (style === void 0)
      style = null;
    if (color === void 0)
      color = null;
    setBorderProperty($receiver, 'border-right', width, style, color);
  }
  function borderRightColor($receiver, value) {
    $receiver.setProperty_puj7f4$('border-right-color', value.toString());
  }
  function borderRightStyle($receiver, value) {
    $receiver.setProperty_puj7f4$('border-right-style', value.toString());
  }
  function borderRightWidth($receiver, value) {
    $receiver.setProperty_puj7f4$('border-right-width', value.toString());
  }
  function borderRightWidth_0($receiver, value) {
    $receiver.setProperty_puj7f4$('border-right-width', value.toString());
  }
  function borderStyle($receiver, top, right, bottom, left) {
    if (right === void 0)
      right = top;
    if (bottom === void 0)
      bottom = top;
    if (left === void 0)
      left = right;
    $receiver.setBoxProperty_hto8b4$('border-style', top, right, bottom, left);
  }
  function borderTop($receiver, style, color) {
    if (style === void 0)
      style = null;
    if (color === void 0)
      color = null;
    setBorderProperty($receiver, 'border-top', '', style, color);
  }
  function borderTop_0($receiver, width, style, color) {
    if (style === void 0)
      style = null;
    if (color === void 0)
      color = null;
    setBorderProperty($receiver, 'border-top', width, style, color);
  }
  function borderTop_1($receiver, width, style, color) {
    if (style === void 0)
      style = null;
    if (color === void 0)
      color = null;
    setBorderProperty($receiver, 'border-top', width, style, color);
  }
  function borderTopColor($receiver, value) {
    $receiver.setProperty_puj7f4$('border-top-color', value.toString());
  }
  function borderTopStyle($receiver, value) {
    $receiver.setProperty_puj7f4$('border-top-style', value.toString());
  }
  function borderTopWidth($receiver, value) {
    $receiver.setProperty_puj7f4$('border-top-width', value.toString());
  }
  function borderTopWidth_0($receiver, value) {
    $receiver.setProperty_puj7f4$('border-top-width', value.toString());
  }
  function borderWidth($receiver, top, right, bottom, left) {
    if (right === void 0)
      right = top;
    if (bottom === void 0)
      bottom = top;
    if (left === void 0)
      left = right;
    $receiver.setBoxProperty_hto8b4$('border-width', top, right, bottom, left);
  }
  function borderWidth_0($receiver, top, right, bottom, left) {
    if (right === void 0)
      right = top;
    if (bottom === void 0)
      bottom = top;
    if (left === void 0)
      left = right;
    $receiver.setBoxProperty_hto8b4$('border-width', top, right, bottom, left);
  }
  function setBorderProperty($receiver, key, width, style, color) {
    var css = toString(width);
    if (style != null) {
      css += ' ' + toString(style);
    }
    if (color != null) {
      css += ' ' + toString(color);
    }
    if (!(css.length > 0)) {
      var message = 'Specify at least one non-null parameter for ' + key + '.';
      throw IllegalArgumentException_init(message.toString());
    }
    var tmp$;
    $receiver.setProperty_puj7f4$(key, trim(Kotlin.isCharSequence(tmp$ = css) ? tmp$ : throwCCE()).toString());
  }
  function boxSizing($receiver, value) {
    $receiver.setProperty_puj7f4$('box-sizing', value.toString());
  }
  function KatydidCaretStyleBuilder(style) {
    this.style_0 = style;
  }
  KatydidCaretStyleBuilder.prototype.color_btlm55$ = function (value) {
    caretColor(this.style_0, value);
  };
  KatydidCaretStyleBuilder.prototype.color_r2yjbf$ = function (value) {
    caretColor_0(this.style_0, value);
  };
  KatydidCaretStyleBuilder.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidCaretStyleBuilder',
    interfaces: []
  };
  function caret($receiver, build) {
    build(new KatydidCaretStyleBuilder($receiver));
  }
  function caretColor($receiver, value) {
    $receiver.setProperty_puj7f4$('caret-color', value.toString());
  }
  function caretColor_0($receiver, value) {
    $receiver.setProperty_puj7f4$('caret-color', value.toString());
  }
  function color($receiver, value) {
    $receiver.setProperty_puj7f4$('color', value.toString());
  }
  function opacity($receiver, value) {
    if (value <= 0)
      $receiver.setProperty_puj7f4$('opacity', '0');
    else if (value >= 1)
      $receiver.setProperty_puj7f4$('opacity', '1');
    else
      $receiver.setProperty_puj7f4$('opacity', makeDecimalString(value));
  }
  function content($receiver, value) {
    $receiver.setProperty_puj7f4$('content', value.toString());
  }
  function content_0($receiver, value) {
    $receiver.setStringProperty_puj7f4$('content', value);
  }
  function cursor($receiver, value) {
    $receiver.setProperty_puj7f4$('cursor', value.toString());
  }
  function display($receiver, value) {
    $receiver.setProperty_puj7f4$('display', value.toString());
  }
  function clear($receiver, value) {
    $receiver.setProperty_puj7f4$('clear', value.toString());
  }
  function float($receiver, value) {
    $receiver.setProperty_puj7f4$('float', value.toString());
  }
  function KatydidFontStyleBuilder(style) {
    this.style_0 = style;
  }
  KatydidFontStyleBuilder.prototype.family_vqirvp$ = function (values) {
    fontFamily(this.style_0, values.slice());
  };
  KatydidFontStyleBuilder.prototype.size_a29zlg$ = function (value) {
    fontSize(this.style_0, value);
  };
  KatydidFontStyleBuilder.prototype.size_n0fawn$ = function (value) {
    fontSize_0(this.style_0, value);
  };
  KatydidFontStyleBuilder.prototype.size_rtt64d$ = function (value) {
    fontSize_1(this.style_0, value);
  };
  KatydidFontStyleBuilder.prototype.style_rtyf7e$ = function (value) {
    fontStyle(this.style_0, value);
  };
  KatydidFontStyleBuilder.prototype.variant_443ppi$ = function (value) {
    fontVariant(this.style_0, value);
  };
  KatydidFontStyleBuilder.prototype.weight_8rn6bh$ = function (value) {
    fontWeight(this.style_0, value);
  };
  KatydidFontStyleBuilder.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidFontStyleBuilder',
    interfaces: []
  };
  function font($receiver, build) {
    build(new KatydidFontStyleBuilder($receiver));
  }
  function fontFamily($receiver, values) {
    var tmp$;
    var css = '';
    var delimiter = '';
    for (tmp$ = 0; tmp$ !== values.length; ++tmp$) {
      var value = values[tmp$];
      css += delimiter;
      delimiter = ', ';
      if (Regex_init('[a-zA-Z-]+').matches_6bul2c$(value)) {
        css += value;
      }
       else {
        css += '"';
        css += value;
        css += '"';
      }
    }
    var tmp$_0;
    $receiver.setProperty_puj7f4$('font-family', trim(Kotlin.isCharSequence(tmp$_0 = css) ? tmp$_0 : throwCCE()).toString());
  }
  function fontSize($receiver, value) {
    $receiver.setProperty_puj7f4$('font-size', value.toString());
  }
  function fontSize_0($receiver, value) {
    $receiver.setProperty_puj7f4$('font-size', value.toString());
  }
  function fontSize_1($receiver, value) {
    $receiver.setProperty_puj7f4$('font-size', value.toString());
  }
  function fontStyle($receiver, value) {
    $receiver.setProperty_puj7f4$('font-style', value.toString());
  }
  function fontVariant($receiver, value) {
    $receiver.setProperty_puj7f4$('font-variant', value.toString());
  }
  function fontWeight($receiver, value) {
    $receiver.setProperty_puj7f4$('font-weight', value.toString());
  }
  function KatydidLineStyleBuilder(style) {
    this.style_0 = style;
  }
  KatydidLineStyleBuilder.prototype.height_n0fawn$ = function (value) {
    lineHeight(this.style_0, value);
  };
  KatydidLineStyleBuilder.prototype.height_rtt64d$ = function (value) {
    lineHeight_0(this.style_0, value);
  };
  KatydidLineStyleBuilder.prototype.height_mx4ult$ = function (value) {
    lineHeight_1(this.style_0, value);
  };
  KatydidLineStyleBuilder.prototype.height_yqynb7$ = function (value) {
    lineHeight_2(this.style_0, value);
  };
  KatydidLineStyleBuilder.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidLineStyleBuilder',
    interfaces: []
  };
  function letterSpacing($receiver, value) {
    $receiver.setProperty_puj7f4$('letter-spacing', value.toString());
  }
  function letterSpacing_0($receiver, value) {
    $receiver.setProperty_puj7f4$('letter-spacing', value.toString());
  }
  function line($receiver, build) {
    build(new KatydidLineStyleBuilder($receiver));
  }
  function lineHeight($receiver, value) {
    $receiver.setProperty_puj7f4$('line-height', value.toString());
  }
  function lineHeight_0($receiver, value) {
    $receiver.setProperty_puj7f4$('line-height', value.toString());
  }
  function lineHeight_1($receiver, value) {
    $receiver.setProperty_puj7f4$('line-height', makeDecimalString(value));
  }
  function lineHeight_2($receiver, value) {
    $receiver.setProperty_puj7f4$('line-height', value.toString());
  }
  function KatydidListStyleBuilder(style) {
    this.style_0 = style;
  }
  KatydidListStyleBuilder.prototype.image_cpd681$ = function (value) {
    listStyleImage(this.style_0, value);
  };
  KatydidListStyleBuilder.prototype.position_uiljc0$ = function (value) {
    listStylePosition(this.style_0, value);
  };
  KatydidListStyleBuilder.prototype.type_6yliep$ = function (value) {
    listStyleType(this.style_0, value);
  };
  KatydidListStyleBuilder.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidListStyleBuilder',
    interfaces: []
  };
  function listStyle($receiver, build) {
    build(new KatydidListStyleBuilder($receiver));
  }
  function listStyle_0($receiver, type, position, imageUrl) {
    if (position === void 0)
      position = null;
    if (imageUrl === void 0)
      imageUrl = null;
    var css = type.toString();
    if (position != null) {
      css += ' ' + toString(position);
    }
    if (imageUrl != null) {
      css += ' url(' + '"' + toString(imageUrl) + '"' + ')';
    }
    $receiver.setProperty_puj7f4$('list-style', css);
  }
  function listStyleImage($receiver, value) {
    $receiver.setProperty_puj7f4$('list-style-image', value.toString());
  }
  function listStylePosition($receiver, value) {
    $receiver.setProperty_puj7f4$('list-style-position', value.toString());
  }
  function listStyleType($receiver, value) {
    $receiver.setProperty_puj7f4$('list-style-type', value.toString());
  }
  function KatydidMarginStyleBuilder(style) {
    this.style_0 = style;
  }
  KatydidMarginStyleBuilder.prototype.bottom_n0fawn$ = function (value) {
    marginBottom(this.style_0, value);
  };
  KatydidMarginStyleBuilder.prototype.bottom_rtt64d$ = function (value) {
    marginBottom_0(this.style_0, value);
  };
  KatydidMarginStyleBuilder.prototype.bottom_r2yjbf$ = function (value) {
    marginBottom_1(this.style_0, value);
  };
  KatydidMarginStyleBuilder.prototype.left_n0fawn$ = function (value) {
    marginLeft(this.style_0, value);
  };
  KatydidMarginStyleBuilder.prototype.left_rtt64d$ = function (value) {
    marginLeft_0(this.style_0, value);
  };
  KatydidMarginStyleBuilder.prototype.left_r2yjbf$ = function (value) {
    marginLeft_1(this.style_0, value);
  };
  KatydidMarginStyleBuilder.prototype.right_n0fawn$ = function (value) {
    marginRight(this.style_0, value);
  };
  KatydidMarginStyleBuilder.prototype.right_rtt64d$ = function (value) {
    marginRight_0(this.style_0, value);
  };
  KatydidMarginStyleBuilder.prototype.right_r2yjbf$ = function (value) {
    marginRight_1(this.style_0, value);
  };
  KatydidMarginStyleBuilder.prototype.top_n0fawn$ = function (value) {
    marginTop(this.style_0, value);
  };
  KatydidMarginStyleBuilder.prototype.top_rtt64d$ = function (value) {
    marginTop_0(this.style_0, value);
  };
  KatydidMarginStyleBuilder.prototype.top_r2yjbf$ = function (value) {
    marginTop_1(this.style_0, value);
  };
  KatydidMarginStyleBuilder.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidMarginStyleBuilder',
    interfaces: []
  };
  function margin($receiver, build) {
    build(new KatydidMarginStyleBuilder($receiver));
  }
  function margin_0($receiver, top, right, bottom, left) {
    if (right === void 0)
      right = top;
    if (bottom === void 0)
      bottom = top;
    if (left === void 0)
      left = right;
    $receiver.setBoxProperty_hto8b4$('margin', top, right, bottom, left);
  }
  function margin_1($receiver, top, right, bottom, left) {
    if (right === void 0)
      right = top;
    if (bottom === void 0)
      bottom = top;
    if (left === void 0)
      left = right;
    $receiver.setBoxProperty_hto8b4$('margin', top, right, bottom, left);
  }
  function margin_2($receiver, value) {
    $receiver.setProperty_puj7f4$('margin', value.toString());
  }
  function marginBottom($receiver, value) {
    $receiver.setProperty_puj7f4$('margin-bottom', value.toString());
  }
  function marginBottom_0($receiver, value) {
    $receiver.setProperty_puj7f4$('margin-bottom', value.toString());
  }
  function marginBottom_1($receiver, value) {
    $receiver.setProperty_puj7f4$('margin-bottom', value.toString());
  }
  function marginLeft($receiver, value) {
    $receiver.setProperty_puj7f4$('margin-left', value.toString());
  }
  function marginLeft_0($receiver, value) {
    $receiver.setProperty_puj7f4$('margin-left', value.toString());
  }
  function marginLeft_1($receiver, value) {
    $receiver.setProperty_puj7f4$('margin-left', value.toString());
  }
  function marginRight($receiver, value) {
    $receiver.setProperty_puj7f4$('margin-right', value.toString());
  }
  function marginRight_0($receiver, value) {
    $receiver.setProperty_puj7f4$('margin-right', value.toString());
  }
  function marginRight_1($receiver, value) {
    $receiver.setProperty_puj7f4$('margin-right', value.toString());
  }
  function marginTop($receiver, value) {
    $receiver.setProperty_puj7f4$('margin-top', value.toString());
  }
  function marginTop_0($receiver, value) {
    $receiver.setProperty_puj7f4$('margin-top', value.toString());
  }
  function marginTop_1($receiver, value) {
    $receiver.setProperty_puj7f4$('margin-top', value.toString());
  }
  function KatydidOutlineStyleBuilder(style) {
    this.style_0 = style;
  }
  KatydidOutlineStyleBuilder.prototype.color_btlm55$ = function (value) {
    outlineColor(this.style_0, value);
  };
  KatydidOutlineStyleBuilder.prototype.color_pfzv19$ = function (value) {
    outlineColor_0(this.style_0, value);
  };
  KatydidOutlineStyleBuilder.prototype.offset_n0fawn$ = function (value) {
    outlineOffset(this.style_0, value);
  };
  KatydidOutlineStyleBuilder.prototype.style_w2hgcf$ = function (value) {
    outlineStyle(this.style_0, value);
  };
  KatydidOutlineStyleBuilder.prototype.width_w0hq7e$ = function (value) {
    outlineWidth(this.style_0, value);
  };
  KatydidOutlineStyleBuilder.prototype.width_n0fawn$ = function (value) {
    outlineWidth_0(this.style_0, value);
  };
  KatydidOutlineStyleBuilder.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidOutlineStyleBuilder',
    interfaces: []
  };
  function outline($receiver, build) {
    build(new KatydidOutlineStyleBuilder($receiver));
  }
  function outline_0($receiver, color, style, width) {
    $receiver.setProperty_puj7f4$('outline', color.toString() + ' ' + style + ' ' + width);
  }
  function outline_1($receiver, color, style, width) {
    $receiver.setProperty_puj7f4$('outline', color.toString() + ' ' + style + ' ' + width);
  }
  function outline_2($receiver, color, style, width) {
    $receiver.setProperty_puj7f4$('outline', color.toString() + ' ' + style + ' ' + width);
  }
  function outline_3($receiver, color, style, width) {
    $receiver.setProperty_puj7f4$('outline', color.toString() + ' ' + style + ' ' + width);
  }
  function outlineColor($receiver, value) {
    $receiver.setProperty_puj7f4$('outline-color', value.toString());
  }
  function outlineColor_0($receiver, value) {
    $receiver.setProperty_puj7f4$('outline-color', value.toString());
  }
  function outlineOffset($receiver, value) {
    $receiver.setProperty_puj7f4$('outline-offset', value.toString());
  }
  function outlineStyle($receiver, value) {
    $receiver.setProperty_puj7f4$('outline-style', value.toString());
  }
  function outlineWidth($receiver, value) {
    $receiver.setProperty_puj7f4$('outline-width', value.toString());
  }
  function outlineWidth_0($receiver, value) {
    $receiver.setProperty_puj7f4$('outline-width', value.toString());
  }
  function KatydidOverflowStyleBuilder(style) {
    this.style_0 = style;
  }
  KatydidOverflowStyleBuilder.prototype.x_7cm0de$ = function (value) {
    overflowX(this.style_0, value);
  };
  KatydidOverflowStyleBuilder.prototype.y_7cm0de$ = function (value) {
    overflowY(this.style_0, value);
  };
  KatydidOverflowStyleBuilder.prototype.wrap_w396uw$ = function (value) {
    overflowWrap(this.style_0, value);
  };
  KatydidOverflowStyleBuilder.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidOverflowStyleBuilder',
    interfaces: []
  };
  function overflow($receiver, build) {
    build(new KatydidOverflowStyleBuilder($receiver));
  }
  function overflow_0($receiver, x, y) {
    if (y === void 0)
      y = x;
    $receiver.setXyProperty_l8dco4$('overflow', x, y);
  }
  function overflowX($receiver, value) {
    $receiver.setProperty_puj7f4$('overflow-x', value.toString());
  }
  function overflowY($receiver, value) {
    $receiver.setProperty_puj7f4$('overflow-y', value.toString());
  }
  function overflowWrap($receiver, value) {
    $receiver.setProperty_puj7f4$('overflow-wrap', value.toString());
  }
  function resize($receiver, value) {
    $receiver.setProperty_puj7f4$('resize', value.toString());
  }
  function KatydidPaddingStyleBuilder(style) {
    this.style_0 = style;
  }
  KatydidPaddingStyleBuilder.prototype.bottom_n0fawn$ = function (value) {
    paddingBottom(this.style_0, value);
  };
  KatydidPaddingStyleBuilder.prototype.bottom_rtt64d$ = function (value) {
    paddingBottom_0(this.style_0, value);
  };
  KatydidPaddingStyleBuilder.prototype.left_n0fawn$ = function (value) {
    paddingLeft(this.style_0, value);
  };
  KatydidPaddingStyleBuilder.prototype.left_rtt64d$ = function (value) {
    paddingLeft_0(this.style_0, value);
  };
  KatydidPaddingStyleBuilder.prototype.right_n0fawn$ = function (value) {
    paddingRight(this.style_0, value);
  };
  KatydidPaddingStyleBuilder.prototype.right_rtt64d$ = function (value) {
    paddingRight_0(this.style_0, value);
  };
  KatydidPaddingStyleBuilder.prototype.top_n0fawn$ = function (value) {
    paddingTop(this.style_0, value);
  };
  KatydidPaddingStyleBuilder.prototype.top_rtt64d$ = function (value) {
    paddingTop_0(this.style_0, value);
  };
  KatydidPaddingStyleBuilder.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidPaddingStyleBuilder',
    interfaces: []
  };
  function padding($receiver, build) {
    build(new KatydidPaddingStyleBuilder($receiver));
  }
  function padding_0($receiver, top, right, bottom, left) {
    if (right === void 0)
      right = top;
    if (bottom === void 0)
      bottom = top;
    if (left === void 0)
      left = right;
    $receiver.setBoxProperty_hto8b4$('padding', top, right, bottom, left);
  }
  function padding_1($receiver, top, right, bottom, left) {
    if (right === void 0)
      right = top;
    if (bottom === void 0)
      bottom = top;
    if (left === void 0)
      left = right;
    $receiver.setBoxProperty_hto8b4$('padding', top, right, bottom, left);
  }
  function paddingBottom($receiver, value) {
    $receiver.setProperty_puj7f4$('padding-bottom', value.toString());
  }
  function paddingBottom_0($receiver, value) {
    $receiver.setProperty_puj7f4$('padding-bottom', value.toString());
  }
  function paddingLeft($receiver, value) {
    $receiver.setProperty_puj7f4$('padding-left', value.toString());
  }
  function paddingLeft_0($receiver, value) {
    $receiver.setProperty_puj7f4$('padding-left', value.toString());
  }
  function paddingRight($receiver, value) {
    $receiver.setProperty_puj7f4$('padding-right', value.toString());
  }
  function paddingRight_0($receiver, value) {
    $receiver.setProperty_puj7f4$('padding-right', value.toString());
  }
  function paddingTop($receiver, value) {
    $receiver.setProperty_puj7f4$('padding-top', value.toString());
  }
  function paddingTop_0($receiver, value) {
    $receiver.setProperty_puj7f4$('padding-top', value.toString());
  }
  function KatydidPageBreakStyleBuilder(style) {
    this.style_0 = style;
  }
  KatydidPageBreakStyleBuilder.prototype.after_bzov4k$ = function (value) {
    pageBreakAfter(this.style_0, value);
  };
  KatydidPageBreakStyleBuilder.prototype.before_bzov4k$ = function (value) {
    pageBreakBefore(this.style_0, value);
  };
  KatydidPageBreakStyleBuilder.prototype.inside_f7fs8g$ = function (value) {
    pageBreakInside(this.style_0, value);
  };
  KatydidPageBreakStyleBuilder.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidPageBreakStyleBuilder',
    interfaces: []
  };
  function pageBreak($receiver, build) {
    build(new KatydidPageBreakStyleBuilder($receiver));
  }
  function pageBreakAfter($receiver, value) {
    $receiver.setProperty_puj7f4$('page-break-after', value.toString());
  }
  function pageBreakBefore($receiver, value) {
    $receiver.setProperty_puj7f4$('page-break-before', value.toString());
  }
  function pageBreakInside($receiver, value) {
    $receiver.setProperty_puj7f4$('page-break-inside', value.toString());
  }
  function bottom($receiver, value) {
    $receiver.setProperty_puj7f4$('bottom', value.toString());
  }
  function bottom_0($receiver, value) {
    $receiver.setProperty_puj7f4$('bottom', value.toString());
  }
  function bottom_1($receiver, value) {
    $receiver.setProperty_puj7f4$('bottom', value.toString());
  }
  function left($receiver, value) {
    $receiver.setProperty_puj7f4$('left', value.toString());
  }
  function left_0($receiver, value) {
    $receiver.setProperty_puj7f4$('left', value.toString());
  }
  function left_1($receiver, value) {
    $receiver.setProperty_puj7f4$('left', value.toString());
  }
  function position($receiver, value) {
    $receiver.setProperty_puj7f4$('position', value.toString());
  }
  function right($receiver, value) {
    $receiver.setProperty_puj7f4$('right', value.toString());
  }
  function right_0($receiver, value) {
    $receiver.setProperty_puj7f4$('right', value.toString());
  }
  function right_1($receiver, value) {
    $receiver.setProperty_puj7f4$('right', value.toString());
  }
  function top($receiver, value) {
    $receiver.setProperty_puj7f4$('top', value.toString());
  }
  function top_0($receiver, value) {
    $receiver.setProperty_puj7f4$('top', value.toString());
  }
  function top_1($receiver, value) {
    $receiver.setProperty_puj7f4$('top', value.toString());
  }
  function zIndex($receiver, value) {
    $receiver.setProperty_puj7f4$('z-index', value.toString());
  }
  function zIndex_0($receiver, value) {
    $receiver.setProperty_puj7f4$('z-index', value.toString());
  }
  function KatydidStyleBuilderDsl() {
  }
  KatydidStyleBuilderDsl.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidStyleBuilderDsl',
    interfaces: [Annotation]
  };
  function borderCollapse($receiver, value) {
    $receiver.setProperty_puj7f4$('border-collapse', value.toString());
  }
  function borderSpacing($receiver, horizontal, vertical) {
    if (vertical === void 0)
      vertical = horizontal;
    $receiver.setXyProperty_l8dco4$('border-spacing', horizontal, vertical);
  }
  function captionSide($receiver, value) {
    $receiver.setProperty_puj7f4$('caption-side', value.toString());
  }
  function emptyCells($receiver, value) {
    $receiver.setProperty_puj7f4$('empty-cells', value.toString());
  }
  function tableLayout($receiver, value) {
    $receiver.setProperty_puj7f4$('table-layout', value.toString());
  }
  function KatydidTextDecorationStyleBuilder(style) {
    this.style_0 = style;
  }
  KatydidTextDecorationStyleBuilder.prototype.color_btlm55$ = function (value) {
    textDecorationColor(this.style_0, value);
  };
  KatydidTextDecorationStyleBuilder.prototype.line_r36pjo$ = function (value) {
    textDecorationLine(this.style_0, value);
  };
  KatydidTextDecorationStyleBuilder.prototype.line_ms8f12$ = function (values) {
    textDecorationLine_0(this.style_0, values.slice());
  };
  KatydidTextDecorationStyleBuilder.prototype.style_1zqmnc$ = function (value) {
    textDecorationStyle(this.style_0, value);
  };
  KatydidTextDecorationStyleBuilder.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidTextDecorationStyleBuilder',
    interfaces: []
  };
  function KatydidTextStyleBuilder(style) {
    this.style_0 = style;
  }
  KatydidTextStyleBuilder.prototype.align_jsxxdw$ = function (value) {
    textAlign(this.style_0, value);
  };
  KatydidTextStyleBuilder.prototype.alignAll_jsxxdw$ = function (value) {
    textAlignAll(this.style_0, value);
  };
  KatydidTextStyleBuilder.prototype.alignLast_jsxxdw$ = function (value) {
    textAlignLast(this.style_0, value);
  };
  KatydidTextStyleBuilder.prototype.decoration_5rp38k$ = function (build) {
    build(new KatydidTextDecorationStyleBuilder(this.style_0));
  };
  KatydidTextStyleBuilder.prototype.decoration_r36pjo$ = function (value) {
    textDecoration(this.style_0, value);
  };
  KatydidTextStyleBuilder.prototype.decoration_rs5uks$ = function (line, decorationStyle, color, moreLines) {
    if (line === void 0)
      line = null;
    if (decorationStyle === void 0)
      decorationStyle = null;
    if (color === void 0)
      color = null;
    if (moreLines === void 0)
      moreLines = [];
    textDecoration_0(this.style_0, line, decorationStyle, color, moreLines.slice());
  };
  KatydidTextStyleBuilder.prototype.decorationColor_btlm55$ = function (value) {
    textDecorationColor(this.style_0, value);
  };
  KatydidTextStyleBuilder.prototype.decorationLine_r36pjo$ = function (value) {
    textDecorationLine(this.style_0, value);
  };
  KatydidTextStyleBuilder.prototype.decorationLine_ms8f12$ = function (values) {
    textDecorationLine_0(this.style_0, values.slice());
  };
  KatydidTextStyleBuilder.prototype.decorationStyle_1zqmnc$ = function (value) {
    textDecorationStyle(this.style_0, value);
  };
  KatydidTextStyleBuilder.prototype.indent_n0fawn$ = function (value) {
    textIndent(this.style_0, value);
  };
  KatydidTextStyleBuilder.prototype.indent_rtt64d$ = function (value) {
    textIndent_0(this.style_0, value);
  };
  KatydidTextStyleBuilder.prototype.justify_v096h$ = function (value) {
    textJustify(this.style_0, value);
  };
  KatydidTextStyleBuilder.prototype.overflow_gmpgd1$ = function (value) {
    textOverflow(this.style_0, value);
  };
  KatydidTextStyleBuilder.prototype.transform_bnnfkz$ = function (value) {
    textTransform(this.style_0, value);
  };
  KatydidTextStyleBuilder.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidTextStyleBuilder',
    interfaces: []
  };
  function tabSize($receiver, value) {
    if (!(value >= 0)) {
      var message = "Tab size cannot be negative: '" + value + "'.";
      throw IllegalArgumentException_init(message.toString());
    }
    $receiver.setProperty_puj7f4$('tab-size', value.toString());
  }
  function tabSize_0($receiver, value) {
    if (!value.isNotNegative) {
      var message = "Tab size cannot be negative: '" + value + "'.";
      throw IllegalArgumentException_init(message.toString());
    }
    $receiver.setProperty_puj7f4$('tab-size', value.toString());
  }
  function text($receiver, build) {
    build(new KatydidTextStyleBuilder($receiver));
  }
  function textAlign($receiver, value) {
    $receiver.setProperty_puj7f4$('text-align', value.toString());
  }
  function textAlignAll($receiver, value) {
    if (!(value !== ETextAlign$justifyAll_getInstance())) {
      var message = "Option 'justify-all' does not apply for property text-align-all.";
      throw IllegalArgumentException_init(message.toString());
    }
    $receiver.setProperty_puj7f4$('text-align-all', value.toString());
  }
  function textAlignLast($receiver, value) {
    if (!(value !== ETextAlign$justifyAll_getInstance())) {
      var message = "Option 'justify-all' does not apply for property text-align-last.";
      throw IllegalArgumentException_init(message.toString());
    }
    $receiver.setProperty_puj7f4$('text-align-last', value.toString());
  }
  function textDecoration($receiver, value) {
    $receiver.setProperty_puj7f4$('text-decoration', value.toString());
  }
  function textDecoration_0($receiver, line, style, color, moreLines) {
    if (line === void 0)
      line = null;
    if (style === void 0)
      style = null;
    if (color === void 0)
      color = null;
    if (moreLines === void 0)
      moreLines = [];
    var tmp$;
    var css = '';
    if (line != null) {
      css = toString(line);
    }
    if (style != null) {
      css += ' ' + toString(style);
    }
    if (color != null) {
      css += ' ' + toString(color);
    }
    for (tmp$ = 0; tmp$ !== moreLines.length; ++tmp$) {
      var l = moreLines[tmp$];
      css += ' ' + toString(l);
    }
    if (!(css.length > 0)) {
      var message = 'Specify at least one non-null parameter for text-decoration.';
      throw IllegalArgumentException_init(message.toString());
    }
    var $receiver_0 = css;
    var tmp$_0;
    $receiver.setProperty_puj7f4$('text-decoration', trim(Kotlin.isCharSequence(tmp$_0 = $receiver_0) ? tmp$_0 : throwCCE()).toString());
  }
  function textDecorationColor($receiver, value) {
    $receiver.setProperty_puj7f4$('text-decoration-color', value.toString());
  }
  function textDecorationLine($receiver, value) {
    $receiver.setProperty_puj7f4$('text-decoration-line', value.toString());
  }
  function textDecorationLine_0($receiver, values) {
    var destination = ArrayList_init_0(values.length);
    var tmp$;
    for (tmp$ = 0; tmp$ !== values.length; ++tmp$) {
      var item = values[tmp$];
      destination.add_11rb$(item.toString());
    }
    var css = joinToString(destination, ' ');
    $receiver.setProperty_puj7f4$('text-decoration-line', css);
  }
  function textDecorationStyle($receiver, value) {
    $receiver.setProperty_puj7f4$('text-decoration-style', value.toString());
  }
  function textIndent($receiver, value) {
    $receiver.setProperty_puj7f4$('text-indent', value.toString());
  }
  function textIndent_0($receiver, value) {
    $receiver.setProperty_puj7f4$('text-indent', value.toString());
  }
  function textJustify($receiver, value) {
    $receiver.setProperty_puj7f4$('text-justify', value.toString());
  }
  function textOverflow($receiver, value) {
    $receiver.setProperty_puj7f4$('text-overflow', value.toString());
  }
  function textTransform($receiver, value) {
    $receiver.setProperty_puj7f4$('text-transform', value.toString());
  }
  function whiteSpace($receiver, value) {
    $receiver.setProperty_puj7f4$('white-space', value.toString());
  }
  function setVerticalAlign($receiver, baselineShift, alignmentBaseline) {
    var css = baselineShift.toString();
    if (alignmentBaseline != null) {
      css += ' ' + toString(alignmentBaseline);
    }
    $receiver.setProperty_puj7f4$('vertical-align', css);
  }
  function alignmentBaseline($receiver, value) {
    $receiver.setProperty_puj7f4$('alignment-baseline', value.toString());
  }
  function baselineShift($receiver, value) {
    $receiver.setProperty_puj7f4$('baseline-shift', value.toString());
  }
  function baselineShift_0($receiver, value) {
    $receiver.setProperty_puj7f4$('baseline-shift', value.toString());
  }
  function baselineShift_1($receiver, value) {
    $receiver.setProperty_puj7f4$('baseline-shift', value.toString());
  }
  function verticalAlign($receiver, baselineShift, alignmentBaseline) {
    if (alignmentBaseline === void 0)
      alignmentBaseline = null;
    setVerticalAlign($receiver, baselineShift, alignmentBaseline);
  }
  function verticalAlign_0($receiver, baselineShift, alignmentBaseline) {
    if (alignmentBaseline === void 0)
      alignmentBaseline = null;
    setVerticalAlign($receiver, baselineShift, alignmentBaseline);
  }
  function verticalAlign_1($receiver, alignmentBaseline) {
    $receiver.setProperty_puj7f4$('vertical-align', alignmentBaseline.toString());
  }
  function verticalAlign_2($receiver, baselineShift, alignmentBaseline) {
    if (alignmentBaseline === void 0)
      alignmentBaseline = null;
    setVerticalAlign($receiver, baselineShift, alignmentBaseline);
  }
  function visibility($receiver, value) {
    $receiver.setProperty_puj7f4$('visibility', value.toString());
  }
  function orphans($receiver, value) {
    if (!(value > 0)) {
      var message = 'CSS orphans property must be greater than zero.';
      throw IllegalArgumentException_init(message.toString());
    }
    $receiver.setProperty_puj7f4$('orphans', value.toString());
  }
  function widows($receiver, value) {
    if (!(value > 0)) {
      var message = 'CSS widows property must be greater than zero.';
      throw IllegalArgumentException_init(message.toString());
    }
    $receiver.setProperty_puj7f4$('widows', value.toString());
  }
  function height($receiver, value) {
    $receiver.setProperty_puj7f4$('height', value.toString());
  }
  function height_0($receiver, value) {
    $receiver.setProperty_puj7f4$('height', value.toString());
  }
  function height_1($receiver, value) {
    $receiver.setProperty_puj7f4$('height', value.toString());
  }
  function height_2($receiver, value) {
    $receiver.setProperty_puj7f4$('height', value.toString());
  }
  function maxHeight($receiver, value) {
    $receiver.setProperty_puj7f4$('max-height', value.toString());
  }
  function maxHeight_0($receiver, value) {
    $receiver.setProperty_puj7f4$('max-height', value.toString());
  }
  function maxHeight_1($receiver, value) {
    $receiver.setProperty_puj7f4$('max-height', value.toString());
  }
  function maxHeight_2($receiver, value) {
    $receiver.setProperty_puj7f4$('max-height', value.toString());
  }
  function maxWidth($receiver, value) {
    $receiver.setProperty_puj7f4$('max-width', value.toString());
  }
  function maxWidth_0($receiver, value) {
    $receiver.setProperty_puj7f4$('max-width', value.toString());
  }
  function maxWidth_1($receiver, value) {
    $receiver.setProperty_puj7f4$('max-width', value.toString());
  }
  function maxWidth_2($receiver, value) {
    $receiver.setProperty_puj7f4$('max-width', value.toString());
  }
  function minHeight($receiver, value) {
    $receiver.setProperty_puj7f4$('min-height', value.toString());
  }
  function minHeight_0($receiver, value) {
    $receiver.setProperty_puj7f4$('min-height', value.toString());
  }
  function minHeight_1($receiver, value) {
    $receiver.setProperty_puj7f4$('min-height', value.toString());
  }
  function minHeight_2($receiver, value) {
    $receiver.setProperty_puj7f4$('min-height', value.toString());
  }
  function minWidth($receiver, value) {
    $receiver.setProperty_puj7f4$('min-width', value.toString());
  }
  function minWidth_0($receiver, value) {
    $receiver.setProperty_puj7f4$('min-width', value.toString());
  }
  function minWidth_1($receiver, value) {
    $receiver.setProperty_puj7f4$('min-width', value.toString());
  }
  function minWidth_2($receiver, value) {
    $receiver.setProperty_puj7f4$('min-width', value.toString());
  }
  function width($receiver, value) {
    $receiver.setProperty_puj7f4$('width', value.toString());
  }
  function width_0($receiver, value) {
    $receiver.setProperty_puj7f4$('width', value.toString());
  }
  function width_1($receiver, value) {
    $receiver.setProperty_puj7f4$('width', value.toString());
  }
  function width_2($receiver, value) {
    $receiver.setProperty_puj7f4$('width', value.toString());
  }
  function KatydidWordStyleBuilder(style) {
    this.style_0 = style;
  }
  KatydidWordStyleBuilder.prototype.spacing_n0fawn$ = function (value) {
    wordSpacing(this.style_0, value);
  };
  KatydidWordStyleBuilder.prototype.spacing_rtt64d$ = function (value) {
    wordSpacing_0(this.style_0, value);
  };
  KatydidWordStyleBuilder.prototype.spacing_yqynb7$ = function (value) {
    wordSpacing_1(this.style_0, value);
  };
  KatydidWordStyleBuilder.prototype.wrap_w396uw$ = function (value) {
    wordWrap(this.style_0, value);
  };
  KatydidWordStyleBuilder.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'KatydidWordStyleBuilder',
    interfaces: []
  };
  function word($receiver, build) {
    build(new KatydidWordStyleBuilder($receiver));
  }
  function wordSpacing($receiver, value) {
    $receiver.setProperty_puj7f4$('word-spacing', value.toString());
  }
  function wordSpacing_0($receiver, value) {
    $receiver.setProperty_puj7f4$('word-spacing', value.toString());
  }
  function wordSpacing_1($receiver, value) {
    $receiver.setProperty_puj7f4$('word-spacing', value.toString());
  }
  function wordWrap($receiver, value) {
    $receiver.setProperty_puj7f4$('word-wrap', value.toString());
  }
  function KatydidStyle() {
  }
  KatydidStyle.prototype.setBoxProperty_hto8b4$ = function (key, top, right, bottom, left, callback$default) {
    if (right === void 0)
      right = top;
    if (bottom === void 0)
      bottom = top;
    if (left === void 0)
      left = right;
    callback$default ? callback$default(key, top, right, bottom, left) : this.setBoxProperty_hto8b4$$default(key, top, right, bottom, left);
  };
  KatydidStyle.prototype.setXyProperty_l8dco4$ = function (key, x, y, callback$default) {
    if (y === void 0)
      y = x;
    callback$default ? callback$default(key, x, y) : this.setXyProperty_l8dco4$$default(key, x, y);
  };
  KatydidStyle.prototype.toCssString_puj7f4$ = function (indent, whitespace, callback$default) {
    if (indent === void 0)
      indent = '';
    if (whitespace === void 0)
      whitespace = '\n';
    return callback$default ? callback$default(indent, whitespace) : this.toCssString_puj7f4$$default(indent, whitespace);
  };
  KatydidStyle.$metadata$ = {
    kind: Kind_INTERFACE,
    simpleName: 'KatydidStyle',
    interfaces: []
  };
  function makeStyle(build) {
    var result = new KatydidStyleImpl();
    build(result);
    return result;
  }
  function style($receiver, build) {
    var s = makeStyle(build);
    $receiver.attribute_puj7f4$('style', s.toString());
  }
  function KatydidAbstractStyleRule() {
  }
  KatydidAbstractStyleRule.$metadata$ = {
    kind: Kind_INTERFACE,
    simpleName: 'KatydidAbstractStyleRule',
    interfaces: [KatydidStyle, KatydidCompositeCssRule]
  };
  function KatydidCharSetAtRule() {
  }
  KatydidCharSetAtRule.$metadata$ = {
    kind: Kind_INTERFACE,
    simpleName: 'KatydidCharSetAtRule',
    interfaces: [KatydidCssRule]
  };
  function KatydidCompositeCssRule() {
  }
  KatydidCompositeCssRule.$metadata$ = {
    kind: Kind_INTERFACE,
    simpleName: 'KatydidCompositeCssRule',
    interfaces: [KatydidCssRule]
  };
  function KatydidCssRule() {
  }
  KatydidCssRule.prototype.toCssString_za3lpa$ = function (indent, callback$default) {
    if (indent === void 0)
      indent = 0;
    return callback$default ? callback$default(indent) : this.toCssString_za3lpa$$default(indent);
  };
  KatydidCssRule.$metadata$ = {
    kind: Kind_INTERFACE,
    simpleName: 'KatydidCssRule',
    interfaces: []
  };
  function KatydidMediaAtRule() {
  }
  KatydidMediaAtRule.$metadata$ = {
    kind: Kind_INTERFACE,
    simpleName: 'KatydidMediaAtRule',
    interfaces: [KatydidCompositeCssRule]
  };
  function KatydidPlaceholderRule() {
  }
  KatydidPlaceholderRule.$metadata$ = {
    kind: Kind_INTERFACE,
    simpleName: 'KatydidPlaceholderRule',
    interfaces: [KatydidAbstractStyleRule]
  };
  function KatydidStyleRule() {
  }
  KatydidStyleRule.$metadata$ = {
    kind: Kind_INTERFACE,
    simpleName: 'KatydidStyleRule',
    interfaces: [KatydidAbstractStyleRule]
  };
  function KatydidStyleSheet() {
  }
  KatydidStyleSheet.$metadata$ = {
    kind: Kind_INTERFACE,
    simpleName: 'KatydidStyleSheet',
    interfaces: [KatydidCompositeCssRule]
  };
  function makeStyleSheet(build) {
    var result = new KatydidStyleSheetImpl();
    build(result);
    return result;
  }
  function EAlignmentBaseline(name, ordinal, css) {
    Enum.call(this);
    this.css_kqy607$_0 = css;
    this.name$ = name;
    this.ordinal$ = ordinal;
  }
  function EAlignmentBaseline_initFields() {
    EAlignmentBaseline_initFields = function () {
    };
    EAlignmentBaseline$baseline_instance = new EAlignmentBaseline('baseline', 0, 'baseline');
    EAlignmentBaseline$textBottom_instance = new EAlignmentBaseline('textBottom', 1, 'text-bottom');
    EAlignmentBaseline$alphabetic_instance = new EAlignmentBaseline('alphabetic', 2, 'alphabetic');
    EAlignmentBaseline$ideographic_instance = new EAlignmentBaseline('ideographic', 3, 'ideographic');
    EAlignmentBaseline$middle_instance = new EAlignmentBaseline('middle', 4, 'middle');
    EAlignmentBaseline$central_instance = new EAlignmentBaseline('central', 5, 'central');
    EAlignmentBaseline$mathematical_instance = new EAlignmentBaseline('mathematical', 6, 'mathematical');
    EAlignmentBaseline$textTop_instance = new EAlignmentBaseline('textTop', 7, 'text-top');
    EAlignmentBaseline$top_instance = new EAlignmentBaseline('top', 8, 'top');
    EAlignmentBaseline$center_instance = new EAlignmentBaseline('center', 9, 'center');
    EAlignmentBaseline$bottom_instance = new EAlignmentBaseline('bottom', 10, 'bottom');
    EAlignmentBaseline$Companion_getInstance();
  }
  var EAlignmentBaseline$baseline_instance;
  function EAlignmentBaseline$baseline_getInstance() {
    EAlignmentBaseline_initFields();
    return EAlignmentBaseline$baseline_instance;
  }
  var EAlignmentBaseline$textBottom_instance;
  function EAlignmentBaseline$textBottom_getInstance() {
    EAlignmentBaseline_initFields();
    return EAlignmentBaseline$textBottom_instance;
  }
  var EAlignmentBaseline$alphabetic_instance;
  function EAlignmentBaseline$alphabetic_getInstance() {
    EAlignmentBaseline_initFields();
    return EAlignmentBaseline$alphabetic_instance;
  }
  var EAlignmentBaseline$ideographic_instance;
  function EAlignmentBaseline$ideographic_getInstance() {
    EAlignmentBaseline_initFields();
    return EAlignmentBaseline$ideographic_instance;
  }
  var EAlignmentBaseline$middle_instance;
  function EAlignmentBaseline$middle_getInstance() {
    EAlignmentBaseline_initFields();
    return EAlignmentBaseline$middle_instance;
  }
  var EAlignmentBaseline$central_instance;
  function EAlignmentBaseline$central_getInstance() {
    EAlignmentBaseline_initFields();
    return EAlignmentBaseline$central_instance;
  }
  var EAlignmentBaseline$mathematical_instance;
  function EAlignmentBaseline$mathematical_getInstance() {
    EAlignmentBaseline_initFields();
    return EAlignmentBaseline$mathematical_instance;
  }
  var EAlignmentBaseline$textTop_instance;
  function EAlignmentBaseline$textTop_getInstance() {
    EAlignmentBaseline_initFields();
    return EAlignmentBaseline$textTop_instance;
  }
  var EAlignmentBaseline$top_instance;
  function EAlignmentBaseline$top_getInstance() {
    EAlignmentBaseline_initFields();
    return EAlignmentBaseline$top_instance;
  }
  var EAlignmentBaseline$center_instance;
  function EAlignmentBaseline$center_getInstance() {
    EAlignmentBaseline_initFields();
    return EAlignmentBaseline$center_instance;
  }
  var EAlignmentBaseline$bottom_instance;
  function EAlignmentBaseline$bottom_getInstance() {
    EAlignmentBaseline_initFields();
    return EAlignmentBaseline$bottom_instance;
  }
  EAlignmentBaseline.prototype.toString = function () {
    return this.css_kqy607$_0;
  };
  function EAlignmentBaseline$Companion() {
    EAlignmentBaseline$Companion_instance = this;
  }
  EAlignmentBaseline$Companion.prototype.fromString_pdl1vj$ = function (option) {
    if (option == null)
      return null;
    else
      switch (option) {
        case 'alphabetic':
          return EAlignmentBaseline$alphabetic_getInstance();
        case 'baseline':
          return EAlignmentBaseline$baseline_getInstance();
        case 'bottom':
          return EAlignmentBaseline$bottom_getInstance();
        case 'center':
          return EAlignmentBaseline$center_getInstance();
        case 'central':
          return EAlignmentBaseline$central_getInstance();
        case 'ideographic':
          return EAlignmentBaseline$ideographic_getInstance();
        case 'mathematical':
          return EAlignmentBaseline$mathematical_getInstance();
        case 'middle':
          return EAlignmentBaseline$middle_getInstance();
        case 'text-bottom':
          return EAlignmentBaseline$textBottom_getInstance();
        case 'text-top':
          return EAlignmentBaseline$textTop_getInstance();
        case 'top':
          return EAlignmentBaseline$top_getInstance();
        default:throw IllegalArgumentException_init("Unknown alignment-baseline option: '" + toString(option) + "'.");
      }
  };
  EAlignmentBaseline$Companion.$metadata$ = {
    kind: Kind_OBJECT,
    simpleName: 'Companion',
    interfaces: []
  };
  var EAlignmentBaseline$Companion_instance = null;
  function EAlignmentBaseline$Companion_getInstance() {
    EAlignmentBaseline_initFields();
    if (EAlignmentBaseline$Companion_instance === null) {
      new EAlignmentBaseline$Companion();
    }
    return EAlignmentBaseline$Companion_instance;
  }
  EAlignmentBaseline.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'EAlignmentBaseline',
    interfaces: [Enum]
  };
  function EAlignmentBaseline$values() {
    return [EAlignmentBaseline$baseline_getInstance(), EAlignmentBaseline$textBottom_getInstance(), EAlignmentBaseline$alphabetic_getInstance(), EAlignmentBaseline$ideographic_getInstance(), EAlignmentBaseline$middle_getInstance(), EAlignmentBaseline$central_getInstance(), EAlignmentBaseline$mathematical_getInstance(), EAlignmentBaseline$textTop_getInstance(), EAlignmentBaseline$top_getInstance(), EAlignmentBaseline$center_getInstance(), EAlignmentBaseline$bottom_getInstance()];
  }
  EAlignmentBaseline.values = EAlignmentBaseline$values;
  function EAlignmentBaseline$valueOf(name) {
    switch (name) {
      case 'baseline':
        return EAlignmentBaseline$baseline_getInstance();
      case 'textBottom':
        return EAlignmentBaseline$textBottom_getInstance();
      case 'alphabetic':
        return EAlignmentBaseline$alphabetic_getInstance();
      case 'ideographic':
        return EAlignmentBaseline$ideographic_getInstance();
      case 'middle':
        return EAlignmentBaseline$middle_getInstance();
      case 'central':
        return EAlignmentBaseline$central_getInstance();
      case 'mathematical':
        return EAlignmentBaseline$mathematical_getInstance();
      case 'textTop':
        return EAlignmentBaseline$textTop_getInstance();
      case 'top':
        return EAlignmentBaseline$top_getInstance();
      case 'center':
        return EAlignmentBaseline$center_getInstance();
      case 'bottom':
        return EAlignmentBaseline$bottom_getInstance();
      default:throwISE('No enum constant o.katydid.css.types.EAlignmentBaseline.' + name);
    }
  }
  EAlignmentBaseline.valueOf_61zpoe$ = EAlignmentBaseline$valueOf;
  function EAttachment(name, ordinal, css) {
    Enum.call(this);
    this.css_z7rhcq$_0 = css;
    this.name$ = name;
    this.ordinal$ = ordinal;
  }
  function EAttachment_initFields() {
    EAttachment_initFields = function () {
    };
    EAttachment$fixed_instance = new EAttachment('fixed', 0, 'fixed');
    EAttachment$local_instance = new EAttachment('local', 1, 'local');
    EAttachment$scroll_instance = new EAttachment('scroll', 2, 'scroll');
    EAttachment$Companion_getInstance();
  }
  var EAttachment$fixed_instance;
  function EAttachment$fixed_getInstance() {
    EAttachment_initFields();
    return EAttachment$fixed_instance;
  }
  var EAttachment$local_instance;
  function EAttachment$local_getInstance() {
    EAttachment_initFields();
    return EAttachment$local_instance;
  }
  var EAttachment$scroll_instance;
  function EAttachment$scroll_getInstance() {
    EAttachment_initFields();
    return EAttachment$scroll_instance;
  }
  EAttachment.prototype.toString = function () {
    return this.css_z7rhcq$_0;
  };
  function EAttachment$Companion() {
    EAttachment$Companion_instance = this;
  }
  EAttachment$Companion.prototype.fromString_pdl1vj$ = function (option) {
    if (option == null)
      return null;
    else
      switch (option) {
        case 'fixed':
          return EAttachment$fixed_getInstance();
        case 'local':
          return EAttachment$local_getInstance();
        case 'scroll':
          return EAttachment$scroll_getInstance();
        default:throw IllegalArgumentException_init("Unknown background attachment option: '" + toString(option) + "'.");
      }
  };
  EAttachment$Companion.$metadata$ = {
    kind: Kind_OBJECT,
    simpleName: 'Companion',
    interfaces: []
  };
  var EAttachment$Companion_instance = null;
  function EAttachment$Companion_getInstance() {
    EAttachment_initFields();
    if (EAttachment$Companion_instance === null) {
      new EAttachment$Companion();
    }
    return EAttachment$Companion_instance;
  }
  EAttachment.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'EAttachment',
    interfaces: [Enum]
  };
  function EAttachment$values() {
    return [EAttachment$fixed_getInstance(), EAttachment$local_getInstance(), EAttachment$scroll_getInstance()];
  }
  EAttachment.values = EAttachment$values;
  function EAttachment$valueOf(name) {
    switch (name) {
      case 'fixed':
        return EAttachment$fixed_getInstance();
      case 'local':
        return EAttachment$local_getInstance();
      case 'scroll':
        return EAttachment$scroll_getInstance();
      default:throwISE('No enum constant o.katydid.css.types.EAttachment.' + name);
    }
  }
  EAttachment.valueOf_61zpoe$ = EAttachment$valueOf;
  function EAuto(name, ordinal, css) {
    Enum.call(this);
    this.css_ojahju$_0 = css;
    this.name$ = name;
    this.ordinal$ = ordinal;
  }
  function EAuto_initFields() {
    EAuto_initFields = function () {
    };
    EAuto$auto_instance = new EAuto('auto', 0, 'auto');
    EAuto$Companion_getInstance();
  }
  var EAuto$auto_instance;
  function EAuto$auto_getInstance() {
    EAuto_initFields();
    return EAuto$auto_instance;
  }
  EAuto.prototype.toString = function () {
    return this.css_ojahju$_0;
  };
  function EAuto$Companion() {
    EAuto$Companion_instance = this;
  }
  EAuto$Companion.prototype.fromString_pdl1vj$ = function (option) {
    if (option == null)
      return null;
    else if (equals(option, 'auto'))
      return EAuto$auto_getInstance();
    else
      throw IllegalArgumentException_init("Unknown 'auto' option: '" + toString(option) + "'.");
  };
  EAuto$Companion.$metadata$ = {
    kind: Kind_OBJECT,
    simpleName: 'Companion',
    interfaces: []
  };
  var EAuto$Companion_instance = null;
  function EAuto$Companion_getInstance() {
    EAuto_initFields();
    if (EAuto$Companion_instance === null) {
      new EAuto$Companion();
    }
    return EAuto$Companion_instance;
  }
  EAuto.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'EAuto',
    interfaces: [Enum]
  };
  function EAuto$values() {
    return [EAuto$auto_getInstance()];
  }
  EAuto.values = EAuto$values;
  function EAuto$valueOf(name) {
    switch (name) {
      case 'auto':
        return EAuto$auto_getInstance();
      default:throwISE('No enum constant o.katydid.css.types.EAuto.' + name);
    }
  }
  EAuto.valueOf_61zpoe$ = EAuto$valueOf;
  function EBackgroundPosition(name, ordinal, css) {
    Enum.call(this);
    this.css_osbyxe$_0 = css;
    this.name$ = name;
    this.ordinal$ = ordinal;
  }
  function EBackgroundPosition_initFields() {
    EBackgroundPosition_initFields = function () {
    };
    EBackgroundPosition$bottom_instance = new EBackgroundPosition('bottom', 0, 'bottom');
    EBackgroundPosition$center_instance = new EBackgroundPosition('center', 1, 'center');
    EBackgroundPosition$left_instance = new EBackgroundPosition('left', 2, 'left');
    EBackgroundPosition$right_instance = new EBackgroundPosition('right', 3, 'right');
    EBackgroundPosition$top_instance = new EBackgroundPosition('top', 4, 'top');
    EBackgroundPosition$Companion_getInstance();
  }
  var EBackgroundPosition$bottom_instance;
  function EBackgroundPosition$bottom_getInstance() {
    EBackgroundPosition_initFields();
    return EBackgroundPosition$bottom_instance;
  }
  var EBackgroundPosition$center_instance;
  function EBackgroundPosition$center_getInstance() {
    EBackgroundPosition_initFields();
    return EBackgroundPosition$center_instance;
  }
  var EBackgroundPosition$left_instance;
  function EBackgroundPosition$left_getInstance() {
    EBackgroundPosition_initFields();
    return EBackgroundPosition$left_instance;
  }
  var EBackgroundPosition$right_instance;
  function EBackgroundPosition$right_getInstance() {
    EBackgroundPosition_initFields();
    return EBackgroundPosition$right_instance;
  }
  var EBackgroundPosition$top_instance;
  function EBackgroundPosition$top_getInstance() {
    EBackgroundPosition_initFields();
    return EBackgroundPosition$top_instance;
  }
  EBackgroundPosition.prototype.toString = function () {
    return this.css_osbyxe$_0;
  };
  function EBackgroundPosition$Companion() {
    EBackgroundPosition$Companion_instance = this;
  }
  EBackgroundPosition$Companion.prototype.fromString_pdl1vj$ = function (option) {
    if (option == null)
      return null;
    else
      switch (option) {
        case 'bottom':
          return EBackgroundPosition$bottom_getInstance();
        case 'center':
          return EBackgroundPosition$center_getInstance();
        case 'left':
          return EBackgroundPosition$left_getInstance();
        case 'right':
          return EBackgroundPosition$right_getInstance();
        case 'top':
          return EBackgroundPosition$top_getInstance();
        default:throw IllegalArgumentException_init("Unknown display option: '" + toString(option) + "'.");
      }
  };
  EBackgroundPosition$Companion.$metadata$ = {
    kind: Kind_OBJECT,
    simpleName: 'Companion',
    interfaces: []
  };
  var EBackgroundPosition$Companion_instance = null;
  function EBackgroundPosition$Companion_getInstance() {
    EBackgroundPosition_initFields();
    if (EBackgroundPosition$Companion_instance === null) {
      new EBackgroundPosition$Companion();
    }
    return EBackgroundPosition$Companion_instance;
  }
  EBackgroundPosition.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'EBackgroundPosition',
    interfaces: [Enum]
  };
  function EBackgroundPosition$values() {
    return [EBackgroundPosition$bottom_getInstance(), EBackgroundPosition$center_getInstance(), EBackgroundPosition$left_getInstance(), EBackgroundPosition$right_getInstance(), EBackgroundPosition$top_getInstance()];
  }
  EBackgroundPosition.values = EBackgroundPosition$values;
  function EBackgroundPosition$valueOf(name) {
    switch (name) {
      case 'bottom':
        return EBackgroundPosition$bottom_getInstance();
      case 'center':
        return EBackgroundPosition$center_getInstance();
      case 'left':
        return EBackgroundPosition$left_getInstance();
      case 'right':
        return EBackgroundPosition$right_getInstance();
      case 'top':
        return EBackgroundPosition$top_getInstance();
      default:throwISE('No enum constant o.katydid.css.types.EBackgroundPosition.' + name);
    }
  }
  EBackgroundPosition.valueOf_61zpoe$ = EBackgroundPosition$valueOf;
  function EBaselineShift(name, ordinal, css) {
    Enum.call(this);
    this.css_k8v4uc$_0 = css;
    this.name$ = name;
    this.ordinal$ = ordinal;
  }
  function EBaselineShift_initFields() {
    EBaselineShift_initFields = function () {
    };
    EBaselineShift$sub_instance = new EBaselineShift('sub', 0, 'sub');
    EBaselineShift$super_instance = new EBaselineShift('super', 1, 'super');
    EBaselineShift$Companion_getInstance();
  }
  var EBaselineShift$sub_instance;
  function EBaselineShift$sub_getInstance() {
    EBaselineShift_initFields();
    return EBaselineShift$sub_instance;
  }
  var EBaselineShift$super_instance;
  function EBaselineShift$super_getInstance() {
    EBaselineShift_initFields();
    return EBaselineShift$super_instance;
  }
  EBaselineShift.prototype.toString = function () {
    return this.css_k8v4uc$_0;
  };
  function EBaselineShift$Companion() {
    EBaselineShift$Companion_instance = this;
  }
  EBaselineShift$Companion.prototype.fromString_pdl1vj$ = function (option) {
    if (option == null)
      return null;
    else
      switch (option) {
        case 'sub':
          return EBaselineShift$sub_getInstance();
        case 'super':
          return EBaselineShift$super_getInstance();
        default:throw IllegalArgumentException_init("Unknown baseline shift align option: '" + toString(option) + "'.");
      }
  };
  EBaselineShift$Companion.$metadata$ = {
    kind: Kind_OBJECT,
    simpleName: 'Companion',
    interfaces: []
  };
  var EBaselineShift$Companion_instance = null;
  function EBaselineShift$Companion_getInstance() {
    EBaselineShift_initFields();
    if (EBaselineShift$Companion_instance === null) {
      new EBaselineShift$Companion();
    }
    return EBaselineShift$Companion_instance;
  }
  EBaselineShift.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'EBaselineShift',
    interfaces: [Enum]
  };
  function EBaselineShift$values() {
    return [EBaselineShift$sub_getInstance(), EBaselineShift$super_getInstance()];
  }
  EBaselineShift.values = EBaselineShift$values;
  function EBaselineShift$valueOf(name) {
    switch (name) {
      case 'sub':
        return EBaselineShift$sub_getInstance();
      case 'super':
        return EBaselineShift$super_getInstance();
      default:throwISE('No enum constant o.katydid.css.types.EBaselineShift.' + name);
    }
  }
  EBaselineShift.valueOf_61zpoe$ = EBaselineShift$valueOf;
  function EBorderCollapse(name, ordinal, css) {
    Enum.call(this);
    this.css_2yeqts$_0 = css;
    this.name$ = name;
    this.ordinal$ = ordinal;
  }
  function EBorderCollapse_initFields() {
    EBorderCollapse_initFields = function () {
    };
    EBorderCollapse$collapse_instance = new EBorderCollapse('collapse', 0, 'collapse');
    EBorderCollapse$separate_instance = new EBorderCollapse('separate', 1, 'separate');
    EBorderCollapse$Companion_getInstance();
  }
  var EBorderCollapse$collapse_instance;
  function EBorderCollapse$collapse_getInstance() {
    EBorderCollapse_initFields();
    return EBorderCollapse$collapse_instance;
  }
  var EBorderCollapse$separate_instance;
  function EBorderCollapse$separate_getInstance() {
    EBorderCollapse_initFields();
    return EBorderCollapse$separate_instance;
  }
  EBorderCollapse.prototype.toString = function () {
    return this.css_2yeqts$_0;
  };
  function EBorderCollapse$Companion() {
    EBorderCollapse$Companion_instance = this;
  }
  EBorderCollapse$Companion.prototype.fromString_pdl1vj$ = function (option) {
    if (option == null)
      return null;
    else
      switch (option) {
        case 'collapse':
          return EBorderCollapse$collapse_getInstance();
        case 'separate':
          return EBorderCollapse$separate_getInstance();
        default:throw IllegalArgumentException_init("Unknown border collapse option: '" + toString(option) + "'.");
      }
  };
  EBorderCollapse$Companion.$metadata$ = {
    kind: Kind_OBJECT,
    simpleName: 'Companion',
    interfaces: []
  };
  var EBorderCollapse$Companion_instance = null;
  function EBorderCollapse$Companion_getInstance() {
    EBorderCollapse_initFields();
    if (EBorderCollapse$Companion_instance === null) {
      new EBorderCollapse$Companion();
    }
    return EBorderCollapse$Companion_instance;
  }
  EBorderCollapse.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'EBorderCollapse',
    interfaces: [Enum]
  };
  function EBorderCollapse$values() {
    return [EBorderCollapse$collapse_getInstance(), EBorderCollapse$separate_getInstance()];
  }
  EBorderCollapse.values = EBorderCollapse$values;
  function EBorderCollapse$valueOf(name) {
    switch (name) {
      case 'collapse':
        return EBorderCollapse$collapse_getInstance();
      case 'separate':
        return EBorderCollapse$separate_getInstance();
      default:throwISE('No enum constant o.katydid.css.types.EBorderCollapse.' + name);
    }
  }
  EBorderCollapse.valueOf_61zpoe$ = EBorderCollapse$valueOf;
  function EBoxSize() {
  }
  function EBoxSize$minContent() {
    EBoxSize$minContent_instance = this;
    EBoxSize.call(this);
  }
  EBoxSize$minContent.prototype.toString = function () {
    return 'min-content';
  };
  EBoxSize$minContent.$metadata$ = {
    kind: Kind_OBJECT,
    simpleName: 'minContent',
    interfaces: [EBoxSize]
  };
  var EBoxSize$minContent_instance = null;
  function EBoxSize$minContent_getInstance() {
    if (EBoxSize$minContent_instance === null) {
      new EBoxSize$minContent();
    }
    return EBoxSize$minContent_instance;
  }
  function EBoxSize$maxContent() {
    EBoxSize$maxContent_instance = this;
    EBoxSize.call(this);
  }
  EBoxSize$maxContent.prototype.toString = function () {
    return 'max-content';
  };
  EBoxSize$maxContent.$metadata$ = {
    kind: Kind_OBJECT,
    simpleName: 'maxContent',
    interfaces: [EBoxSize]
  };
  var EBoxSize$maxContent_instance = null;
  function EBoxSize$maxContent_getInstance() {
    if (EBoxSize$maxContent_instance === null) {
      new EBoxSize$maxContent();
    }
    return EBoxSize$maxContent_instance;
  }
  function EBoxSize$fitContent(lengthOrPercentage) {
    EBoxSize.call(this);
    this.lengthOrPercentage_0 = lengthOrPercentage;
  }
  EBoxSize$fitContent.prototype.toString = function () {
    return 'fit-content(' + this.lengthOrPercentage_0 + ')';
  };
  EBoxSize$fitContent.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'fitContent',
    interfaces: [EBoxSize]
  };
  function EBoxSize$EBoxSize$fitContent_init(length, $this) {
    $this = $this || Object.create(EBoxSize$fitContent.prototype);
    EBoxSize$fitContent.call($this, length.toString());
    if (!length.isNotNegative) {
      var message = 'Fit-content length may not be negative.';
      throw IllegalArgumentException_init(message.toString());
    }
    return $this;
  }
  function EBoxSize$EBoxSize$fitContent_init_0(percentage, $this) {
    $this = $this || Object.create(EBoxSize$fitContent.prototype);
    EBoxSize$fitContent.call($this, percentage.toString());
    if (!percentage.isNotNegative) {
      var message = 'Fit-content percentage may not be negative.';
      throw IllegalArgumentException_init(message.toString());
    }
    return $this;
  }
  EBoxSize.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'EBoxSize',
    interfaces: []
  };
  function EBoxSizing(name, ordinal, css) {
    Enum.call(this);
    this.css_b419lk$_0 = css;
    this.name$ = name;
    this.ordinal$ = ordinal;
  }
  function EBoxSizing_initFields() {
    EBoxSizing_initFields = function () {
    };
    EBoxSizing$contentBox_instance = new EBoxSizing('contentBox', 0, 'content-box');
    EBoxSizing$borderBox_instance = new EBoxSizing('borderBox', 1, 'border-box');
    EBoxSizing$Companion_getInstance();
  }
  var EBoxSizing$contentBox_instance;
  function EBoxSizing$contentBox_getInstance() {
    EBoxSizing_initFields();
    return EBoxSizing$contentBox_instance;
  }
  var EBoxSizing$borderBox_instance;
  function EBoxSizing$borderBox_getInstance() {
    EBoxSizing_initFields();
    return EBoxSizing$borderBox_instance;
  }
  EBoxSizing.prototype.toString = function () {
    return this.css_b419lk$_0;
  };
  function EBoxSizing$Companion() {
    EBoxSizing$Companion_instance = this;
  }
  EBoxSizing$Companion.prototype.fromString_pdl1vj$ = function (option) {
    if (option == null)
      return null;
    else
      switch (option) {
        case 'border-box':
          return EBoxSizing$borderBox_getInstance();
        case 'content-box':
          return EBoxSizing$contentBox_getInstance();
        default:throw IllegalArgumentException_init("Unknown box sizing option: '" + toString(option) + "'.");
      }
  };
  EBoxSizing$Companion.$metadata$ = {
    kind: Kind_OBJECT,
    simpleName: 'Companion',
    interfaces: []
  };
  var EBoxSizing$Companion_instance = null;
  function EBoxSizing$Companion_getInstance() {
    EBoxSizing_initFields();
    if (EBoxSizing$Companion_instance === null) {
      new EBoxSizing$Companion();
    }
    return EBoxSizing$Companion_instance;
  }
  EBoxSizing.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'EBoxSizing',
    interfaces: [Enum]
  };
  function EBoxSizing$values() {
    return [EBoxSizing$contentBox_getInstance(), EBoxSizing$borderBox_getInstance()];
  }
  EBoxSizing.values = EBoxSizing$values;
  function EBoxSizing$valueOf(name) {
    switch (name) {
      case 'contentBox':
        return EBoxSizing$contentBox_getInstance();
      case 'borderBox':
        return EBoxSizing$borderBox_getInstance();
      default:throwISE('No enum constant o.katydid.css.types.EBoxSizing.' + name);
    }
  }
  EBoxSizing.valueOf_61zpoe$ = EBoxSizing$valueOf;
  function ECaptionSide(name, ordinal, css) {
    Enum.call(this);
    this.css_lgwgyk$_0 = css;
    this.name$ = name;
    this.ordinal$ = ordinal;
  }
  function ECaptionSide_initFields() {
    ECaptionSide_initFields = function () {
    };
    ECaptionSide$top_instance = new ECaptionSide('top', 0, 'top');
    ECaptionSide$bottom_instance = new ECaptionSide('bottom', 1, 'bottom');
    ECaptionSide$Companion_getInstance();
  }
  var ECaptionSide$top_instance;
  function ECaptionSide$top_getInstance() {
    ECaptionSide_initFields();
    return ECaptionSide$top_instance;
  }
  var ECaptionSide$bottom_instance;
  function ECaptionSide$bottom_getInstance() {
    ECaptionSide_initFields();
    return ECaptionSide$bottom_instance;
  }
  ECaptionSide.prototype.toString = function () {
    return this.css_lgwgyk$_0;
  };
  function ECaptionSide$Companion() {
    ECaptionSide$Companion_instance = this;
  }
  ECaptionSide$Companion.prototype.fromString_pdl1vj$ = function (option) {
    if (option == null)
      return null;
    else
      switch (option) {
        case 'bottom':
          return ECaptionSide$bottom_getInstance();
        case 'top':
          return ECaptionSide$top_getInstance();
        default:throw IllegalArgumentException_init("Unknown caption side option: '" + toString(option) + "'.");
      }
  };
  ECaptionSide$Companion.$metadata$ = {
    kind: Kind_OBJECT,
    simpleName: 'Companion',
    interfaces: []
  };
  var ECaptionSide$Companion_instance = null;
  function ECaptionSide$Companion_getInstance() {
    ECaptionSide_initFields();
    if (ECaptionSide$Companion_instance === null) {
      new ECaptionSide$Companion();
    }
    return ECaptionSide$Companion_instance;
  }
  ECaptionSide.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'ECaptionSide',
    interfaces: [Enum]
  };
  function ECaptionSide$values() {
    return [ECaptionSide$top_getInstance(), ECaptionSide$bottom_getInstance()];
  }
  ECaptionSide.values = ECaptionSide$values;
  function ECaptionSide$valueOf(name) {
    switch (name) {
      case 'top':
        return ECaptionSide$top_getInstance();
      case 'bottom':
        return ECaptionSide$bottom_getInstance();
      default:throwISE('No enum constant o.katydid.css.types.ECaptionSide.' + name);
    }
  }
  ECaptionSide.valueOf_61zpoe$ = ECaptionSide$valueOf;
  function EClear(name, ordinal, css) {
    Enum.call(this);
    this.css_9hx0b0$_0 = css;
    this.name$ = name;
    this.ordinal$ = ordinal;
  }
  function EClear_initFields() {
    EClear_initFields = function () {
    };
    EClear$left_instance = new EClear('left', 0, 'left');
    EClear$right_instance = new EClear('right', 1, 'right');
    EClear$both_instance = new EClear('both', 2, 'both');
    EClear$none_instance = new EClear('none', 3, 'none');
    EClear$inlineStart_instance = new EClear('inlineStart', 4, 'inline-start');
    EClear$inlineEnd_instance = new EClear('inlineEnd', 5, 'inline-end');
    EClear$blockStart_instance = new EClear('blockStart', 6, 'block-start');
    EClear$blockEnd_instance = new EClear('blockEnd', 7, 'block-end');
    EClear$top_instance = new EClear('top', 8, 'top');
    EClear$bottom_instance = new EClear('bottom', 9, 'bottom');
    EClear$Companion_getInstance();
  }
  var EClear$left_instance;
  function EClear$left_getInstance() {
    EClear_initFields();
    return EClear$left_instance;
  }
  var EClear$right_instance;
  function EClear$right_getInstance() {
    EClear_initFields();
    return EClear$right_instance;
  }
  var EClear$both_instance;
  function EClear$both_getInstance() {
    EClear_initFields();
    return EClear$both_instance;
  }
  var EClear$none_instance;
  function EClear$none_getInstance() {
    EClear_initFields();
    return EClear$none_instance;
  }
  var EClear$inlineStart_instance;
  function EClear$inlineStart_getInstance() {
    EClear_initFields();
    return EClear$inlineStart_instance;
  }
  var EClear$inlineEnd_instance;
  function EClear$inlineEnd_getInstance() {
    EClear_initFields();
    return EClear$inlineEnd_instance;
  }
  var EClear$blockStart_instance;
  function EClear$blockStart_getInstance() {
    EClear_initFields();
    return EClear$blockStart_instance;
  }
  var EClear$blockEnd_instance;
  function EClear$blockEnd_getInstance() {
    EClear_initFields();
    return EClear$blockEnd_instance;
  }
  var EClear$top_instance;
  function EClear$top_getInstance() {
    EClear_initFields();
    return EClear$top_instance;
  }
  var EClear$bottom_instance;
  function EClear$bottom_getInstance() {
    EClear_initFields();
    return EClear$bottom_instance;
  }
  EClear.prototype.toString = function () {
    return this.css_9hx0b0$_0;
  };
  function EClear$Companion() {
    EClear$Companion_instance = this;
  }
  EClear$Companion.prototype.fromString_pdl1vj$ = function (option) {
    if (option == null)
      return null;
    else
      switch (option) {
        case 'block-end':
          return EClear$blockEnd_getInstance();
        case 'block-start':
          return EClear$blockStart_getInstance();
        case 'both':
          return EClear$both_getInstance();
        case 'bottom':
          return EClear$bottom_getInstance();
        case 'inline-end':
          return EClear$inlineEnd_getInstance();
        case 'inline-start':
          return EClear$inlineStart_getInstance();
        case 'left':
          return EClear$left_getInstance();
        case 'none':
          return EClear$none_getInstance();
        case 'right':
          return EClear$right_getInstance();
        case 'top':
          return EClear$top_getInstance();
        default:throw IllegalArgumentException_init("Unknown clear option: '" + toString(option) + "'.");
      }
  };
  EClear$Companion.$metadata$ = {
    kind: Kind_OBJECT,
    simpleName: 'Companion',
    interfaces: []
  };
  var EClear$Companion_instance = null;
  function EClear$Companion_getInstance() {
    EClear_initFields();
    if (EClear$Companion_instance === null) {
      new EClear$Companion();
    }
    return EClear$Companion_instance;
  }
  EClear.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'EClear',
    interfaces: [Enum]
  };
  function EClear$values() {
    return [EClear$left_getInstance(), EClear$right_getInstance(), EClear$both_getInstance(), EClear$none_getInstance(), EClear$inlineStart_getInstance(), EClear$inlineEnd_getInstance(), EClear$blockStart_getInstance(), EClear$blockEnd_getInstance(), EClear$top_getInstance(), EClear$bottom_getInstance()];
  }
  EClear.values = EClear$values;
  function EClear$valueOf(name) {
    switch (name) {
      case 'left':
        return EClear$left_getInstance();
      case 'right':
        return EClear$right_getInstance();
      case 'both':
        return EClear$both_getInstance();
      case 'none':
        return EClear$none_getInstance();
      case 'inlineStart':
        return EClear$inlineStart_getInstance();
      case 'inlineEnd':
        return EClear$inlineEnd_getInstance();
      case 'blockStart':
        return EClear$blockStart_getInstance();
      case 'blockEnd':
        return EClear$blockEnd_getInstance();
      case 'top':
        return EClear$top_getInstance();
      case 'bottom':
        return EClear$bottom_getInstance();
      default:throwISE('No enum constant o.katydid.css.types.EClear.' + name);
    }
  }
  EClear.valueOf_61zpoe$ = EClear$valueOf;
  function EContent(css) {
    EContent$Companion_getInstance();
    this.css_7yc12w$_0 = css;
  }
  function EContent$none() {
    EContent$none_instance = this;
    EContent.call(this, 'none');
  }
  EContent$none.$metadata$ = {
    kind: Kind_OBJECT,
    simpleName: 'none',
    interfaces: [EContent]
  };
  var EContent$none_instance = null;
  function EContent$none_getInstance() {
    if (EContent$none_instance === null) {
      new EContent$none();
    }
    return EContent$none_instance;
  }
  function EContent$normal() {
    EContent$normal_instance = this;
    EContent.call(this, 'normal');
  }
  EContent$normal.$metadata$ = {
    kind: Kind_OBJECT,
    simpleName: 'normal',
    interfaces: [EContent]
  };
  var EContent$normal_instance = null;
  function EContent$normal_getInstance() {
    if (EContent$normal_instance === null) {
      new EContent$normal();
    }
    return EContent$normal_instance;
  }
  function EContent$openQuote() {
    EContent$openQuote_instance = this;
    EContent.call(this, 'open-quote');
  }
  EContent$openQuote.$metadata$ = {
    kind: Kind_OBJECT,
    simpleName: 'openQuote',
    interfaces: [EContent]
  };
  var EContent$openQuote_instance = null;
  function EContent$openQuote_getInstance() {
    if (EContent$openQuote_instance === null) {
      new EContent$openQuote();
    }
    return EContent$openQuote_instance;
  }
  function EContent$closeQuote() {
    EContent$closeQuote_instance = this;
    EContent.call(this, 'close-quote');
  }
  EContent$closeQuote.$metadata$ = {
    kind: Kind_OBJECT,
    simpleName: 'closeQuote',
    interfaces: [EContent]
  };
  var EContent$closeQuote_instance = null;
  function EContent$closeQuote_getInstance() {
    if (EContent$closeQuote_instance === null) {
      new EContent$closeQuote();
    }
    return EContent$closeQuote_instance;
  }
  function EContent$noOpenQuote() {
    EContent$noOpenQuote_instance = this;
    EContent.call(this, 'no-open-quote');
  }
  EContent$noOpenQuote.$metadata$ = {
    kind: Kind_OBJECT,
    simpleName: 'noOpenQuote',
    interfaces: [EContent]
  };
  var EContent$noOpenQuote_instance = null;
  function EContent$noOpenQuote_getInstance() {
    if (EContent$noOpenQuote_instance === null) {
      new EContent$noOpenQuote();
    }
    return EContent$noOpenQuote_instance;
  }
  function EContent$noCloseQuote() {
    EContent$noCloseQuote_instance = this;
    EContent.call(this, 'no-close-quote');
  }
  EContent$noCloseQuote.$metadata$ = {
    kind: Kind_OBJECT,
    simpleName: 'noCloseQuote',
    interfaces: [EContent]
  };
  var EContent$noCloseQuote_instance = null;
  function EContent$noCloseQuote_getInstance() {
    if (EContent$noCloseQuote_instance === null) {
      new EContent$noCloseQuote();
    }
    return EContent$noCloseQuote_instance;
  }
  function EContent$attr(attribute) {
    EContent.call(this, 'attr(' + attribute + ')');
  }
  EContent$attr.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'attr',
    interfaces: [EContent]
  };
  function EContent$url(attribute) {
    EContent.call(this, 'url(' + '"' + attribute + '"' + ')');
  }
  EContent$url.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'url',
    interfaces: [EContent]
  };
  EContent.prototype.toString = function () {
    return this.css_7yc12w$_0;
  };
  function EContent$Companion() {
    EContent$Companion_instance = this;
  }
  EContent$Companion.prototype.fromString_pdl1vj$ = function (option) {
    if (option == null)
      return null;
    else
      switch (option) {
        case 'close-quote':
          return EContent$closeQuote_getInstance();
        case 'no-close-quote':
          return EContent$noCloseQuote_getInstance();
        case 'no-open-quote':
          return EContent$noOpenQuote_getInstance();
        case 'none':
          return EContent$none_getInstance();
        case 'normal':
          return EContent$normal_getInstance();
        case 'open-quote':
          return EContent$openQuote_getInstance();
        default:throw IllegalArgumentException_init("Unknown content option: '" + toString(option) + "'.");
      }
  };
  EContent$Companion.$metadata$ = {
    kind: Kind_OBJECT,
    simpleName: 'Companion',
    interfaces: []
  };
  var EContent$Companion_instance = null;
  function EContent$Companion_getInstance() {
    if (EContent$Companion_instance === null) {
      new EContent$Companion();
    }
    return EContent$Companion_instance;
  }
  EContent.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'EContent',
    interfaces: []
  };
  function ECursor(name, ordinal, css) {
    Enum.call(this);
    this.css_6z5mhf$_0 = css;
    this.name$ = name;
    this.ordinal$ = ordinal;
  }
  function ECursor_initFields() {
    ECursor_initFields = function () {
    };
    ECursor$auto_instance = new ECursor('auto', 0, 'auto');
    ECursor$default_instance = new ECursor('default', 1, 'default');
    ECursor$none_instance = new ECursor('none', 2, 'none');
    ECursor$contextMenu_instance = new ECursor('contextMenu', 3, 'context-menu');
    ECursor$help_instance = new ECursor('help', 4, 'help');
    ECursor$pointer_instance = new ECursor('pointer', 5, 'pointer');
    ECursor$progress_instance = new ECursor('progress', 6, 'progress');
    ECursor$wait_instance = new ECursor('wait', 7, 'wait');
    ECursor$cell_instance = new ECursor('cell', 8, 'cell');
    ECursor$crosshair_instance = new ECursor('crosshair', 9, 'crosshair');
    ECursor$text_instance = new ECursor('text', 10, 'text');
    ECursor$verticalText_instance = new ECursor('verticalText', 11, 'vertical-text');
    ECursor$alias_instance = new ECursor('alias', 12, 'alias');
    ECursor$copy_instance = new ECursor('copy', 13, 'copy');
    ECursor$move_instance = new ECursor('move', 14, 'move');
    ECursor$noDrop_instance = new ECursor('noDrop', 15, 'no-drop');
    ECursor$notAlowed_instance = new ECursor('notAlowed', 16, 'not-allowed');
    ECursor$grab_instance = new ECursor('grab', 17, 'grab');
    ECursor$grabbing_instance = new ECursor('grabbing', 18, 'grabbing');
    ECursor$eResize_instance = new ECursor('eResize', 19, 'e-resize');
    ECursor$nResize_instance = new ECursor('nResize', 20, 'n-resize');
    ECursor$neResize_instance = new ECursor('neResize', 21, 'ne-resize');
    ECursor$nwResize_instance = new ECursor('nwResize', 22, 'nw-resize');
    ECursor$sResize_instance = new ECursor('sResize', 23, 's-resize');
    ECursor$seResize_instance = new ECursor('seResize', 24, 'se-resize');
    ECursor$swResize_instance = new ECursor('swResize', 25, 'sw-resize');
    ECursor$wResize_instance = new ECursor('wResize', 26, 'w-resize');
    ECursor$ewResize_instance = new ECursor('ewResize', 27, 'ew-resize');
    ECursor$nsResize_instance = new ECursor('nsResize', 28, 'ns-resize');
    ECursor$neswResize_instance = new ECursor('neswResize', 29, 'nesw-resize');
    ECursor$nwseResize_instance = new ECursor('nwseResize', 30, 'nwse-resize');
    ECursor$colResize_instance = new ECursor('colResize', 31, 'col-resize');
    ECursor$rowResize_instance = new ECursor('rowResize', 32, 'row-resize');
    ECursor$allScroll_instance = new ECursor('allScroll', 33, 'all-scroll');
    ECursor$zoomIn_instance = new ECursor('zoomIn', 34, 'zoom-in');
    ECursor$zoomOut_instance = new ECursor('zoomOut', 35, 'zoom-out');
    ECursor$Companion_getInstance();
  }
  var ECursor$auto_instance;
  function ECursor$auto_getInstance() {
    ECursor_initFields();
    return ECursor$auto_instance;
  }
  var ECursor$default_instance;
  function ECursor$default_getInstance() {
    ECursor_initFields();
    return ECursor$default_instance;
  }
  var ECursor$none_instance;
  function ECursor$none_getInstance() {
    ECursor_initFields();
    return ECursor$none_instance;
  }
  var ECursor$contextMenu_instance;
  function ECursor$contextMenu_getInstance() {
    ECursor_initFields();
    return ECursor$contextMenu_instance;
  }
  var ECursor$help_instance;
  function ECursor$help_getInstance() {
    ECursor_initFields();
    return ECursor$help_instance;
  }
  var ECursor$pointer_instance;
  function ECursor$pointer_getInstance() {
    ECursor_initFields();
    return ECursor$pointer_instance;
  }
  var ECursor$progress_instance;
  function ECursor$progress_getInstance() {
    ECursor_initFields();
    return ECursor$progress_instance;
  }
  var ECursor$wait_instance;
  function ECursor$wait_getInstance() {
    ECursor_initFields();
    return ECursor$wait_instance;
  }
  var ECursor$cell_instance;
  function ECursor$cell_getInstance() {
    ECursor_initFields();
    return ECursor$cell_instance;
  }
  var ECursor$crosshair_instance;
  function ECursor$crosshair_getInstance() {
    ECursor_initFields();
    return ECursor$crosshair_instance;
  }
  var ECursor$text_instance;
  function ECursor$text_getInstance() {
    ECursor_initFields();
    return ECursor$text_instance;
  }
  var ECursor$verticalText_instance;
  function ECursor$verticalText_getInstance() {
    ECursor_initFields();
    return ECursor$verticalText_instance;
  }
  var ECursor$alias_instance;
  function ECursor$alias_getInstance() {
    ECursor_initFields();
    return ECursor$alias_instance;
  }
  var ECursor$copy_instance;
  function ECursor$copy_getInstance() {
    ECursor_initFields();
    return ECursor$copy_instance;
  }
  var ECursor$move_instance;
  function ECursor$move_getInstance() {
    ECursor_initFields();
    return ECursor$move_instance;
  }
  var ECursor$noDrop_instance;
  function ECursor$noDrop_getInstance() {
    ECursor_initFields();
    return ECursor$noDrop_instance;
  }
  var ECursor$notAlowed_instance;
  function ECursor$notAlowed_getInstance() {
    ECursor_initFields();
    return ECursor$notAlowed_instance;
  }
  var ECursor$grab_instance;
  function ECursor$grab_getInstance() {
    ECursor_initFields();
    return ECursor$grab_instance;
  }
  var ECursor$grabbing_instance;
  function ECursor$grabbing_getInstance() {
    ECursor_initFields();
    return ECursor$grabbing_instance;
  }
  var ECursor$eResize_instance;
  function ECursor$eResize_getInstance() {
    ECursor_initFields();
    return ECursor$eResize_instance;
  }
  var ECursor$nResize_instance;
  function ECursor$nResize_getInstance() {
    ECursor_initFields();
    return ECursor$nResize_instance;
  }
  var ECursor$neResize_instance;
  function ECursor$neResize_getInstance() {
    ECursor_initFields();
    return ECursor$neResize_instance;
  }
  var ECursor$nwResize_instance;
  function ECursor$nwResize_getInstance() {
    ECursor_initFields();
    return ECursor$nwResize_instance;
  }
  var ECursor$sResize_instance;
  function ECursor$sResize_getInstance() {
    ECursor_initFields();
    return ECursor$sResize_instance;
  }
  var ECursor$seResize_instance;
  function ECursor$seResize_getInstance() {
    ECursor_initFields();
    return ECursor$seResize_instance;
  }
  var ECursor$swResize_instance;
  function ECursor$swResize_getInstance() {
    ECursor_initFields();
    return ECursor$swResize_instance;
  }
  var ECursor$wResize_instance;
  function ECursor$wResize_getInstance() {
    ECursor_initFields();
    return ECursor$wResize_instance;
  }
  var ECursor$ewResize_instance;
  function ECursor$ewResize_getInstance() {
    ECursor_initFields();
    return ECursor$ewResize_instance;
  }
  var ECursor$nsResize_instance;
  function ECursor$nsResize_getInstance() {
    ECursor_initFields();
    return ECursor$nsResize_instance;
  }
  var ECursor$neswResize_instance;
  function ECursor$neswResize_getInstance() {
    ECursor_initFields();
    return ECursor$neswResize_instance;
  }
  var ECursor$nwseResize_instance;
  function ECursor$nwseResize_getInstance() {
    ECursor_initFields();
    return ECursor$nwseResize_instance;
  }
  var ECursor$colResize_instance;
  function ECursor$colResize_getInstance() {
    ECursor_initFields();
    return ECursor$colResize_instance;
  }
  var ECursor$rowResize_instance;
  function ECursor$rowResize_getInstance() {
    ECursor_initFields();
    return ECursor$rowResize_instance;
  }
  var ECursor$allScroll_instance;
  function ECursor$allScroll_getInstance() {
    ECursor_initFields();
    return ECursor$allScroll_instance;
  }
  var ECursor$zoomIn_instance;
  function ECursor$zoomIn_getInstance() {
    ECursor_initFields();
    return ECursor$zoomIn_instance;
  }
  var ECursor$zoomOut_instance;
  function ECursor$zoomOut_getInstance() {
    ECursor_initFields();
    return ECursor$zoomOut_instance;
  }
  ECursor.prototype.toString = function () {
    return this.css_6z5mhf$_0;
  };
  function ECursor$Companion() {
    ECursor$Companion_instance = this;
  }
  ECursor$Companion.prototype.fromString_pdl1vj$ = function (option) {
    if (option == null)
      return null;
    else
      switch (option) {
        case 'alias':
          return ECursor$alias_getInstance();
        case 'all-scroll':
          return ECursor$allScroll_getInstance();
        case 'auto':
          return ECursor$auto_getInstance();
        case 'cell':
          return ECursor$cell_getInstance();
        case 'col-resize':
          return ECursor$colResize_getInstance();
        case 'context-menu':
          return ECursor$contextMenu_getInstance();
        case 'copy':
          return ECursor$copy_getInstance();
        case 'crosshair':
          return ECursor$crosshair_getInstance();
        case 'default':
          return ECursor$default_getInstance();
        case 'e-resize':
          return ECursor$eResize_getInstance();
        case 'ew-resize':
          return ECursor$ewResize_getInstance();
        case 'grab':
          return ECursor$grab_getInstance();
        case 'grabbing':
          return ECursor$grabbing_getInstance();
        case 'help':
          return ECursor$help_getInstance();
        case 'move':
          return ECursor$move_getInstance();
        case 'n-resize':
          return ECursor$nResize_getInstance();
        case 'ne-resize':
          return ECursor$neResize_getInstance();
        case 'nesw-resize':
          return ECursor$neswResize_getInstance();
        case 'no-drop':
          return ECursor$noDrop_getInstance();
        case 'none':
          return ECursor$none_getInstance();
        case 'not-allowed':
          return ECursor$notAlowed_getInstance();
        case 'ns-resize':
          return ECursor$nsResize_getInstance();
        case 'nw-resize':
          return ECursor$nwResize_getInstance();
        case 'nwse-resize':
          return ECursor$nwseResize_getInstance();
        case 'pointer':
          return ECursor$pointer_getInstance();
        case 'progress':
          return ECursor$progress_getInstance();
        case 'row-resize':
          return ECursor$rowResize_getInstance();
        case 's-resize':
          return ECursor$sResize_getInstance();
        case 'se-resize':
          return ECursor$seResize_getInstance();
        case 'sw-resize':
          return ECursor$swResize_getInstance();
        case 'text':
          return ECursor$text_getInstance();
        case 'vertical-text':
          return ECursor$verticalText_getInstance();
        case 'w-resize':
          return ECursor$wResize_getInstance();
        case 'wait':
          return ECursor$wait_getInstance();
        case 'zoom-in':
          return ECursor$zoomIn_getInstance();
        case 'zoom-out':
          return ECursor$zoomOut_getInstance();
        default:throw IllegalArgumentException_init("Unknown cursor option: '" + toString(option) + "'.");
      }
  };
  ECursor$Companion.$metadata$ = {
    kind: Kind_OBJECT,
    simpleName: 'Companion',
    interfaces: []
  };
  var ECursor$Companion_instance = null;
  function ECursor$Companion_getInstance() {
    ECursor_initFields();
    if (ECursor$Companion_instance === null) {
      new ECursor$Companion();
    }
    return ECursor$Companion_instance;
  }
  ECursor.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'ECursor',
    interfaces: [Enum]
  };
  function ECursor$values() {
    return [ECursor$auto_getInstance(), ECursor$default_getInstance(), ECursor$none_getInstance(), ECursor$contextMenu_getInstance(), ECursor$help_getInstance(), ECursor$pointer_getInstance(), ECursor$progress_getInstance(), ECursor$wait_getInstance(), ECursor$cell_getInstance(), ECursor$crosshair_getInstance(), ECursor$text_getInstance(), ECursor$verticalText_getInstance(), ECursor$alias_getInstance(), ECursor$copy_getInstance(), ECursor$move_getInstance(), ECursor$noDrop_getInstance(), ECursor$notAlowed_getInstance(), ECursor$grab_getInstance(), ECursor$grabbing_getInstance(), ECursor$eResize_getInstance(), ECursor$nResize_getInstance(), ECursor$neResize_getInstance(), ECursor$nwResize_getInstance(), ECursor$sResize_getInstance(), ECursor$seResize_getInstance(), ECursor$swResize_getInstance(), ECursor$wResize_getInstance(), ECursor$ewResize_getInstance(), ECursor$nsResize_getInstance(), ECursor$neswResize_getInstance(), ECursor$nwseResize_getInstance(), ECursor$colResize_getInstance(), ECursor$rowResize_getInstance(), ECursor$allScroll_getInstance(), ECursor$zoomIn_getInstance(), ECursor$zoomOut_getInstance()];
  }
  ECursor.values = ECursor$values;
  function ECursor$valueOf(name) {
    switch (name) {
      case 'auto':
        return ECursor$auto_getInstance();
      case 'default':
        return ECursor$default_getInstance();
      case 'none':
        return ECursor$none_getInstance();
      case 'contextMenu':
        return ECursor$contextMenu_getInstance();
      case 'help':
        return ECursor$help_getInstance();
      case 'pointer':
        return ECursor$pointer_getInstance();
      case 'progress':
        return ECursor$progress_getInstance();
      case 'wait':
        return ECursor$wait_getInstance();
      case 'cell':
        return ECursor$cell_getInstance();
      case 'crosshair':
        return ECursor$crosshair_getInstance();
      case 'text':
        return ECursor$text_getInstance();
      case 'verticalText':
        return ECursor$verticalText_getInstance();
      case 'alias':
        return ECursor$alias_getInstance();
      case 'copy':
        return ECursor$copy_getInstance();
      case 'move':
        return ECursor$move_getInstance();
      case 'noDrop':
        return ECursor$noDrop_getInstance();
      case 'notAlowed':
        return ECursor$notAlowed_getInstance();
      case 'grab':
        return ECursor$grab_getInstance();
      case 'grabbing':
        return ECursor$grabbing_getInstance();
      case 'eResize':
        return ECursor$eResize_getInstance();
      case 'nResize':
        return ECursor$nResize_getInstance();
      case 'neResize':
        return ECursor$neResize_getInstance();
      case 'nwResize':
        return ECursor$nwResize_getInstance();
      case 'sResize':
        return ECursor$sResize_getInstance();
      case 'seResize':
        return ECursor$seResize_getInstance();
      case 'swResize':
        return ECursor$swResize_getInstance();
      case 'wResize':
        return ECursor$wResize_getInstance();
      case 'ewResize':
        return ECursor$ewResize_getInstance();
      case 'nsResize':
        return ECursor$nsResize_getInstance();
      case 'neswResize':
        return ECursor$neswResize_getInstance();
      case 'nwseResize':
        return ECursor$nwseResize_getInstance();
      case 'colResize':
        return ECursor$colResize_getInstance();
      case 'rowResize':
        return ECursor$rowResize_getInstance();
      case 'allScroll':
        return ECursor$allScroll_getInstance();
      case 'zoomIn':
        return ECursor$zoomIn_getInstance();
      case 'zoomOut':
        return ECursor$zoomOut_getInstance();
      default:throwISE('No enum constant o.katydid.css.types.ECursor.' + name);
    }
  }
  ECursor.valueOf_61zpoe$ = ECursor$valueOf;
  function EDisplay(name, ordinal, css) {
    Enum.call(this);
    this.css_503uu7$_0 = css;
    this.name$ = name;
    this.ordinal$ = ordinal;
  }
  function EDisplay_initFields() {
    EDisplay_initFields = function () {
    };
    EDisplay$block_instance = new EDisplay('block', 0, 'block');
    EDisplay$inline_instance = new EDisplay('inline', 1, 'inline');
    EDisplay$inlineBlock_instance = new EDisplay('inlineBlock', 2, 'inline-block');
    EDisplay$inlineTable_instance = new EDisplay('inlineTable', 3, 'inline-table');
    EDisplay$listItem_instance = new EDisplay('listItem', 4, 'list-item');
    EDisplay$none_instance = new EDisplay('none', 5, 'none');
    EDisplay$table_instance = new EDisplay('table', 6, 'table');
    EDisplay$tableCaption_instance = new EDisplay('tableCaption', 7, 'table-caption');
    EDisplay$tableCell_instance = new EDisplay('tableCell', 8, 'table-cell');
    EDisplay$tableColumn_instance = new EDisplay('tableColumn', 9, 'table-column');
    EDisplay$tableColumnGroup_instance = new EDisplay('tableColumnGroup', 10, 'table-column-group');
    EDisplay$tableFooterGroup_instance = new EDisplay('tableFooterGroup', 11, 'table-footer-group');
    EDisplay$tableHeaderGroup_instance = new EDisplay('tableHeaderGroup', 12, 'table-header-group');
    EDisplay$tableRow_instance = new EDisplay('tableRow', 13, 'table-row');
    EDisplay$tableRowGroup_instance = new EDisplay('tableRowGroup', 14, 'table-row-group');
    EDisplay$Companion_getInstance();
  }
  var EDisplay$block_instance;
  function EDisplay$block_getInstance() {
    EDisplay_initFields();
    return EDisplay$block_instance;
  }
  var EDisplay$inline_instance;
  function EDisplay$inline_getInstance() {
    EDisplay_initFields();
    return EDisplay$inline_instance;
  }
  var EDisplay$inlineBlock_instance;
  function EDisplay$inlineBlock_getInstance() {
    EDisplay_initFields();
    return EDisplay$inlineBlock_instance;
  }
  var EDisplay$inlineTable_instance;
  function EDisplay$inlineTable_getInstance() {
    EDisplay_initFields();
    return EDisplay$inlineTable_instance;
  }
  var EDisplay$listItem_instance;
  function EDisplay$listItem_getInstance() {
    EDisplay_initFields();
    return EDisplay$listItem_instance;
  }
  var EDisplay$none_instance;
  function EDisplay$none_getInstance() {
    EDisplay_initFields();
    return EDisplay$none_instance;
  }
  var EDisplay$table_instance;
  function EDisplay$table_getInstance() {
    EDisplay_initFields();
    return EDisplay$table_instance;
  }
  var EDisplay$tableCaption_instance;
  function EDisplay$tableCaption_getInstance() {
    EDisplay_initFields();
    return EDisplay$tableCaption_instance;
  }
  var EDisplay$tableCell_instance;
  function EDisplay$tableCell_getInstance() {
    EDisplay_initFields();
    return EDisplay$tableCell_instance;
  }
  var EDisplay$tableColumn_instance;
  function EDisplay$tableColumn_getInstance() {
    EDisplay_initFields();
    return EDisplay$tableColumn_instance;
  }
  var EDisplay$tableColumnGroup_instance;
  function EDisplay$tableColumnGroup_getInstance() {
    EDisplay_initFields();
    return EDisplay$tableColumnGroup_instance;
  }
  var EDisplay$tableFooterGroup_instance;
  function EDisplay$tableFooterGroup_getInstance() {
    EDisplay_initFields();
    return EDisplay$tableFooterGroup_instance;
  }
  var EDisplay$tableHeaderGroup_instance;
  function EDisplay$tableHeaderGroup_getInstance() {
    EDisplay_initFields();
    return EDisplay$tableHeaderGroup_instance;
  }
  var EDisplay$tableRow_instance;
  function EDisplay$tableRow_getInstance() {
    EDisplay_initFields();
    return EDisplay$tableRow_instance;
  }
  var EDisplay$tableRowGroup_instance;
  function EDisplay$tableRowGroup_getInstance() {
    EDisplay_initFields();
    return EDisplay$tableRowGroup_instance;
  }
  EDisplay.prototype.toString = function () {
    return this.css_503uu7$_0;
  };
  function EDisplay$Companion() {
    EDisplay$Companion_instance = this;
  }
  EDisplay$Companion.prototype.fromString_pdl1vj$ = function (option) {
    if (option == null)
      return null;
    else
      switch (option) {
        case 'block':
          return EDisplay$block_getInstance();
        case 'inline':
          return EDisplay$inline_getInstance();
        case 'inline-block':
          return EDisplay$inlineBlock_getInstance();
        case 'inline-table':
          return EDisplay$inlineTable_getInstance();
        case 'list-item':
          return EDisplay$listItem_getInstance();
        case 'none':
          return EDisplay$none_getInstance();
        case 'table':
          return EDisplay$table_getInstance();
        case 'table-caption':
          return EDisplay$tableCaption_getInstance();
        case 'table-cell':
          return EDisplay$tableCell_getInstance();
        case 'table-column':
          return EDisplay$tableColumn_getInstance();
        case 'table-column-group':
          return EDisplay$tableColumnGroup_getInstance();
        case 'table-footer-group':
          return EDisplay$tableFooterGroup_getInstance();
        case 'table-header-group':
          return EDisplay$tableHeaderGroup_getInstance();
        case 'table-row':
          return EDisplay$tableRow_getInstance();
        case 'table-row-group':
          return EDisplay$tableRowGroup_getInstance();
        default:throw IllegalArgumentException_init("Unknown display option: '" + toString(option) + "'.");
      }
  };
  EDisplay$Companion.$metadata$ = {
    kind: Kind_OBJECT,
    simpleName: 'Companion',
    interfaces: []
  };
  var EDisplay$Companion_instance = null;
  function EDisplay$Companion_getInstance() {
    EDisplay_initFields();
    if (EDisplay$Companion_instance === null) {
      new EDisplay$Companion();
    }
    return EDisplay$Companion_instance;
  }
  EDisplay.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'EDisplay',
    interfaces: [Enum]
  };
  function EDisplay$values() {
    return [EDisplay$block_getInstance(), EDisplay$inline_getInstance(), EDisplay$inlineBlock_getInstance(), EDisplay$inlineTable_getInstance(), EDisplay$listItem_getInstance(), EDisplay$none_getInstance(), EDisplay$table_getInstance(), EDisplay$tableCaption_getInstance(), EDisplay$tableCell_getInstance(), EDisplay$tableColumn_getInstance(), EDisplay$tableColumnGroup_getInstance(), EDisplay$tableFooterGroup_getInstance(), EDisplay$tableHeaderGroup_getInstance(), EDisplay$tableRow_getInstance(), EDisplay$tableRowGroup_getInstance()];
  }
  EDisplay.values = EDisplay$values;
  function EDisplay$valueOf(name) {
    switch (name) {
      case 'block':
        return EDisplay$block_getInstance();
      case 'inline':
        return EDisplay$inline_getInstance();
      case 'inlineBlock':
        return EDisplay$inlineBlock_getInstance();
      case 'inlineTable':
        return EDisplay$inlineTable_getInstance();
      case 'listItem':
        return EDisplay$listItem_getInstance();
      case 'none':
        return EDisplay$none_getInstance();
      case 'table':
        return EDisplay$table_getInstance();
      case 'tableCaption':
        return EDisplay$tableCaption_getInstance();
      case 'tableCell':
        return EDisplay$tableCell_getInstance();
      case 'tableColumn':
        return EDisplay$tableColumn_getInstance();
      case 'tableColumnGroup':
        return EDisplay$tableColumnGroup_getInstance();
      case 'tableFooterGroup':
        return EDisplay$tableFooterGroup_getInstance();
      case 'tableHeaderGroup':
        return EDisplay$tableHeaderGroup_getInstance();
      case 'tableRow':
        return EDisplay$tableRow_getInstance();
      case 'tableRowGroup':
        return EDisplay$tableRowGroup_getInstance();
      default:throwISE('No enum constant o.katydid.css.types.EDisplay.' + name);
    }
  }
  EDisplay.valueOf_61zpoe$ = EDisplay$valueOf;
  function EEmptyCells(name, ordinal, css) {
    Enum.call(this);
    this.css_ai89gb$_0 = css;
    this.name$ = name;
    this.ordinal$ = ordinal;
  }
  function EEmptyCells_initFields() {
    EEmptyCells_initFields = function () {
    };
    EEmptyCells$show_instance = new EEmptyCells('show', 0, 'show');
    EEmptyCells$hide_instance = new EEmptyCells('hide', 1, 'hide');
    EEmptyCells$Companion_getInstance();
  }
  var EEmptyCells$show_instance;
  function EEmptyCells$show_getInstance() {
    EEmptyCells_initFields();
    return EEmptyCells$show_instance;
  }
  var EEmptyCells$hide_instance;
  function EEmptyCells$hide_getInstance() {
    EEmptyCells_initFields();
    return EEmptyCells$hide_instance;
  }
  EEmptyCells.prototype.toString = function () {
    return this.css_ai89gb$_0;
  };
  function EEmptyCells$Companion() {
    EEmptyCells$Companion_instance = this;
  }
  EEmptyCells$Companion.prototype.fromString_pdl1vj$ = function (option) {
    if (option == null)
      return null;
    else
      switch (option) {
        case 'hide':
          return EEmptyCells$hide_getInstance();
        case 'show':
          return EEmptyCells$show_getInstance();
        default:throw IllegalArgumentException_init("Unknown clear option: '" + toString(option) + "'.");
      }
  };
  EEmptyCells$Companion.$metadata$ = {
    kind: Kind_OBJECT,
    simpleName: 'Companion',
    interfaces: []
  };
  var EEmptyCells$Companion_instance = null;
  function EEmptyCells$Companion_getInstance() {
    EEmptyCells_initFields();
    if (EEmptyCells$Companion_instance === null) {
      new EEmptyCells$Companion();
    }
    return EEmptyCells$Companion_instance;
  }
  EEmptyCells.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'EEmptyCells',
    interfaces: [Enum]
  };
  function EEmptyCells$values() {
    return [EEmptyCells$show_getInstance(), EEmptyCells$hide_getInstance()];
  }
  EEmptyCells.values = EEmptyCells$values;
  function EEmptyCells$valueOf(name) {
    switch (name) {
      case 'show':
        return EEmptyCells$show_getInstance();
      case 'hide':
        return EEmptyCells$hide_getInstance();
      default:throwISE('No enum constant o.katydid.css.types.EEmptyCells.' + name);
    }
  }
  EEmptyCells.valueOf_61zpoe$ = EEmptyCells$valueOf;
  function EFloat(name, ordinal, css) {
    Enum.call(this);
    this.css_e7156j$_0 = css;
    this.name$ = name;
    this.ordinal$ = ordinal;
  }
  function EFloat_initFields() {
    EFloat_initFields = function () {
    };
    EFloat$left_instance = new EFloat('left', 0, 'left');
    EFloat$right_instance = new EFloat('right', 1, 'right');
    EFloat$none_instance = new EFloat('none', 2, 'none');
    EFloat$inlineStart_instance = new EFloat('inlineStart', 3, 'inline-start');
    EFloat$inlineEnd_instance = new EFloat('inlineEnd', 4, 'inline-end');
    EFloat$blockStart_instance = new EFloat('blockStart', 5, 'block-start');
    EFloat$blockEnd_instance = new EFloat('blockEnd', 6, 'block-end');
    EFloat$top_instance = new EFloat('top', 7, 'top');
    EFloat$bottom_instance = new EFloat('bottom', 8, 'bottom');
    EFloat$snapBlock_instance = new EFloat('snapBlock', 9, 'snap-block');
    EFloat$snapInline_instance = new EFloat('snapInline', 10, 'snap-inline');
    EFloat$Companion_getInstance();
  }
  var EFloat$left_instance;
  function EFloat$left_getInstance() {
    EFloat_initFields();
    return EFloat$left_instance;
  }
  var EFloat$right_instance;
  function EFloat$right_getInstance() {
    EFloat_initFields();
    return EFloat$right_instance;
  }
  var EFloat$none_instance;
  function EFloat$none_getInstance() {
    EFloat_initFields();
    return EFloat$none_instance;
  }
  var EFloat$inlineStart_instance;
  function EFloat$inlineStart_getInstance() {
    EFloat_initFields();
    return EFloat$inlineStart_instance;
  }
  var EFloat$inlineEnd_instance;
  function EFloat$inlineEnd_getInstance() {
    EFloat_initFields();
    return EFloat$inlineEnd_instance;
  }
  var EFloat$blockStart_instance;
  function EFloat$blockStart_getInstance() {
    EFloat_initFields();
    return EFloat$blockStart_instance;
  }
  var EFloat$blockEnd_instance;
  function EFloat$blockEnd_getInstance() {
    EFloat_initFields();
    return EFloat$blockEnd_instance;
  }
  var EFloat$top_instance;
  function EFloat$top_getInstance() {
    EFloat_initFields();
    return EFloat$top_instance;
  }
  var EFloat$bottom_instance;
  function EFloat$bottom_getInstance() {
    EFloat_initFields();
    return EFloat$bottom_instance;
  }
  var EFloat$snapBlock_instance;
  function EFloat$snapBlock_getInstance() {
    EFloat_initFields();
    return EFloat$snapBlock_instance;
  }
  var EFloat$snapInline_instance;
  function EFloat$snapInline_getInstance() {
    EFloat_initFields();
    return EFloat$snapInline_instance;
  }
  EFloat.prototype.toString = function () {
    return this.css_e7156j$_0;
  };
  function EFloat$Companion() {
    EFloat$Companion_instance = this;
  }
  EFloat$Companion.prototype.fromString_pdl1vj$ = function (option) {
    if (option == null)
      return null;
    else
      switch (option) {
        case 'block-end':
          return EFloat$blockEnd_getInstance();
        case 'block-start':
          return EFloat$blockStart_getInstance();
        case 'bottom':
          return EFloat$bottom_getInstance();
        case 'inline-end':
          return EFloat$inlineEnd_getInstance();
        case 'inline-start':
          return EFloat$inlineStart_getInstance();
        case 'left':
          return EFloat$left_getInstance();
        case 'none':
          return EFloat$none_getInstance();
        case 'right':
          return EFloat$right_getInstance();
        case 'snap-block':
          return EFloat$snapBlock_getInstance();
        case 'snap-inline':
          return EFloat$snapInline_getInstance();
        case 'top':
          return EFloat$top_getInstance();
        default:throw IllegalArgumentException_init("Unknown float option: '" + toString(option) + "'.");
      }
  };
  EFloat$Companion.$metadata$ = {
    kind: Kind_OBJECT,
    simpleName: 'Companion',
    interfaces: []
  };
  var EFloat$Companion_instance = null;
  function EFloat$Companion_getInstance() {
    EFloat_initFields();
    if (EFloat$Companion_instance === null) {
      new EFloat$Companion();
    }
    return EFloat$Companion_instance;
  }
  EFloat.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'EFloat',
    interfaces: [Enum]
  };
  function EFloat$values() {
    return [EFloat$left_getInstance(), EFloat$right_getInstance(), EFloat$none_getInstance(), EFloat$inlineStart_getInstance(), EFloat$inlineEnd_getInstance(), EFloat$blockStart_getInstance(), EFloat$blockEnd_getInstance(), EFloat$top_getInstance(), EFloat$bottom_getInstance(), EFloat$snapBlock_getInstance(), EFloat$snapInline_getInstance()];
  }
  EFloat.values = EFloat$values;
  function EFloat$valueOf(name) {
    switch (name) {
      case 'left':
        return EFloat$left_getInstance();
      case 'right':
        return EFloat$right_getInstance();
      case 'none':
        return EFloat$none_getInstance();
      case 'inlineStart':
        return EFloat$inlineStart_getInstance();
      case 'inlineEnd':
        return EFloat$inlineEnd_getInstance();
      case 'blockStart':
        return EFloat$blockStart_getInstance();
      case 'blockEnd':
        return EFloat$blockEnd_getInstance();
      case 'top':
        return EFloat$top_getInstance();
      case 'bottom':
        return EFloat$bottom_getInstance();
      case 'snapBlock':
        return EFloat$snapBlock_getInstance();
      case 'snapInline':
        return EFloat$snapInline_getInstance();
      default:throwISE('No enum constant o.katydid.css.types.EFloat.' + name);
    }
  }
  EFloat.valueOf_61zpoe$ = EFloat$valueOf;
  function EFontSize(name, ordinal, css) {
    Enum.call(this);
    this.css_x0kn21$_0 = css;
    this.name$ = name;
    this.ordinal$ = ordinal;
  }
  function EFontSize_initFields() {
    EFontSize_initFields = function () {
    };
    EFontSize$xxSmall_instance = new EFontSize('xxSmall', 0, 'xx-small');
    EFontSize$xSmall_instance = new EFontSize('xSmall', 1, 'x-small');
    EFontSize$small_instance = new EFontSize('small', 2, 'small');
    EFontSize$medium_instance = new EFontSize('medium', 3, 'medium');
    EFontSize$large_instance = new EFontSize('large', 4, 'large');
    EFontSize$xLarge_instance = new EFontSize('xLarge', 5, 'x-large');
    EFontSize$xxLarge_instance = new EFontSize('xxLarge', 6, 'xx-large');
    EFontSize$larger_instance = new EFontSize('larger', 7, 'larger');
    EFontSize$smaller_instance = new EFontSize('smaller', 8, 'smaller');
    EFontSize$Companion_getInstance();
  }
  var EFontSize$xxSmall_instance;
  function EFontSize$xxSmall_getInstance() {
    EFontSize_initFields();
    return EFontSize$xxSmall_instance;
  }
  var EFontSize$xSmall_instance;
  function EFontSize$xSmall_getInstance() {
    EFontSize_initFields();
    return EFontSize$xSmall_instance;
  }
  var EFontSize$small_instance;
  function EFontSize$small_getInstance() {
    EFontSize_initFields();
    return EFontSize$small_instance;
  }
  var EFontSize$medium_instance;
  function EFontSize$medium_getInstance() {
    EFontSize_initFields();
    return EFontSize$medium_instance;
  }
  var EFontSize$large_instance;
  function EFontSize$large_getInstance() {
    EFontSize_initFields();
    return EFontSize$large_instance;
  }
  var EFontSize$xLarge_instance;
  function EFontSize$xLarge_getInstance() {
    EFontSize_initFields();
    return EFontSize$xLarge_instance;
  }
  var EFontSize$xxLarge_instance;
  function EFontSize$xxLarge_getInstance() {
    EFontSize_initFields();
    return EFontSize$xxLarge_instance;
  }
  var EFontSize$larger_instance;
  function EFontSize$larger_getInstance() {
    EFontSize_initFields();
    return EFontSize$larger_instance;
  }
  var EFontSize$smaller_instance;
  function EFontSize$smaller_getInstance() {
    EFontSize_initFields();
    return EFontSize$smaller_instance;
  }
  EFontSize.prototype.toString = function () {
    return this.css_x0kn21$_0;
  };
  function EFontSize$Companion() {
    EFontSize$Companion_instance = this;
  }
  EFontSize$Companion.prototype.fromString_pdl1vj$ = function (option) {
    if (option == null)
      return null;
    else
      switch (option) {
        case 'large':
          return EFontSize$large_getInstance();
        case 'larger':
          return EFontSize$larger_getInstance();
        case 'medium':
          return EFontSize$medium_getInstance();
        case 'small':
          return EFontSize$small_getInstance();
        case 'smaller':
          return EFontSize$smaller_getInstance();
        case 'x-large':
          return EFontSize$xLarge_getInstance();
        case 'x-small':
          return EFontSize$xSmall_getInstance();
        case 'xx-large':
          return EFontSize$xxLarge_getInstance();
        case 'xx-small':
          return EFontSize$xxSmall_getInstance();
        default:throw IllegalArgumentException_init("Unknown font size option: '" + toString(option) + "'.");
      }
  };
  EFontSize$Companion.$metadata$ = {
    kind: Kind_OBJECT,
    simpleName: 'Companion',
    interfaces: []
  };
  var EFontSize$Companion_instance = null;
  function EFontSize$Companion_getInstance() {
    EFontSize_initFields();
    if (EFontSize$Companion_instance === null) {
      new EFontSize$Companion();
    }
    return EFontSize$Companion_instance;
  }
  EFontSize.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'EFontSize',
    interfaces: [Enum]
  };
  function EFontSize$values() {
    return [EFontSize$xxSmall_getInstance(), EFontSize$xSmall_getInstance(), EFontSize$small_getInstance(), EFontSize$medium_getInstance(), EFontSize$large_getInstance(), EFontSize$xLarge_getInstance(), EFontSize$xxLarge_getInstance(), EFontSize$larger_getInstance(), EFontSize$smaller_getInstance()];
  }
  EFontSize.values = EFontSize$values;
  function EFontSize$valueOf(name) {
    switch (name) {
      case 'xxSmall':
        return EFontSize$xxSmall_getInstance();
      case 'xSmall':
        return EFontSize$xSmall_getInstance();
      case 'small':
        return EFontSize$small_getInstance();
      case 'medium':
        return EFontSize$medium_getInstance();
      case 'large':
        return EFontSize$large_getInstance();
      case 'xLarge':
        return EFontSize$xLarge_getInstance();
      case 'xxLarge':
        return EFontSize$xxLarge_getInstance();
      case 'larger':
        return EFontSize$larger_getInstance();
      case 'smaller':
        return EFontSize$smaller_getInstance();
      default:throwISE('No enum constant o.katydid.css.types.EFontSize.' + name);
    }
  }
  EFontSize.valueOf_61zpoe$ = EFontSize$valueOf;
  function EFontStyle(name, ordinal, css) {
    Enum.call(this);
    this.css_chigov$_0 = css;
    this.name$ = name;
    this.ordinal$ = ordinal;
  }
  function EFontStyle_initFields() {
    EFontStyle_initFields = function () {
    };
    EFontStyle$normal_instance = new EFontStyle('normal', 0, 'normal');
    EFontStyle$italic_instance = new EFontStyle('italic', 1, 'italic');
    EFontStyle$oblique_instance = new EFontStyle('oblique', 2, 'oblique');
    EFontStyle$Companion_getInstance();
  }
  var EFontStyle$normal_instance;
  function EFontStyle$normal_getInstance() {
    EFontStyle_initFields();
    return EFontStyle$normal_instance;
  }
  var EFontStyle$italic_instance;
  function EFontStyle$italic_getInstance() {
    EFontStyle_initFields();
    return EFontStyle$italic_instance;
  }
  var EFontStyle$oblique_instance;
  function EFontStyle$oblique_getInstance() {
    EFontStyle_initFields();
    return EFontStyle$oblique_instance;
  }
  EFontStyle.prototype.toString = function () {
    return this.css_chigov$_0;
  };
  function EFontStyle$Companion() {
    EFontStyle$Companion_instance = this;
  }
  EFontStyle$Companion.prototype.fromString_pdl1vj$ = function (option) {
    if (option == null)
      return null;
    else
      switch (option) {
        case 'italic':
          return EFontStyle$italic_getInstance();
        case 'normal':
          return EFontStyle$normal_getInstance();
        case 'oblique':
          return EFontStyle$oblique_getInstance();
        default:throw IllegalArgumentException_init("Unknown font style option: '" + toString(option) + "'.");
      }
  };
  EFontStyle$Companion.$metadata$ = {
    kind: Kind_OBJECT,
    simpleName: 'Companion',
    interfaces: []
  };
  var EFontStyle$Companion_instance = null;
  function EFontStyle$Companion_getInstance() {
    EFontStyle_initFields();
    if (EFontStyle$Companion_instance === null) {
      new EFontStyle$Companion();
    }
    return EFontStyle$Companion_instance;
  }
  EFontStyle.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'EFontStyle',
    interfaces: [Enum]
  };
  function EFontStyle$values() {
    return [EFontStyle$normal_getInstance(), EFontStyle$italic_getInstance(), EFontStyle$oblique_getInstance()];
  }
  EFontStyle.values = EFontStyle$values;
  function EFontStyle$valueOf(name) {
    switch (name) {
      case 'normal':
        return EFontStyle$normal_getInstance();
      case 'italic':
        return EFontStyle$italic_getInstance();
      case 'oblique':
        return EFontStyle$oblique_getInstance();
      default:throwISE('No enum constant o.katydid.css.types.EFontStyle.' + name);
    }
  }
  EFontStyle.valueOf_61zpoe$ = EFontStyle$valueOf;
  function EFontVariant(name, ordinal, css) {
    Enum.call(this);
    this.css_i65a7f$_0 = css;
    this.name$ = name;
    this.ordinal$ = ordinal;
  }
  function EFontVariant_initFields() {
    EFontVariant_initFields = function () {
    };
    EFontVariant$normal_instance = new EFontVariant('normal', 0, 'normal');
    EFontVariant$smallCaps_instance = new EFontVariant('smallCaps', 1, 'small-caps');
    EFontVariant$allSmallCaps_instance = new EFontVariant('allSmallCaps', 2, 'all-small-caps');
    EFontVariant$petiteCaps_instance = new EFontVariant('petiteCaps', 3, 'petite-caps');
    EFontVariant$allPetiteCaps_instance = new EFontVariant('allPetiteCaps', 4, 'all-petite-caps');
    EFontVariant$unicase_instance = new EFontVariant('unicase', 5, 'unicase');
    EFontVariant$titlingCaps_instance = new EFontVariant('titlingCaps', 6, 'titling-caps');
    EFontVariant$Companion_getInstance();
  }
  var EFontVariant$normal_instance;
  function EFontVariant$normal_getInstance() {
    EFontVariant_initFields();
    return EFontVariant$normal_instance;
  }
  var EFontVariant$smallCaps_instance;
  function EFontVariant$smallCaps_getInstance() {
    EFontVariant_initFields();
    return EFontVariant$smallCaps_instance;
  }
  var EFontVariant$allSmallCaps_instance;
  function EFontVariant$allSmallCaps_getInstance() {
    EFontVariant_initFields();
    return EFontVariant$allSmallCaps_instance;
  }
  var EFontVariant$petiteCaps_instance;
  function EFontVariant$petiteCaps_getInstance() {
    EFontVariant_initFields();
    return EFontVariant$petiteCaps_instance;
  }
  var EFontVariant$allPetiteCaps_instance;
  function EFontVariant$allPetiteCaps_getInstance() {
    EFontVariant_initFields();
    return EFontVariant$allPetiteCaps_instance;
  }
  var EFontVariant$unicase_instance;
  function EFontVariant$unicase_getInstance() {
    EFontVariant_initFields();
    return EFontVariant$unicase_instance;
  }
  var EFontVariant$titlingCaps_instance;
  function EFontVariant$titlingCaps_getInstance() {
    EFontVariant_initFields();
    return EFontVariant$titlingCaps_instance;
  }
  EFontVariant.prototype.toString = function () {
    return this.css_i65a7f$_0;
  };
  function EFontVariant$Companion() {
    EFontVariant$Companion_instance = this;
  }
  EFontVariant$Companion.prototype.fromString_pdl1vj$ = function (option) {
    if (option == null)
      return null;
    else
      switch (option) {
        case 'all-petite-caps':
          return EFontVariant$allPetiteCaps_getInstance();
        case 'all-small-caps':
          return EFontVariant$allSmallCaps_getInstance();
        case 'normal':
          return EFontVariant$normal_getInstance();
        case 'petite-caps':
          return EFontVariant$petiteCaps_getInstance();
        case 'small-caps':
          return EFontVariant$smallCaps_getInstance();
        case 'titling-caps':
          return EFontVariant$titlingCaps_getInstance();
        case 'unicase':
          return EFontVariant$unicase_getInstance();
        default:throw IllegalArgumentException_init("Unknown font variant option: '" + toString(option) + "'.");
      }
  };
  EFontVariant$Companion.$metadata$ = {
    kind: Kind_OBJECT,
    simpleName: 'Companion',
    interfaces: []
  };
  var EFontVariant$Companion_instance = null;
  function EFontVariant$Companion_getInstance() {
    EFontVariant_initFields();
    if (EFontVariant$Companion_instance === null) {
      new EFontVariant$Companion();
    }
    return EFontVariant$Companion_instance;
  }
  EFontVariant.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'EFontVariant',
    interfaces: [Enum]
  };
  function EFontVariant$values() {
    return [EFontVariant$normal_getInstance(), EFontVariant$smallCaps_getInstance(), EFontVariant$allSmallCaps_getInstance(), EFontVariant$petiteCaps_getInstance(), EFontVariant$allPetiteCaps_getInstance(), EFontVariant$unicase_getInstance(), EFontVariant$titlingCaps_getInstance()];
  }
  EFontVariant.values = EFontVariant$values;
  function EFontVariant$valueOf(name) {
    switch (name) {
      case 'normal':
        return EFontVariant$normal_getInstance();
      case 'smallCaps':
        return EFontVariant$smallCaps_getInstance();
      case 'allSmallCaps':
        return EFontVariant$allSmallCaps_getInstance();
      case 'petiteCaps':
        return EFontVariant$petiteCaps_getInstance();
      case 'allPetiteCaps':
        return EFontVariant$allPetiteCaps_getInstance();
      case 'unicase':
        return EFontVariant$unicase_getInstance();
      case 'titlingCaps':
        return EFontVariant$titlingCaps_getInstance();
      default:throwISE('No enum constant o.katydid.css.types.EFontVariant.' + name);
    }
  }
  EFontVariant.valueOf_61zpoe$ = EFontVariant$valueOf;
  function EFontWeight(name, ordinal, css) {
    Enum.call(this);
    this.css_h5wt42$_0 = css;
    this.name$ = name;
    this.ordinal$ = ordinal;
  }
  function EFontWeight_initFields() {
    EFontWeight_initFields = function () {
    };
    EFontWeight$normal_instance = new EFontWeight('normal', 0, 'normal');
    EFontWeight$bold_instance = new EFontWeight('bold', 1, 'bold');
    EFontWeight$bolder_instance = new EFontWeight('bolder', 2, 'bolder');
    EFontWeight$lighter_instance = new EFontWeight('lighter', 3, 'lighter');
    EFontWeight$weight100_instance = new EFontWeight('weight100', 4, '100');
    EFontWeight$weight200_instance = new EFontWeight('weight200', 5, '200');
    EFontWeight$weight300_instance = new EFontWeight('weight300', 6, '300');
    EFontWeight$weight400_instance = new EFontWeight('weight400', 7, '400');
    EFontWeight$weight500_instance = new EFontWeight('weight500', 8, '500');
    EFontWeight$weight600_instance = new EFontWeight('weight600', 9, '600');
    EFontWeight$weight700_instance = new EFontWeight('weight700', 10, '700');
    EFontWeight$weight800_instance = new EFontWeight('weight800', 11, '800');
    EFontWeight$weight900_instance = new EFontWeight('weight900', 12, '900');
    EFontWeight$Companion_getInstance();
  }
  var EFontWeight$normal_instance;
  function EFontWeight$normal_getInstance() {
    EFontWeight_initFields();
    return EFontWeight$normal_instance;
  }
  var EFontWeight$bold_instance;
  function EFontWeight$bold_getInstance() {
    EFontWeight_initFields();
    return EFontWeight$bold_instance;
  }
  var EFontWeight$bolder_instance;
  function EFontWeight$bolder_getInstance() {
    EFontWeight_initFields();
    return EFontWeight$bolder_instance;
  }
  var EFontWeight$lighter_instance;
  function EFontWeight$lighter_getInstance() {
    EFontWeight_initFields();
    return EFontWeight$lighter_instance;
  }
  var EFontWeight$weight100_instance;
  function EFontWeight$weight100_getInstance() {
    EFontWeight_initFields();
    return EFontWeight$weight100_instance;
  }
  var EFontWeight$weight200_instance;
  function EFontWeight$weight200_getInstance() {
    EFontWeight_initFields();
    return EFontWeight$weight200_instance;
  }
  var EFontWeight$weight300_instance;
  function EFontWeight$weight300_getInstance() {
    EFontWeight_initFields();
    return EFontWeight$weight300_instance;
  }
  var EFontWeight$weight400_instance;
  function EFontWeight$weight400_getInstance() {
    EFontWeight_initFields();
    return EFontWeight$weight400_instance;
  }
  var EFontWeight$weight500_instance;
  function EFontWeight$weight500_getInstance() {
    EFontWeight_initFields();
    return EFontWeight$weight500_instance;
  }
  var EFontWeight$weight600_instance;
  function EFontWeight$weight600_getInstance() {
    EFontWeight_initFields();
    return EFontWeight$weight600_instance;
  }
  var EFontWeight$weight700_instance;
  function EFontWeight$weight700_getInstance() {
    EFontWeight_initFields();
    return EFontWeight$weight700_instance;
  }
  var EFontWeight$weight800_instance;
  function EFontWeight$weight800_getInstance() {
    EFontWeight_initFields();
    return EFontWeight$weight800_instance;
  }
  var EFontWeight$weight900_instance;
  function EFontWeight$weight900_getInstance() {
    EFontWeight_initFields();
    return EFontWeight$weight900_instance;
  }
  EFontWeight.prototype.toString = function () {
    return this.css_h5wt42$_0;
  };
  function EFontWeight$Companion() {
    EFontWeight$Companion_instance = this;
  }
  EFontWeight$Companion.prototype.fromString_pdl1vj$ = function (option) {
    if (option == null)
      return null;
    else
      switch (option) {
        case '100':
          return EFontWeight$weight100_getInstance();
        case '200':
          return EFontWeight$weight200_getInstance();
        case '300':
          return EFontWeight$weight300_getInstance();
        case '400':
          return EFontWeight$weight400_getInstance();
        case '500':
          return EFontWeight$weight500_getInstance();
        case '600':
          return EFontWeight$weight600_getInstance();
        case '700':
          return EFontWeight$weight700_getInstance();
        case '800':
          return EFontWeight$weight800_getInstance();
        case '900':
          return EFontWeight$weight900_getInstance();
        case 'bold':
          return EFontWeight$bold_getInstance();
        case 'bolder':
          return EFontWeight$bolder_getInstance();
        case 'lighter':
          return EFontWeight$lighter_getInstance();
        case 'normal':
          return EFontWeight$normal_getInstance();
        default:throw IllegalArgumentException_init("Unknown font weight option: '" + toString(option) + "'.");
      }
  };
  EFontWeight$Companion.$metadata$ = {
    kind: Kind_OBJECT,
    simpleName: 'Companion',
    interfaces: []
  };
  var EFontWeight$Companion_instance = null;
  function EFontWeight$Companion_getInstance() {
    EFontWeight_initFields();
    if (EFontWeight$Companion_instance === null) {
      new EFontWeight$Companion();
    }
    return EFontWeight$Companion_instance;
  }
  EFontWeight.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'EFontWeight',
    interfaces: [Enum]
  };
  function EFontWeight$values() {
    return [EFontWeight$normal_getInstance(), EFontWeight$bold_getInstance(), EFontWeight$bolder_getInstance(), EFontWeight$lighter_getInstance(), EFontWeight$weight100_getInstance(), EFontWeight$weight200_getInstance(), EFontWeight$weight300_getInstance(), EFontWeight$weight400_getInstance(), EFontWeight$weight500_getInstance(), EFontWeight$weight600_getInstance(), EFontWeight$weight700_getInstance(), EFontWeight$weight800_getInstance(), EFontWeight$weight900_getInstance()];
  }
  EFontWeight.values = EFontWeight$values;
  function EFontWeight$valueOf(name) {
    switch (name) {
      case 'normal':
        return EFontWeight$normal_getInstance();
      case 'bold':
        return EFontWeight$bold_getInstance();
      case 'bolder':
        return EFontWeight$bolder_getInstance();
      case 'lighter':
        return EFontWeight$lighter_getInstance();
      case 'weight100':
        return EFontWeight$weight100_getInstance();
      case 'weight200':
        return EFontWeight$weight200_getInstance();
      case 'weight300':
        return EFontWeight$weight300_getInstance();
      case 'weight400':
        return EFontWeight$weight400_getInstance();
      case 'weight500':
        return EFontWeight$weight500_getInstance();
      case 'weight600':
        return EFontWeight$weight600_getInstance();
      case 'weight700':
        return EFontWeight$weight700_getInstance();
      case 'weight800':
        return EFontWeight$weight800_getInstance();
      case 'weight900':
        return EFontWeight$weight900_getInstance();
      default:throwISE('No enum constant o.katydid.css.types.EFontWeight.' + name);
    }
  }
  EFontWeight.valueOf_61zpoe$ = EFontWeight$valueOf;
  function EImage(css) {
    EImage$Companion_getInstance();
    this.css_l8m1wa$_0 = css;
  }
  function EImage$none() {
    EImage$none_instance = this;
    EImage.call(this, 'none');
  }
  EImage$none.$metadata$ = {
    kind: Kind_OBJECT,
    simpleName: 'none',
    interfaces: [EImage]
  };
  var EImage$none_instance = null;
  function EImage$none_getInstance() {
    if (EImage$none_instance === null) {
      new EImage$none();
    }
    return EImage$none_instance;
  }
  function EImage$url(attribute) {
    EImage.call(this, 'url(' + '"' + attribute + '"' + ')');
  }
  EImage$url.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'url',
    interfaces: [EImage]
  };
  function EImage$image(imageList, color) {
    if (color === void 0)
      color = null;
    EImage.call(this, 'image(' + joinToString_0(imageList, ', ', void 0, void 0, void 0, void 0, EImage$EImage$image_init$lambda) + (color == null ? '' : ', ' + toString(color)) + ')');
  }
  function EImage$EImage$image_init$lambda(i) {
    return '"' + i + '"';
  }
  EImage$image.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'image',
    interfaces: [EImage]
  };
  EImage.prototype.toString = function () {
    return this.css_l8m1wa$_0;
  };
  function EImage$Companion() {
    EImage$Companion_instance = this;
  }
  EImage$Companion.prototype.fromString_pdl1vj$ = function (option) {
    if (option == null)
      return null;
    else
      throw IllegalArgumentException_init("Unknown content option: '" + toString(option) + "'.");
  };
  EImage$Companion.$metadata$ = {
    kind: Kind_OBJECT,
    simpleName: 'Companion',
    interfaces: []
  };
  var EImage$Companion_instance = null;
  function EImage$Companion_getInstance() {
    if (EImage$Companion_instance === null) {
      new EImage$Companion();
    }
    return EImage$Companion_instance;
  }
  EImage.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'EImage',
    interfaces: []
  };
  function ELineStyle(name, ordinal, css) {
    Enum.call(this);
    this.css_b0ub1g$_0 = css;
    this.name$ = name;
    this.ordinal$ = ordinal;
  }
  function ELineStyle_initFields() {
    ELineStyle_initFields = function () {
    };
    ELineStyle$none_instance = new ELineStyle('none', 0, 'none');
    ELineStyle$hidden_instance = new ELineStyle('hidden', 1, 'hidden');
    ELineStyle$dotted_instance = new ELineStyle('dotted', 2, 'dotted');
    ELineStyle$dashed_instance = new ELineStyle('dashed', 3, 'dashed');
    ELineStyle$solid_instance = new ELineStyle('solid', 4, 'solid');
    ELineStyle$double_instance = new ELineStyle('double', 5, 'double');
    ELineStyle$groove_instance = new ELineStyle('groove', 6, 'groove');
    ELineStyle$ridge_instance = new ELineStyle('ridge', 7, 'ridge');
    ELineStyle$inset_instance = new ELineStyle('inset', 8, 'inset');
    ELineStyle$outset_instance = new ELineStyle('outset', 9, 'outset');
    ELineStyle$Companion_getInstance();
  }
  var ELineStyle$none_instance;
  function ELineStyle$none_getInstance() {
    ELineStyle_initFields();
    return ELineStyle$none_instance;
  }
  var ELineStyle$hidden_instance;
  function ELineStyle$hidden_getInstance() {
    ELineStyle_initFields();
    return ELineStyle$hidden_instance;
  }
  var ELineStyle$dotted_instance;
  function ELineStyle$dotted_getInstance() {
    ELineStyle_initFields();
    return ELineStyle$dotted_instance;
  }
  var ELineStyle$dashed_instance;
  function ELineStyle$dashed_getInstance() {
    ELineStyle_initFields();
    return ELineStyle$dashed_instance;
  }
  var ELineStyle$solid_instance;
  function ELineStyle$solid_getInstance() {
    ELineStyle_initFields();
    return ELineStyle$solid_instance;
  }
  var ELineStyle$double_instance;
  function ELineStyle$double_getInstance() {
    ELineStyle_initFields();
    return ELineStyle$double_instance;
  }
  var ELineStyle$groove_instance;
  function ELineStyle$groove_getInstance() {
    ELineStyle_initFields();
    return ELineStyle$groove_instance;
  }
  var ELineStyle$ridge_instance;
  function ELineStyle$ridge_getInstance() {
    ELineStyle_initFields();
    return ELineStyle$ridge_instance;
  }
  var ELineStyle$inset_instance;
  function ELineStyle$inset_getInstance() {
    ELineStyle_initFields();
    return ELineStyle$inset_instance;
  }
  var ELineStyle$outset_instance;
  function ELineStyle$outset_getInstance() {
    ELineStyle_initFields();
    return ELineStyle$outset_instance;
  }
  ELineStyle.prototype.toString = function () {
    return this.css_b0ub1g$_0;
  };
  function ELineStyle$Companion() {
    ELineStyle$Companion_instance = this;
  }
  ELineStyle$Companion.prototype.fromString_pdl1vj$ = function (option) {
    if (option == null)
      return null;
    else
      switch (option) {
        case 'dashed':
          return ELineStyle$dashed_getInstance();
        case 'dotted':
          return ELineStyle$dotted_getInstance();
        case 'double':
          return ELineStyle$double_getInstance();
        case 'groove':
          return ELineStyle$groove_getInstance();
        case 'hidden':
          return ELineStyle$hidden_getInstance();
        case 'inset':
          return ELineStyle$inset_getInstance();
        case 'none':
          return ELineStyle$none_getInstance();
        case 'outset':
          return ELineStyle$outset_getInstance();
        case 'ridge':
          return ELineStyle$ridge_getInstance();
        case 'solid':
          return ELineStyle$solid_getInstance();
        default:throw IllegalArgumentException_init("Unknown border style option: '" + toString(option) + "'.");
      }
  };
  ELineStyle$Companion.$metadata$ = {
    kind: Kind_OBJECT,
    simpleName: 'Companion',
    interfaces: []
  };
  var ELineStyle$Companion_instance = null;
  function ELineStyle$Companion_getInstance() {
    ELineStyle_initFields();
    if (ELineStyle$Companion_instance === null) {
      new ELineStyle$Companion();
    }
    return ELineStyle$Companion_instance;
  }
  ELineStyle.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'ELineStyle',
    interfaces: [Enum]
  };
  function ELineStyle$values() {
    return [ELineStyle$none_getInstance(), ELineStyle$hidden_getInstance(), ELineStyle$dotted_getInstance(), ELineStyle$dashed_getInstance(), ELineStyle$solid_getInstance(), ELineStyle$double_getInstance(), ELineStyle$groove_getInstance(), ELineStyle$ridge_getInstance(), ELineStyle$inset_getInstance(), ELineStyle$outset_getInstance()];
  }
  ELineStyle.values = ELineStyle$values;
  function ELineStyle$valueOf(name) {
    switch (name) {
      case 'none':
        return ELineStyle$none_getInstance();
      case 'hidden':
        return ELineStyle$hidden_getInstance();
      case 'dotted':
        return ELineStyle$dotted_getInstance();
      case 'dashed':
        return ELineStyle$dashed_getInstance();
      case 'solid':
        return ELineStyle$solid_getInstance();
      case 'double':
        return ELineStyle$double_getInstance();
      case 'groove':
        return ELineStyle$groove_getInstance();
      case 'ridge':
        return ELineStyle$ridge_getInstance();
      case 'inset':
        return ELineStyle$inset_getInstance();
      case 'outset':
        return ELineStyle$outset_getInstance();
      default:throwISE('No enum constant o.katydid.css.types.ELineStyle.' + name);
    }
  }
  ELineStyle.valueOf_61zpoe$ = ELineStyle$valueOf;
  function ELineWidth(name, ordinal, css) {
    Enum.call(this);
    this.css_hji0sx$_0 = css;
    this.name$ = name;
    this.ordinal$ = ordinal;
  }
  function ELineWidth_initFields() {
    ELineWidth_initFields = function () {
    };
    ELineWidth$thin_instance = new ELineWidth('thin', 0, 'thin');
    ELineWidth$medium_instance = new ELineWidth('medium', 1, 'medium');
    ELineWidth$thick_instance = new ELineWidth('thick', 2, 'thick');
    ELineWidth$Companion_getInstance();
  }
  var ELineWidth$thin_instance;
  function ELineWidth$thin_getInstance() {
    ELineWidth_initFields();
    return ELineWidth$thin_instance;
  }
  var ELineWidth$medium_instance;
  function ELineWidth$medium_getInstance() {
    ELineWidth_initFields();
    return ELineWidth$medium_instance;
  }
  var ELineWidth$thick_instance;
  function ELineWidth$thick_getInstance() {
    ELineWidth_initFields();
    return ELineWidth$thick_instance;
  }
  ELineWidth.prototype.toString = function () {
    return this.css_hji0sx$_0;
  };
  function ELineWidth$Companion() {
    ELineWidth$Companion_instance = this;
  }
  ELineWidth$Companion.prototype.fromString_pdl1vj$ = function (option) {
    if (option == null)
      return null;
    else
      switch (option) {
        case 'medium':
          return ELineWidth$medium_getInstance();
        case 'thick':
          return ELineWidth$thick_getInstance();
        case 'thin':
          return ELineWidth$thin_getInstance();
        default:throw IllegalArgumentException_init("Unknown border style option: '" + toString(option) + "'.");
      }
  };
  ELineWidth$Companion.$metadata$ = {
    kind: Kind_OBJECT,
    simpleName: 'Companion',
    interfaces: []
  };
  var ELineWidth$Companion_instance = null;
  function ELineWidth$Companion_getInstance() {
    ELineWidth_initFields();
    if (ELineWidth$Companion_instance === null) {
      new ELineWidth$Companion();
    }
    return ELineWidth$Companion_instance;
  }
  ELineWidth.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'ELineWidth',
    interfaces: [Enum]
  };
  function ELineWidth$values() {
    return [ELineWidth$thin_getInstance(), ELineWidth$medium_getInstance(), ELineWidth$thick_getInstance()];
  }
  ELineWidth.values = ELineWidth$values;
  function ELineWidth$valueOf(name) {
    switch (name) {
      case 'thin':
        return ELineWidth$thin_getInstance();
      case 'medium':
        return ELineWidth$medium_getInstance();
      case 'thick':
        return ELineWidth$thick_getInstance();
      default:throwISE('No enum constant o.katydid.css.types.ELineWidth.' + name);
    }
  }
  ELineWidth.valueOf_61zpoe$ = ELineWidth$valueOf;
  function EListStylePosition(name, ordinal, css) {
    Enum.call(this);
    this.css_cco3c5$_0 = css;
    this.name$ = name;
    this.ordinal$ = ordinal;
  }
  function EListStylePosition_initFields() {
    EListStylePosition_initFields = function () {
    };
    EListStylePosition$outside_instance = new EListStylePosition('outside', 0, 'outside');
    EListStylePosition$inside_instance = new EListStylePosition('inside', 1, 'inside');
    EListStylePosition$Companion_getInstance();
  }
  var EListStylePosition$outside_instance;
  function EListStylePosition$outside_getInstance() {
    EListStylePosition_initFields();
    return EListStylePosition$outside_instance;
  }
  var EListStylePosition$inside_instance;
  function EListStylePosition$inside_getInstance() {
    EListStylePosition_initFields();
    return EListStylePosition$inside_instance;
  }
  EListStylePosition.prototype.toString = function () {
    return this.css_cco3c5$_0;
  };
  function EListStylePosition$Companion() {
    EListStylePosition$Companion_instance = this;
  }
  EListStylePosition$Companion.prototype.fromString_pdl1vj$ = function (option) {
    if (option == null)
      return null;
    else
      switch (option) {
        case 'inside':
          return EListStylePosition$inside_getInstance();
        case 'outside':
          return EListStylePosition$outside_getInstance();
        default:throw IllegalArgumentException_init("Unknown list style position option: '" + toString(option) + "'.");
      }
  };
  EListStylePosition$Companion.$metadata$ = {
    kind: Kind_OBJECT,
    simpleName: 'Companion',
    interfaces: []
  };
  var EListStylePosition$Companion_instance = null;
  function EListStylePosition$Companion_getInstance() {
    EListStylePosition_initFields();
    if (EListStylePosition$Companion_instance === null) {
      new EListStylePosition$Companion();
    }
    return EListStylePosition$Companion_instance;
  }
  EListStylePosition.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'EListStylePosition',
    interfaces: [Enum]
  };
  function EListStylePosition$values() {
    return [EListStylePosition$outside_getInstance(), EListStylePosition$inside_getInstance()];
  }
  EListStylePosition.values = EListStylePosition$values;
  function EListStylePosition$valueOf(name) {
    switch (name) {
      case 'outside':
        return EListStylePosition$outside_getInstance();
      case 'inside':
        return EListStylePosition$inside_getInstance();
      default:throwISE('No enum constant o.katydid.css.types.EListStylePosition.' + name);
    }
  }
  EListStylePosition.valueOf_61zpoe$ = EListStylePosition$valueOf;
  function EListStyleType(name, ordinal, css) {
    Enum.call(this);
    this.css_s0mz90$_0 = css;
    this.name$ = name;
    this.ordinal$ = ordinal;
  }
  function EListStyleType_initFields() {
    EListStyleType_initFields = function () {
    };
    EListStyleType$disc_instance = new EListStyleType('disc', 0, 'disc');
    EListStyleType$circle_instance = new EListStyleType('circle', 1, 'circle');
    EListStyleType$square_instance = new EListStyleType('square', 2, 'square');
    EListStyleType$decimal_instance = new EListStyleType('decimal', 3, 'decimal');
    EListStyleType$decimalLeadingZero_instance = new EListStyleType('decimalLeadingZero', 4, 'decimal-leading-zero');
    EListStyleType$lowerRoman_instance = new EListStyleType('lowerRoman', 5, 'lower-roman');
    EListStyleType$upperRoman_instance = new EListStyleType('upperRoman', 6, 'upper-roman');
    EListStyleType$georgian_instance = new EListStyleType('georgian', 7, 'georgian');
    EListStyleType$armenian_instance = new EListStyleType('armenian', 8, 'armenian');
    EListStyleType$lowerLatin_instance = new EListStyleType('lowerLatin', 9, 'lower-latin');
    EListStyleType$upperLatin_instance = new EListStyleType('upperLatin', 10, 'upper-latin');
    EListStyleType$lowerGreek_instance = new EListStyleType('lowerGreek', 11, 'lower-greek');
    EListStyleType$Companion_getInstance();
  }
  var EListStyleType$disc_instance;
  function EListStyleType$disc_getInstance() {
    EListStyleType_initFields();
    return EListStyleType$disc_instance;
  }
  var EListStyleType$circle_instance;
  function EListStyleType$circle_getInstance() {
    EListStyleType_initFields();
    return EListStyleType$circle_instance;
  }
  var EListStyleType$square_instance;
  function EListStyleType$square_getInstance() {
    EListStyleType_initFields();
    return EListStyleType$square_instance;
  }
  var EListStyleType$decimal_instance;
  function EListStyleType$decimal_getInstance() {
    EListStyleType_initFields();
    return EListStyleType$decimal_instance;
  }
  var EListStyleType$decimalLeadingZero_instance;
  function EListStyleType$decimalLeadingZero_getInstance() {
    EListStyleType_initFields();
    return EListStyleType$decimalLeadingZero_instance;
  }
  var EListStyleType$lowerRoman_instance;
  function EListStyleType$lowerRoman_getInstance() {
    EListStyleType_initFields();
    return EListStyleType$lowerRoman_instance;
  }
  var EListStyleType$upperRoman_instance;
  function EListStyleType$upperRoman_getInstance() {
    EListStyleType_initFields();
    return EListStyleType$upperRoman_instance;
  }
  var EListStyleType$georgian_instance;
  function EListStyleType$georgian_getInstance() {
    EListStyleType_initFields();
    return EListStyleType$georgian_instance;
  }
  var EListStyleType$armenian_instance;
  function EListStyleType$armenian_getInstance() {
    EListStyleType_initFields();
    return EListStyleType$armenian_instance;
  }
  var EListStyleType$lowerLatin_instance;
  function EListStyleType$lowerLatin_getInstance() {
    EListStyleType_initFields();
    return EListStyleType$lowerLatin_instance;
  }
  var EListStyleType$upperLatin_instance;
  function EListStyleType$upperLatin_getInstance() {
    EListStyleType_initFields();
    return EListStyleType$upperLatin_instance;
  }
  var EListStyleType$lowerGreek_instance;
  function EListStyleType$lowerGreek_getInstance() {
    EListStyleType_initFields();
    return EListStyleType$lowerGreek_instance;
  }
  EListStyleType.prototype.toString = function () {
    return this.css_s0mz90$_0;
  };
  function EListStyleType$Companion() {
    EListStyleType$Companion_instance = this;
    this.lowerAlpha = EListStyleType$lowerLatin_getInstance();
    this.upperAlpha = EListStyleType$upperLatin_getInstance();
  }
  EListStyleType$Companion.prototype.fromString_pdl1vj$ = function (option) {
    if (option == null)
      return null;
    else
      switch (option) {
        case 'armenian':
          return EListStyleType$armenian_getInstance();
        case 'circle':
          return EListStyleType$circle_getInstance();
        case 'decimal':
          return EListStyleType$decimal_getInstance();
        case 'decimal-leading-zero':
          return EListStyleType$decimalLeadingZero_getInstance();
        case 'disc':
          return EListStyleType$disc_getInstance();
        case 'georgian':
          return EListStyleType$georgian_getInstance();
        case 'lower-alpha':
          return EListStyleType$lowerLatin_getInstance();
        case 'lower-greek':
          return EListStyleType$lowerGreek_getInstance();
        case 'lower-latin':
          return EListStyleType$lowerLatin_getInstance();
        case 'lower-roman':
          return EListStyleType$lowerRoman_getInstance();
        case 'square':
          return EListStyleType$square_getInstance();
        case 'upper-alpha':
          return EListStyleType$upperLatin_getInstance();
        case 'upper-latin':
          return EListStyleType$upperLatin_getInstance();
        case 'upper-roman':
          return EListStyleType$upperRoman_getInstance();
        default:throw IllegalArgumentException_init("Unknown list style type option: '" + toString(option) + "'.");
      }
  };
  EListStyleType$Companion.$metadata$ = {
    kind: Kind_OBJECT,
    simpleName: 'Companion',
    interfaces: []
  };
  var EListStyleType$Companion_instance = null;
  function EListStyleType$Companion_getInstance() {
    EListStyleType_initFields();
    if (EListStyleType$Companion_instance === null) {
      new EListStyleType$Companion();
    }
    return EListStyleType$Companion_instance;
  }
  EListStyleType.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'EListStyleType',
    interfaces: [Enum]
  };
  function EListStyleType$values() {
    return [EListStyleType$disc_getInstance(), EListStyleType$circle_getInstance(), EListStyleType$square_getInstance(), EListStyleType$decimal_getInstance(), EListStyleType$decimalLeadingZero_getInstance(), EListStyleType$lowerRoman_getInstance(), EListStyleType$upperRoman_getInstance(), EListStyleType$georgian_getInstance(), EListStyleType$armenian_getInstance(), EListStyleType$lowerLatin_getInstance(), EListStyleType$upperLatin_getInstance(), EListStyleType$lowerGreek_getInstance()];
  }
  EListStyleType.values = EListStyleType$values;
  function EListStyleType$valueOf(name) {
    switch (name) {
      case 'disc':
        return EListStyleType$disc_getInstance();
      case 'circle':
        return EListStyleType$circle_getInstance();
      case 'square':
        return EListStyleType$square_getInstance();
      case 'decimal':
        return EListStyleType$decimal_getInstance();
      case 'decimalLeadingZero':
        return EListStyleType$decimalLeadingZero_getInstance();
      case 'lowerRoman':
        return EListStyleType$lowerRoman_getInstance();
      case 'upperRoman':
        return EListStyleType$upperRoman_getInstance();
      case 'georgian':
        return EListStyleType$georgian_getInstance();
      case 'armenian':
        return EListStyleType$armenian_getInstance();
      case 'lowerLatin':
        return EListStyleType$lowerLatin_getInstance();
      case 'upperLatin':
        return EListStyleType$upperLatin_getInstance();
      case 'lowerGreek':
        return EListStyleType$lowerGreek_getInstance();
      default:throwISE('No enum constant o.katydid.css.types.EListStyleType.' + name);
    }
  }
  EListStyleType.valueOf_61zpoe$ = EListStyleType$valueOf;
  function ENone(name, ordinal, css) {
    Enum.call(this);
    this.css_9h9xf5$_0 = css;
    this.name$ = name;
    this.ordinal$ = ordinal;
  }
  function ENone_initFields() {
    ENone_initFields = function () {
    };
    ENone$none_instance = new ENone('none', 0, 'none');
    ENone$Companion_getInstance();
  }
  var ENone$none_instance;
  function ENone$none_getInstance() {
    ENone_initFields();
    return ENone$none_instance;
  }
  ENone.prototype.toString = function () {
    return this.css_9h9xf5$_0;
  };
  function ENone$Companion() {
    ENone$Companion_instance = this;
  }
  ENone$Companion.prototype.fromString_pdl1vj$ = function (option) {
    if (option == null)
      return null;
    else if (equals(option, 'none'))
      return ENone$none_getInstance();
    else
      return null;
  };
  ENone$Companion.$metadata$ = {
    kind: Kind_OBJECT,
    simpleName: 'Companion',
    interfaces: []
  };
  var ENone$Companion_instance = null;
  function ENone$Companion_getInstance() {
    ENone_initFields();
    if (ENone$Companion_instance === null) {
      new ENone$Companion();
    }
    return ENone$Companion_instance;
  }
  ENone.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'ENone',
    interfaces: [Enum]
  };
  function ENone$values() {
    return [ENone$none_getInstance()];
  }
  ENone.values = ENone$values;
  function ENone$valueOf(name) {
    switch (name) {
      case 'none':
        return ENone$none_getInstance();
      default:throwISE('No enum constant o.katydid.css.types.ENone.' + name);
    }
  }
  ENone.valueOf_61zpoe$ = ENone$valueOf;
  function ENormal(name, ordinal, css) {
    Enum.call(this);
    this.css_sm9h5u$_0 = css;
    this.name$ = name;
    this.ordinal$ = ordinal;
  }
  function ENormal_initFields() {
    ENormal_initFields = function () {
    };
    ENormal$normal_instance = new ENormal('normal', 0, 'normal');
    ENormal$Companion_getInstance();
  }
  var ENormal$normal_instance;
  function ENormal$normal_getInstance() {
    ENormal_initFields();
    return ENormal$normal_instance;
  }
  ENormal.prototype.toString = function () {
    return this.css_sm9h5u$_0;
  };
  function ENormal$Companion() {
    ENormal$Companion_instance = this;
  }
  ENormal$Companion.prototype.fromString_pdl1vj$ = function (option) {
    if (option == null)
      return null;
    else if (equals(option, 'normal'))
      return ENormal$normal_getInstance();
    else
      throw IllegalArgumentException_init("Unknown 'normal' option: '" + toString(option) + "'.");
  };
  ENormal$Companion.$metadata$ = {
    kind: Kind_OBJECT,
    simpleName: 'Companion',
    interfaces: []
  };
  var ENormal$Companion_instance = null;
  function ENormal$Companion_getInstance() {
    ENormal_initFields();
    if (ENormal$Companion_instance === null) {
      new ENormal$Companion();
    }
    return ENormal$Companion_instance;
  }
  ENormal.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'ENormal',
    interfaces: [Enum]
  };
  function ENormal$values() {
    return [ENormal$normal_getInstance()];
  }
  ENormal.values = ENormal$values;
  function ENormal$valueOf(name) {
    switch (name) {
      case 'normal':
        return ENormal$normal_getInstance();
      default:throwISE('No enum constant o.katydid.css.types.ENormal.' + name);
    }
  }
  ENormal.valueOf_61zpoe$ = ENormal$valueOf;
  function EOutlineColor(name, ordinal, css) {
    Enum.call(this);
    this.css_5fc3d4$_0 = css;
    this.name$ = name;
    this.ordinal$ = ordinal;
  }
  function EOutlineColor_initFields() {
    EOutlineColor_initFields = function () {
    };
    EOutlineColor$invert_instance = new EOutlineColor('invert', 0, 'invert');
    EOutlineColor$Companion_getInstance();
  }
  var EOutlineColor$invert_instance;
  function EOutlineColor$invert_getInstance() {
    EOutlineColor_initFields();
    return EOutlineColor$invert_instance;
  }
  EOutlineColor.prototype.toString = function () {
    return this.css_5fc3d4$_0;
  };
  function EOutlineColor$Companion() {
    EOutlineColor$Companion_instance = this;
  }
  EOutlineColor$Companion.prototype.fromString_pdl1vj$ = function (option) {
    if (option == null)
      return null;
    else if (equals(option, 'invert'))
      return EOutlineColor$invert_getInstance();
    else
      throw IllegalArgumentException_init("Unknown outline color option: '" + toString(option) + "'.");
  };
  EOutlineColor$Companion.$metadata$ = {
    kind: Kind_OBJECT,
    simpleName: 'Companion',
    interfaces: []
  };
  var EOutlineColor$Companion_instance = null;
  function EOutlineColor$Companion_getInstance() {
    EOutlineColor_initFields();
    if (EOutlineColor$Companion_instance === null) {
      new EOutlineColor$Companion();
    }
    return EOutlineColor$Companion_instance;
  }
  EOutlineColor.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'EOutlineColor',
    interfaces: [Enum]
  };
  function EOutlineColor$values() {
    return [EOutlineColor$invert_getInstance()];
  }
  EOutlineColor.values = EOutlineColor$values;
  function EOutlineColor$valueOf(name) {
    switch (name) {
      case 'invert':
        return EOutlineColor$invert_getInstance();
      default:throwISE('No enum constant o.katydid.css.types.EOutlineColor.' + name);
    }
  }
  EOutlineColor.valueOf_61zpoe$ = EOutlineColor$valueOf;
  function EOverflow(name, ordinal, css) {
    Enum.call(this);
    this.css_104wm1$_0 = css;
    this.name$ = name;
    this.ordinal$ = ordinal;
  }
  function EOverflow_initFields() {
    EOverflow_initFields = function () {
    };
    EOverflow$visible_instance = new EOverflow('visible', 0, 'visible');
    EOverflow$hidden_instance = new EOverflow('hidden', 1, 'hidden');
    EOverflow$clip_instance = new EOverflow('clip', 2, 'clip');
    EOverflow$scroll_instance = new EOverflow('scroll', 3, 'scroll');
    EOverflow$auto_instance = new EOverflow('auto', 4, 'auto');
    EOverflow$Companion_getInstance();
  }
  var EOverflow$visible_instance;
  function EOverflow$visible_getInstance() {
    EOverflow_initFields();
    return EOverflow$visible_instance;
  }
  var EOverflow$hidden_instance;
  function EOverflow$hidden_getInstance() {
    EOverflow_initFields();
    return EOverflow$hidden_instance;
  }
  var EOverflow$clip_instance;
  function EOverflow$clip_getInstance() {
    EOverflow_initFields();
    return EOverflow$clip_instance;
  }
  var EOverflow$scroll_instance;
  function EOverflow$scroll_getInstance() {
    EOverflow_initFields();
    return EOverflow$scroll_instance;
  }
  var EOverflow$auto_instance;
  function EOverflow$auto_getInstance() {
    EOverflow_initFields();
    return EOverflow$auto_instance;
  }
  EOverflow.prototype.toString = function () {
    return this.css_104wm1$_0;
  };
  function EOverflow$Companion() {
    EOverflow$Companion_instance = this;
  }
  EOverflow$Companion.prototype.fromString_pdl1vj$ = function (option) {
    if (option == null)
      return null;
    else
      switch (option) {
        case 'auto':
          return EOverflow$auto_getInstance();
        case 'clip':
          return EOverflow$clip_getInstance();
        case 'hidden':
          return EOverflow$hidden_getInstance();
        case 'scroll':
          return EOverflow$scroll_getInstance();
        case 'visible':
          return EOverflow$visible_getInstance();
        default:throw IllegalArgumentException_init("Unknown overflow option: '" + toString(option) + "'.");
      }
  };
  EOverflow$Companion.$metadata$ = {
    kind: Kind_OBJECT,
    simpleName: 'Companion',
    interfaces: []
  };
  var EOverflow$Companion_instance = null;
  function EOverflow$Companion_getInstance() {
    EOverflow_initFields();
    if (EOverflow$Companion_instance === null) {
      new EOverflow$Companion();
    }
    return EOverflow$Companion_instance;
  }
  EOverflow.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'EOverflow',
    interfaces: [Enum]
  };
  function EOverflow$values() {
    return [EOverflow$visible_getInstance(), EOverflow$hidden_getInstance(), EOverflow$clip_getInstance(), EOverflow$scroll_getInstance(), EOverflow$auto_getInstance()];
  }
  EOverflow.values = EOverflow$values;
  function EOverflow$valueOf(name) {
    switch (name) {
      case 'visible':
        return EOverflow$visible_getInstance();
      case 'hidden':
        return EOverflow$hidden_getInstance();
      case 'clip':
        return EOverflow$clip_getInstance();
      case 'scroll':
        return EOverflow$scroll_getInstance();
      case 'auto':
        return EOverflow$auto_getInstance();
      default:throwISE('No enum constant o.katydid.css.types.EOverflow.' + name);
    }
  }
  EOverflow.valueOf_61zpoe$ = EOverflow$valueOf;
  function EOverflowWrap(name, ordinal, css) {
    Enum.call(this);
    this.css_dxyvul$_0 = css;
    this.name$ = name;
    this.ordinal$ = ordinal;
  }
  function EOverflowWrap_initFields() {
    EOverflowWrap_initFields = function () {
    };
    EOverflowWrap$normal_instance = new EOverflowWrap('normal', 0, 'normal');
    EOverflowWrap$breakWord_instance = new EOverflowWrap('breakWord', 1, 'break-word');
    EOverflowWrap$Companion_getInstance();
  }
  var EOverflowWrap$normal_instance;
  function EOverflowWrap$normal_getInstance() {
    EOverflowWrap_initFields();
    return EOverflowWrap$normal_instance;
  }
  var EOverflowWrap$breakWord_instance;
  function EOverflowWrap$breakWord_getInstance() {
    EOverflowWrap_initFields();
    return EOverflowWrap$breakWord_instance;
  }
  EOverflowWrap.prototype.toString = function () {
    return this.css_dxyvul$_0;
  };
  function EOverflowWrap$Companion() {
    EOverflowWrap$Companion_instance = this;
  }
  EOverflowWrap$Companion.prototype.fromString_pdl1vj$ = function (option) {
    if (option == null)
      return null;
    else
      switch (option) {
        case 'normal':
          return EOverflowWrap$normal_getInstance();
        case 'break-word':
          return EOverflowWrap$breakWord_getInstance();
        default:throw IllegalArgumentException_init("Unknown overflow wrap option: '" + toString(option) + "'.");
      }
  };
  EOverflowWrap$Companion.$metadata$ = {
    kind: Kind_OBJECT,
    simpleName: 'Companion',
    interfaces: []
  };
  var EOverflowWrap$Companion_instance = null;
  function EOverflowWrap$Companion_getInstance() {
    EOverflowWrap_initFields();
    if (EOverflowWrap$Companion_instance === null) {
      new EOverflowWrap$Companion();
    }
    return EOverflowWrap$Companion_instance;
  }
  EOverflowWrap.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'EOverflowWrap',
    interfaces: [Enum]
  };
  function EOverflowWrap$values() {
    return [EOverflowWrap$normal_getInstance(), EOverflowWrap$breakWord_getInstance()];
  }
  EOverflowWrap.values = EOverflowWrap$values;
  function EOverflowWrap$valueOf(name) {
    switch (name) {
      case 'normal':
        return EOverflowWrap$normal_getInstance();
      case 'breakWord':
        return EOverflowWrap$breakWord_getInstance();
      default:throwISE('No enum constant o.katydid.css.types.EOverflowWrap.' + name);
    }
  }
  EOverflowWrap.valueOf_61zpoe$ = EOverflowWrap$valueOf;
  function EPageBreak(name, ordinal, css) {
    Enum.call(this);
    this.css_kp081d$_0 = css;
    this.name$ = name;
    this.ordinal$ = ordinal;
  }
  function EPageBreak_initFields() {
    EPageBreak_initFields = function () {
    };
    EPageBreak$auto_instance = new EPageBreak('auto', 0, 'auto');
    EPageBreak$always_instance = new EPageBreak('always', 1, 'always');
    EPageBreak$avoid_instance = new EPageBreak('avoid', 2, 'avoid');
    EPageBreak$left_instance = new EPageBreak('left', 3, 'left');
    EPageBreak$right_instance = new EPageBreak('right', 4, 'right');
    EPageBreak$Companion_getInstance();
  }
  var EPageBreak$auto_instance;
  function EPageBreak$auto_getInstance() {
    EPageBreak_initFields();
    return EPageBreak$auto_instance;
  }
  var EPageBreak$always_instance;
  function EPageBreak$always_getInstance() {
    EPageBreak_initFields();
    return EPageBreak$always_instance;
  }
  var EPageBreak$avoid_instance;
  function EPageBreak$avoid_getInstance() {
    EPageBreak_initFields();
    return EPageBreak$avoid_instance;
  }
  var EPageBreak$left_instance;
  function EPageBreak$left_getInstance() {
    EPageBreak_initFields();
    return EPageBreak$left_instance;
  }
  var EPageBreak$right_instance;
  function EPageBreak$right_getInstance() {
    EPageBreak_initFields();
    return EPageBreak$right_instance;
  }
  EPageBreak.prototype.toString = function () {
    return this.css_kp081d$_0;
  };
  function EPageBreak$Companion() {
    EPageBreak$Companion_instance = this;
  }
  EPageBreak$Companion.prototype.fromString_pdl1vj$ = function (option) {
    if (option == null)
      return null;
    else
      switch (option) {
        case 'always':
          return EPageBreak$always_getInstance();
        case 'auto':
          return EPageBreak$auto_getInstance();
        case 'avoid':
          return EPageBreak$avoid_getInstance();
        case 'left':
          return EPageBreak$left_getInstance();
        case 'right':
          return EPageBreak$right_getInstance();
        default:throw IllegalArgumentException_init("Unknown page break option: '" + toString(option) + "'.");
      }
  };
  EPageBreak$Companion.$metadata$ = {
    kind: Kind_OBJECT,
    simpleName: 'Companion',
    interfaces: []
  };
  var EPageBreak$Companion_instance = null;
  function EPageBreak$Companion_getInstance() {
    EPageBreak_initFields();
    if (EPageBreak$Companion_instance === null) {
      new EPageBreak$Companion();
    }
    return EPageBreak$Companion_instance;
  }
  EPageBreak.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'EPageBreak',
    interfaces: [Enum]
  };
  function EPageBreak$values() {
    return [EPageBreak$auto_getInstance(), EPageBreak$always_getInstance(), EPageBreak$avoid_getInstance(), EPageBreak$left_getInstance(), EPageBreak$right_getInstance()];
  }
  EPageBreak.values = EPageBreak$values;
  function EPageBreak$valueOf(name) {
    switch (name) {
      case 'auto':
        return EPageBreak$auto_getInstance();
      case 'always':
        return EPageBreak$always_getInstance();
      case 'avoid':
        return EPageBreak$avoid_getInstance();
      case 'left':
        return EPageBreak$left_getInstance();
      case 'right':
        return EPageBreak$right_getInstance();
      default:throwISE('No enum constant o.katydid.css.types.EPageBreak.' + name);
    }
  }
  EPageBreak.valueOf_61zpoe$ = EPageBreak$valueOf;
  function EPageBreakInside(name, ordinal, css) {
    Enum.call(this);
    this.css_wnnw8b$_0 = css;
    this.name$ = name;
    this.ordinal$ = ordinal;
  }
  function EPageBreakInside_initFields() {
    EPageBreakInside_initFields = function () {
    };
    EPageBreakInside$auto_instance = new EPageBreakInside('auto', 0, 'auto');
    EPageBreakInside$avoid_instance = new EPageBreakInside('avoid', 1, 'avoid');
    EPageBreakInside$Companion_getInstance();
  }
  var EPageBreakInside$auto_instance;
  function EPageBreakInside$auto_getInstance() {
    EPageBreakInside_initFields();
    return EPageBreakInside$auto_instance;
  }
  var EPageBreakInside$avoid_instance;
  function EPageBreakInside$avoid_getInstance() {
    EPageBreakInside_initFields();
    return EPageBreakInside$avoid_instance;
  }
  EPageBreakInside.prototype.toString = function () {
    return this.css_wnnw8b$_0;
  };
  function EPageBreakInside$Companion() {
    EPageBreakInside$Companion_instance = this;
  }
  EPageBreakInside$Companion.prototype.fromString_pdl1vj$ = function (option) {
    if (option == null)
      return null;
    else
      switch (option) {
        case 'auto':
          return EPageBreakInside$auto_getInstance();
        case 'avoid':
          return EPageBreakInside$avoid_getInstance();
        default:throw IllegalArgumentException_init("Unknown page break inside option: '" + toString(option) + "'.");
      }
  };
  EPageBreakInside$Companion.$metadata$ = {
    kind: Kind_OBJECT,
    simpleName: 'Companion',
    interfaces: []
  };
  var EPageBreakInside$Companion_instance = null;
  function EPageBreakInside$Companion_getInstance() {
    EPageBreakInside_initFields();
    if (EPageBreakInside$Companion_instance === null) {
      new EPageBreakInside$Companion();
    }
    return EPageBreakInside$Companion_instance;
  }
  EPageBreakInside.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'EPageBreakInside',
    interfaces: [Enum]
  };
  function EPageBreakInside$values() {
    return [EPageBreakInside$auto_getInstance(), EPageBreakInside$avoid_getInstance()];
  }
  EPageBreakInside.values = EPageBreakInside$values;
  function EPageBreakInside$valueOf(name) {
    switch (name) {
      case 'auto':
        return EPageBreakInside$auto_getInstance();
      case 'avoid':
        return EPageBreakInside$avoid_getInstance();
      default:throwISE('No enum constant o.katydid.css.types.EPageBreakInside.' + name);
    }
  }
  EPageBreakInside.valueOf_61zpoe$ = EPageBreakInside$valueOf;
  function EPosition(name, ordinal, css) {
    Enum.call(this);
    this.css_6kt1k0$_0 = css;
    this.name$ = name;
    this.ordinal$ = ordinal;
  }
  function EPosition_initFields() {
    EPosition_initFields = function () {
    };
    EPosition$static_instance = new EPosition('static', 0, 'static');
    EPosition$relative_instance = new EPosition('relative', 1, 'relative');
    EPosition$absolute_instance = new EPosition('absolute', 2, 'absolute');
    EPosition$sticky_instance = new EPosition('sticky', 3, 'sticky');
    EPosition$fixed_instance = new EPosition('fixed', 4, 'fixed');
    EPosition$Companion_getInstance();
  }
  var EPosition$static_instance;
  function EPosition$static_getInstance() {
    EPosition_initFields();
    return EPosition$static_instance;
  }
  var EPosition$relative_instance;
  function EPosition$relative_getInstance() {
    EPosition_initFields();
    return EPosition$relative_instance;
  }
  var EPosition$absolute_instance;
  function EPosition$absolute_getInstance() {
    EPosition_initFields();
    return EPosition$absolute_instance;
  }
  var EPosition$sticky_instance;
  function EPosition$sticky_getInstance() {
    EPosition_initFields();
    return EPosition$sticky_instance;
  }
  var EPosition$fixed_instance;
  function EPosition$fixed_getInstance() {
    EPosition_initFields();
    return EPosition$fixed_instance;
  }
  EPosition.prototype.toString = function () {
    return this.css_6kt1k0$_0;
  };
  function EPosition$Companion() {
    EPosition$Companion_instance = this;
  }
  EPosition$Companion.prototype.fromString_pdl1vj$ = function (option) {
    if (option == null)
      return null;
    else
      switch (option) {
        case 'absolute':
          return EPosition$absolute_getInstance();
        case 'fixed':
          return EPosition$fixed_getInstance();
        case 'relative':
          return EPosition$relative_getInstance();
        case 'static':
          return EPosition$static_getInstance();
        case 'sticky':
          return EPosition$sticky_getInstance();
        default:throw IllegalArgumentException_init("Unknown position option: '" + toString(option) + "'.");
      }
  };
  EPosition$Companion.$metadata$ = {
    kind: Kind_OBJECT,
    simpleName: 'Companion',
    interfaces: []
  };
  var EPosition$Companion_instance = null;
  function EPosition$Companion_getInstance() {
    EPosition_initFields();
    if (EPosition$Companion_instance === null) {
      new EPosition$Companion();
    }
    return EPosition$Companion_instance;
  }
  EPosition.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'EPosition',
    interfaces: [Enum]
  };
  function EPosition$values() {
    return [EPosition$static_getInstance(), EPosition$relative_getInstance(), EPosition$absolute_getInstance(), EPosition$sticky_getInstance(), EPosition$fixed_getInstance()];
  }
  EPosition.values = EPosition$values;
  function EPosition$valueOf(name) {
    switch (name) {
      case 'static':
        return EPosition$static_getInstance();
      case 'relative':
        return EPosition$relative_getInstance();
      case 'absolute':
        return EPosition$absolute_getInstance();
      case 'sticky':
        return EPosition$sticky_getInstance();
      case 'fixed':
        return EPosition$fixed_getInstance();
      default:throwISE('No enum constant o.katydid.css.types.EPosition.' + name);
    }
  }
  EPosition.valueOf_61zpoe$ = EPosition$valueOf;
  function ERepeatStyle(name, ordinal, css) {
    Enum.call(this);
    this.css_z6rt85$_0 = css;
    this.name$ = name;
    this.ordinal$ = ordinal;
  }
  function ERepeatStyle_initFields() {
    ERepeatStyle_initFields = function () {
    };
    ERepeatStyle$repeat_instance = new ERepeatStyle('repeat', 0, 'repeat');
    ERepeatStyle$space_instance = new ERepeatStyle('space', 1, 'space');
    ERepeatStyle$round_instance = new ERepeatStyle('round', 2, 'round');
    ERepeatStyle$noRepeat_instance = new ERepeatStyle('noRepeat', 3, 'no-repeat');
    ERepeatStyle$repeatX_instance = new ERepeatStyle('repeatX', 4, 'repeat-x');
    ERepeatStyle$repeatY_instance = new ERepeatStyle('repeatY', 5, 'repeat-y');
    ERepeatStyle$Companion_getInstance();
  }
  var ERepeatStyle$repeat_instance;
  function ERepeatStyle$repeat_getInstance() {
    ERepeatStyle_initFields();
    return ERepeatStyle$repeat_instance;
  }
  var ERepeatStyle$space_instance;
  function ERepeatStyle$space_getInstance() {
    ERepeatStyle_initFields();
    return ERepeatStyle$space_instance;
  }
  var ERepeatStyle$round_instance;
  function ERepeatStyle$round_getInstance() {
    ERepeatStyle_initFields();
    return ERepeatStyle$round_instance;
  }
  var ERepeatStyle$noRepeat_instance;
  function ERepeatStyle$noRepeat_getInstance() {
    ERepeatStyle_initFields();
    return ERepeatStyle$noRepeat_instance;
  }
  var ERepeatStyle$repeatX_instance;
  function ERepeatStyle$repeatX_getInstance() {
    ERepeatStyle_initFields();
    return ERepeatStyle$repeatX_instance;
  }
  var ERepeatStyle$repeatY_instance;
  function ERepeatStyle$repeatY_getInstance() {
    ERepeatStyle_initFields();
    return ERepeatStyle$repeatY_instance;
  }
  ERepeatStyle.prototype.toString = function () {
    return this.css_z6rt85$_0;
  };
  function ERepeatStyle$Companion() {
    ERepeatStyle$Companion_instance = this;
  }
  ERepeatStyle$Companion.prototype.fromString_pdl1vj$ = function (option) {
    if (option == null)
      return null;
    else
      switch (option) {
        case 'no-repeat':
          return ERepeatStyle$noRepeat_getInstance();
        case 'repeat':
          return ERepeatStyle$repeat_getInstance();
        case 'repeat-x':
          return ERepeatStyle$repeatX_getInstance();
        case 'repeat-y':
          return ERepeatStyle$repeatY_getInstance();
        case 'round':
          return ERepeatStyle$round_getInstance();
        case 'space':
          return ERepeatStyle$space_getInstance();
        default:throw IllegalArgumentException_init("Unknown background repeat option: '" + toString(option) + "'.");
      }
  };
  ERepeatStyle$Companion.$metadata$ = {
    kind: Kind_OBJECT,
    simpleName: 'Companion',
    interfaces: []
  };
  var ERepeatStyle$Companion_instance = null;
  function ERepeatStyle$Companion_getInstance() {
    ERepeatStyle_initFields();
    if (ERepeatStyle$Companion_instance === null) {
      new ERepeatStyle$Companion();
    }
    return ERepeatStyle$Companion_instance;
  }
  ERepeatStyle.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'ERepeatStyle',
    interfaces: [Enum]
  };
  function ERepeatStyle$values() {
    return [ERepeatStyle$repeat_getInstance(), ERepeatStyle$space_getInstance(), ERepeatStyle$round_getInstance(), ERepeatStyle$noRepeat_getInstance(), ERepeatStyle$repeatX_getInstance(), ERepeatStyle$repeatY_getInstance()];
  }
  ERepeatStyle.values = ERepeatStyle$values;
  function ERepeatStyle$valueOf(name) {
    switch (name) {
      case 'repeat':
        return ERepeatStyle$repeat_getInstance();
      case 'space':
        return ERepeatStyle$space_getInstance();
      case 'round':
        return ERepeatStyle$round_getInstance();
      case 'noRepeat':
        return ERepeatStyle$noRepeat_getInstance();
      case 'repeatX':
        return ERepeatStyle$repeatX_getInstance();
      case 'repeatY':
        return ERepeatStyle$repeatY_getInstance();
      default:throwISE('No enum constant o.katydid.css.types.ERepeatStyle.' + name);
    }
  }
  ERepeatStyle.valueOf_61zpoe$ = ERepeatStyle$valueOf;
  function EResize(name, ordinal, css) {
    Enum.call(this);
    this.css_iml8qd$_0 = css;
    this.name$ = name;
    this.ordinal$ = ordinal;
  }
  function EResize_initFields() {
    EResize_initFields = function () {
    };
    EResize$none_instance = new EResize('none', 0, 'none');
    EResize$both_instance = new EResize('both', 1, 'both');
    EResize$horizontal_instance = new EResize('horizontal', 2, 'horizontal');
    EResize$vertical_instance = new EResize('vertical', 3, 'vertical');
    EResize$Companion_getInstance();
  }
  var EResize$none_instance;
  function EResize$none_getInstance() {
    EResize_initFields();
    return EResize$none_instance;
  }
  var EResize$both_instance;
  function EResize$both_getInstance() {
    EResize_initFields();
    return EResize$both_instance;
  }
  var EResize$horizontal_instance;
  function EResize$horizontal_getInstance() {
    EResize_initFields();
    return EResize$horizontal_instance;
  }
  var EResize$vertical_instance;
  function EResize$vertical_getInstance() {
    EResize_initFields();
    return EResize$vertical_instance;
  }
  EResize.prototype.toString = function () {
    return this.css_iml8qd$_0;
  };
  function EResize$Companion() {
    EResize$Companion_instance = this;
  }
  EResize$Companion.prototype.fromString_pdl1vj$ = function (option) {
    if (option == null)
      return null;
    else
      switch (option) {
        case 'both':
          return EResize$both_getInstance();
        case 'horizontal':
          return EResize$horizontal_getInstance();
        case 'none':
          return EResize$none_getInstance();
        case 'vertical':
          return EResize$vertical_getInstance();
        default:throw IllegalArgumentException_init("Unknown resize option: '" + toString(option) + "'.");
      }
  };
  EResize$Companion.$metadata$ = {
    kind: Kind_OBJECT,
    simpleName: 'Companion',
    interfaces: []
  };
  var EResize$Companion_instance = null;
  function EResize$Companion_getInstance() {
    EResize_initFields();
    if (EResize$Companion_instance === null) {
      new EResize$Companion();
    }
    return EResize$Companion_instance;
  }
  EResize.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'EResize',
    interfaces: [Enum]
  };
  function EResize$values() {
    return [EResize$none_getInstance(), EResize$both_getInstance(), EResize$horizontal_getInstance(), EResize$vertical_getInstance()];
  }
  EResize.values = EResize$values;
  function EResize$valueOf(name) {
    switch (name) {
      case 'none':
        return EResize$none_getInstance();
      case 'both':
        return EResize$both_getInstance();
      case 'horizontal':
        return EResize$horizontal_getInstance();
      case 'vertical':
        return EResize$vertical_getInstance();
      default:throwISE('No enum constant o.katydid.css.types.EResize.' + name);
    }
  }
  EResize.valueOf_61zpoe$ = EResize$valueOf;
  function ETableLayout(name, ordinal, css) {
    Enum.call(this);
    this.css_387geh$_0 = css;
    this.name$ = name;
    this.ordinal$ = ordinal;
  }
  function ETableLayout_initFields() {
    ETableLayout_initFields = function () {
    };
    ETableLayout$fixed_instance = new ETableLayout('fixed', 0, 'fixed');
    ETableLayout$auto_instance = new ETableLayout('auto', 1, 'auto');
    ETableLayout$Companion_getInstance();
  }
  var ETableLayout$fixed_instance;
  function ETableLayout$fixed_getInstance() {
    ETableLayout_initFields();
    return ETableLayout$fixed_instance;
  }
  var ETableLayout$auto_instance;
  function ETableLayout$auto_getInstance() {
    ETableLayout_initFields();
    return ETableLayout$auto_instance;
  }
  ETableLayout.prototype.toString = function () {
    return this.css_387geh$_0;
  };
  function ETableLayout$Companion() {
    ETableLayout$Companion_instance = this;
  }
  ETableLayout$Companion.prototype.fromString_pdl1vj$ = function (option) {
    if (option == null)
      return null;
    else
      switch (option) {
        case 'auto':
          return ETableLayout$auto_getInstance();
        case 'fixed':
          return ETableLayout$fixed_getInstance();
        default:throw IllegalArgumentException_init("Unknown table layout option: '" + toString(option) + "'.");
      }
  };
  ETableLayout$Companion.$metadata$ = {
    kind: Kind_OBJECT,
    simpleName: 'Companion',
    interfaces: []
  };
  var ETableLayout$Companion_instance = null;
  function ETableLayout$Companion_getInstance() {
    ETableLayout_initFields();
    if (ETableLayout$Companion_instance === null) {
      new ETableLayout$Companion();
    }
    return ETableLayout$Companion_instance;
  }
  ETableLayout.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'ETableLayout',
    interfaces: [Enum]
  };
  function ETableLayout$values() {
    return [ETableLayout$fixed_getInstance(), ETableLayout$auto_getInstance()];
  }
  ETableLayout.values = ETableLayout$values;
  function ETableLayout$valueOf(name) {
    switch (name) {
      case 'fixed':
        return ETableLayout$fixed_getInstance();
      case 'auto':
        return ETableLayout$auto_getInstance();
      default:throwISE('No enum constant o.katydid.css.types.ETableLayout.' + name);
    }
  }
  ETableLayout.valueOf_61zpoe$ = ETableLayout$valueOf;
  function ETextAlign(name, ordinal, css) {
    Enum.call(this);
    this.css_groxvt$_0 = css;
    this.name$ = name;
    this.ordinal$ = ordinal;
  }
  function ETextAlign_initFields() {
    ETextAlign_initFields = function () {
    };
    ETextAlign$start_instance = new ETextAlign('start', 0, 'start');
    ETextAlign$end_instance = new ETextAlign('end', 1, 'end');
    ETextAlign$left_instance = new ETextAlign('left', 2, 'left');
    ETextAlign$right_instance = new ETextAlign('right', 3, 'right');
    ETextAlign$center_instance = new ETextAlign('center', 4, 'center');
    ETextAlign$justify_instance = new ETextAlign('justify', 5, 'justify');
    ETextAlign$justifyAll_instance = new ETextAlign('justifyAll', 6, 'justify-all');
    ETextAlign$matchParent_instance = new ETextAlign('matchParent', 7, 'match-parent');
    ETextAlign$Companion_getInstance();
  }
  var ETextAlign$start_instance;
  function ETextAlign$start_getInstance() {
    ETextAlign_initFields();
    return ETextAlign$start_instance;
  }
  var ETextAlign$end_instance;
  function ETextAlign$end_getInstance() {
    ETextAlign_initFields();
    return ETextAlign$end_instance;
  }
  var ETextAlign$left_instance;
  function ETextAlign$left_getInstance() {
    ETextAlign_initFields();
    return ETextAlign$left_instance;
  }
  var ETextAlign$right_instance;
  function ETextAlign$right_getInstance() {
    ETextAlign_initFields();
    return ETextAlign$right_instance;
  }
  var ETextAlign$center_instance;
  function ETextAlign$center_getInstance() {
    ETextAlign_initFields();
    return ETextAlign$center_instance;
  }
  var ETextAlign$justify_instance;
  function ETextAlign$justify_getInstance() {
    ETextAlign_initFields();
    return ETextAlign$justify_instance;
  }
  var ETextAlign$justifyAll_instance;
  function ETextAlign$justifyAll_getInstance() {
    ETextAlign_initFields();
    return ETextAlign$justifyAll_instance;
  }
  var ETextAlign$matchParent_instance;
  function ETextAlign$matchParent_getInstance() {
    ETextAlign_initFields();
    return ETextAlign$matchParent_instance;
  }
  ETextAlign.prototype.toString = function () {
    return this.css_groxvt$_0;
  };
  function ETextAlign$Companion() {
    ETextAlign$Companion_instance = this;
  }
  ETextAlign$Companion.prototype.fromString_pdl1vj$ = function (option) {
    if (option == null)
      return null;
    else
      switch (option) {
        case 'center':
          return ETextAlign$center_getInstance();
        case 'end':
          return ETextAlign$end_getInstance();
        case 'justify':
          return ETextAlign$justify_getInstance();
        case 'justify-all':
          return ETextAlign$justifyAll_getInstance();
        case 'left':
          return ETextAlign$left_getInstance();
        case 'match-parent':
          return ETextAlign$matchParent_getInstance();
        case 'right':
          return ETextAlign$right_getInstance();
        case 'start':
          return ETextAlign$start_getInstance();
        default:throw IllegalArgumentException_init("Unknown text align option: '" + toString(option) + "'.");
      }
  };
  ETextAlign$Companion.$metadata$ = {
    kind: Kind_OBJECT,
    simpleName: 'Companion',
    interfaces: []
  };
  var ETextAlign$Companion_instance = null;
  function ETextAlign$Companion_getInstance() {
    ETextAlign_initFields();
    if (ETextAlign$Companion_instance === null) {
      new ETextAlign$Companion();
    }
    return ETextAlign$Companion_instance;
  }
  ETextAlign.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'ETextAlign',
    interfaces: [Enum]
  };
  function ETextAlign$values() {
    return [ETextAlign$start_getInstance(), ETextAlign$end_getInstance(), ETextAlign$left_getInstance(), ETextAlign$right_getInstance(), ETextAlign$center_getInstance(), ETextAlign$justify_getInstance(), ETextAlign$justifyAll_getInstance(), ETextAlign$matchParent_getInstance()];
  }
  ETextAlign.values = ETextAlign$values;
  function ETextAlign$valueOf(name) {
    switch (name) {
      case 'start':
        return ETextAlign$start_getInstance();
      case 'end':
        return ETextAlign$end_getInstance();
      case 'left':
        return ETextAlign$left_getInstance();
      case 'right':
        return ETextAlign$right_getInstance();
      case 'center':
        return ETextAlign$center_getInstance();
      case 'justify':
        return ETextAlign$justify_getInstance();
      case 'justifyAll':
        return ETextAlign$justifyAll_getInstance();
      case 'matchParent':
        return ETextAlign$matchParent_getInstance();
      default:throwISE('No enum constant o.katydid.css.types.ETextAlign.' + name);
    }
  }
  ETextAlign.valueOf_61zpoe$ = ETextAlign$valueOf;
  function ETextDecorationLine(name, ordinal, css) {
    Enum.call(this);
    this.css_duruh4$_0 = css;
    this.name$ = name;
    this.ordinal$ = ordinal;
  }
  function ETextDecorationLine_initFields() {
    ETextDecorationLine_initFields = function () {
    };
    ETextDecorationLine$underline_instance = new ETextDecorationLine('underline', 0, 'underline');
    ETextDecorationLine$overline_instance = new ETextDecorationLine('overline', 1, 'overline');
    ETextDecorationLine$lineThrough_instance = new ETextDecorationLine('lineThrough', 2, 'line-through');
    ETextDecorationLine$Companion_getInstance();
  }
  var ETextDecorationLine$underline_instance;
  function ETextDecorationLine$underline_getInstance() {
    ETextDecorationLine_initFields();
    return ETextDecorationLine$underline_instance;
  }
  var ETextDecorationLine$overline_instance;
  function ETextDecorationLine$overline_getInstance() {
    ETextDecorationLine_initFields();
    return ETextDecorationLine$overline_instance;
  }
  var ETextDecorationLine$lineThrough_instance;
  function ETextDecorationLine$lineThrough_getInstance() {
    ETextDecorationLine_initFields();
    return ETextDecorationLine$lineThrough_instance;
  }
  ETextDecorationLine.prototype.toString = function () {
    return this.css_duruh4$_0;
  };
  function ETextDecorationLine$Companion() {
    ETextDecorationLine$Companion_instance = this;
  }
  ETextDecorationLine$Companion.prototype.fromString_pdl1vj$ = function (option) {
    if (option == null)
      return null;
    else
      switch (option) {
        case 'line-through':
          return ETextDecorationLine$lineThrough_getInstance();
        case 'overline':
          return ETextDecorationLine$overline_getInstance();
        case 'underline':
          return ETextDecorationLine$underline_getInstance();
        default:throw IllegalArgumentException_init("Unknown text decoration option: '" + toString(option) + "'.");
      }
  };
  ETextDecorationLine$Companion.$metadata$ = {
    kind: Kind_OBJECT,
    simpleName: 'Companion',
    interfaces: []
  };
  var ETextDecorationLine$Companion_instance = null;
  function ETextDecorationLine$Companion_getInstance() {
    ETextDecorationLine_initFields();
    if (ETextDecorationLine$Companion_instance === null) {
      new ETextDecorationLine$Companion();
    }
    return ETextDecorationLine$Companion_instance;
  }
  ETextDecorationLine.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'ETextDecorationLine',
    interfaces: [Enum]
  };
  function ETextDecorationLine$values() {
    return [ETextDecorationLine$underline_getInstance(), ETextDecorationLine$overline_getInstance(), ETextDecorationLine$lineThrough_getInstance()];
  }
  ETextDecorationLine.values = ETextDecorationLine$values;
  function ETextDecorationLine$valueOf(name) {
    switch (name) {
      case 'underline':
        return ETextDecorationLine$underline_getInstance();
      case 'overline':
        return ETextDecorationLine$overline_getInstance();
      case 'lineThrough':
        return ETextDecorationLine$lineThrough_getInstance();
      default:throwISE('No enum constant o.katydid.css.types.ETextDecorationLine.' + name);
    }
  }
  ETextDecorationLine.valueOf_61zpoe$ = ETextDecorationLine$valueOf;
  function ETextDecorationStyle(name, ordinal, css) {
    Enum.call(this);
    this.css_j4260d$_0 = css;
    this.name$ = name;
    this.ordinal$ = ordinal;
  }
  function ETextDecorationStyle_initFields() {
    ETextDecorationStyle_initFields = function () {
    };
    ETextDecorationStyle$dotted_instance = new ETextDecorationStyle('dotted', 0, 'dotted');
    ETextDecorationStyle$dashed_instance = new ETextDecorationStyle('dashed', 1, 'dashed');
    ETextDecorationStyle$solid_instance = new ETextDecorationStyle('solid', 2, 'solid');
    ETextDecorationStyle$double_instance = new ETextDecorationStyle('double', 3, 'double');
    ETextDecorationStyle$wavy_instance = new ETextDecorationStyle('wavy', 4, 'wavy');
    ETextDecorationStyle$Companion_getInstance();
  }
  var ETextDecorationStyle$dotted_instance;
  function ETextDecorationStyle$dotted_getInstance() {
    ETextDecorationStyle_initFields();
    return ETextDecorationStyle$dotted_instance;
  }
  var ETextDecorationStyle$dashed_instance;
  function ETextDecorationStyle$dashed_getInstance() {
    ETextDecorationStyle_initFields();
    return ETextDecorationStyle$dashed_instance;
  }
  var ETextDecorationStyle$solid_instance;
  function ETextDecorationStyle$solid_getInstance() {
    ETextDecorationStyle_initFields();
    return ETextDecorationStyle$solid_instance;
  }
  var ETextDecorationStyle$double_instance;
  function ETextDecorationStyle$double_getInstance() {
    ETextDecorationStyle_initFields();
    return ETextDecorationStyle$double_instance;
  }
  var ETextDecorationStyle$wavy_instance;
  function ETextDecorationStyle$wavy_getInstance() {
    ETextDecorationStyle_initFields();
    return ETextDecorationStyle$wavy_instance;
  }
  ETextDecorationStyle.prototype.toString = function () {
    return this.css_j4260d$_0;
  };
  function ETextDecorationStyle$Companion() {
    ETextDecorationStyle$Companion_instance = this;
  }
  ETextDecorationStyle$Companion.prototype.fromString_pdl1vj$ = function (option) {
    if (option == null)
      return null;
    else
      switch (option) {
        case 'dotted':
          return ETextDecorationStyle$dotted_getInstance();
        case 'dashed':
          return ETextDecorationStyle$dashed_getInstance();
        case 'solid':
          return ETextDecorationStyle$solid_getInstance();
        case 'double':
          return ETextDecorationStyle$double_getInstance();
        case 'wavy':
          return ETextDecorationStyle$wavy_getInstance();
        default:throw IllegalArgumentException_init("Unknown text decoration style option: '" + toString(option) + "'.");
      }
  };
  ETextDecorationStyle$Companion.$metadata$ = {
    kind: Kind_OBJECT,
    simpleName: 'Companion',
    interfaces: []
  };
  var ETextDecorationStyle$Companion_instance = null;
  function ETextDecorationStyle$Companion_getInstance() {
    ETextDecorationStyle_initFields();
    if (ETextDecorationStyle$Companion_instance === null) {
      new ETextDecorationStyle$Companion();
    }
    return ETextDecorationStyle$Companion_instance;
  }
  ETextDecorationStyle.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'ETextDecorationStyle',
    interfaces: [Enum]
  };
  function ETextDecorationStyle$values() {
    return [ETextDecorationStyle$dotted_getInstance(), ETextDecorationStyle$dashed_getInstance(), ETextDecorationStyle$solid_getInstance(), ETextDecorationStyle$double_getInstance(), ETextDecorationStyle$wavy_getInstance()];
  }
  ETextDecorationStyle.values = ETextDecorationStyle$values;
  function ETextDecorationStyle$valueOf(name) {
    switch (name) {
      case 'dotted':
        return ETextDecorationStyle$dotted_getInstance();
      case 'dashed':
        return ETextDecorationStyle$dashed_getInstance();
      case 'solid':
        return ETextDecorationStyle$solid_getInstance();
      case 'double':
        return ETextDecorationStyle$double_getInstance();
      case 'wavy':
        return ETextDecorationStyle$wavy_getInstance();
      default:throwISE('No enum constant o.katydid.css.types.ETextDecorationStyle.' + name);
    }
  }
  ETextDecorationStyle.valueOf_61zpoe$ = ETextDecorationStyle$valueOf;
  function ETextJustify(name, ordinal, css) {
    Enum.call(this);
    this.css_92mmji$_0 = css;
    this.name$ = name;
    this.ordinal$ = ordinal;
  }
  function ETextJustify_initFields() {
    ETextJustify_initFields = function () {
    };
    ETextJustify$auto_instance = new ETextJustify('auto', 0, 'auto');
    ETextJustify$none_instance = new ETextJustify('none', 1, 'none');
    ETextJustify$interWord_instance = new ETextJustify('interWord', 2, 'inter-word');
    ETextJustify$interCharacter_instance = new ETextJustify('interCharacter', 3, 'inter-character');
    ETextJustify$Companion_getInstance();
  }
  var ETextJustify$auto_instance;
  function ETextJustify$auto_getInstance() {
    ETextJustify_initFields();
    return ETextJustify$auto_instance;
  }
  var ETextJustify$none_instance;
  function ETextJustify$none_getInstance() {
    ETextJustify_initFields();
    return ETextJustify$none_instance;
  }
  var ETextJustify$interWord_instance;
  function ETextJustify$interWord_getInstance() {
    ETextJustify_initFields();
    return ETextJustify$interWord_instance;
  }
  var ETextJustify$interCharacter_instance;
  function ETextJustify$interCharacter_getInstance() {
    ETextJustify_initFields();
    return ETextJustify$interCharacter_instance;
  }
  ETextJustify.prototype.toString = function () {
    return this.css_92mmji$_0;
  };
  function ETextJustify$Companion() {
    ETextJustify$Companion_instance = this;
  }
  ETextJustify$Companion.prototype.fromString_pdl1vj$ = function (option) {
    if (option == null)
      return null;
    else
      switch (option) {
        case 'auto':
          return ETextJustify$auto_getInstance();
        case 'none':
          return ETextJustify$none_getInstance();
        case 'inter-word':
          return ETextJustify$interWord_getInstance();
        case 'inter-character':
          return ETextJustify$interCharacter_getInstance();
        default:throw IllegalArgumentException_init("Unknown text justify option: '" + toString(option) + "'.");
      }
  };
  ETextJustify$Companion.$metadata$ = {
    kind: Kind_OBJECT,
    simpleName: 'Companion',
    interfaces: []
  };
  var ETextJustify$Companion_instance = null;
  function ETextJustify$Companion_getInstance() {
    ETextJustify_initFields();
    if (ETextJustify$Companion_instance === null) {
      new ETextJustify$Companion();
    }
    return ETextJustify$Companion_instance;
  }
  ETextJustify.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'ETextJustify',
    interfaces: [Enum]
  };
  function ETextJustify$values() {
    return [ETextJustify$auto_getInstance(), ETextJustify$none_getInstance(), ETextJustify$interWord_getInstance(), ETextJustify$interCharacter_getInstance()];
  }
  ETextJustify.values = ETextJustify$values;
  function ETextJustify$valueOf(name) {
    switch (name) {
      case 'auto':
        return ETextJustify$auto_getInstance();
      case 'none':
        return ETextJustify$none_getInstance();
      case 'interWord':
        return ETextJustify$interWord_getInstance();
      case 'interCharacter':
        return ETextJustify$interCharacter_getInstance();
      default:throwISE('No enum constant o.katydid.css.types.ETextJustify.' + name);
    }
  }
  ETextJustify.valueOf_61zpoe$ = ETextJustify$valueOf;
  function ETextOverflow(name, ordinal, css) {
    Enum.call(this);
    this.css_l3fzgm$_0 = css;
    this.name$ = name;
    this.ordinal$ = ordinal;
  }
  function ETextOverflow_initFields() {
    ETextOverflow_initFields = function () {
    };
    ETextOverflow$clip_instance = new ETextOverflow('clip', 0, 'clip');
    ETextOverflow$ellipsis_instance = new ETextOverflow('ellipsis', 1, 'ellipsis');
    ETextOverflow$Companion_getInstance();
  }
  var ETextOverflow$clip_instance;
  function ETextOverflow$clip_getInstance() {
    ETextOverflow_initFields();
    return ETextOverflow$clip_instance;
  }
  var ETextOverflow$ellipsis_instance;
  function ETextOverflow$ellipsis_getInstance() {
    ETextOverflow_initFields();
    return ETextOverflow$ellipsis_instance;
  }
  ETextOverflow.prototype.toString = function () {
    return this.css_l3fzgm$_0;
  };
  function ETextOverflow$Companion() {
    ETextOverflow$Companion_instance = this;
  }
  ETextOverflow$Companion.prototype.fromString_pdl1vj$ = function (option) {
    if (option == null)
      return null;
    else
      switch (option) {
        case 'clip':
          return ETextOverflow$clip_getInstance();
        case 'ellipsis':
          return ETextOverflow$ellipsis_getInstance();
        default:throw IllegalArgumentException_init("Unknown text overflow option: '" + toString(option) + "'.");
      }
  };
  ETextOverflow$Companion.$metadata$ = {
    kind: Kind_OBJECT,
    simpleName: 'Companion',
    interfaces: []
  };
  var ETextOverflow$Companion_instance = null;
  function ETextOverflow$Companion_getInstance() {
    ETextOverflow_initFields();
    if (ETextOverflow$Companion_instance === null) {
      new ETextOverflow$Companion();
    }
    return ETextOverflow$Companion_instance;
  }
  ETextOverflow.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'ETextOverflow',
    interfaces: [Enum]
  };
  function ETextOverflow$values() {
    return [ETextOverflow$clip_getInstance(), ETextOverflow$ellipsis_getInstance()];
  }
  ETextOverflow.values = ETextOverflow$values;
  function ETextOverflow$valueOf(name) {
    switch (name) {
      case 'clip':
        return ETextOverflow$clip_getInstance();
      case 'ellipsis':
        return ETextOverflow$ellipsis_getInstance();
      default:throwISE('No enum constant o.katydid.css.types.ETextOverflow.' + name);
    }
  }
  ETextOverflow.valueOf_61zpoe$ = ETextOverflow$valueOf;
  function ETextTransform(name, ordinal, css) {
    Enum.call(this);
    this.css_nwwyrm$_0 = css;
    this.name$ = name;
    this.ordinal$ = ordinal;
  }
  function ETextTransform_initFields() {
    ETextTransform_initFields = function () {
    };
    ETextTransform$capitalize_instance = new ETextTransform('capitalize', 0, 'capitalize');
    ETextTransform$uppercase_instance = new ETextTransform('uppercase', 1, 'uppercase');
    ETextTransform$lowercase_instance = new ETextTransform('lowercase', 2, 'lowercase');
    ETextTransform$none_instance = new ETextTransform('none', 3, 'none');
    ETextTransform$fullWidth_instance = new ETextTransform('fullWidth', 4, 'full-width');
    ETextTransform$Companion_getInstance();
  }
  var ETextTransform$capitalize_instance;
  function ETextTransform$capitalize_getInstance() {
    ETextTransform_initFields();
    return ETextTransform$capitalize_instance;
  }
  var ETextTransform$uppercase_instance;
  function ETextTransform$uppercase_getInstance() {
    ETextTransform_initFields();
    return ETextTransform$uppercase_instance;
  }
  var ETextTransform$lowercase_instance;
  function ETextTransform$lowercase_getInstance() {
    ETextTransform_initFields();
    return ETextTransform$lowercase_instance;
  }
  var ETextTransform$none_instance;
  function ETextTransform$none_getInstance() {
    ETextTransform_initFields();
    return ETextTransform$none_instance;
  }
  var ETextTransform$fullWidth_instance;
  function ETextTransform$fullWidth_getInstance() {
    ETextTransform_initFields();
    return ETextTransform$fullWidth_instance;
  }
  ETextTransform.prototype.toString = function () {
    return this.css_nwwyrm$_0;
  };
  function ETextTransform$Companion() {
    ETextTransform$Companion_instance = this;
  }
  ETextTransform$Companion.prototype.fromString_pdl1vj$ = function (option) {
    if (option == null)
      return null;
    else
      switch (option) {
        case 'capitalize':
          return ETextTransform$capitalize_getInstance();
        case 'full-width':
          return ETextTransform$fullWidth_getInstance();
        case 'lowercase':
          return ETextTransform$lowercase_getInstance();
        case 'none':
          return ETextTransform$none_getInstance();
        case 'uppercase':
          return ETextTransform$uppercase_getInstance();
        default:throw IllegalArgumentException_init("Unknown text transform option: '" + toString(option) + "'.");
      }
  };
  ETextTransform$Companion.$metadata$ = {
    kind: Kind_OBJECT,
    simpleName: 'Companion',
    interfaces: []
  };
  var ETextTransform$Companion_instance = null;
  function ETextTransform$Companion_getInstance() {
    ETextTransform_initFields();
    if (ETextTransform$Companion_instance === null) {
      new ETextTransform$Companion();
    }
    return ETextTransform$Companion_instance;
  }
  ETextTransform.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'ETextTransform',
    interfaces: [Enum]
  };
  function ETextTransform$values() {
    return [ETextTransform$capitalize_getInstance(), ETextTransform$uppercase_getInstance(), ETextTransform$lowercase_getInstance(), ETextTransform$none_getInstance(), ETextTransform$fullWidth_getInstance()];
  }
  ETextTransform.values = ETextTransform$values;
  function ETextTransform$valueOf(name) {
    switch (name) {
      case 'capitalize':
        return ETextTransform$capitalize_getInstance();
      case 'uppercase':
        return ETextTransform$uppercase_getInstance();
      case 'lowercase':
        return ETextTransform$lowercase_getInstance();
      case 'none':
        return ETextTransform$none_getInstance();
      case 'fullWidth':
        return ETextTransform$fullWidth_getInstance();
      default:throwISE('No enum constant o.katydid.css.types.ETextTransform.' + name);
    }
  }
  ETextTransform.valueOf_61zpoe$ = ETextTransform$valueOf;
  function EUnicodeBidi(name, ordinal, css) {
    Enum.call(this);
    this.css_y7iwzc$_0 = css;
    this.name$ = name;
    this.ordinal$ = ordinal;
  }
  function EUnicodeBidi_initFields() {
    EUnicodeBidi_initFields = function () {
    };
    EUnicodeBidi$normal_instance = new EUnicodeBidi('normal', 0, 'normal');
    EUnicodeBidi$embed_instance = new EUnicodeBidi('embed', 1, 'embed');
    EUnicodeBidi$isolate_instance = new EUnicodeBidi('isolate', 2, 'isolate');
    EUnicodeBidi$bidiOverride_instance = new EUnicodeBidi('bidiOverride', 3, 'bidi-override');
    EUnicodeBidi$isolateOverride_instance = new EUnicodeBidi('isolateOverride', 4, 'isolate-override');
    EUnicodeBidi$plaintext_instance = new EUnicodeBidi('plaintext', 5, 'plaintext');
    EUnicodeBidi$Companion_getInstance();
  }
  var EUnicodeBidi$normal_instance;
  function EUnicodeBidi$normal_getInstance() {
    EUnicodeBidi_initFields();
    return EUnicodeBidi$normal_instance;
  }
  var EUnicodeBidi$embed_instance;
  function EUnicodeBidi$embed_getInstance() {
    EUnicodeBidi_initFields();
    return EUnicodeBidi$embed_instance;
  }
  var EUnicodeBidi$isolate_instance;
  function EUnicodeBidi$isolate_getInstance() {
    EUnicodeBidi_initFields();
    return EUnicodeBidi$isolate_instance;
  }
  var EUnicodeBidi$bidiOverride_instance;
  function EUnicodeBidi$bidiOverride_getInstance() {
    EUnicodeBidi_initFields();
    return EUnicodeBidi$bidiOverride_instance;
  }
  var EUnicodeBidi$isolateOverride_instance;
  function EUnicodeBidi$isolateOverride_getInstance() {
    EUnicodeBidi_initFields();
    return EUnicodeBidi$isolateOverride_instance;
  }
  var EUnicodeBidi$plaintext_instance;
  function EUnicodeBidi$plaintext_getInstance() {
    EUnicodeBidi_initFields();
    return EUnicodeBidi$plaintext_instance;
  }
  EUnicodeBidi.prototype.toString = function () {
    return this.css_y7iwzc$_0;
  };
  function EUnicodeBidi$Companion() {
    EUnicodeBidi$Companion_instance = this;
  }
  EUnicodeBidi$Companion.prototype.fromString_pdl1vj$ = function (option) {
    if (option == null)
      return null;
    else
      switch (option) {
        case 'bidi-override':
          return EUnicodeBidi$bidiOverride_getInstance();
        case 'embed':
          return EUnicodeBidi$embed_getInstance();
        case 'isolate':
          return EUnicodeBidi$isolate_getInstance();
        case 'isolateOverride':
          return EUnicodeBidi$isolateOverride_getInstance();
        case 'normal':
          return EUnicodeBidi$normal_getInstance();
        case 'plaintext':
          return EUnicodeBidi$plaintext_getInstance();
        default:throw IllegalArgumentException_init("Unknown unicode-bidi option: '" + toString(option) + "'.");
      }
  };
  EUnicodeBidi$Companion.$metadata$ = {
    kind: Kind_OBJECT,
    simpleName: 'Companion',
    interfaces: []
  };
  var EUnicodeBidi$Companion_instance = null;
  function EUnicodeBidi$Companion_getInstance() {
    EUnicodeBidi_initFields();
    if (EUnicodeBidi$Companion_instance === null) {
      new EUnicodeBidi$Companion();
    }
    return EUnicodeBidi$Companion_instance;
  }
  EUnicodeBidi.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'EUnicodeBidi',
    interfaces: [Enum]
  };
  function EUnicodeBidi$values() {
    return [EUnicodeBidi$normal_getInstance(), EUnicodeBidi$embed_getInstance(), EUnicodeBidi$isolate_getInstance(), EUnicodeBidi$bidiOverride_getInstance(), EUnicodeBidi$isolateOverride_getInstance(), EUnicodeBidi$plaintext_getInstance()];
  }
  EUnicodeBidi.values = EUnicodeBidi$values;
  function EUnicodeBidi$valueOf(name) {
    switch (name) {
      case 'normal':
        return EUnicodeBidi$normal_getInstance();
      case 'embed':
        return EUnicodeBidi$embed_getInstance();
      case 'isolate':
        return EUnicodeBidi$isolate_getInstance();
      case 'bidiOverride':
        return EUnicodeBidi$bidiOverride_getInstance();
      case 'isolateOverride':
        return EUnicodeBidi$isolateOverride_getInstance();
      case 'plaintext':
        return EUnicodeBidi$plaintext_getInstance();
      default:throwISE('No enum constant o.katydid.css.types.EUnicodeBidi.' + name);
    }
  }
  EUnicodeBidi.valueOf_61zpoe$ = EUnicodeBidi$valueOf;
  function EVisibility(name, ordinal, css) {
    Enum.call(this);
    this.css_bz4qtz$_0 = css;
    this.name$ = name;
    this.ordinal$ = ordinal;
  }
  function EVisibility_initFields() {
    EVisibility_initFields = function () {
    };
    EVisibility$visible_instance = new EVisibility('visible', 0, 'visible');
    EVisibility$hidden_instance = new EVisibility('hidden', 1, 'hidden');
    EVisibility$collapse_instance = new EVisibility('collapse', 2, 'collapse');
    EVisibility$Companion_getInstance();
  }
  var EVisibility$visible_instance;
  function EVisibility$visible_getInstance() {
    EVisibility_initFields();
    return EVisibility$visible_instance;
  }
  var EVisibility$hidden_instance;
  function EVisibility$hidden_getInstance() {
    EVisibility_initFields();
    return EVisibility$hidden_instance;
  }
  var EVisibility$collapse_instance;
  function EVisibility$collapse_getInstance() {
    EVisibility_initFields();
    return EVisibility$collapse_instance;
  }
  EVisibility.prototype.toString = function () {
    return this.css_bz4qtz$_0;
  };
  function EVisibility$Companion() {
    EVisibility$Companion_instance = this;
  }
  EVisibility$Companion.prototype.fromString_pdl1vj$ = function (option) {
    if (option == null)
      return null;
    else
      switch (option) {
        case 'collapse':
          return EVisibility$collapse_getInstance();
        case 'hidden':
          return EVisibility$hidden_getInstance();
        case 'visible':
          return EVisibility$visible_getInstance();
        default:throw IllegalArgumentException_init("Unknown visibility option: '" + toString(option) + "'.");
      }
  };
  EVisibility$Companion.$metadata$ = {
    kind: Kind_OBJECT,
    simpleName: 'Companion',
    interfaces: []
  };
  var EVisibility$Companion_instance = null;
  function EVisibility$Companion_getInstance() {
    EVisibility_initFields();
    if (EVisibility$Companion_instance === null) {
      new EVisibility$Companion();
    }
    return EVisibility$Companion_instance;
  }
  EVisibility.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'EVisibility',
    interfaces: [Enum]
  };
  function EVisibility$values() {
    return [EVisibility$visible_getInstance(), EVisibility$hidden_getInstance(), EVisibility$collapse_getInstance()];
  }
  EVisibility.values = EVisibility$values;
  function EVisibility$valueOf(name) {
    switch (name) {
      case 'visible':
        return EVisibility$visible_getInstance();
      case 'hidden':
        return EVisibility$hidden_getInstance();
      case 'collapse':
        return EVisibility$collapse_getInstance();
      default:throwISE('No enum constant o.katydid.css.types.EVisibility.' + name);
    }
  }
  EVisibility.valueOf_61zpoe$ = EVisibility$valueOf;
  function EWhiteSpace(name, ordinal, css) {
    Enum.call(this);
    this.css_cazhck$_0 = css;
    this.name$ = name;
    this.ordinal$ = ordinal;
  }
  function EWhiteSpace_initFields() {
    EWhiteSpace_initFields = function () {
    };
    EWhiteSpace$normal_instance = new EWhiteSpace('normal', 0, 'normal');
    EWhiteSpace$pre_instance = new EWhiteSpace('pre', 1, 'pre');
    EWhiteSpace$nowrap_instance = new EWhiteSpace('nowrap', 2, 'nowrap');
    EWhiteSpace$preWrap_instance = new EWhiteSpace('preWrap', 3, 'pre-wrap');
    EWhiteSpace$breakSpaces_instance = new EWhiteSpace('breakSpaces', 4, 'break-spaces');
    EWhiteSpace$preLine_instance = new EWhiteSpace('preLine', 5, 'pre-line');
    EWhiteSpace$Companion_getInstance();
  }
  var EWhiteSpace$normal_instance;
  function EWhiteSpace$normal_getInstance() {
    EWhiteSpace_initFields();
    return EWhiteSpace$normal_instance;
  }
  var EWhiteSpace$pre_instance;
  function EWhiteSpace$pre_getInstance() {
    EWhiteSpace_initFields();
    return EWhiteSpace$pre_instance;
  }
  var EWhiteSpace$nowrap_instance;
  function EWhiteSpace$nowrap_getInstance() {
    EWhiteSpace_initFields();
    return EWhiteSpace$nowrap_instance;
  }
  var EWhiteSpace$preWrap_instance;
  function EWhiteSpace$preWrap_getInstance() {
    EWhiteSpace_initFields();
    return EWhiteSpace$preWrap_instance;
  }
  var EWhiteSpace$breakSpaces_instance;
  function EWhiteSpace$breakSpaces_getInstance() {
    EWhiteSpace_initFields();
    return EWhiteSpace$breakSpaces_instance;
  }
  var EWhiteSpace$preLine_instance;
  function EWhiteSpace$preLine_getInstance() {
    EWhiteSpace_initFields();
    return EWhiteSpace$preLine_instance;
  }
  EWhiteSpace.prototype.toString = function () {
    return this.css_cazhck$_0;
  };
  function EWhiteSpace$Companion() {
    EWhiteSpace$Companion_instance = this;
  }
  EWhiteSpace$Companion.prototype.fromString_pdl1vj$ = function (option) {
    if (option == null)
      return null;
    else
      switch (option) {
        case 'normal':
          return EWhiteSpace$normal_getInstance();
        case 'pre':
          return EWhiteSpace$pre_getInstance();
        case 'nowrap':
          return EWhiteSpace$nowrap_getInstance();
        case 'pre-wrap':
          return EWhiteSpace$preWrap_getInstance();
        case 'break-space':
          return EWhiteSpace$breakSpaces_getInstance();
        case 'pre-line':
          return EWhiteSpace$preLine_getInstance();
        default:throw IllegalArgumentException_init("Unknown white space option: '" + toString(option) + "'.");
      }
  };
  EWhiteSpace$Companion.$metadata$ = {
    kind: Kind_OBJECT,
    simpleName: 'Companion',
    interfaces: []
  };
  var EWhiteSpace$Companion_instance = null;
  function EWhiteSpace$Companion_getInstance() {
    EWhiteSpace_initFields();
    if (EWhiteSpace$Companion_instance === null) {
      new EWhiteSpace$Companion();
    }
    return EWhiteSpace$Companion_instance;
  }
  EWhiteSpace.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'EWhiteSpace',
    interfaces: [Enum]
  };
  function EWhiteSpace$values() {
    return [EWhiteSpace$normal_getInstance(), EWhiteSpace$pre_getInstance(), EWhiteSpace$nowrap_getInstance(), EWhiteSpace$preWrap_getInstance(), EWhiteSpace$breakSpaces_getInstance(), EWhiteSpace$preLine_getInstance()];
  }
  EWhiteSpace.values = EWhiteSpace$values;
  function EWhiteSpace$valueOf(name) {
    switch (name) {
      case 'normal':
        return EWhiteSpace$normal_getInstance();
      case 'pre':
        return EWhiteSpace$pre_getInstance();
      case 'nowrap':
        return EWhiteSpace$nowrap_getInstance();
      case 'preWrap':
        return EWhiteSpace$preWrap_getInstance();
      case 'breakSpaces':
        return EWhiteSpace$breakSpaces_getInstance();
      case 'preLine':
        return EWhiteSpace$preLine_getInstance();
      default:throwISE('No enum constant o.katydid.css.types.EWhiteSpace.' + name);
    }
  }
  EWhiteSpace.valueOf_61zpoe$ = EWhiteSpace$valueOf;
  function makeDecimalString(number) {
    var n = number.toFixed(3);
    return trimEnd(trimEnd(n.toString(), Kotlin.charArrayOf(48)), Kotlin.charArrayOf(46));
  }
  var package$i = _.i || (_.i = {});
  var package$katydid = package$i.katydid || (package$i.katydid = {});
  var package$css = package$katydid.css || (package$katydid.css = {});
  var package$colors = package$css.colors || (package$css.colors = {});
  package$colors.HslColor = HslColor;
  Object.defineProperty(RgbColor, 'Companion', {
    get: RgbColor$Companion_getInstance
  });
  package$colors.RgbColor_init_hu04m1$ = RgbColor_init;
  package$colors.RgbColor_init_7b5o5w$ = RgbColor_init_0;
  package$colors.RgbColor = RgbColor;
  var package$styles = package$css.styles || (package$css.styles = {});
  package$styles.KatydidStyleImpl = KatydidStyleImpl;
  var package$stylesheets = package$css.stylesheets || (package$css.stylesheets = {});
  package$stylesheets.KatydidAbstractStyleRuleImpl = KatydidAbstractStyleRuleImpl;
  package$stylesheets.KatydidCharSetAtRuleImpl = KatydidCharSetAtRuleImpl;
  package$stylesheets.KatydidCompositeCssRuleImpl = KatydidCompositeCssRuleImpl;
  package$stylesheets.KatydidMediaAtRuleImpl = KatydidMediaAtRuleImpl;
  package$stylesheets.KatydidPlaceholderRuleImpl = KatydidPlaceholderRuleImpl;
  package$stylesheets.KatydidStyleRuleImpl = KatydidStyleRuleImpl;
  package$stylesheets.KatydidStyleSheetImpl = KatydidStyleSheetImpl;
  var package$js = _.js || (_.js = {});
  var package$katydid_0 = package$js.katydid || (package$js.katydid = {});
  var package$css_0 = package$katydid_0.css || (package$katydid_0.css = {});
  package$css_0.buildStyleElement_95j5yg$ = buildStyleElement;
  Object.defineProperty(Color, 'Companion', {
    get: Color$Companion_getInstance
  });
  var package$o = _.o || (_.o = {});
  var package$katydid_1 = package$o.katydid || (package$o.katydid = {});
  var package$css_1 = package$katydid_1.css || (package$katydid_1.css = {});
  var package$colors_0 = package$css_1.colors || (package$css_1.colors = {});
  package$colors_0.Color = Color;
  package$colors_0.rgb_qt1dr2$ = rgb;
  package$colors_0.rgba_hu04m1$ = rgba;
  package$colors_0.rgb_y2kzbl$ = rgb_0;
  package$colors_0.rgba_7b5o5w$ = rgba_0;
  package$colors_0.hsl_nhq4am$ = hsl;
  package$colors_0.hsla_eyukp3$ = hsla;
  Object.defineProperty(package$colors_0, 'aliceblue', {
    get: function () {
      return aliceblue;
    }
  });
  Object.defineProperty(package$colors_0, 'antiquewhite', {
    get: function () {
      return antiquewhite;
    }
  });
  Object.defineProperty(package$colors_0, 'aqua', {
    get: function () {
      return aqua;
    }
  });
  Object.defineProperty(package$colors_0, 'aquamarine', {
    get: function () {
      return aquamarine;
    }
  });
  Object.defineProperty(package$colors_0, 'azure', {
    get: function () {
      return azure;
    }
  });
  Object.defineProperty(package$colors_0, 'beige', {
    get: function () {
      return beige;
    }
  });
  Object.defineProperty(package$colors_0, 'bisque', {
    get: function () {
      return bisque;
    }
  });
  Object.defineProperty(package$colors_0, 'black', {
    get: function () {
      return black;
    }
  });
  Object.defineProperty(package$colors_0, 'blanchedalmond', {
    get: function () {
      return blanchedalmond;
    }
  });
  Object.defineProperty(package$colors_0, 'blue', {
    get: function () {
      return blue;
    }
  });
  Object.defineProperty(package$colors_0, 'blueviolet', {
    get: function () {
      return blueviolet;
    }
  });
  Object.defineProperty(package$colors_0, 'brown', {
    get: function () {
      return brown;
    }
  });
  Object.defineProperty(package$colors_0, 'burlywood', {
    get: function () {
      return burlywood;
    }
  });
  Object.defineProperty(package$colors_0, 'cadetblue', {
    get: function () {
      return cadetblue;
    }
  });
  Object.defineProperty(package$colors_0, 'chartreuse', {
    get: function () {
      return chartreuse;
    }
  });
  Object.defineProperty(package$colors_0, 'chocolate', {
    get: function () {
      return chocolate;
    }
  });
  Object.defineProperty(package$colors_0, 'coral', {
    get: function () {
      return coral;
    }
  });
  Object.defineProperty(package$colors_0, 'cornflowerblue', {
    get: function () {
      return cornflowerblue;
    }
  });
  Object.defineProperty(package$colors_0, 'cornsilk', {
    get: function () {
      return cornsilk;
    }
  });
  Object.defineProperty(package$colors_0, 'crimson', {
    get: function () {
      return crimson;
    }
  });
  Object.defineProperty(package$colors_0, 'cyan', {
    get: function () {
      return cyan;
    }
  });
  Object.defineProperty(package$colors_0, 'darkblue', {
    get: function () {
      return darkblue;
    }
  });
  Object.defineProperty(package$colors_0, 'darkcyan', {
    get: function () {
      return darkcyan;
    }
  });
  Object.defineProperty(package$colors_0, 'darkgoldenrod', {
    get: function () {
      return darkgoldenrod;
    }
  });
  Object.defineProperty(package$colors_0, 'darkgray', {
    get: function () {
      return darkgray;
    }
  });
  Object.defineProperty(package$colors_0, 'darkgreen', {
    get: function () {
      return darkgreen;
    }
  });
  Object.defineProperty(package$colors_0, 'darkgrey', {
    get: function () {
      return darkgrey;
    }
  });
  Object.defineProperty(package$colors_0, 'darkkhaki', {
    get: function () {
      return darkkhaki;
    }
  });
  Object.defineProperty(package$colors_0, 'darkmagenta', {
    get: function () {
      return darkmagenta;
    }
  });
  Object.defineProperty(package$colors_0, 'darkolivegreen', {
    get: function () {
      return darkolivegreen;
    }
  });
  Object.defineProperty(package$colors_0, 'darkorange', {
    get: function () {
      return darkorange;
    }
  });
  Object.defineProperty(package$colors_0, 'darkorchid', {
    get: function () {
      return darkorchid;
    }
  });
  Object.defineProperty(package$colors_0, 'darkred', {
    get: function () {
      return darkred;
    }
  });
  Object.defineProperty(package$colors_0, 'darksalmon', {
    get: function () {
      return darksalmon;
    }
  });
  Object.defineProperty(package$colors_0, 'darkseagreen', {
    get: function () {
      return darkseagreen;
    }
  });
  Object.defineProperty(package$colors_0, 'darkslateblue', {
    get: function () {
      return darkslateblue;
    }
  });
  Object.defineProperty(package$colors_0, 'darkslategray', {
    get: function () {
      return darkslategray;
    }
  });
  Object.defineProperty(package$colors_0, 'darkslategrey', {
    get: function () {
      return darkslategrey;
    }
  });
  Object.defineProperty(package$colors_0, 'darkturquoise', {
    get: function () {
      return darkturquoise;
    }
  });
  Object.defineProperty(package$colors_0, 'darkviolet', {
    get: function () {
      return darkviolet;
    }
  });
  Object.defineProperty(package$colors_0, 'deeppink', {
    get: function () {
      return deeppink;
    }
  });
  Object.defineProperty(package$colors_0, 'deepskyblue', {
    get: function () {
      return deepskyblue;
    }
  });
  Object.defineProperty(package$colors_0, 'dimgray', {
    get: function () {
      return dimgray;
    }
  });
  Object.defineProperty(package$colors_0, 'dimgrey', {
    get: function () {
      return dimgrey;
    }
  });
  Object.defineProperty(package$colors_0, 'dodgerblue', {
    get: function () {
      return dodgerblue;
    }
  });
  Object.defineProperty(package$colors_0, 'firebrick', {
    get: function () {
      return firebrick;
    }
  });
  Object.defineProperty(package$colors_0, 'floralwhite', {
    get: function () {
      return floralwhite;
    }
  });
  Object.defineProperty(package$colors_0, 'forestgreen', {
    get: function () {
      return forestgreen;
    }
  });
  Object.defineProperty(package$colors_0, 'fuchsia', {
    get: function () {
      return fuchsia;
    }
  });
  Object.defineProperty(package$colors_0, 'gainsboro', {
    get: function () {
      return gainsboro;
    }
  });
  Object.defineProperty(package$colors_0, 'ghostwhite', {
    get: function () {
      return ghostwhite;
    }
  });
  Object.defineProperty(package$colors_0, 'gold', {
    get: function () {
      return gold;
    }
  });
  Object.defineProperty(package$colors_0, 'goldenrod', {
    get: function () {
      return goldenrod;
    }
  });
  Object.defineProperty(package$colors_0, 'gray', {
    get: function () {
      return gray;
    }
  });
  Object.defineProperty(package$colors_0, 'green', {
    get: function () {
      return green;
    }
  });
  Object.defineProperty(package$colors_0, 'greenyellow', {
    get: function () {
      return greenyellow;
    }
  });
  Object.defineProperty(package$colors_0, 'grey', {
    get: function () {
      return grey;
    }
  });
  Object.defineProperty(package$colors_0, 'honeydew', {
    get: function () {
      return honeydew;
    }
  });
  Object.defineProperty(package$colors_0, 'hotpink', {
    get: function () {
      return hotpink;
    }
  });
  Object.defineProperty(package$colors_0, 'indianred', {
    get: function () {
      return indianred;
    }
  });
  Object.defineProperty(package$colors_0, 'indigo', {
    get: function () {
      return indigo;
    }
  });
  Object.defineProperty(package$colors_0, 'ivory', {
    get: function () {
      return ivory;
    }
  });
  Object.defineProperty(package$colors_0, 'khaki', {
    get: function () {
      return khaki;
    }
  });
  Object.defineProperty(package$colors_0, 'lavender', {
    get: function () {
      return lavender;
    }
  });
  Object.defineProperty(package$colors_0, 'lavenderblush', {
    get: function () {
      return lavenderblush;
    }
  });
  Object.defineProperty(package$colors_0, 'lawngreen', {
    get: function () {
      return lawngreen;
    }
  });
  Object.defineProperty(package$colors_0, 'lemonchiffon', {
    get: function () {
      return lemonchiffon;
    }
  });
  Object.defineProperty(package$colors_0, 'lightblue', {
    get: function () {
      return lightblue;
    }
  });
  Object.defineProperty(package$colors_0, 'lightcoral', {
    get: function () {
      return lightcoral;
    }
  });
  Object.defineProperty(package$colors_0, 'lightcyan', {
    get: function () {
      return lightcyan;
    }
  });
  Object.defineProperty(package$colors_0, 'lightgoldenrodyellow', {
    get: function () {
      return lightgoldenrodyellow;
    }
  });
  Object.defineProperty(package$colors_0, 'lightgray', {
    get: function () {
      return lightgray;
    }
  });
  Object.defineProperty(package$colors_0, 'lightgreen', {
    get: function () {
      return lightgreen;
    }
  });
  Object.defineProperty(package$colors_0, 'lightgrey', {
    get: function () {
      return lightgrey;
    }
  });
  Object.defineProperty(package$colors_0, 'lightpink', {
    get: function () {
      return lightpink;
    }
  });
  Object.defineProperty(package$colors_0, 'lightsalmon', {
    get: function () {
      return lightsalmon;
    }
  });
  Object.defineProperty(package$colors_0, 'lightseagreen', {
    get: function () {
      return lightseagreen;
    }
  });
  Object.defineProperty(package$colors_0, 'lightskyblue', {
    get: function () {
      return lightskyblue;
    }
  });
  Object.defineProperty(package$colors_0, 'lightslategray', {
    get: function () {
      return lightslategray;
    }
  });
  Object.defineProperty(package$colors_0, 'lightslategrey', {
    get: function () {
      return lightslategrey;
    }
  });
  Object.defineProperty(package$colors_0, 'lightsteelblue', {
    get: function () {
      return lightsteelblue;
    }
  });
  Object.defineProperty(package$colors_0, 'lightyellow', {
    get: function () {
      return lightyellow;
    }
  });
  Object.defineProperty(package$colors_0, 'lime', {
    get: function () {
      return lime;
    }
  });
  Object.defineProperty(package$colors_0, 'limegreen', {
    get: function () {
      return limegreen;
    }
  });
  Object.defineProperty(package$colors_0, 'linen', {
    get: function () {
      return linen;
    }
  });
  Object.defineProperty(package$colors_0, 'magenta', {
    get: function () {
      return magenta;
    }
  });
  Object.defineProperty(package$colors_0, 'maroon', {
    get: function () {
      return maroon;
    }
  });
  Object.defineProperty(package$colors_0, 'mediumaquamarine', {
    get: function () {
      return mediumaquamarine;
    }
  });
  Object.defineProperty(package$colors_0, 'mediumblue', {
    get: function () {
      return mediumblue;
    }
  });
  Object.defineProperty(package$colors_0, 'mediumorchid', {
    get: function () {
      return mediumorchid;
    }
  });
  Object.defineProperty(package$colors_0, 'mediumpurple', {
    get: function () {
      return mediumpurple;
    }
  });
  Object.defineProperty(package$colors_0, 'mediumseagreen', {
    get: function () {
      return mediumseagreen;
    }
  });
  Object.defineProperty(package$colors_0, 'mediumslateblue', {
    get: function () {
      return mediumslateblue;
    }
  });
  Object.defineProperty(package$colors_0, 'mediumspringgreen', {
    get: function () {
      return mediumspringgreen;
    }
  });
  Object.defineProperty(package$colors_0, 'mediumturquoise', {
    get: function () {
      return mediumturquoise;
    }
  });
  Object.defineProperty(package$colors_0, 'mediumvioletred', {
    get: function () {
      return mediumvioletred;
    }
  });
  Object.defineProperty(package$colors_0, 'midnightblue', {
    get: function () {
      return midnightblue;
    }
  });
  Object.defineProperty(package$colors_0, 'mintcream', {
    get: function () {
      return mintcream;
    }
  });
  Object.defineProperty(package$colors_0, 'mistyrose', {
    get: function () {
      return mistyrose;
    }
  });
  Object.defineProperty(package$colors_0, 'moccasin', {
    get: function () {
      return moccasin;
    }
  });
  Object.defineProperty(package$colors_0, 'navajowhite', {
    get: function () {
      return navajowhite;
    }
  });
  Object.defineProperty(package$colors_0, 'navy', {
    get: function () {
      return navy;
    }
  });
  Object.defineProperty(package$colors_0, 'oldlace', {
    get: function () {
      return oldlace;
    }
  });
  Object.defineProperty(package$colors_0, 'olive', {
    get: function () {
      return olive;
    }
  });
  Object.defineProperty(package$colors_0, 'olivedrab', {
    get: function () {
      return olivedrab;
    }
  });
  Object.defineProperty(package$colors_0, 'orange', {
    get: function () {
      return orange;
    }
  });
  Object.defineProperty(package$colors_0, 'orangered', {
    get: function () {
      return orangered;
    }
  });
  Object.defineProperty(package$colors_0, 'orchid', {
    get: function () {
      return orchid;
    }
  });
  Object.defineProperty(package$colors_0, 'palegoldenrod', {
    get: function () {
      return palegoldenrod;
    }
  });
  Object.defineProperty(package$colors_0, 'palegreen', {
    get: function () {
      return palegreen;
    }
  });
  Object.defineProperty(package$colors_0, 'paleturquoise', {
    get: function () {
      return paleturquoise;
    }
  });
  Object.defineProperty(package$colors_0, 'palevioletred', {
    get: function () {
      return palevioletred;
    }
  });
  Object.defineProperty(package$colors_0, 'papayawhip', {
    get: function () {
      return papayawhip;
    }
  });
  Object.defineProperty(package$colors_0, 'peachpuff', {
    get: function () {
      return peachpuff;
    }
  });
  Object.defineProperty(package$colors_0, 'peru', {
    get: function () {
      return peru;
    }
  });
  Object.defineProperty(package$colors_0, 'pink', {
    get: function () {
      return pink;
    }
  });
  Object.defineProperty(package$colors_0, 'plum', {
    get: function () {
      return plum;
    }
  });
  Object.defineProperty(package$colors_0, 'powderblue', {
    get: function () {
      return powderblue;
    }
  });
  Object.defineProperty(package$colors_0, 'purple', {
    get: function () {
      return purple;
    }
  });
  Object.defineProperty(package$colors_0, 'red', {
    get: function () {
      return red;
    }
  });
  Object.defineProperty(package$colors_0, 'rosybrown', {
    get: function () {
      return rosybrown;
    }
  });
  Object.defineProperty(package$colors_0, 'royalblue', {
    get: function () {
      return royalblue;
    }
  });
  Object.defineProperty(package$colors_0, 'saddlebrown', {
    get: function () {
      return saddlebrown;
    }
  });
  Object.defineProperty(package$colors_0, 'salmon', {
    get: function () {
      return salmon;
    }
  });
  Object.defineProperty(package$colors_0, 'sandybrown', {
    get: function () {
      return sandybrown;
    }
  });
  Object.defineProperty(package$colors_0, 'seagreen', {
    get: function () {
      return seagreen;
    }
  });
  Object.defineProperty(package$colors_0, 'seashell', {
    get: function () {
      return seashell;
    }
  });
  Object.defineProperty(package$colors_0, 'sienna', {
    get: function () {
      return sienna;
    }
  });
  Object.defineProperty(package$colors_0, 'silver', {
    get: function () {
      return silver;
    }
  });
  Object.defineProperty(package$colors_0, 'skyblue', {
    get: function () {
      return skyblue;
    }
  });
  Object.defineProperty(package$colors_0, 'slateblue', {
    get: function () {
      return slateblue;
    }
  });
  Object.defineProperty(package$colors_0, 'slategray', {
    get: function () {
      return slategray;
    }
  });
  Object.defineProperty(package$colors_0, 'slategrey', {
    get: function () {
      return slategrey;
    }
  });
  Object.defineProperty(package$colors_0, 'snow', {
    get: function () {
      return snow;
    }
  });
  Object.defineProperty(package$colors_0, 'springgreen', {
    get: function () {
      return springgreen;
    }
  });
  Object.defineProperty(package$colors_0, 'steelblue', {
    get: function () {
      return steelblue;
    }
  });
  Object.defineProperty(package$colors_0, 'tan', {
    get: function () {
      return tan;
    }
  });
  Object.defineProperty(package$colors_0, 'teal', {
    get: function () {
      return teal;
    }
  });
  Object.defineProperty(package$colors_0, 'thistle', {
    get: function () {
      return thistle;
    }
  });
  Object.defineProperty(package$colors_0, 'tomato', {
    get: function () {
      return tomato;
    }
  });
  Object.defineProperty(package$colors_0, 'transparent', {
    get: function () {
      return transparent;
    }
  });
  Object.defineProperty(package$colors_0, 'turquoise', {
    get: function () {
      return turquoise;
    }
  });
  Object.defineProperty(package$colors_0, 'violet', {
    get: function () {
      return violet;
    }
  });
  Object.defineProperty(package$colors_0, 'wheat', {
    get: function () {
      return wheat;
    }
  });
  Object.defineProperty(package$colors_0, 'white', {
    get: function () {
      return white;
    }
  });
  Object.defineProperty(package$colors_0, 'whitesmoke', {
    get: function () {
      return whitesmoke;
    }
  });
  Object.defineProperty(package$colors_0, 'yellow', {
    get: function () {
      return yellow;
    }
  });
  Object.defineProperty(package$colors_0, 'yellowgreen', {
    get: function () {
      return yellowgreen;
    }
  });
  package$colors_0.useCssColorNames = useCssColorNames;
  package$colors_0.opacify_qagkg2$ = opacify;
  package$colors_0.transparentize_qagkg2$ = transparentize;
  var package$measurements = package$css_1.measurements || (package$css_1.measurements = {});
  package$measurements.Length = Length;
  package$measurements.length_61zpoe$ = length;
  package$measurements.length_za3rmp$ = length_0;
  package$measurements.get_ch_rcaex3$ = get_ch;
  package$measurements.get_cm_rcaex3$ = get_cm;
  package$measurements.get_em_rcaex3$ = get_em;
  package$measurements.get_ex_rcaex3$ = get_ex;
  package$measurements.get_inch_rcaex3$ = get_inch;
  package$measurements.get_mm_rcaex3$ = get_mm;
  package$measurements.get_pc_rcaex3$ = get_pc;
  package$measurements.get_pt_rcaex3$ = get_pt;
  package$measurements.get_px_rcaex3$ = get_px;
  package$measurements.get_Q_rcaex3$ = get_Q;
  package$measurements.get_rem_rcaex3$ = get_rem;
  package$measurements.get_vh_rcaex3$ = get_vh;
  package$measurements.get_vmax_rcaex3$ = get_vmax;
  package$measurements.get_vmin_rcaex3$ = get_vmin;
  package$measurements.get_vw_rcaex3$ = get_vw;
  Object.defineProperty(LengthUnit, 'CENTIMETER', {
    get: LengthUnit$CENTIMETER_getInstance
  });
  Object.defineProperty(LengthUnit, 'FONT_SIZE_ELEMENT', {
    get: LengthUnit$FONT_SIZE_ELEMENT_getInstance
  });
  Object.defineProperty(LengthUnit, 'FONT_SIZE_ROOT_ELEMENT', {
    get: LengthUnit$FONT_SIZE_ROOT_ELEMENT_getInstance
  });
  Object.defineProperty(LengthUnit, 'INCH', {
    get: LengthUnit$INCH_getInstance
  });
  Object.defineProperty(LengthUnit, 'MILLIMETER', {
    get: LengthUnit$MILLIMETER_getInstance
  });
  Object.defineProperty(LengthUnit, 'PICA', {
    get: LengthUnit$PICA_getInstance
  });
  Object.defineProperty(LengthUnit, 'PIXEL', {
    get: LengthUnit$PIXEL_getInstance
  });
  Object.defineProperty(LengthUnit, 'POINT', {
    get: LengthUnit$POINT_getInstance
  });
  Object.defineProperty(LengthUnit, 'QUARTER_MILLIMETER', {
    get: LengthUnit$QUARTER_MILLIMETER_getInstance
  });
  Object.defineProperty(LengthUnit, 'VIEW_PORT_HEIGHT_01', {
    get: LengthUnit$VIEW_PORT_HEIGHT_01_getInstance
  });
  Object.defineProperty(LengthUnit, 'VIEW_PORT_MAXIMUM_01', {
    get: LengthUnit$VIEW_PORT_MAXIMUM_01_getInstance
  });
  Object.defineProperty(LengthUnit, 'VIEW_PORT_MINIMUM_01', {
    get: LengthUnit$VIEW_PORT_MINIMUM_01_getInstance
  });
  Object.defineProperty(LengthUnit, 'VIEW_PORT_WIDTH_01', {
    get: LengthUnit$VIEW_PORT_WIDTH_01_getInstance
  });
  Object.defineProperty(LengthUnit, 'X_HEIGHT', {
    get: LengthUnit$X_HEIGHT_getInstance
  });
  Object.defineProperty(LengthUnit, 'ZERO_WIDTH', {
    get: LengthUnit$ZERO_WIDTH_getInstance
  });
  Object.defineProperty(LengthUnit, 'Companion', {
    get: LengthUnit$Companion_getInstance
  });
  package$measurements.LengthUnit = LengthUnit;
  package$measurements.Percentage = Percentage;
  package$measurements.percentage_61zpoe$ = percentage;
  package$measurements.percentage_za3rmp$ = percentage_0;
  package$measurements.get_percent_rcaex3$ = get_percent;
  var package$styles_0 = package$css_1.styles || (package$css_1.styles = {});
  var package$builders = package$styles_0.builders || (package$styles_0.builders = {});
  package$builders.KatydidAnimationStyleBuilder = KatydidAnimationStyleBuilder;
  package$builders.animation_otb3rv$ = animation;
  package$builders.animationName_4h78ie$ = animationName;
  package$builders.animationName_85dgd0$ = animationName_0;
  package$builders.KatydidBackgroundStyleBuilder = KatydidBackgroundStyleBuilder;
  package$builders.background_j8zboj$ = background;
  package$builders.backgroundAttachment_gdisey$ = backgroundAttachment;
  package$builders.backgroundColor_rp620z$ = backgroundColor;
  package$builders.backgroundImage_6c8oas$ = backgroundImage;
  package$builders.backgroundPosition_4r4b5i$ = backgroundPosition;
  package$builders.backgroundPosition_wfldde$ = backgroundPosition_0;
  package$builders.backgroundPosition_n5gy1c$ = backgroundPosition_1;
  package$builders.backgroundPosition_54i8pt$ = backgroundPosition_2;
  package$builders.backgroundPosition_p9u9dw$ = backgroundPosition_3;
  package$builders.backgroundPosition_yg607n$ = backgroundPosition_4;
  package$builders.backgroundPosition_gbjorg$ = backgroundPosition_5;
  package$builders.backgroundRepeat_67idod$ = backgroundRepeat;
  package$builders.backgroundRepeat_1g6tf5$ = backgroundRepeat_0;
  package$builders.KatydidBorderBottomStyleBuilder = KatydidBorderBottomStyleBuilder;
  package$builders.KatydidBorderLeftStyleBuilder = KatydidBorderLeftStyleBuilder;
  package$builders.KatydidBorderRightStyleBuilder = KatydidBorderRightStyleBuilder;
  package$builders.KatydidBorderTopStyleBuilder = KatydidBorderTopStyleBuilder;
  package$builders.KatydidBorderStyleBuilder = KatydidBorderStyleBuilder;
  package$builders.border_kr9bs1$ = border;
  package$builders.border_no98cu$ = border_0;
  package$builders.border_ihg390$ = border_1;
  package$builders.border_95zgtn$ = border_2;
  package$builders.borderBottom_no98cu$ = borderBottom;
  package$builders.borderBottom_ihg390$ = borderBottom_0;
  package$builders.borderBottom_95zgtn$ = borderBottom_1;
  package$builders.borderBottomColor_rp620z$ = borderBottomColor;
  package$builders.borderBottomStyle_mi3cet$ = borderBottomStyle;
  package$builders.borderBottomWidth_mg3m9s$ = borderBottomWidth;
  package$builders.borderBottomWidth_54i8pt$ = borderBottomWidth_0;
  package$builders.borderColor_ijr58i$ = borderColor;
  package$builders.borderLeft_no98cu$ = borderLeft;
  package$builders.borderLeft_ihg390$ = borderLeft_0;
  package$builders.borderLeft_95zgtn$ = borderLeft_1;
  package$builders.borderLeftColor_rp620z$ = borderLeftColor;
  package$builders.borderLeftStyle_mi3cet$ = borderLeftStyle;
  package$builders.borderLeftWidth_mg3m9s$ = borderLeftWidth;
  package$builders.borderLeftWidth_54i8pt$ = borderLeftWidth_0;
  package$builders.borderRight_no98cu$ = borderRight;
  package$builders.borderRight_ihg390$ = borderRight_0;
  package$builders.borderRight_95zgtn$ = borderRight_1;
  package$builders.borderRightColor_rp620z$ = borderRightColor;
  package$builders.borderRightStyle_mi3cet$ = borderRightStyle;
  package$builders.borderRightWidth_mg3m9s$ = borderRightWidth;
  package$builders.borderRightWidth_54i8pt$ = borderRightWidth_0;
  package$builders.borderStyle_4kjcn2$ = borderStyle;
  package$builders.borderTop_no98cu$ = borderTop;
  package$builders.borderTop_ihg390$ = borderTop_0;
  package$builders.borderTop_95zgtn$ = borderTop_1;
  package$builders.borderTopColor_rp620z$ = borderTopColor;
  package$builders.borderTopStyle_mi3cet$ = borderTopStyle;
  package$builders.borderTopWidth_mg3m9s$ = borderTopWidth;
  package$builders.borderTopWidth_54i8pt$ = borderTopWidth_0;
  package$builders.borderWidth_yc74si$ = borderWidth;
  package$builders.borderWidth_ja1nre$ = borderWidth_0;
  package$builders.boxSizing_jp7wc7$ = boxSizing;
  package$builders.KatydidCaretStyleBuilder = KatydidCaretStyleBuilder;
  package$builders.caret_e7tmze$ = caret;
  package$builders.caretColor_rp620z$ = caretColor;
  package$builders.caretColor_4hfeqn$ = caretColor_0;
  package$builders.color_rp620z$ = color;
  package$builders.opacity_bilxx5$ = opacity;
  package$builders.content_lnm5rt$ = content;
  package$builders.content_85dgd0$ = content_0;
  package$builders.cursor_olkzwo$ = cursor;
  package$builders.display_9qt20g$ = display;
  package$builders.clear_32vxy3$ = clear;
  package$builders.float_34jj56$ = float;
  package$builders.KatydidFontStyleBuilder = KatydidFontStyleBuilder;
  package$builders.font_l6vsak$ = font;
  package$builders.fontFamily_p6629n$ = fontFamily;
  package$builders.fontSize_gmmp7i$ = fontSize;
  package$builders.fontSize_54i8pt$ = fontSize_0;
  package$builders.fontSize_yg607n$ = fontSize_1;
  package$builders.fontStyle_i9kb9s$ = fontStyle;
  package$builders.fontVariant_q907pg$ = fontVariant;
  package$builders.fontWeight_3o1zq1$ = fontWeight;
  package$builders.KatydidLineStyleBuilder = KatydidLineStyleBuilder;
  package$builders.letterSpacing_54i8pt$ = letterSpacing;
  package$builders.letterSpacing_tprxw9$ = letterSpacing_0;
  package$builders.line_rrdf1l$ = line;
  package$builders.lineHeight_54i8pt$ = lineHeight;
  package$builders.lineHeight_yg607n$ = lineHeight_0;
  package$builders.lineHeight_bilxx5$ = lineHeight_1;
  package$builders.lineHeight_tprxw9$ = lineHeight_2;
  package$builders.KatydidListStyleBuilder = KatydidListStyleBuilder;
  package$builders.listStyle_w5ip3n$ = listStyle;
  package$builders.listStyle_gjtzhd$ = listStyle_0;
  package$builders.listStyleImage_3679nt$ = listStyleImage;
  package$builders.listStylePosition_wo89je$ = listStylePosition;
  package$builders.listStyleType_6su1id$ = listStyleType;
  package$builders.KatydidMarginStyleBuilder = KatydidMarginStyleBuilder;
  package$builders.margin_ozvf8j$ = margin;
  package$builders.margin_ja1nre$ = margin_0;
  package$builders.margin_z3gdhi$ = margin_1;
  package$builders.margin_4hfeqn$ = margin_2;
  package$builders.marginBottom_54i8pt$ = marginBottom;
  package$builders.marginBottom_yg607n$ = marginBottom_0;
  package$builders.marginBottom_4hfeqn$ = marginBottom_1;
  package$builders.marginLeft_54i8pt$ = marginLeft;
  package$builders.marginLeft_yg607n$ = marginLeft_0;
  package$builders.marginLeft_4hfeqn$ = marginLeft_1;
  package$builders.marginRight_54i8pt$ = marginRight;
  package$builders.marginRight_yg607n$ = marginRight_0;
  package$builders.marginRight_4hfeqn$ = marginRight_1;
  package$builders.marginTop_54i8pt$ = marginTop;
  package$builders.marginTop_yg607n$ = marginTop_0;
  package$builders.marginTop_4hfeqn$ = marginTop_1;
  package$builders.KatydidOutlineStyleBuilder = KatydidOutlineStyleBuilder;
  package$builders.outline_w9znon$ = outline;
  package$builders.outline_xf37js$ = outline_0;
  package$builders.outline_xpod5k$ = outline_1;
  package$builders.outline_ez074p$ = outline_2;
  package$builders.outline_9qt6dl$ = outline_3;
  package$builders.outlineColor_rp620z$ = outlineColor;
  package$builders.outlineColor_rp74r1$ = outlineColor_0;
  package$builders.outlineOffset_54i8pt$ = outlineOffset;
  package$builders.outlineStyle_mi3cet$ = outlineStyle;
  package$builders.outlineWidth_mg3m9s$ = outlineWidth;
  package$builders.outlineWidth_54i8pt$ = outlineWidth_0;
  package$builders.KatydidOverflowStyleBuilder = KatydidOverflowStyleBuilder;
  package$builders.overflow_a2egeh$ = overflow;
  package$builders.overflow_crxue2$ = overflow_0;
  package$builders.overflowX_dwypzg$ = overflowX;
  package$builders.overflowY_dwypzg$ = overflowY;
  package$builders.overflowWrap_e7c4o2$ = overflowWrap;
  package$builders.resize_vgh25i$ = resize;
  package$builders.KatydidPaddingStyleBuilder = KatydidPaddingStyleBuilder;
  package$builders.padding_yaai6w$ = padding;
  package$builders.padding_ja1nre$ = padding_0;
  package$builders.padding_z3gdhi$ = padding_1;
  package$builders.paddingBottom_54i8pt$ = paddingBottom;
  package$builders.paddingBottom_yg607n$ = paddingBottom_0;
  package$builders.paddingLeft_54i8pt$ = paddingLeft;
  package$builders.paddingLeft_yg607n$ = paddingLeft_0;
  package$builders.paddingRight_54i8pt$ = paddingRight;
  package$builders.paddingRight_yg607n$ = paddingRight_0;
  package$builders.paddingTop_54i8pt$ = paddingTop;
  package$builders.paddingTop_yg607n$ = paddingTop_0;
  package$builders.KatydidPageBreakStyleBuilder = KatydidPageBreakStyleBuilder;
  package$builders.pageBreak_lk6br$ = pageBreak;
  package$builders.pageBreakAfter_lk2z26$ = pageBreakAfter;
  package$builders.pageBreakBefore_lk2z26$ = pageBreakBefore;
  package$builders.pageBreakInside_1o7a8q$ = pageBreakInside;
  package$builders.bottom_54i8pt$ = bottom;
  package$builders.bottom_yg607n$ = bottom_0;
  package$builders.bottom_4hfeqn$ = bottom_1;
  package$builders.left_54i8pt$ = left;
  package$builders.left_yg607n$ = left_0;
  package$builders.left_4hfeqn$ = left_1;
  package$builders.position_ab2qqt$ = position;
  package$builders.right_54i8pt$ = right;
  package$builders.right_yg607n$ = right_0;
  package$builders.right_4hfeqn$ = right_1;
  package$builders.top_54i8pt$ = top;
  package$builders.top_yg607n$ = top_0;
  package$builders.top_4hfeqn$ = top_1;
  package$builders.zIndex_x3n704$ = zIndex;
  package$builders.zIndex_4hfeqn$ = zIndex_0;
  package$builders.KatydidStyleBuilderDsl = KatydidStyleBuilderDsl;
  package$builders.borderCollapse_h3lb3f$ = borderCollapse;
  package$builders.borderSpacing_p9u9dw$ = borderSpacing;
  package$builders.captionSide_ved6az$ = captionSide;
  package$builders.emptyCells_24xgne$ = emptyCells;
  package$builders.tableLayout_67q8ii$ = tableLayout;
  package$builders.KatydidTextDecorationStyleBuilder = KatydidTextDecorationStyleBuilder;
  package$builders.KatydidTextStyleBuilder = KatydidTextStyleBuilder;
  package$builders.tabSize_x3n704$ = tabSize;
  package$builders.tabSize_54i8pt$ = tabSize_0;
  package$builders.text_x9iowu$ = text;
  package$builders.textAlign_a8jtga$ = textAlign;
  package$builders.textAlignAll_a8jtga$ = textAlignAll;
  package$builders.textAlignLast_a8jtga$ = textAlignLast;
  package$builders.textDecoration_4h78ie$ = textDecoration;
  package$builders.textDecoration_68x5i6$ = textDecoration_0;
  package$builders.textDecorationColor_rp620z$ = textDecorationColor;
  package$builders.textDecorationLine_4h78ie$ = textDecorationLine;
  package$builders.textDecorationLine_9ze7tg$ = textDecorationLine_0;
  package$builders.textDecorationStyle_85htmm$ = textDecorationStyle;
  package$builders.textIndent_54i8pt$ = textIndent;
  package$builders.textIndent_yg607n$ = textIndent_0;
  package$builders.textJustify_ti3o8h$ = textJustify;
  package$builders.textOverflow_197ltt$ = textOverflow;
  package$builders.textTransform_23s4c3$ = textTransform;
  package$builders.whiteSpace_jwl3nz$ = whiteSpace;
  package$builders.alignmentBaseline_l9hm2$ = alignmentBaseline;
  package$builders.baselineShift_54i8pt$ = baselineShift;
  package$builders.baselineShift_yg607n$ = baselineShift_0;
  package$builders.baselineShift_jhwuid$ = baselineShift_1;
  package$builders.verticalAlign_alofy2$ = verticalAlign;
  package$builders.verticalAlign_9vo5fq$ = verticalAlign_0;
  package$builders.verticalAlign_l9hm2$ = verticalAlign_1;
  package$builders.verticalAlign_td3dzi$ = verticalAlign_2;
  package$builders.visibility_n3z7uk$ = visibility;
  package$builders.orphans_x3n704$ = orphans;
  package$builders.widows_x3n704$ = widows;
  package$builders.height_54i8pt$ = height;
  package$builders.height_yg607n$ = height_0;
  package$builders.height_4hfeqn$ = height_1;
  package$builders.height_yu0kl6$ = height_2;
  package$builders.maxHeight_54i8pt$ = maxHeight;
  package$builders.maxHeight_yg607n$ = maxHeight_0;
  package$builders.maxHeight_4h78ie$ = maxHeight_1;
  package$builders.maxHeight_yu0kl6$ = maxHeight_2;
  package$builders.maxWidth_54i8pt$ = maxWidth;
  package$builders.maxWidth_yg607n$ = maxWidth_0;
  package$builders.maxWidth_4h78ie$ = maxWidth_1;
  package$builders.maxWidth_yu0kl6$ = maxWidth_2;
  package$builders.minHeight_54i8pt$ = minHeight;
  package$builders.minHeight_yg607n$ = minHeight_0;
  package$builders.minHeight_4hfeqn$ = minHeight_1;
  package$builders.minHeight_yu0kl6$ = minHeight_2;
  package$builders.minWidth_54i8pt$ = minWidth;
  package$builders.minWidth_yg607n$ = minWidth_0;
  package$builders.minWidth_4hfeqn$ = minWidth_1;
  package$builders.minWidth_yu0kl6$ = minWidth_2;
  package$builders.width_54i8pt$ = width;
  package$builders.width_yg607n$ = width_0;
  package$builders.width_4hfeqn$ = width_1;
  package$builders.width_yu0kl6$ = width_2;
  package$builders.KatydidWordStyleBuilder = KatydidWordStyleBuilder;
  package$builders.word_56vhfl$ = word;
  package$builders.wordSpacing_54i8pt$ = wordSpacing;
  package$builders.wordSpacing_yg607n$ = wordSpacing_0;
  package$builders.wordSpacing_tprxw9$ = wordSpacing_1;
  package$builders.wordWrap_e7c4o2$ = wordWrap;
  package$styles_0.KatydidStyle = KatydidStyle;
  package$styles_0.makeStyle_v0sp70$ = makeStyle;
  package$styles_0.style_biqugo$ = style;
  var package$stylesheets_0 = package$css_1.stylesheets || (package$css_1.stylesheets = {});
  package$stylesheets_0.KatydidAbstractStyleRule = KatydidAbstractStyleRule;
  package$stylesheets_0.KatydidCharSetAtRule = KatydidCharSetAtRule;
  package$stylesheets_0.KatydidCompositeCssRule = KatydidCompositeCssRule;
  package$stylesheets_0.KatydidCssRule = KatydidCssRule;
  package$stylesheets_0.KatydidMediaAtRule = KatydidMediaAtRule;
  package$stylesheets_0.KatydidPlaceholderRule = KatydidPlaceholderRule;
  package$stylesheets_0.KatydidStyleRule = KatydidStyleRule;
  package$stylesheets_0.KatydidStyleSheet = KatydidStyleSheet;
  package$stylesheets_0.makeStyleSheet_vawl44$ = makeStyleSheet;
  Object.defineProperty(EAlignmentBaseline, 'baseline', {
    get: EAlignmentBaseline$baseline_getInstance
  });
  Object.defineProperty(EAlignmentBaseline, 'textBottom', {
    get: EAlignmentBaseline$textBottom_getInstance
  });
  Object.defineProperty(EAlignmentBaseline, 'alphabetic', {
    get: EAlignmentBaseline$alphabetic_getInstance
  });
  Object.defineProperty(EAlignmentBaseline, 'ideographic', {
    get: EAlignmentBaseline$ideographic_getInstance
  });
  Object.defineProperty(EAlignmentBaseline, 'middle', {
    get: EAlignmentBaseline$middle_getInstance
  });
  Object.defineProperty(EAlignmentBaseline, 'central', {
    get: EAlignmentBaseline$central_getInstance
  });
  Object.defineProperty(EAlignmentBaseline, 'mathematical', {
    get: EAlignmentBaseline$mathematical_getInstance
  });
  Object.defineProperty(EAlignmentBaseline, 'textTop', {
    get: EAlignmentBaseline$textTop_getInstance
  });
  Object.defineProperty(EAlignmentBaseline, 'top', {
    get: EAlignmentBaseline$top_getInstance
  });
  Object.defineProperty(EAlignmentBaseline, 'center', {
    get: EAlignmentBaseline$center_getInstance
  });
  Object.defineProperty(EAlignmentBaseline, 'bottom', {
    get: EAlignmentBaseline$bottom_getInstance
  });
  Object.defineProperty(EAlignmentBaseline, 'Companion', {
    get: EAlignmentBaseline$Companion_getInstance
  });
  var package$types = package$css_1.types || (package$css_1.types = {});
  package$types.EAlignmentBaseline = EAlignmentBaseline;
  Object.defineProperty(EAttachment, 'fixed', {
    get: EAttachment$fixed_getInstance
  });
  Object.defineProperty(EAttachment, 'local', {
    get: EAttachment$local_getInstance
  });
  Object.defineProperty(EAttachment, 'scroll', {
    get: EAttachment$scroll_getInstance
  });
  Object.defineProperty(EAttachment, 'Companion', {
    get: EAttachment$Companion_getInstance
  });
  package$types.EAttachment = EAttachment;
  Object.defineProperty(EAuto, 'auto', {
    get: EAuto$auto_getInstance
  });
  Object.defineProperty(EAuto, 'Companion', {
    get: EAuto$Companion_getInstance
  });
  package$types.EAuto = EAuto;
  Object.defineProperty(EBackgroundPosition, 'bottom', {
    get: EBackgroundPosition$bottom_getInstance
  });
  Object.defineProperty(EBackgroundPosition, 'center', {
    get: EBackgroundPosition$center_getInstance
  });
  Object.defineProperty(EBackgroundPosition, 'left', {
    get: EBackgroundPosition$left_getInstance
  });
  Object.defineProperty(EBackgroundPosition, 'right', {
    get: EBackgroundPosition$right_getInstance
  });
  Object.defineProperty(EBackgroundPosition, 'top', {
    get: EBackgroundPosition$top_getInstance
  });
  Object.defineProperty(EBackgroundPosition, 'Companion', {
    get: EBackgroundPosition$Companion_getInstance
  });
  package$types.EBackgroundPosition = EBackgroundPosition;
  Object.defineProperty(EBaselineShift, 'sub', {
    get: EBaselineShift$sub_getInstance
  });
  Object.defineProperty(EBaselineShift, 'super', {
    get: EBaselineShift$super_getInstance
  });
  Object.defineProperty(EBaselineShift, 'Companion', {
    get: EBaselineShift$Companion_getInstance
  });
  package$types.EBaselineShift = EBaselineShift;
  Object.defineProperty(EBorderCollapse, 'collapse', {
    get: EBorderCollapse$collapse_getInstance
  });
  Object.defineProperty(EBorderCollapse, 'separate', {
    get: EBorderCollapse$separate_getInstance
  });
  Object.defineProperty(EBorderCollapse, 'Companion', {
    get: EBorderCollapse$Companion_getInstance
  });
  package$types.EBorderCollapse = EBorderCollapse;
  Object.defineProperty(EBoxSize, 'minContent', {
    get: EBoxSize$minContent_getInstance
  });
  Object.defineProperty(EBoxSize, 'maxContent', {
    get: EBoxSize$maxContent_getInstance
  });
  EBoxSize.fitContent_init_n0fawn$ = EBoxSize$EBoxSize$fitContent_init;
  EBoxSize.fitContent_init_rtt64d$ = EBoxSize$EBoxSize$fitContent_init_0;
  EBoxSize.fitContent = EBoxSize$fitContent;
  package$types.EBoxSize = EBoxSize;
  Object.defineProperty(EBoxSizing, 'contentBox', {
    get: EBoxSizing$contentBox_getInstance
  });
  Object.defineProperty(EBoxSizing, 'borderBox', {
    get: EBoxSizing$borderBox_getInstance
  });
  Object.defineProperty(EBoxSizing, 'Companion', {
    get: EBoxSizing$Companion_getInstance
  });
  package$types.EBoxSizing = EBoxSizing;
  Object.defineProperty(ECaptionSide, 'top', {
    get: ECaptionSide$top_getInstance
  });
  Object.defineProperty(ECaptionSide, 'bottom', {
    get: ECaptionSide$bottom_getInstance
  });
  Object.defineProperty(ECaptionSide, 'Companion', {
    get: ECaptionSide$Companion_getInstance
  });
  package$types.ECaptionSide = ECaptionSide;
  Object.defineProperty(EClear, 'left', {
    get: EClear$left_getInstance
  });
  Object.defineProperty(EClear, 'right', {
    get: EClear$right_getInstance
  });
  Object.defineProperty(EClear, 'both', {
    get: EClear$both_getInstance
  });
  Object.defineProperty(EClear, 'none', {
    get: EClear$none_getInstance
  });
  Object.defineProperty(EClear, 'inlineStart', {
    get: EClear$inlineStart_getInstance
  });
  Object.defineProperty(EClear, 'inlineEnd', {
    get: EClear$inlineEnd_getInstance
  });
  Object.defineProperty(EClear, 'blockStart', {
    get: EClear$blockStart_getInstance
  });
  Object.defineProperty(EClear, 'blockEnd', {
    get: EClear$blockEnd_getInstance
  });
  Object.defineProperty(EClear, 'top', {
    get: EClear$top_getInstance
  });
  Object.defineProperty(EClear, 'bottom', {
    get: EClear$bottom_getInstance
  });
  Object.defineProperty(EClear, 'Companion', {
    get: EClear$Companion_getInstance
  });
  package$types.EClear = EClear;
  Object.defineProperty(EContent, 'none', {
    get: EContent$none_getInstance
  });
  Object.defineProperty(EContent, 'normal', {
    get: EContent$normal_getInstance
  });
  Object.defineProperty(EContent, 'openQuote', {
    get: EContent$openQuote_getInstance
  });
  Object.defineProperty(EContent, 'closeQuote', {
    get: EContent$closeQuote_getInstance
  });
  Object.defineProperty(EContent, 'noOpenQuote', {
    get: EContent$noOpenQuote_getInstance
  });
  Object.defineProperty(EContent, 'noCloseQuote', {
    get: EContent$noCloseQuote_getInstance
  });
  EContent.attr = EContent$attr;
  EContent.url = EContent$url;
  Object.defineProperty(EContent, 'Companion', {
    get: EContent$Companion_getInstance
  });
  package$types.EContent = EContent;
  Object.defineProperty(ECursor, 'auto', {
    get: ECursor$auto_getInstance
  });
  Object.defineProperty(ECursor, 'default', {
    get: ECursor$default_getInstance
  });
  Object.defineProperty(ECursor, 'none', {
    get: ECursor$none_getInstance
  });
  Object.defineProperty(ECursor, 'contextMenu', {
    get: ECursor$contextMenu_getInstance
  });
  Object.defineProperty(ECursor, 'help', {
    get: ECursor$help_getInstance
  });
  Object.defineProperty(ECursor, 'pointer', {
    get: ECursor$pointer_getInstance
  });
  Object.defineProperty(ECursor, 'progress', {
    get: ECursor$progress_getInstance
  });
  Object.defineProperty(ECursor, 'wait', {
    get: ECursor$wait_getInstance
  });
  Object.defineProperty(ECursor, 'cell', {
    get: ECursor$cell_getInstance
  });
  Object.defineProperty(ECursor, 'crosshair', {
    get: ECursor$crosshair_getInstance
  });
  Object.defineProperty(ECursor, 'text', {
    get: ECursor$text_getInstance
  });
  Object.defineProperty(ECursor, 'verticalText', {
    get: ECursor$verticalText_getInstance
  });
  Object.defineProperty(ECursor, 'alias', {
    get: ECursor$alias_getInstance
  });
  Object.defineProperty(ECursor, 'copy', {
    get: ECursor$copy_getInstance
  });
  Object.defineProperty(ECursor, 'move', {
    get: ECursor$move_getInstance
  });
  Object.defineProperty(ECursor, 'noDrop', {
    get: ECursor$noDrop_getInstance
  });
  Object.defineProperty(ECursor, 'notAlowed', {
    get: ECursor$notAlowed_getInstance
  });
  Object.defineProperty(ECursor, 'grab', {
    get: ECursor$grab_getInstance
  });
  Object.defineProperty(ECursor, 'grabbing', {
    get: ECursor$grabbing_getInstance
  });
  Object.defineProperty(ECursor, 'eResize', {
    get: ECursor$eResize_getInstance
  });
  Object.defineProperty(ECursor, 'nResize', {
    get: ECursor$nResize_getInstance
  });
  Object.defineProperty(ECursor, 'neResize', {
    get: ECursor$neResize_getInstance
  });
  Object.defineProperty(ECursor, 'nwResize', {
    get: ECursor$nwResize_getInstance
  });
  Object.defineProperty(ECursor, 'sResize', {
    get: ECursor$sResize_getInstance
  });
  Object.defineProperty(ECursor, 'seResize', {
    get: ECursor$seResize_getInstance
  });
  Object.defineProperty(ECursor, 'swResize', {
    get: ECursor$swResize_getInstance
  });
  Object.defineProperty(ECursor, 'wResize', {
    get: ECursor$wResize_getInstance
  });
  Object.defineProperty(ECursor, 'ewResize', {
    get: ECursor$ewResize_getInstance
  });
  Object.defineProperty(ECursor, 'nsResize', {
    get: ECursor$nsResize_getInstance
  });
  Object.defineProperty(ECursor, 'neswResize', {
    get: ECursor$neswResize_getInstance
  });
  Object.defineProperty(ECursor, 'nwseResize', {
    get: ECursor$nwseResize_getInstance
  });
  Object.defineProperty(ECursor, 'colResize', {
    get: ECursor$colResize_getInstance
  });
  Object.defineProperty(ECursor, 'rowResize', {
    get: ECursor$rowResize_getInstance
  });
  Object.defineProperty(ECursor, 'allScroll', {
    get: ECursor$allScroll_getInstance
  });
  Object.defineProperty(ECursor, 'zoomIn', {
    get: ECursor$zoomIn_getInstance
  });
  Object.defineProperty(ECursor, 'zoomOut', {
    get: ECursor$zoomOut_getInstance
  });
  Object.defineProperty(ECursor, 'Companion', {
    get: ECursor$Companion_getInstance
  });
  package$types.ECursor = ECursor;
  Object.defineProperty(EDisplay, 'block', {
    get: EDisplay$block_getInstance
  });
  Object.defineProperty(EDisplay, 'inline', {
    get: EDisplay$inline_getInstance
  });
  Object.defineProperty(EDisplay, 'inlineBlock', {
    get: EDisplay$inlineBlock_getInstance
  });
  Object.defineProperty(EDisplay, 'inlineTable', {
    get: EDisplay$inlineTable_getInstance
  });
  Object.defineProperty(EDisplay, 'listItem', {
    get: EDisplay$listItem_getInstance
  });
  Object.defineProperty(EDisplay, 'none', {
    get: EDisplay$none_getInstance
  });
  Object.defineProperty(EDisplay, 'table', {
    get: EDisplay$table_getInstance
  });
  Object.defineProperty(EDisplay, 'tableCaption', {
    get: EDisplay$tableCaption_getInstance
  });
  Object.defineProperty(EDisplay, 'tableCell', {
    get: EDisplay$tableCell_getInstance
  });
  Object.defineProperty(EDisplay, 'tableColumn', {
    get: EDisplay$tableColumn_getInstance
  });
  Object.defineProperty(EDisplay, 'tableColumnGroup', {
    get: EDisplay$tableColumnGroup_getInstance
  });
  Object.defineProperty(EDisplay, 'tableFooterGroup', {
    get: EDisplay$tableFooterGroup_getInstance
  });
  Object.defineProperty(EDisplay, 'tableHeaderGroup', {
    get: EDisplay$tableHeaderGroup_getInstance
  });
  Object.defineProperty(EDisplay, 'tableRow', {
    get: EDisplay$tableRow_getInstance
  });
  Object.defineProperty(EDisplay, 'tableRowGroup', {
    get: EDisplay$tableRowGroup_getInstance
  });
  Object.defineProperty(EDisplay, 'Companion', {
    get: EDisplay$Companion_getInstance
  });
  package$types.EDisplay = EDisplay;
  Object.defineProperty(EEmptyCells, 'show', {
    get: EEmptyCells$show_getInstance
  });
  Object.defineProperty(EEmptyCells, 'hide', {
    get: EEmptyCells$hide_getInstance
  });
  Object.defineProperty(EEmptyCells, 'Companion', {
    get: EEmptyCells$Companion_getInstance
  });
  package$types.EEmptyCells = EEmptyCells;
  Object.defineProperty(EFloat, 'left', {
    get: EFloat$left_getInstance
  });
  Object.defineProperty(EFloat, 'right', {
    get: EFloat$right_getInstance
  });
  Object.defineProperty(EFloat, 'none', {
    get: EFloat$none_getInstance
  });
  Object.defineProperty(EFloat, 'inlineStart', {
    get: EFloat$inlineStart_getInstance
  });
  Object.defineProperty(EFloat, 'inlineEnd', {
    get: EFloat$inlineEnd_getInstance
  });
  Object.defineProperty(EFloat, 'blockStart', {
    get: EFloat$blockStart_getInstance
  });
  Object.defineProperty(EFloat, 'blockEnd', {
    get: EFloat$blockEnd_getInstance
  });
  Object.defineProperty(EFloat, 'top', {
    get: EFloat$top_getInstance
  });
  Object.defineProperty(EFloat, 'bottom', {
    get: EFloat$bottom_getInstance
  });
  Object.defineProperty(EFloat, 'snapBlock', {
    get: EFloat$snapBlock_getInstance
  });
  Object.defineProperty(EFloat, 'snapInline', {
    get: EFloat$snapInline_getInstance
  });
  Object.defineProperty(EFloat, 'Companion', {
    get: EFloat$Companion_getInstance
  });
  package$types.EFloat = EFloat;
  Object.defineProperty(EFontSize, 'xxSmall', {
    get: EFontSize$xxSmall_getInstance
  });
  Object.defineProperty(EFontSize, 'xSmall', {
    get: EFontSize$xSmall_getInstance
  });
  Object.defineProperty(EFontSize, 'small', {
    get: EFontSize$small_getInstance
  });
  Object.defineProperty(EFontSize, 'medium', {
    get: EFontSize$medium_getInstance
  });
  Object.defineProperty(EFontSize, 'large', {
    get: EFontSize$large_getInstance
  });
  Object.defineProperty(EFontSize, 'xLarge', {
    get: EFontSize$xLarge_getInstance
  });
  Object.defineProperty(EFontSize, 'xxLarge', {
    get: EFontSize$xxLarge_getInstance
  });
  Object.defineProperty(EFontSize, 'larger', {
    get: EFontSize$larger_getInstance
  });
  Object.defineProperty(EFontSize, 'smaller', {
    get: EFontSize$smaller_getInstance
  });
  Object.defineProperty(EFontSize, 'Companion', {
    get: EFontSize$Companion_getInstance
  });
  package$types.EFontSize = EFontSize;
  Object.defineProperty(EFontStyle, 'normal', {
    get: EFontStyle$normal_getInstance
  });
  Object.defineProperty(EFontStyle, 'italic', {
    get: EFontStyle$italic_getInstance
  });
  Object.defineProperty(EFontStyle, 'oblique', {
    get: EFontStyle$oblique_getInstance
  });
  Object.defineProperty(EFontStyle, 'Companion', {
    get: EFontStyle$Companion_getInstance
  });
  package$types.EFontStyle = EFontStyle;
  Object.defineProperty(EFontVariant, 'normal', {
    get: EFontVariant$normal_getInstance
  });
  Object.defineProperty(EFontVariant, 'smallCaps', {
    get: EFontVariant$smallCaps_getInstance
  });
  Object.defineProperty(EFontVariant, 'allSmallCaps', {
    get: EFontVariant$allSmallCaps_getInstance
  });
  Object.defineProperty(EFontVariant, 'petiteCaps', {
    get: EFontVariant$petiteCaps_getInstance
  });
  Object.defineProperty(EFontVariant, 'allPetiteCaps', {
    get: EFontVariant$allPetiteCaps_getInstance
  });
  Object.defineProperty(EFontVariant, 'unicase', {
    get: EFontVariant$unicase_getInstance
  });
  Object.defineProperty(EFontVariant, 'titlingCaps', {
    get: EFontVariant$titlingCaps_getInstance
  });
  Object.defineProperty(EFontVariant, 'Companion', {
    get: EFontVariant$Companion_getInstance
  });
  package$types.EFontVariant = EFontVariant;
  Object.defineProperty(EFontWeight, 'normal', {
    get: EFontWeight$normal_getInstance
  });
  Object.defineProperty(EFontWeight, 'bold', {
    get: EFontWeight$bold_getInstance
  });
  Object.defineProperty(EFontWeight, 'bolder', {
    get: EFontWeight$bolder_getInstance
  });
  Object.defineProperty(EFontWeight, 'lighter', {
    get: EFontWeight$lighter_getInstance
  });
  Object.defineProperty(EFontWeight, 'weight100', {
    get: EFontWeight$weight100_getInstance
  });
  Object.defineProperty(EFontWeight, 'weight200', {
    get: EFontWeight$weight200_getInstance
  });
  Object.defineProperty(EFontWeight, 'weight300', {
    get: EFontWeight$weight300_getInstance
  });
  Object.defineProperty(EFontWeight, 'weight400', {
    get: EFontWeight$weight400_getInstance
  });
  Object.defineProperty(EFontWeight, 'weight500', {
    get: EFontWeight$weight500_getInstance
  });
  Object.defineProperty(EFontWeight, 'weight600', {
    get: EFontWeight$weight600_getInstance
  });
  Object.defineProperty(EFontWeight, 'weight700', {
    get: EFontWeight$weight700_getInstance
  });
  Object.defineProperty(EFontWeight, 'weight800', {
    get: EFontWeight$weight800_getInstance
  });
  Object.defineProperty(EFontWeight, 'weight900', {
    get: EFontWeight$weight900_getInstance
  });
  Object.defineProperty(EFontWeight, 'Companion', {
    get: EFontWeight$Companion_getInstance
  });
  package$types.EFontWeight = EFontWeight;
  Object.defineProperty(EImage, 'none', {
    get: EImage$none_getInstance
  });
  EImage.url = EImage$url;
  EImage.image = EImage$image;
  Object.defineProperty(EImage, 'Companion', {
    get: EImage$Companion_getInstance
  });
  package$types.EImage = EImage;
  Object.defineProperty(ELineStyle, 'none', {
    get: ELineStyle$none_getInstance
  });
  Object.defineProperty(ELineStyle, 'hidden', {
    get: ELineStyle$hidden_getInstance
  });
  Object.defineProperty(ELineStyle, 'dotted', {
    get: ELineStyle$dotted_getInstance
  });
  Object.defineProperty(ELineStyle, 'dashed', {
    get: ELineStyle$dashed_getInstance
  });
  Object.defineProperty(ELineStyle, 'solid', {
    get: ELineStyle$solid_getInstance
  });
  Object.defineProperty(ELineStyle, 'double', {
    get: ELineStyle$double_getInstance
  });
  Object.defineProperty(ELineStyle, 'groove', {
    get: ELineStyle$groove_getInstance
  });
  Object.defineProperty(ELineStyle, 'ridge', {
    get: ELineStyle$ridge_getInstance
  });
  Object.defineProperty(ELineStyle, 'inset', {
    get: ELineStyle$inset_getInstance
  });
  Object.defineProperty(ELineStyle, 'outset', {
    get: ELineStyle$outset_getInstance
  });
  Object.defineProperty(ELineStyle, 'Companion', {
    get: ELineStyle$Companion_getInstance
  });
  package$types.ELineStyle = ELineStyle;
  Object.defineProperty(ELineWidth, 'thin', {
    get: ELineWidth$thin_getInstance
  });
  Object.defineProperty(ELineWidth, 'medium', {
    get: ELineWidth$medium_getInstance
  });
  Object.defineProperty(ELineWidth, 'thick', {
    get: ELineWidth$thick_getInstance
  });
  Object.defineProperty(ELineWidth, 'Companion', {
    get: ELineWidth$Companion_getInstance
  });
  package$types.ELineWidth = ELineWidth;
  Object.defineProperty(EListStylePosition, 'outside', {
    get: EListStylePosition$outside_getInstance
  });
  Object.defineProperty(EListStylePosition, 'inside', {
    get: EListStylePosition$inside_getInstance
  });
  Object.defineProperty(EListStylePosition, 'Companion', {
    get: EListStylePosition$Companion_getInstance
  });
  package$types.EListStylePosition = EListStylePosition;
  Object.defineProperty(EListStyleType, 'disc', {
    get: EListStyleType$disc_getInstance
  });
  Object.defineProperty(EListStyleType, 'circle', {
    get: EListStyleType$circle_getInstance
  });
  Object.defineProperty(EListStyleType, 'square', {
    get: EListStyleType$square_getInstance
  });
  Object.defineProperty(EListStyleType, 'decimal', {
    get: EListStyleType$decimal_getInstance
  });
  Object.defineProperty(EListStyleType, 'decimalLeadingZero', {
    get: EListStyleType$decimalLeadingZero_getInstance
  });
  Object.defineProperty(EListStyleType, 'lowerRoman', {
    get: EListStyleType$lowerRoman_getInstance
  });
  Object.defineProperty(EListStyleType, 'upperRoman', {
    get: EListStyleType$upperRoman_getInstance
  });
  Object.defineProperty(EListStyleType, 'georgian', {
    get: EListStyleType$georgian_getInstance
  });
  Object.defineProperty(EListStyleType, 'armenian', {
    get: EListStyleType$armenian_getInstance
  });
  Object.defineProperty(EListStyleType, 'lowerLatin', {
    get: EListStyleType$lowerLatin_getInstance
  });
  Object.defineProperty(EListStyleType, 'upperLatin', {
    get: EListStyleType$upperLatin_getInstance
  });
  Object.defineProperty(EListStyleType, 'lowerGreek', {
    get: EListStyleType$lowerGreek_getInstance
  });
  Object.defineProperty(EListStyleType, 'Companion', {
    get: EListStyleType$Companion_getInstance
  });
  package$types.EListStyleType = EListStyleType;
  Object.defineProperty(ENone, 'none', {
    get: ENone$none_getInstance
  });
  Object.defineProperty(ENone, 'Companion', {
    get: ENone$Companion_getInstance
  });
  package$types.ENone = ENone;
  Object.defineProperty(ENormal, 'normal', {
    get: ENormal$normal_getInstance
  });
  Object.defineProperty(ENormal, 'Companion', {
    get: ENormal$Companion_getInstance
  });
  package$types.ENormal = ENormal;
  Object.defineProperty(EOutlineColor, 'invert', {
    get: EOutlineColor$invert_getInstance
  });
  Object.defineProperty(EOutlineColor, 'Companion', {
    get: EOutlineColor$Companion_getInstance
  });
  package$types.EOutlineColor = EOutlineColor;
  Object.defineProperty(EOverflow, 'visible', {
    get: EOverflow$visible_getInstance
  });
  Object.defineProperty(EOverflow, 'hidden', {
    get: EOverflow$hidden_getInstance
  });
  Object.defineProperty(EOverflow, 'clip', {
    get: EOverflow$clip_getInstance
  });
  Object.defineProperty(EOverflow, 'scroll', {
    get: EOverflow$scroll_getInstance
  });
  Object.defineProperty(EOverflow, 'auto', {
    get: EOverflow$auto_getInstance
  });
  Object.defineProperty(EOverflow, 'Companion', {
    get: EOverflow$Companion_getInstance
  });
  package$types.EOverflow = EOverflow;
  Object.defineProperty(EOverflowWrap, 'normal', {
    get: EOverflowWrap$normal_getInstance
  });
  Object.defineProperty(EOverflowWrap, 'breakWord', {
    get: EOverflowWrap$breakWord_getInstance
  });
  Object.defineProperty(EOverflowWrap, 'Companion', {
    get: EOverflowWrap$Companion_getInstance
  });
  package$types.EOverflowWrap = EOverflowWrap;
  Object.defineProperty(EPageBreak, 'auto', {
    get: EPageBreak$auto_getInstance
  });
  Object.defineProperty(EPageBreak, 'always', {
    get: EPageBreak$always_getInstance
  });
  Object.defineProperty(EPageBreak, 'avoid', {
    get: EPageBreak$avoid_getInstance
  });
  Object.defineProperty(EPageBreak, 'left', {
    get: EPageBreak$left_getInstance
  });
  Object.defineProperty(EPageBreak, 'right', {
    get: EPageBreak$right_getInstance
  });
  Object.defineProperty(EPageBreak, 'Companion', {
    get: EPageBreak$Companion_getInstance
  });
  package$types.EPageBreak = EPageBreak;
  Object.defineProperty(EPageBreakInside, 'auto', {
    get: EPageBreakInside$auto_getInstance
  });
  Object.defineProperty(EPageBreakInside, 'avoid', {
    get: EPageBreakInside$avoid_getInstance
  });
  Object.defineProperty(EPageBreakInside, 'Companion', {
    get: EPageBreakInside$Companion_getInstance
  });
  package$types.EPageBreakInside = EPageBreakInside;
  Object.defineProperty(EPosition, 'static', {
    get: EPosition$static_getInstance
  });
  Object.defineProperty(EPosition, 'relative', {
    get: EPosition$relative_getInstance
  });
  Object.defineProperty(EPosition, 'absolute', {
    get: EPosition$absolute_getInstance
  });
  Object.defineProperty(EPosition, 'sticky', {
    get: EPosition$sticky_getInstance
  });
  Object.defineProperty(EPosition, 'fixed', {
    get: EPosition$fixed_getInstance
  });
  Object.defineProperty(EPosition, 'Companion', {
    get: EPosition$Companion_getInstance
  });
  package$types.EPosition = EPosition;
  Object.defineProperty(ERepeatStyle, 'repeat', {
    get: ERepeatStyle$repeat_getInstance
  });
  Object.defineProperty(ERepeatStyle, 'space', {
    get: ERepeatStyle$space_getInstance
  });
  Object.defineProperty(ERepeatStyle, 'round', {
    get: ERepeatStyle$round_getInstance
  });
  Object.defineProperty(ERepeatStyle, 'noRepeat', {
    get: ERepeatStyle$noRepeat_getInstance
  });
  Object.defineProperty(ERepeatStyle, 'repeatX', {
    get: ERepeatStyle$repeatX_getInstance
  });
  Object.defineProperty(ERepeatStyle, 'repeatY', {
    get: ERepeatStyle$repeatY_getInstance
  });
  Object.defineProperty(ERepeatStyle, 'Companion', {
    get: ERepeatStyle$Companion_getInstance
  });
  package$types.ERepeatStyle = ERepeatStyle;
  Object.defineProperty(EResize, 'none', {
    get: EResize$none_getInstance
  });
  Object.defineProperty(EResize, 'both', {
    get: EResize$both_getInstance
  });
  Object.defineProperty(EResize, 'horizontal', {
    get: EResize$horizontal_getInstance
  });
  Object.defineProperty(EResize, 'vertical', {
    get: EResize$vertical_getInstance
  });
  Object.defineProperty(EResize, 'Companion', {
    get: EResize$Companion_getInstance
  });
  package$types.EResize = EResize;
  Object.defineProperty(ETableLayout, 'fixed', {
    get: ETableLayout$fixed_getInstance
  });
  Object.defineProperty(ETableLayout, 'auto', {
    get: ETableLayout$auto_getInstance
  });
  Object.defineProperty(ETableLayout, 'Companion', {
    get: ETableLayout$Companion_getInstance
  });
  package$types.ETableLayout = ETableLayout;
  Object.defineProperty(ETextAlign, 'start', {
    get: ETextAlign$start_getInstance
  });
  Object.defineProperty(ETextAlign, 'end', {
    get: ETextAlign$end_getInstance
  });
  Object.defineProperty(ETextAlign, 'left', {
    get: ETextAlign$left_getInstance
  });
  Object.defineProperty(ETextAlign, 'right', {
    get: ETextAlign$right_getInstance
  });
  Object.defineProperty(ETextAlign, 'center', {
    get: ETextAlign$center_getInstance
  });
  Object.defineProperty(ETextAlign, 'justify', {
    get: ETextAlign$justify_getInstance
  });
  Object.defineProperty(ETextAlign, 'justifyAll', {
    get: ETextAlign$justifyAll_getInstance
  });
  Object.defineProperty(ETextAlign, 'matchParent', {
    get: ETextAlign$matchParent_getInstance
  });
  Object.defineProperty(ETextAlign, 'Companion', {
    get: ETextAlign$Companion_getInstance
  });
  package$types.ETextAlign = ETextAlign;
  Object.defineProperty(ETextDecorationLine, 'underline', {
    get: ETextDecorationLine$underline_getInstance
  });
  Object.defineProperty(ETextDecorationLine, 'overline', {
    get: ETextDecorationLine$overline_getInstance
  });
  Object.defineProperty(ETextDecorationLine, 'lineThrough', {
    get: ETextDecorationLine$lineThrough_getInstance
  });
  Object.defineProperty(ETextDecorationLine, 'Companion', {
    get: ETextDecorationLine$Companion_getInstance
  });
  package$types.ETextDecorationLine = ETextDecorationLine;
  Object.defineProperty(ETextDecorationStyle, 'dotted', {
    get: ETextDecorationStyle$dotted_getInstance
  });
  Object.defineProperty(ETextDecorationStyle, 'dashed', {
    get: ETextDecorationStyle$dashed_getInstance
  });
  Object.defineProperty(ETextDecorationStyle, 'solid', {
    get: ETextDecorationStyle$solid_getInstance
  });
  Object.defineProperty(ETextDecorationStyle, 'double', {
    get: ETextDecorationStyle$double_getInstance
  });
  Object.defineProperty(ETextDecorationStyle, 'wavy', {
    get: ETextDecorationStyle$wavy_getInstance
  });
  Object.defineProperty(ETextDecorationStyle, 'Companion', {
    get: ETextDecorationStyle$Companion_getInstance
  });
  package$types.ETextDecorationStyle = ETextDecorationStyle;
  Object.defineProperty(ETextJustify, 'auto', {
    get: ETextJustify$auto_getInstance
  });
  Object.defineProperty(ETextJustify, 'none', {
    get: ETextJustify$none_getInstance
  });
  Object.defineProperty(ETextJustify, 'interWord', {
    get: ETextJustify$interWord_getInstance
  });
  Object.defineProperty(ETextJustify, 'interCharacter', {
    get: ETextJustify$interCharacter_getInstance
  });
  Object.defineProperty(ETextJustify, 'Companion', {
    get: ETextJustify$Companion_getInstance
  });
  package$types.ETextJustify = ETextJustify;
  Object.defineProperty(ETextOverflow, 'clip', {
    get: ETextOverflow$clip_getInstance
  });
  Object.defineProperty(ETextOverflow, 'ellipsis', {
    get: ETextOverflow$ellipsis_getInstance
  });
  Object.defineProperty(ETextOverflow, 'Companion', {
    get: ETextOverflow$Companion_getInstance
  });
  package$types.ETextOverflow = ETextOverflow;
  Object.defineProperty(ETextTransform, 'capitalize', {
    get: ETextTransform$capitalize_getInstance
  });
  Object.defineProperty(ETextTransform, 'uppercase', {
    get: ETextTransform$uppercase_getInstance
  });
  Object.defineProperty(ETextTransform, 'lowercase', {
    get: ETextTransform$lowercase_getInstance
  });
  Object.defineProperty(ETextTransform, 'none', {
    get: ETextTransform$none_getInstance
  });
  Object.defineProperty(ETextTransform, 'fullWidth', {
    get: ETextTransform$fullWidth_getInstance
  });
  Object.defineProperty(ETextTransform, 'Companion', {
    get: ETextTransform$Companion_getInstance
  });
  package$types.ETextTransform = ETextTransform;
  Object.defineProperty(EUnicodeBidi, 'normal', {
    get: EUnicodeBidi$normal_getInstance
  });
  Object.defineProperty(EUnicodeBidi, 'embed', {
    get: EUnicodeBidi$embed_getInstance
  });
  Object.defineProperty(EUnicodeBidi, 'isolate', {
    get: EUnicodeBidi$isolate_getInstance
  });
  Object.defineProperty(EUnicodeBidi, 'bidiOverride', {
    get: EUnicodeBidi$bidiOverride_getInstance
  });
  Object.defineProperty(EUnicodeBidi, 'isolateOverride', {
    get: EUnicodeBidi$isolateOverride_getInstance
  });
  Object.defineProperty(EUnicodeBidi, 'plaintext', {
    get: EUnicodeBidi$plaintext_getInstance
  });
  Object.defineProperty(EUnicodeBidi, 'Companion', {
    get: EUnicodeBidi$Companion_getInstance
  });
  package$types.EUnicodeBidi = EUnicodeBidi;
  Object.defineProperty(EVisibility, 'visible', {
    get: EVisibility$visible_getInstance
  });
  Object.defineProperty(EVisibility, 'hidden', {
    get: EVisibility$hidden_getInstance
  });
  Object.defineProperty(EVisibility, 'collapse', {
    get: EVisibility$collapse_getInstance
  });
  Object.defineProperty(EVisibility, 'Companion', {
    get: EVisibility$Companion_getInstance
  });
  package$types.EVisibility = EVisibility;
  Object.defineProperty(EWhiteSpace, 'normal', {
    get: EWhiteSpace$normal_getInstance
  });
  Object.defineProperty(EWhiteSpace, 'pre', {
    get: EWhiteSpace$pre_getInstance
  });
  Object.defineProperty(EWhiteSpace, 'nowrap', {
    get: EWhiteSpace$nowrap_getInstance
  });
  Object.defineProperty(EWhiteSpace, 'preWrap', {
    get: EWhiteSpace$preWrap_getInstance
  });
  Object.defineProperty(EWhiteSpace, 'breakSpaces', {
    get: EWhiteSpace$breakSpaces_getInstance
  });
  Object.defineProperty(EWhiteSpace, 'preLine', {
    get: EWhiteSpace$preLine_getInstance
  });
  Object.defineProperty(EWhiteSpace, 'Companion', {
    get: EWhiteSpace$Companion_getInstance
  });
  package$types.EWhiteSpace = EWhiteSpace;
  var package$x = _.x || (_.x = {});
  var package$katydid_2 = package$x.katydid || (package$x.katydid = {});
  var package$css_2 = package$katydid_2.css || (package$katydid_2.css = {});
  var package$infrastructure = package$css_2.infrastructure || (package$css_2.infrastructure = {});
  package$infrastructure.makeDecimalString_mx4ult$ = makeDecimalString;
  KatydidStyleImpl.prototype.setBoxProperty_hto8b4$ = KatydidStyle.prototype.setBoxProperty_hto8b4$;
  KatydidStyleImpl.prototype.setXyProperty_l8dco4$ = KatydidStyle.prototype.setXyProperty_l8dco4$;
  KatydidStyleImpl.prototype.toCssString_puj7f4$ = KatydidStyle.prototype.toCssString_puj7f4$;
  KatydidCompositeCssRule.prototype.toCssString_za3lpa$ = KatydidCssRule.prototype.toCssString_za3lpa$;
  KatydidCompositeCssRuleImpl.prototype.toCssString_za3lpa$ = KatydidCompositeCssRule.prototype.toCssString_za3lpa$;
  KatydidAbstractStyleRule.prototype.toCssString_za3lpa$ = KatydidCompositeCssRule.prototype.toCssString_za3lpa$;
  KatydidAbstractStyleRule.prototype.toCssString_puj7f4$ = KatydidStyle.prototype.toCssString_puj7f4$;
  KatydidAbstractStyleRule.prototype.setBoxProperty_hto8b4$ = KatydidStyle.prototype.setBoxProperty_hto8b4$;
  KatydidAbstractStyleRule.prototype.setXyProperty_l8dco4$ = KatydidStyle.prototype.setXyProperty_l8dco4$;
  KatydidAbstractStyleRuleImpl.prototype.toCssString_puj7f4$ = KatydidAbstractStyleRule.prototype.toCssString_puj7f4$;
  KatydidAbstractStyleRuleImpl.prototype.setBoxProperty_hto8b4$ = KatydidAbstractStyleRule.prototype.setBoxProperty_hto8b4$;
  KatydidAbstractStyleRuleImpl.prototype.setXyProperty_l8dco4$ = KatydidAbstractStyleRule.prototype.setXyProperty_l8dco4$;
  KatydidCharSetAtRule.prototype.toCssString_za3lpa$ = KatydidCssRule.prototype.toCssString_za3lpa$;
  KatydidCharSetAtRuleImpl.prototype.toCssString_za3lpa$ = KatydidCharSetAtRule.prototype.toCssString_za3lpa$;
  KatydidMediaAtRule.prototype.toCssString_za3lpa$ = KatydidCompositeCssRule.prototype.toCssString_za3lpa$;
  KatydidPlaceholderRule.prototype.toCssString_za3lpa$ = KatydidAbstractStyleRule.prototype.toCssString_za3lpa$;
  KatydidPlaceholderRule.prototype.toCssString_puj7f4$ = KatydidAbstractStyleRule.prototype.toCssString_puj7f4$;
  KatydidPlaceholderRule.prototype.setBoxProperty_hto8b4$ = KatydidAbstractStyleRule.prototype.setBoxProperty_hto8b4$;
  KatydidPlaceholderRule.prototype.setXyProperty_l8dco4$ = KatydidAbstractStyleRule.prototype.setXyProperty_l8dco4$;
  KatydidStyleRule.prototype.toCssString_za3lpa$ = KatydidAbstractStyleRule.prototype.toCssString_za3lpa$;
  KatydidStyleRule.prototype.toCssString_puj7f4$ = KatydidAbstractStyleRule.prototype.toCssString_puj7f4$;
  KatydidStyleRule.prototype.setBoxProperty_hto8b4$ = KatydidAbstractStyleRule.prototype.setBoxProperty_hto8b4$;
  KatydidStyleRule.prototype.setXyProperty_l8dco4$ = KatydidAbstractStyleRule.prototype.setXyProperty_l8dco4$;
  KatydidStyleSheet.prototype.toCssString_za3lpa$ = KatydidCompositeCssRule.prototype.toCssString_za3lpa$;
  aliceblue = new RgbColor(240, 248, 255, 1.0, 'aliceblue');
  antiquewhite = new RgbColor(250, 235, 215, 1.0, 'antiquewhite');
  aqua = new RgbColor(0, 255, 255, 1.0, 'aqua');
  aquamarine = new RgbColor(127, 255, 212, 1.0, 'aquamarine');
  azure = new RgbColor(240, 255, 255, 1.0, 'azure');
  beige = new RgbColor(245, 245, 220, 1.0, 'beige');
  bisque = new RgbColor(255, 228, 196, 1.0, 'bisque');
  black = new RgbColor(0, 0, 0, 1.0, 'black');
  blanchedalmond = new RgbColor(255, 235, 205, 1.0, 'blanchedalmond');
  blue = new RgbColor(0, 0, 255, 1.0, 'blue');
  blueviolet = new RgbColor(138, 43, 226, 1.0, 'blueviolet');
  brown = new RgbColor(165, 42, 42, 1.0, 'brown');
  burlywood = new RgbColor(222, 184, 135, 1.0, 'burlywood');
  cadetblue = new RgbColor(95, 158, 160, 1.0, 'cadetblue');
  chartreuse = new RgbColor(127, 255, 0, 1.0, 'chartreuse');
  chocolate = new RgbColor(210, 105, 30, 1.0, 'chocolate');
  coral = new RgbColor(255, 127, 80, 1.0, 'coral');
  cornflowerblue = new RgbColor(100, 149, 237, 1.0, 'cornflowerblue');
  cornsilk = new RgbColor(255, 248, 220, 1.0, 'cornsilk');
  crimson = new RgbColor(220, 20, 60, 1.0, 'crimson');
  cyan = new RgbColor(0, 255, 255, 1.0, 'cyan');
  darkblue = new RgbColor(0, 0, 139, 1.0, 'darkblue');
  darkcyan = new RgbColor(0, 139, 139, 1.0, 'darkcyan');
  darkgoldenrod = new RgbColor(184, 134, 11, 1.0, 'darkgoldenrod');
  darkgray = new RgbColor(169, 169, 169, 1.0, 'darkgray');
  darkgreen = new RgbColor(0, 100, 0, 1.0, 'darkgreen');
  darkgrey = RgbColor_init(169, 169, 169, 1.0);
  darkkhaki = new RgbColor(189, 183, 107, 1.0, 'darkkhaki');
  darkmagenta = new RgbColor(139, 0, 139, 1.0, 'darkmagenta');
  darkolivegreen = new RgbColor(85, 107, 47, 1.0, 'darkolivegreen');
  darkorange = new RgbColor(255, 140, 0, 1.0, 'darkorange');
  darkorchid = new RgbColor(153, 50, 204, 1.0, 'darkorchid');
  darkred = new RgbColor(139, 0, 0, 1.0, 'darkred');
  darksalmon = new RgbColor(233, 150, 122, 1.0, 'darksalmon');
  darkseagreen = new RgbColor(143, 188, 143, 1.0, 'darkseagreen');
  darkslateblue = new RgbColor(72, 61, 139, 1.0, 'darkslateblue');
  darkslategray = new RgbColor(47, 79, 79, 1.0, 'darkslategray');
  darkslategrey = RgbColor_init(47, 79, 79, 1.0);
  darkturquoise = new RgbColor(0, 206, 209, 1.0, 'darkturquoise');
  darkviolet = new RgbColor(148, 0, 211, 1.0, 'darkviolet');
  deeppink = new RgbColor(255, 20, 147, 1.0, 'deeppink');
  deepskyblue = new RgbColor(0, 191, 255, 1.0, 'deepskyblue');
  dimgray = new RgbColor(105, 105, 105, 1.0, 'dimgray');
  dimgrey = RgbColor_init(105, 105, 105, 1.0);
  dodgerblue = new RgbColor(30, 144, 255, 1.0, 'dodgerblue');
  firebrick = new RgbColor(178, 34, 34, 1.0, 'firebrick');
  floralwhite = new RgbColor(255, 250, 240, 1.0, 'floralwhite');
  forestgreen = new RgbColor(34, 139, 34, 1.0, 'forestgreen');
  fuchsia = new RgbColor(255, 0, 255, 1.0, 'fuchsia');
  gainsboro = new RgbColor(220, 220, 220, 1.0, 'gainsboro');
  ghostwhite = new RgbColor(248, 248, 255, 1.0, 'ghostwhite');
  gold = new RgbColor(255, 215, 0, 1.0, 'gold');
  goldenrod = new RgbColor(218, 165, 32, 1.0, 'goldenrod');
  gray = new RgbColor(128, 128, 128, 1.0, 'gray');
  green = new RgbColor(0, 128, 0, 1.0, 'green');
  greenyellow = new RgbColor(173, 255, 47, 1.0, 'greenyellow');
  grey = RgbColor_init(128, 128, 128, 1.0);
  honeydew = new RgbColor(240, 255, 240, 1.0, 'honeydew');
  hotpink = new RgbColor(255, 105, 180, 1.0, 'hotpink');
  indianred = new RgbColor(205, 92, 92, 1.0, 'indianred');
  indigo = new RgbColor(75, 0, 130, 1.0, 'indigo');
  ivory = new RgbColor(255, 255, 240, 1.0, 'ivory');
  khaki = new RgbColor(240, 230, 140, 1.0, 'khaki');
  lavender = new RgbColor(230, 230, 250, 1.0, 'lavender');
  lavenderblush = new RgbColor(255, 240, 245, 1.0, 'lavendarblush');
  lawngreen = new RgbColor(124, 252, 0, 1.0, 'lawngreen');
  lemonchiffon = new RgbColor(255, 250, 205, 1.0, 'lemonchiffon');
  lightblue = new RgbColor(173, 216, 230, 1.0, 'lightblue');
  lightcoral = new RgbColor(240, 128, 128, 1.0, 'lightcoral');
  lightcyan = new RgbColor(224, 255, 255, 1.0, 'lightcyan');
  lightgoldenrodyellow = new RgbColor(250, 250, 210, 1.0, 'lightgoldenrodyellow');
  lightgray = new RgbColor(211, 211, 211, 1.0, 'lightgray');
  lightgreen = new RgbColor(144, 238, 144, 1.0, 'lightgreen');
  lightgrey = RgbColor_init(211, 211, 211, 1.0);
  lightpink = new RgbColor(255, 182, 193, 1.0, 'lightpink');
  lightsalmon = new RgbColor(255, 160, 122, 1.0, 'lightsalmon');
  lightseagreen = new RgbColor(32, 178, 170, 1.0, 'lightseagreen');
  lightskyblue = new RgbColor(135, 206, 250, 1.0, 'lightskyblue');
  lightslategray = new RgbColor(119, 136, 153, 1.0, 'lightslategray');
  lightslategrey = RgbColor_init(119, 136, 153, 1.0);
  lightsteelblue = new RgbColor(176, 196, 222, 1.0, 'lightsteelblue');
  lightyellow = new RgbColor(255, 255, 224, 1.0, 'lightyellow');
  lime = new RgbColor(0, 255, 0, 1.0, 'lime');
  limegreen = new RgbColor(50, 205, 50, 1.0, 'limegreen');
  linen = new RgbColor(250, 240, 230, 1.0, 'linen');
  magenta = new RgbColor(255, 0, 255, 1.0, 'magenta');
  maroon = new RgbColor(128, 0, 0, 1.0, 'maroon');
  mediumaquamarine = new RgbColor(102, 205, 170, 1.0, 'mediumaquamarine');
  mediumblue = new RgbColor(0, 0, 205, 1.0, 'mediumblue');
  mediumorchid = new RgbColor(186, 85, 211, 1.0, 'mediumorchid');
  mediumpurple = new RgbColor(147, 112, 219, 1.0, 'mediumpurple');
  mediumseagreen = new RgbColor(60, 179, 113, 1.0, 'mediumseagreen');
  mediumslateblue = new RgbColor(123, 104, 238, 1.0, 'mediumslateblue');
  mediumspringgreen = new RgbColor(0, 250, 154, 1.0, 'mediumspringgreen');
  mediumturquoise = new RgbColor(72, 209, 204, 1.0, 'mediumturquoise');
  mediumvioletred = new RgbColor(199, 21, 133, 1.0, 'mediumvioletred');
  midnightblue = new RgbColor(25, 25, 112, 1.0, 'midnightblue');
  mintcream = new RgbColor(245, 255, 250, 1.0, 'mintcream');
  mistyrose = new RgbColor(255, 228, 225, 1.0, 'mistyrose');
  moccasin = new RgbColor(255, 228, 181, 1.0, 'moccasin');
  navajowhite = new RgbColor(255, 222, 173, 1.0, 'navajowhite');
  navy = new RgbColor(0, 0, 128, 1.0, 'navy');
  oldlace = new RgbColor(253, 245, 230, 1.0, 'oldlace');
  olive = new RgbColor(128, 128, 0, 1.0, 'olive');
  olivedrab = new RgbColor(107, 142, 35, 1.0, 'olivedrab');
  orange = new RgbColor(255, 165, 0, 1.0, 'orange');
  orangered = new RgbColor(255, 69, 0, 1.0, 'orangered');
  orchid = new RgbColor(218, 112, 214, 1.0, 'orchid');
  palegoldenrod = new RgbColor(238, 232, 170, 1.0, 'palegoldenrod');
  palegreen = new RgbColor(152, 251, 152, 1.0, 'palegreen');
  paleturquoise = new RgbColor(175, 238, 238, 1.0, 'paleturquoise');
  palevioletred = new RgbColor(219, 112, 147, 1.0, 'palevioletred');
  papayawhip = new RgbColor(255, 239, 213, 1.0, 'papayawhip');
  peachpuff = new RgbColor(255, 218, 185, 1.0, 'peachpuff');
  peru = new RgbColor(205, 133, 63, 1.0, 'peru');
  pink = new RgbColor(255, 192, 203, 1.0, 'pink');
  plum = new RgbColor(221, 160, 221, 1.0, 'plum');
  powderblue = new RgbColor(176, 224, 230, 1.0, 'powderblue');
  purple = new RgbColor(128, 0, 128, 1.0, 'purple');
  red = new RgbColor(255, 0, 0, 1.0, 'red');
  rosybrown = new RgbColor(188, 143, 143, 1.0, 'rosybrown');
  royalblue = new RgbColor(65, 105, 225, 1.0, 'royalblue');
  saddlebrown = new RgbColor(139, 69, 19, 1.0, 'saddlebrown');
  salmon = new RgbColor(250, 128, 114, 1.0, 'salmon');
  sandybrown = new RgbColor(244, 164, 96, 1.0, 'sandybrown');
  seagreen = new RgbColor(46, 139, 87, 1.0, 'seagreen');
  seashell = new RgbColor(255, 245, 238, 1.0, 'seashell');
  sienna = new RgbColor(160, 82, 45, 1.0, 'sienna');
  silver = new RgbColor(192, 192, 192, 1.0, 'silver');
  skyblue = new RgbColor(135, 206, 235, 1.0, 'skyblue');
  slateblue = new RgbColor(106, 90, 205, 1.0, 'slateblue');
  slategray = new RgbColor(112, 128, 144, 1.0, 'slategray');
  slategrey = RgbColor_init(112, 128, 144, 1.0);
  snow = new RgbColor(255, 250, 250, 1.0, 'snow');
  springgreen = new RgbColor(0, 255, 127, 1.0, 'springgreen');
  steelblue = new RgbColor(70, 130, 180, 1.0, 'steelblue');
  tan = new RgbColor(210, 180, 140, 1.0, 'tan');
  teal = new RgbColor(0, 128, 128, 1.0, 'teal');
  thistle = new RgbColor(216, 191, 216, 1.0, 'thistle');
  tomato = new RgbColor(255, 99, 71, 1.0, 'tomato');
  transparent = new RgbColor(0, 0, 0, 0.0, 'transparent');
  turquoise = new RgbColor(64, 224, 208, 1.0, 'turquoise');
  violet = new RgbColor(238, 130, 238, 1.0, 'violet');
  wheat = new RgbColor(245, 222, 179, 1.0, 'wheat');
  white = new RgbColor(255, 255, 255, 1.0, 'white');
  whitesmoke = new RgbColor(245, 245, 245, 1.0, 'whitesmoke');
  yellow = new RgbColor(255, 255, 0, 1.0, 'yellow');
  yellowgreen = new RgbColor(154, 205, 50, 1.0, 'yellowgreen');
  Kotlin.defineModule('Katydid-CSS-JS', _);
  return _;
}(typeof this['Katydid-CSS-JS'] === 'undefined' ? {} : this['Katydid-CSS-JS'], kotlin);

//# sourceMappingURL=Katydid-CSS-JS.js.map
