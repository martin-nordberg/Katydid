if (typeof kotlin === 'undefined') {
  throw new Error("Error loading module 'Katydid-Samples'. Its dependency 'kotlin' was not found. Please, check whether 'kotlin' is loaded prior to 'Katydid-Samples'.");
}
if (typeof this['Katydid-VDOM-JS'] === 'undefined') {
  throw new Error("Error loading module 'Katydid-Samples'. Its dependency 'Katydid-VDOM-JS' was not found. Please, check whether 'Katydid-VDOM-JS' is loaded prior to 'Katydid-Samples'.");
}
if (typeof this['Katydid-CSS-JS'] === 'undefined') {
  throw new Error("Error loading module 'Katydid-Samples'. Its dependency 'Katydid-CSS-JS' was not found. Please, check whether 'Katydid-CSS-JS' is loaded prior to 'Katydid-Samples'.");
}
if (typeof this['Katydid-Events-JS'] === 'undefined') {
  throw new Error("Error loading module 'Katydid-Samples'. Its dependency 'Katydid-Events-JS' was not found. Please, check whether 'Katydid-Events-JS' is loaded prior to 'Katydid-Samples'.");
}
this['Katydid-Samples'] = function (_, Kotlin, $module$Katydid_VDOM_JS, $module$Katydid_CSS_JS, $module$Katydid_Events_JS) {
  'use strict';
  var Unit = Kotlin.kotlin.Unit;
  var getCallableRef = Kotlin.getCallableRef;
  var listOf = Kotlin.kotlin.collections.listOf_mh5how$;
  var KatydidApplicationCycle = $module$Katydid_VDOM_JS.js.katydid.vdom.api.KatydidApplicationCycle;
  var Kind_CLASS = Kotlin.Kind.CLASS;
  var KatydidApplication = $module$Katydid_VDOM_JS.js.katydid.vdom.api.KatydidApplication;
  var ensureNotNull = Kotlin.ensureNotNull;
  var buildStyleElement = $module$Katydid_CSS_JS.js.katydid.css.buildStyleElement_95j5yg$;
  var runApplication = $module$Katydid_VDOM_JS.js.katydid.vdom.api.runApplication_8b6ioz$;
  var fontFamily = $module$Katydid_CSS_JS.o.katydid.css.styles.builders.fontFamily_p6629n$;
  var colors = $module$Katydid_CSS_JS.o.katydid.css.colors;
  var backgroundColor = $module$Katydid_CSS_JS.o.katydid.css.styles.builders.backgroundColor_rp620z$;
  var EFloat = $module$Katydid_CSS_JS.o.katydid.css.types.EFloat;
  var float = $module$Katydid_CSS_JS.o.katydid.css.styles.builders.float_34jj56$;
  var get_px = $module$Katydid_CSS_JS.o.katydid.css.measurements.get_px_rcaex3$;
  var fontSize = $module$Katydid_CSS_JS.o.katydid.css.styles.builders.fontSize_54i8pt$;
  var ETextAlign = $module$Katydid_CSS_JS.o.katydid.css.types.ETextAlign;
  var textAlign = $module$Katydid_CSS_JS.o.katydid.css.styles.builders.textAlign_a8jtga$;
  var get_em = $module$Katydid_CSS_JS.o.katydid.css.measurements.get_em_rcaex3$;
  var width = $module$Katydid_CSS_JS.o.katydid.css.styles.builders.width_54i8pt$;
  var makeStyleSheet = $module$Katydid_CSS_JS.o.katydid.css.stylesheets.makeStyleSheet_vawl44$;
  var Kind_OBJECT = Kotlin.Kind.OBJECT;
  var emptyList = Kotlin.kotlin.collections.emptyList_287e2$;
  var split = Kotlin.kotlin.text.split_ip8yn$;
  var color = $module$Katydid_CSS_JS.o.katydid.css.styles.builders.color_rp620z$;
  var style = $module$Katydid_CSS_JS.o.katydid.css.styles.style_biqugo$;
  var IntRange = Kotlin.kotlin.ranges.IntRange;
  var substring = Kotlin.kotlin.text.substring_fc3b62$;
  var marginRight = $module$Katydid_CSS_JS.o.katydid.css.styles.builders.marginRight_54i8pt$;
  var oninput = $module$Katydid_Events_JS.o.katydid.events.eventhandling.oninput_i6t1xa$;
  var katydid = $module$Katydid_VDOM_JS.o.katydid.vdom.application.katydid_fujzwl$;
  var makeKatydidLifecycle = $module$Katydid_VDOM_JS.o.katydid.vdom.application.makeKatydidLifecycle_287e2$;
  var EDisplay = $module$Katydid_CSS_JS.o.katydid.css.types.EDisplay;
  var display = $module$Katydid_CSS_JS.o.katydid.css.styles.builders.display_9qt20g$;
  var maxHeight = $module$Katydid_CSS_JS.o.katydid.css.styles.builders.maxHeight_54i8pt$;
  var EOverflow = $module$Katydid_CSS_JS.o.katydid.css.types.EOverflow;
  var overflowY = $module$Katydid_CSS_JS.o.katydid.css.styles.builders.overflowY_dwypzg$;
  var EClear = $module$Katydid_CSS_JS.o.katydid.css.types.EClear;
  var clear = $module$Katydid_CSS_JS.o.katydid.css.styles.builders.clear_32vxy3$;
  var marginTop = $module$Katydid_CSS_JS.o.katydid.css.styles.builders.marginTop_54i8pt$;
  var maxWidth = $module$Katydid_CSS_JS.o.katydid.css.styles.builders.maxWidth_54i8pt$;
  var ELineStyle = $module$Katydid_CSS_JS.o.katydid.css.types.ELineStyle;
  var borderStyle = $module$Katydid_CSS_JS.o.katydid.css.styles.builders.borderStyle_4kjcn2$;
  var margin = $module$Katydid_CSS_JS.o.katydid.css.styles.builders.margin_ja1nre$;
  var EBorderCollapse = $module$Katydid_CSS_JS.o.katydid.css.types.EBorderCollapse;
  var borderCollapse = $module$Katydid_CSS_JS.o.katydid.css.styles.builders.borderCollapse_h3lb3f$;
  var borderSpacing = $module$Katydid_CSS_JS.o.katydid.css.styles.builders.borderSpacing_p9u9dw$;
  var padding = $module$Katydid_CSS_JS.o.katydid.css.styles.builders.padding_ja1nre$;
  var border = $module$Katydid_CSS_JS.o.katydid.css.styles.builders.border_95zgtn$;
  var height = $module$Katydid_CSS_JS.o.katydid.css.styles.builders.height_54i8pt$;
  var ECursor = $module$Katydid_CSS_JS.o.katydid.css.types.ECursor;
  var cursor = $module$Katydid_CSS_JS.o.katydid.css.styles.builders.cursor_olkzwo$;
  var ETextDecorationLine = $module$Katydid_CSS_JS.o.katydid.css.types.ETextDecorationLine;
  var textDecoration = $module$Katydid_CSS_JS.o.katydid.css.styles.builders.textDecoration_68x5i6$;
  var Color = $module$Katydid_CSS_JS.o.katydid.css.colors.Color;
  var EAlignmentBaseline = $module$Katydid_CSS_JS.o.katydid.css.types.EAlignmentBaseline;
  var verticalAlign = $module$Katydid_CSS_JS.o.katydid.css.styles.builders.verticalAlign_l9hm2$;
  var Enum = Kotlin.kotlin.Enum;
  var throwISE = Kotlin.throwISE;
  var throwUPAE = Kotlin.throwUPAE;
  var mutableSetOf = Kotlin.kotlin.collections.mutableSetOf_i5x0yv$;
  var ArrayList_init = Kotlin.kotlin.collections.ArrayList_init_mqih57$;
  var listOf_0 = Kotlin.kotlin.collections.listOf_i5x0yv$;
  var ArrayList_init_0 = Kotlin.kotlin.collections.ArrayList_init_287e2$;
  var elementAt = Kotlin.kotlin.collections.elementAt_ba2ldo$;
  var equals = Kotlin.equals;
  var marginLeft = $module$Katydid_CSS_JS.o.katydid.css.styles.builders.marginLeft_54i8pt$;
  var to = Kotlin.kotlin.to_ujzrz7$;
  var onclick = $module$Katydid_Events_JS.o.katydid.events.eventhandling.onclick_qkbymb$;
  var EFontWeight = $module$Katydid_CSS_JS.o.katydid.css.types.EFontWeight;
  var fontWeight = $module$Katydid_CSS_JS.o.katydid.css.styles.builders.fontWeight_3o1zq1$;
  var sorted = Kotlin.kotlin.collections.sorted_exjks8$;
  var joinToString = Kotlin.kotlin.collections.joinToString_fmv235$;
  var toBoolean = Kotlin.kotlin.text.toBoolean_pdl1vz$;
  var onchange = $module$Katydid_Events_JS.o.katydid.events.eventhandling.onchange_94yeqk$;
  var onblur = $module$Katydid_Events_JS.o.katydid.events.eventhandling.onblur_gtueds$;
  var onmouseenter = $module$Katydid_Events_JS.o.katydid.events.eventhandling.onmouseenter_qkbymb$;
  var onmouseleave = $module$Katydid_Events_JS.o.katydid.events.eventhandling.onmouseleave_qkbymb$;
  var borderColor = $module$Katydid_CSS_JS.o.katydid.css.styles.builders.borderColor_ijr58i$;
  var EPosition = $module$Katydid_CSS_JS.o.katydid.css.types.EPosition;
  var position = $module$Katydid_CSS_JS.o.katydid.css.styles.builders.position_ab2qqt$;
  var isBlank = Kotlin.kotlin.text.isBlank_gw00vp$;
  var toSet = Kotlin.kotlin.collections.toSet_7wnvza$;
  var collectionSizeOrDefault = Kotlin.kotlin.collections.collectionSizeOrDefault_ba2ldo$;
  var ArrayList_init_1 = Kotlin.kotlin.collections.ArrayList_init_ww73n8$;
  var plus = Kotlin.kotlin.collections.plus_e8164j$;
  var minus = Kotlin.kotlin.collections.minus_4pa84t$;
  var plus_0 = Kotlin.kotlin.collections.plus_qloxvw$;
  var minus_0 = Kotlin.kotlin.collections.minus_2ws7j4$;
  var IllegalStateException_init = Kotlin.kotlin.IllegalStateException_init_pdl1vj$;
  var emptyMap = Kotlin.kotlin.collections.emptyMap_q3lmfv$;
  var UnsupportedOperationException_init = Kotlin.kotlin.UnsupportedOperationException_init_pdl1vj$;
  var throwCCE = Kotlin.throwCCE;
  var get_percent = $module$Katydid_CSS_JS.o.katydid.css.measurements.get_percent_rcaex3$;
  var width_0 = $module$Katydid_CSS_JS.o.katydid.css.styles.builders.width_yg607n$;
  ClockTickMsg.prototype = Object.create(DigitalClockMsg.prototype);
  ClockTickMsg.prototype.constructor = ClockTickMsg;
  Cell$State.prototype = Object.create(Enum.prototype);
  Cell$State.prototype.constructor = Cell$State;
  CellGroup$Type.prototype = Object.create(Enum.prototype);
  CellGroup$Type.prototype.constructor = CellGroup$Type;
  PlaceValueMsg.prototype = Object.create(SudokuSolverMsg.prototype);
  PlaceValueMsg.prototype.constructor = PlaceValueMsg;
  RemoveValueMsg.prototype = Object.create(SudokuSolverMsg.prototype);
  RemoveValueMsg.prototype.constructor = RemoveValueMsg;
  ChangeSettingsMsg.prototype = Object.create(SudokuSolverMsg.prototype);
  ChangeSettingsMsg.prototype.constructor = ChangeSettingsMsg;
  ChangeIsXSudoku.prototype = Object.create(SettingsChange.prototype);
  ChangeIsXSudoku.prototype.constructor = ChangeIsXSudoku;
  ChangeIsSolvedAutomatically.prototype = Object.create(SettingsChange.prototype);
  ChangeIsSolvedAutomatically.prototype.constructor = ChangeIsSolvedAutomatically;
  ChangeIsUserSolving.prototype = Object.create(SettingsChange.prototype);
  ChangeIsUserSolving.prototype.constructor = ChangeIsUserSolving;
  BoardNameRenameMsg.prototype = Object.create(BoardNameMsg.prototype);
  BoardNameRenameMsg.prototype.constructor = BoardNameRenameMsg;
  BoardNameStartEditingMsg.prototype = Object.create(BoardNameMsg.prototype);
  BoardNameStartEditingMsg.prototype.constructor = BoardNameStartEditingMsg;
  BoardNameStartHoveringMsg.prototype = Object.create(BoardNameMsg.prototype);
  BoardNameStartHoveringMsg.prototype.constructor = BoardNameStartHoveringMsg;
  BoardNameStopEditingMsg.prototype = Object.create(BoardNameMsg.prototype);
  BoardNameStopEditingMsg.prototype.constructor = BoardNameStopEditingMsg;
  BoardNameStopHoveringMsg.prototype = Object.create(BoardNameMsg.prototype);
  BoardNameStopHoveringMsg.prototype.constructor = BoardNameStopHoveringMsg;
  CreateBoardAction.prototype = Object.create(Action.prototype);
  CreateBoardAction.prototype.constructor = CreateBoardAction;
  RenameBoardAction.prototype = Object.create(Action.prototype);
  RenameBoardAction.prototype.constructor = RenameBoardAction;
  DeleteBoardAction.prototype = Object.create(Action.prototype);
  DeleteBoardAction.prototype.constructor = DeleteBoardAction;
  DeleteColumnAction.prototype = Object.create(Action.prototype);
  DeleteColumnAction.prototype.constructor = DeleteColumnAction;
  ChangeCardDetailsAction.prototype = Object.create(Action.prototype);
  ChangeCardDetailsAction.prototype.constructor = ChangeCardDetailsAction;
  ChangeCardTitleAction.prototype = Object.create(Action.prototype);
  ChangeCardTitleAction.prototype.constructor = ChangeCardTitleAction;
  ChangeColumnHeadingAction.prototype = Object.create(Action.prototype);
  ChangeColumnHeadingAction.prototype.constructor = ChangeColumnHeadingAction;
  DeleteCardAction.prototype = Object.create(Action.prototype);
  DeleteCardAction.prototype.constructor = DeleteCardAction;
  RenameColumnMsg.prototype = Object.create(WipCardsMsg.prototype);
  RenameColumnMsg.prototype.constructor = RenameColumnMsg;
  WipCardsBoardNameMsg.prototype = Object.create(WipCardsMsg.prototype);
  WipCardsBoardNameMsg.prototype.constructor = WipCardsBoardNameMsg;
  WipCardsBoardUiState.prototype = Object.create(WipCardsUiState.prototype);
  WipCardsBoardUiState.prototype.constructor = WipCardsBoardUiState;
  function DigitalClockApplication() {
  }
  DigitalClockApplication.prototype.initialize = function () {
    return new KatydidApplicationCycle(new DigitalClockAppState(), listOf(getCallableRef('updateTime', function (dispatchMessages) {
      return updateTime(dispatchMessages), Unit;
    })));
  };
  DigitalClockApplication.prototype.update_xwzc9p$ = function (applicationState, message) {
    return updateDigitalClock(applicationState, message);
  };
  DigitalClockApplication.prototype.view_11rb$ = function (applicationState) {
    return viewDigitalClock(applicationState);
  };
  DigitalClockApplication.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'DigitalClockApplication',
    interfaces: [KatydidApplication]
  };
  function digitalClockMain(args) {
    var css = makeDigitalClockStyleSheet();
    var cssElement = ensureNotNull(document.getElementById('appStyleElement'));
    buildStyleElement(cssElement, css);
    runApplication('app', new DigitalClockApplication());
  }
  function makeDigitalClockStyleSheet$lambda$lambda($receiver) {
    fontFamily($receiver, ['Arial', 'Helvetica Neue', 'Helvetica', 'sans-serif']);
    return Unit;
  }
  function makeDigitalClockStyleSheet$lambda$lambda$lambda($receiver) {
    width($receiver, get_em(1));
    return Unit;
  }
  function makeDigitalClockStyleSheet$lambda$lambda$lambda_0($receiver) {
    width($receiver, get_em(0.3));
    return Unit;
  }
  function makeDigitalClockStyleSheet$lambda$lambda_0($receiver) {
    backgroundColor($receiver, colors.black);
    float($receiver, EFloat.left);
    fontSize($receiver, get_px(100));
    fontFamily($receiver, ['Orbitron']);
    textAlign($receiver, ETextAlign.center);
    $receiver.invoke_k851pc$('&.digit', makeDigitalClockStyleSheet$lambda$lambda$lambda);
    $receiver.invoke_k851pc$('&.separator', makeDigitalClockStyleSheet$lambda$lambda$lambda_0);
    return Unit;
  }
  function makeDigitalClockStyleSheet$lambda($receiver) {
    $receiver.invoke_k851pc$('body', makeDigitalClockStyleSheet$lambda$lambda);
    $receiver.invoke_k851pc$('div.clock', makeDigitalClockStyleSheet$lambda$lambda_0);
    return Unit;
  }
  function makeDigitalClockStyleSheet() {
    return makeStyleSheet(makeDigitalClockStyleSheet$lambda);
  }
  function DigitalClockAppState(time) {
    if (time === void 0)
      time = new Date();
    this.time = time;
  }
  DigitalClockAppState.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'DigitalClockAppState',
    interfaces: []
  };
  DigitalClockAppState.prototype.component1 = function () {
    return this.time;
  };
  DigitalClockAppState.prototype.copy_qjzqsm$ = function (time) {
    return new DigitalClockAppState(time === void 0 ? this.time : time);
  };
  DigitalClockAppState.prototype.toString = function () {
    return 'DigitalClockAppState(time=' + Kotlin.toString(this.time) + ')';
  };
  DigitalClockAppState.prototype.hashCode = function () {
    var result = 0;
    result = result * 31 + Kotlin.hashCode(this.time) | 0;
    return result;
  };
  DigitalClockAppState.prototype.equals = function (other) {
    return this === other || (other !== null && (typeof other === 'object' && (Object.getPrototypeOf(this) === Object.getPrototypeOf(other) && Kotlin.equals(this.time, other.time))));
  };
  function DigitalClockMsg() {
  }
  DigitalClockMsg.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'DigitalClockMsg',
    interfaces: []
  };
  function ClockTickMsg() {
    ClockTickMsg_instance = this;
    DigitalClockMsg.call(this);
  }
  ClockTickMsg.$metadata$ = {
    kind: Kind_OBJECT,
    simpleName: 'ClockTickMsg',
    interfaces: [DigitalClockMsg]
  };
  var ClockTickMsg_instance = null;
  function ClockTickMsg_getInstance() {
    if (ClockTickMsg_instance === null) {
      new ClockTickMsg();
    }
    return ClockTickMsg_instance;
  }
  function updateTime$lambda(closure$dispatchMessages) {
    return function () {
      closure$dispatchMessages(listOf(ClockTickMsg_getInstance()));
      return Unit;
    };
  }
  function updateTime(dispatchMessages) {
    window.setInterval(updateTime$lambda(dispatchMessages), 1000);
  }
  function updateDigitalClock(applicationState, message) {
    var tmp$;
    var commandsToExecute = emptyList();
    if (Kotlin.isType(message, ClockTickMsg))
      tmp$ = new DigitalClockAppState();
    else
      tmp$ = Kotlin.noWhenBranchMatched();
    var newApplicationState = tmp$;
    return new KatydidApplicationCycle(newApplicationState, commandsToExecute);
  }
  function viewDigitalClock$lambda$lambda$lambda(closure$timeZone) {
    return function ($receiver) {
      $receiver.text_4w9ihe$(closure$timeZone);
      return Unit;
    };
  }
  function viewDigitalClock$lambda$lambda$lambda$lambda($receiver) {
    color($receiver, colors.red);
    return Unit;
  }
  function viewDigitalClock$lambda$lambda$lambda$lambda_0(closure$time) {
    return function ($receiver) {
      $receiver.text_4w9ihe$(substring(closure$time, new IntRange(0, 0)));
      return Unit;
    };
  }
  function viewDigitalClock$lambda$lambda$lambda$lambda_1(closure$time) {
    return function ($receiver) {
      $receiver.text_4w9ihe$(substring(closure$time, new IntRange(1, 1)));
      return Unit;
    };
  }
  function viewDigitalClock$lambda$lambda$lambda$lambda_2($receiver) {
    $receiver.text_4w9ihe$(':');
    return Unit;
  }
  function viewDigitalClock$lambda$lambda$lambda$lambda_3(closure$time) {
    return function ($receiver) {
      $receiver.text_4w9ihe$(substring(closure$time, new IntRange(3, 3)));
      return Unit;
    };
  }
  function viewDigitalClock$lambda$lambda$lambda$lambda_4(closure$time) {
    return function ($receiver) {
      $receiver.text_4w9ihe$(substring(closure$time, new IntRange(4, 4)));
      return Unit;
    };
  }
  function viewDigitalClock$lambda$lambda$lambda$lambda_5($receiver) {
    $receiver.text_4w9ihe$(':');
    return Unit;
  }
  function viewDigitalClock$lambda$lambda$lambda$lambda_6(closure$time) {
    return function ($receiver) {
      $receiver.text_4w9ihe$(substring(closure$time, new IntRange(6, 6)));
      return Unit;
    };
  }
  function viewDigitalClock$lambda$lambda$lambda$lambda_7(closure$time) {
    return function ($receiver) {
      $receiver.text_4w9ihe$(substring(closure$time, new IntRange(7, 7)));
      return Unit;
    };
  }
  function viewDigitalClock$lambda$lambda$lambda_0(closure$time) {
    return function ($receiver) {
      style($receiver, viewDigitalClock$lambda$lambda$lambda$lambda);
      $receiver.div_6zr3om$('#h1.clock.digit', void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, viewDigitalClock$lambda$lambda$lambda$lambda_0(closure$time));
      $receiver.div_6zr3om$('#h2.clock.digit', void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, viewDigitalClock$lambda$lambda$lambda$lambda_1(closure$time));
      $receiver.div_6zr3om$('#m0.clock.separator', void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, viewDigitalClock$lambda$lambda$lambda$lambda_2);
      $receiver.div_6zr3om$('#m1.clock.digit', void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, viewDigitalClock$lambda$lambda$lambda$lambda_3(closure$time));
      $receiver.div_6zr3om$('#m2.clock.digit', void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, viewDigitalClock$lambda$lambda$lambda$lambda_4(closure$time));
      $receiver.div_6zr3om$('#s0.clock.separator', void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, viewDigitalClock$lambda$lambda$lambda$lambda_5);
      $receiver.div_6zr3om$('#s1.clock.digit', void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, viewDigitalClock$lambda$lambda$lambda$lambda_6(closure$time));
      $receiver.div_6zr3om$('#s2.clock.digit', void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, viewDigitalClock$lambda$lambda$lambda$lambda_7(closure$time));
      return Unit;
    };
  }
  function viewDigitalClock$lambda$lambda(closure$applicationState) {
    return function ($receiver) {
      var timePieces = split(closure$applicationState.time.toTimeString(), [' '], void 0, 2);
      var time = timePieces.get_za3lpa$(0);
      var timeZone = timePieces.get_za3lpa$(1);
      $receiver.h1_qckjfy$(void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, viewDigitalClock$lambda$lambda$lambda(timeZone));
      $receiver.div_6zr3om$('#display', void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, viewDigitalClock$lambda$lambda$lambda_0(time));
      return Unit;
    };
  }
  function viewDigitalClock$lambda(closure$applicationState) {
    return function ($receiver) {
      $receiver.main_6zr3om$('#digital-clock-app', void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, viewDigitalClock$lambda$lambda(closure$applicationState));
      return Unit;
    };
  }
  function viewDigitalClock(applicationState) {
    return viewDigitalClock$lambda(applicationState);
  }
  function GreetMeAppState(myName) {
    this.myName = myName;
  }
  GreetMeAppState.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'GreetMeAppState',
    interfaces: []
  };
  GreetMeAppState.prototype.component1 = function () {
    return this.myName;
  };
  GreetMeAppState.prototype.copy_61zpoe$ = function (myName) {
    return new GreetMeAppState(myName === void 0 ? this.myName : myName);
  };
  GreetMeAppState.prototype.toString = function () {
    return 'GreetMeAppState(myName=' + Kotlin.toString(this.myName) + ')';
  };
  GreetMeAppState.prototype.hashCode = function () {
    var result = 0;
    result = result * 31 + Kotlin.hashCode(this.myName) | 0;
    return result;
  };
  GreetMeAppState.prototype.equals = function (other) {
    return this === other || (other !== null && (typeof other === 'object' && (Object.getPrototypeOf(this) === Object.getPrototypeOf(other) && Kotlin.equals(this.myName, other.myName))));
  };
  function GreetMeMsg(newName) {
    this.newName = newName;
  }
  GreetMeMsg.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'GreetMeMsg',
    interfaces: []
  };
  GreetMeMsg.prototype.component1 = function () {
    return this.newName;
  };
  GreetMeMsg.prototype.copy_61zpoe$ = function (newName) {
    return new GreetMeMsg(newName === void 0 ? this.newName : newName);
  };
  GreetMeMsg.prototype.toString = function () {
    return 'GreetMeMsg(newName=' + Kotlin.toString(this.newName) + ')';
  };
  GreetMeMsg.prototype.hashCode = function () {
    var result = 0;
    result = result * 31 + Kotlin.hashCode(this.newName) | 0;
    return result;
  };
  GreetMeMsg.prototype.equals = function (other) {
    return this === other || (other !== null && (typeof other === 'object' && (Object.getPrototypeOf(this) === Object.getPrototypeOf(other) && Kotlin.equals(this.newName, other.newName))));
  };
  function GreetMeApplication() {
  }
  GreetMeApplication.prototype.initialize = function () {
    return new KatydidApplicationCycle(new GreetMeAppState('Katydid User'));
  };
  GreetMeApplication.prototype.update_xwzc9p$ = function (applicationState, message) {
    return new KatydidApplicationCycle(new GreetMeAppState(message.newName));
  };
  function GreetMeApplication$view$lambda$lambda$lambda($receiver) {
    $receiver.text_4w9ihe$('Greet Me');
    return Unit;
  }
  function GreetMeApplication$view$lambda$lambda$lambda_0(closure$applicationState) {
    return function ($receiver) {
      $receiver.text_4w9ihe$('Greetings, ' + closure$applicationState.myName + ', from a Kotlin sample application.');
      return Unit;
    };
  }
  function GreetMeApplication$view$lambda$lambda$lambda_1($receiver) {
    return Unit;
  }
  function GreetMeApplication$view$lambda$lambda$lambda$lambda$lambda($receiver) {
    marginRight($receiver, get_em(1.5));
    return Unit;
  }
  function GreetMeApplication$view$lambda$lambda$lambda$lambda($receiver) {
    style($receiver, GreetMeApplication$view$lambda$lambda$lambda$lambda$lambda);
    $receiver.text_4w9ihe$('My Name Is:');
    return Unit;
  }
  function GreetMeApplication$view$lambda$lambda$lambda$lambda$lambda_0(event) {
    var newValue = event.getTargetAttribute_ytbaoo$('value');
    return listOf(new GreetMeMsg(newValue));
  }
  function GreetMeApplication$view$lambda$lambda$lambda$lambda_0($receiver) {
    oninput($receiver, GreetMeApplication$view$lambda$lambda$lambda$lambda$lambda_0);
    return Unit;
  }
  function GreetMeApplication$view$lambda$lambda$lambda_2(closure$applicationState) {
    return function ($receiver) {
      $receiver.label_va30u7$(void 0, void 0, void 0, void 0, void 0, void 0, 'name-box', void 0, void 0, void 0, void 0, void 0, void 0, void 0, GreetMeApplication$view$lambda$lambda$lambda$lambda);
      $receiver.inputText_y74p72$(void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, closure$applicationState.myName, GreetMeApplication$view$lambda$lambda$lambda$lambda_0);
      return Unit;
    };
  }
  function GreetMeApplication$view$lambda$lambda(closure$applicationState) {
    return function ($receiver) {
      $receiver.h1_qckjfy$(void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, GreetMeApplication$view$lambda$lambda$lambda);
      $receiver.span_qckjfy$(void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, GreetMeApplication$view$lambda$lambda$lambda_0(closure$applicationState));
      $receiver.br_9mj9vz$(void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, GreetMeApplication$view$lambda$lambda$lambda_1);
      $receiver.form_roosm5$(void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, 'margin-top:1.5em;', void 0, void 0, void 0, void 0, GreetMeApplication$view$lambda$lambda$lambda_2(closure$applicationState));
      return Unit;
    };
  }
  function GreetMeApplication$view$lambda(closure$applicationState) {
    return function ($receiver) {
      $receiver.div_6zr3om$('#greet-me-app', void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, GreetMeApplication$view$lambda$lambda(closure$applicationState));
      return Unit;
    };
  }
  GreetMeApplication.prototype.view_11rb$ = function (applicationState) {
    return GreetMeApplication$view$lambda(applicationState);
  };
  GreetMeApplication.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'GreetMeApplication',
    interfaces: [KatydidApplication]
  };
  function greetMeMain(args) {
    runApplication('app', new GreetMeApplication());
  }
  function helloWorldView$lambda$lambda$lambda($receiver) {
    $receiver.text_4w9ihe$('Hello World');
    return Unit;
  }
  function helloWorldView$lambda$lambda$lambda_0($receiver) {
    $receiver.text_4w9ihe$('Greetings from a Kotlin sample application.');
    return Unit;
  }
  function helloWorldView$lambda$lambda($receiver) {
    $receiver.h1_qckjfy$('#heading', void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, 'color:blue', void 0, void 0, void 0, helloWorldView$lambda$lambda$lambda);
    $receiver.span_qckjfy$('#greeting.span-greeting', void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, helloWorldView$lambda$lambda$lambda_0);
    return Unit;
  }
  function helloWorldView$lambda($receiver) {
    $receiver.div_6zr3om$('#hello-world-app', void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, helloWorldView$lambda$lambda);
    return Unit;
  }
  var helloWorldView;
  function helloWorldMain(args) {
    var lifecycle = makeKatydidLifecycle();
    var appElement = document.getElementById('app');
    if (appElement != null) {
      lifecycle.build_f7u8rf$(appElement, helloWorldView);
    }
     else {
      console.log('ERROR: Application element div#app not found.');
    }
    console.log('DONE');
  }
  function SudokuSolverApplication() {
  }
  SudokuSolverApplication.prototype.initialize = function () {
    return new KatydidApplicationCycle(new SudokuSolverAppState());
  };
  SudokuSolverApplication.prototype.update_xwzc9p$ = function (applicationState, message) {
    return updateSudokuSolver(applicationState, message);
  };
  SudokuSolverApplication.prototype.view_11rb$ = function (applicationState) {
    return viewSudokuSolver(applicationState);
  };
  SudokuSolverApplication.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'SudokuSolverApplication',
    interfaces: [KatydidApplication]
  };
  function sudokuSolverMain(args) {
    var css = makeSudokuStyleSheet();
    var cssElement = ensureNotNull(document.getElementById('appStyleElement'));
    buildStyleElement(cssElement, css);
    runApplication('app', new SudokuSolverApplication());
  }
  function makeSudokuStyleSheet$lambda$lambda($receiver) {
    fontFamily($receiver, ['Arial', 'Helvetica Neue', 'Helvetica', 'sans-serif']);
    return Unit;
  }
  function makeSudokuStyleSheet$lambda$lambda$lambda($receiver) {
    maxHeight($receiver, get_px(850));
    overflowY($receiver, EOverflow.scroll);
    return Unit;
  }
  function makeSudokuStyleSheet$lambda$lambda$lambda_0($receiver) {
    clear($receiver, EClear.both);
    marginTop($receiver, get_px(15));
    maxWidth($receiver, get_px(700));
    return Unit;
  }
  function makeSudokuStyleSheet$lambda$lambda$lambda_1($receiver) {
    borderStyle($receiver, ELineStyle.none);
    margin($receiver, get_px(3), get_px(3), get_px(3), get_px(3));
    return Unit;
  }
  function makeSudokuStyleSheet$lambda$lambda_0($receiver) {
    display($receiver, EDisplay.inlineBlock);
    float($receiver, EFloat.left);
    $receiver.invoke_k851pc$('&#changes', makeSudokuStyleSheet$lambda$lambda$lambda);
    $receiver.or_68i6bt$('&#settings', $receiver.invoke_k851pc$('&#notes', makeSudokuStyleSheet$lambda$lambda$lambda_0));
    $receiver.invoke_k851pc$('&#settings fieldset', makeSudokuStyleSheet$lambda$lambda$lambda_1);
    return Unit;
  }
  function makeSudokuStyleSheet$lambda$lambda$lambda_2($receiver) {
    border($receiver, get_px(3), ELineStyle.solid, colors.black);
    return Unit;
  }
  function makeSudokuStyleSheet$lambda$lambda$lambda$lambda$lambda($receiver) {
    color($receiver, colors.blue);
    return Unit;
  }
  function makeSudokuStyleSheet$lambda$lambda$lambda$lambda$lambda_0($receiver) {
    color($receiver, colors.green);
    return Unit;
  }
  function makeSudokuStyleSheet$lambda$lambda$lambda$lambda$lambda_1($receiver) {
    color($receiver, colors.purple);
    cursor($receiver, ECursor.pointer);
    textDecoration($receiver, ETextDecorationLine.underline);
    return Unit;
  }
  function makeSudokuStyleSheet$lambda$lambda$lambda$lambda$lambda_2($receiver) {
    backgroundColor($receiver, colors.pink);
    return Unit;
  }
  function makeSudokuStyleSheet$lambda$lambda$lambda$lambda($receiver) {
    border($receiver, get_px(1), ELineStyle.solid, colors.black);
    borderCollapse($receiver, EBorderCollapse.collapse);
    borderSpacing($receiver, get_px(0));
    fontSize($receiver, get_px(50));
    height($receiver, get_px(66));
    padding($receiver, get_px(3));
    textAlign($receiver, ETextAlign.center);
    width($receiver, get_px(66));
    $receiver.invoke_k851pc$('&.guessed', makeSudokuStyleSheet$lambda$lambda$lambda$lambda$lambda);
    $receiver.invoke_k851pc$('&.solved', makeSudokuStyleSheet$lambda$lambda$lambda$lambda$lambda_0);
    $receiver.or_68i6bt$('&.guessed:hover', $receiver.invoke_k851pc$('&.defined:hover', makeSudokuStyleSheet$lambda$lambda$lambda$lambda$lambda_1));
    $receiver.invoke_k851pc$('&.unfillable', makeSudokuStyleSheet$lambda$lambda$lambda$lambda$lambda_2);
    return Unit;
  }
  function makeSudokuStyleSheet$lambda$lambda$lambda_3($receiver) {
    border($receiver, get_px(2), ELineStyle.solid, colors.black);
    $receiver.invoke_k851pc$('td.cell', makeSudokuStyleSheet$lambda$lambda$lambda$lambda);
    return Unit;
  }
  function makeSudokuStyleSheet$lambda$lambda$lambda$lambda_0($receiver) {
    color($receiver, colors.blue);
    cursor($receiver, ECursor.pointer);
    textDecoration($receiver, ETextDecorationLine.underline);
    return Unit;
  }
  function makeSudokuStyleSheet$lambda$lambda$lambda_4($receiver) {
    fontSize($receiver, get_px(12));
    height($receiver, get_px(20));
    width($receiver, get_px(20));
    $receiver.invoke_k851pc$('&.candidate:hover', makeSudokuStyleSheet$lambda$lambda$lambda$lambda_0);
    return Unit;
  }
  function makeSudokuStyleSheet$lambda$lambda$lambda$lambda_1($receiver) {
    backgroundColor($receiver, ensureNotNull(Color.Companion.fromHex_61zpoe$('#f2f2f2')));
    return Unit;
  }
  function makeSudokuStyleSheet$lambda$lambda$lambda$lambda_2($receiver) {
    fontSize($receiver, get_px(15));
    textAlign($receiver, ETextAlign.left);
    verticalAlign($receiver, EAlignmentBaseline.top);
    width($receiver, get_px(450));
    return Unit;
  }
  function makeSudokuStyleSheet$lambda$lambda$lambda$lambda_3($receiver) {
    textAlign($receiver, ETextAlign.left);
    verticalAlign($receiver, EAlignmentBaseline.top);
    width($receiver, get_px(100));
    return Unit;
  }
  function makeSudokuStyleSheet$lambda$lambda$lambda$lambda_4($receiver) {
    textAlign($receiver, ETextAlign.left);
    verticalAlign($receiver, EAlignmentBaseline.top);
    width($receiver, get_px(200));
    return Unit;
  }
  function makeSudokuStyleSheet$lambda$lambda$lambda_5($receiver) {
    $receiver.invoke_k851pc$('tr:nth-child(even)', makeSudokuStyleSheet$lambda$lambda$lambda$lambda_1);
    $receiver.or_68i6bt$('th.candidates-removed', $receiver.invoke_k851pc$('td.candidates-removed', makeSudokuStyleSheet$lambda$lambda$lambda$lambda_2));
    $receiver.or_68i6bt$('th.cell-value-set', $receiver.invoke_k851pc$('td.cell-value-set', makeSudokuStyleSheet$lambda$lambda$lambda$lambda_3));
    $receiver.or_68i6bt$('th.change-description', $receiver.invoke_k851pc$('td.change-description', makeSudokuStyleSheet$lambda$lambda$lambda$lambda_4));
    return Unit;
  }
  function makeSudokuStyleSheet$lambda$lambda_1($receiver) {
    borderCollapse($receiver, EBorderCollapse.collapse);
    borderSpacing($receiver, get_px(0));
    padding($receiver, get_px(0));
    $receiver.invoke_k851pc$('&.board', makeSudokuStyleSheet$lambda$lambda$lambda_2);
    $receiver.invoke_k851pc$('&.block', makeSudokuStyleSheet$lambda$lambda$lambda_3);
    $receiver.invoke_k851pc$('&.candidates td', makeSudokuStyleSheet$lambda$lambda$lambda_4);
    $receiver.invoke_k851pc$('&.changes', makeSudokuStyleSheet$lambda$lambda$lambda_5);
    return Unit;
  }
  function makeSudokuStyleSheet$lambda($receiver) {
    $receiver.invoke_k851pc$('body', makeSudokuStyleSheet$lambda$lambda);
    $receiver.invoke_k851pc$('section', makeSudokuStyleSheet$lambda$lambda_0);
    $receiver.invoke_k851pc$('table', makeSudokuStyleSheet$lambda$lambda_1);
    return Unit;
  }
  function makeSudokuStyleSheet() {
    return makeStyleSheet(makeSudokuStyleSheet$lambda);
  }
  function BoardChange(description, cellValueSet, candidatesRemoved) {
    this.description = description;
    this.cellValueSet = cellValueSet;
    this.candidatesRemoved = candidatesRemoved;
  }
  BoardChange.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'BoardChange',
    interfaces: []
  };
  BoardChange.prototype.component1 = function () {
    return this.description;
  };
  BoardChange.prototype.component2 = function () {
    return this.cellValueSet;
  };
  BoardChange.prototype.component3 = function () {
    return this.candidatesRemoved;
  };
  BoardChange.prototype.copy_bg8n2v$ = function (description, cellValueSet, candidatesRemoved) {
    return new BoardChange(description === void 0 ? this.description : description, cellValueSet === void 0 ? this.cellValueSet : cellValueSet, candidatesRemoved === void 0 ? this.candidatesRemoved : candidatesRemoved);
  };
  BoardChange.prototype.toString = function () {
    return 'BoardChange(description=' + Kotlin.toString(this.description) + (', cellValueSet=' + Kotlin.toString(this.cellValueSet)) + (', candidatesRemoved=' + Kotlin.toString(this.candidatesRemoved)) + ')';
  };
  BoardChange.prototype.hashCode = function () {
    var result = 0;
    result = result * 31 + Kotlin.hashCode(this.description) | 0;
    result = result * 31 + Kotlin.hashCode(this.cellValueSet) | 0;
    result = result * 31 + Kotlin.hashCode(this.candidatesRemoved) | 0;
    return result;
  };
  BoardChange.prototype.equals = function (other) {
    return this === other || (other !== null && (typeof other === 'object' && (Object.getPrototypeOf(this) === Object.getPrototypeOf(other) && (Kotlin.equals(this.description, other.description) && Kotlin.equals(this.cellValueSet, other.cellValueSet) && Kotlin.equals(this.candidatesRemoved, other.candidatesRemoved)))));
  };
  function Cell() {
    this.block_fk79m1$_0 = this.block_fk79m1$_0;
    this.candidates = mutableSetOf([0, 1, 2, 3, 4, 5, 6, 7, 8]);
    this.column_18o8aw$_0 = this.column_18o8aw$_0;
    this.diagonal0 = null;
    this.diagonal1 = null;
    this.row_bq7nes$_0 = this.row_bq7nes$_0;
    this.state = Cell$State$UNSET_getInstance();
    this.value = null;
  }
  function Cell$State(name, ordinal) {
    Enum.call(this);
    this.name$ = name;
    this.ordinal$ = ordinal;
  }
  function Cell$State_initFields() {
    Cell$State_initFields = function () {
    };
    Cell$State$UNSET_instance = new Cell$State('UNSET', 0);
    Cell$State$DEFINED_instance = new Cell$State('DEFINED', 1);
    Cell$State$GUESSED_instance = new Cell$State('GUESSED', 2);
    Cell$State$SOLVED_instance = new Cell$State('SOLVED', 3);
  }
  var Cell$State$UNSET_instance;
  function Cell$State$UNSET_getInstance() {
    Cell$State_initFields();
    return Cell$State$UNSET_instance;
  }
  var Cell$State$DEFINED_instance;
  function Cell$State$DEFINED_getInstance() {
    Cell$State_initFields();
    return Cell$State$DEFINED_instance;
  }
  var Cell$State$GUESSED_instance;
  function Cell$State$GUESSED_getInstance() {
    Cell$State_initFields();
    return Cell$State$GUESSED_instance;
  }
  var Cell$State$SOLVED_instance;
  function Cell$State$SOLVED_getInstance() {
    Cell$State_initFields();
    return Cell$State$SOLVED_instance;
  }
  Cell$State.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'State',
    interfaces: [Enum]
  };
  function Cell$State$values() {
    return [Cell$State$UNSET_getInstance(), Cell$State$DEFINED_getInstance(), Cell$State$GUESSED_getInstance(), Cell$State$SOLVED_getInstance()];
  }
  Cell$State.values = Cell$State$values;
  function Cell$State$valueOf(name) {
    switch (name) {
      case 'UNSET':
        return Cell$State$UNSET_getInstance();
      case 'DEFINED':
        return Cell$State$DEFINED_getInstance();
      case 'GUESSED':
        return Cell$State$GUESSED_getInstance();
      case 'SOLVED':
        return Cell$State$SOLVED_getInstance();
      default:throwISE('No enum constant js.katydid.samples.sudokusolver.Cell.State.' + name);
    }
  }
  Cell$State.valueOf_61zpoe$ = Cell$State$valueOf;
  Object.defineProperty(Cell.prototype, 'block', {
    get: function () {
      if (this.block_fk79m1$_0 == null)
        return throwUPAE('block');
      return this.block_fk79m1$_0;
    },
    set: function (block) {
      this.block_fk79m1$_0 = block;
    }
  });
  Object.defineProperty(Cell.prototype, 'column', {
    get: function () {
      if (this.column_18o8aw$_0 == null)
        return throwUPAE('column');
      return this.column_18o8aw$_0;
    },
    set: function (column) {
      this.column_18o8aw$_0 = column;
    }
  });
  Object.defineProperty(Cell.prototype, 'row', {
    get: function () {
      if (this.row_bq7nes$_0 == null)
        return throwUPAE('row');
      return this.row_bq7nes$_0;
    },
    set: function (row) {
      this.row_bq7nes$_0 = row;
    }
  });
  Object.defineProperty(Cell.prototype, 'name', {
    get: function () {
      var v = this.value;
      return v != null ? this.row.name + this.column.name + '#' + (v + 1 | 0) : this.row.name + this.column.name;
    }
  });
  Cell.prototype.removeCandidate_za3lpa$ = function (candidate) {
    var tmp$, tmp$_0;
    if (this.candidates.remove_11rb$(candidate)) {
      this.row.removeCellCandidate_k3imf0$(this, candidate);
      this.column.removeCellCandidate_k3imf0$(this, candidate);
      this.block.removeCellCandidate_k3imf0$(this, candidate);
      (tmp$ = this.diagonal0) != null ? (tmp$.removeCellCandidate_k3imf0$(this, candidate), Unit) : null;
      (tmp$_0 = this.diagonal1) != null ? (tmp$_0.removeCellCandidate_k3imf0$(this, candidate), Unit) : null;
      return true;
    }
    return false;
  };
  Cell.prototype.setValue_ajq5b3$ = function (newValue, newState) {
    var tmp$, tmp$_0, tmp$_1, tmp$_2, tmp$_3, tmp$_4, tmp$_5, tmp$_6, tmp$_7, tmp$_8;
    tmp$ = this.candidates.iterator();
    while (tmp$.hasNext()) {
      var c = tmp$.next();
      this.removeCandidate_za3lpa$(c);
    }
    this.value = newValue;
    this.state = newState;
    var result = ArrayList_init_0();
    tmp$_0 = this.row.cells.iterator();
    while (tmp$_0.hasNext()) {
      var cell = tmp$_0.next();
      if (cell.removeCandidate_za3lpa$(newValue)) {
        result.add_11rb$(cell.name + '#' + (newValue + 1 | 0));
      }
    }
    tmp$_1 = this.column.cells.iterator();
    while (tmp$_1.hasNext()) {
      var cell_0 = tmp$_1.next();
      if (cell_0.removeCandidate_za3lpa$(newValue)) {
        result.add_11rb$(cell_0.name + '#' + (newValue + 1 | 0));
      }
    }
    tmp$_2 = this.block.cells.iterator();
    while (tmp$_2.hasNext()) {
      var cell_1 = tmp$_2.next();
      if (cell_1.removeCandidate_za3lpa$(newValue)) {
        result.add_11rb$(cell_1.name + '#' + (newValue + 1 | 0));
      }
    }
    tmp$_5 = ((tmp$_4 = (tmp$_3 = this.diagonal0) != null ? tmp$_3.cells : null) != null ? tmp$_4 : emptyList()).iterator();
    while (tmp$_5.hasNext()) {
      var cell_2 = tmp$_5.next();
      if (cell_2.removeCandidate_za3lpa$(newValue)) {
        result.add_11rb$(cell_2.name + '#' + (newValue + 1 | 0));
      }
    }
    tmp$_8 = ((tmp$_7 = (tmp$_6 = this.diagonal1) != null ? tmp$_6.cells : null) != null ? tmp$_7 : emptyList()).iterator();
    while (tmp$_8.hasNext()) {
      var cell_3 = tmp$_8.next();
      if (cell_3.removeCandidate_za3lpa$(newValue)) {
        result.add_11rb$(cell_3.name + '#' + (newValue + 1 | 0));
      }
    }
    return result;
  };
  Cell.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'Cell',
    interfaces: []
  };
  function CellGroup(type, index, cells) {
    this.type = type;
    this.index = index;
    this.cells = cells;
    this.cellsWithCandidate = null;
    this.cellsWithCandidate = listOf_0([ArrayList_init(this.cells), ArrayList_init(this.cells), ArrayList_init(this.cells), ArrayList_init(this.cells), ArrayList_init(this.cells), ArrayList_init(this.cells), ArrayList_init(this.cells), ArrayList_init(this.cells), ArrayList_init(this.cells)]);
  }
  function CellGroup$Type(name, ordinal) {
    Enum.call(this);
    this.name$ = name;
    this.ordinal$ = ordinal;
  }
  function CellGroup$Type_initFields() {
    CellGroup$Type_initFields = function () {
    };
    CellGroup$Type$ROW_instance = new CellGroup$Type('ROW', 0);
    CellGroup$Type$COLUMN_instance = new CellGroup$Type('COLUMN', 1);
    CellGroup$Type$BLOCK_instance = new CellGroup$Type('BLOCK', 2);
    CellGroup$Type$DIAGNONAL_instance = new CellGroup$Type('DIAGNONAL', 3);
  }
  var CellGroup$Type$ROW_instance;
  function CellGroup$Type$ROW_getInstance() {
    CellGroup$Type_initFields();
    return CellGroup$Type$ROW_instance;
  }
  var CellGroup$Type$COLUMN_instance;
  function CellGroup$Type$COLUMN_getInstance() {
    CellGroup$Type_initFields();
    return CellGroup$Type$COLUMN_instance;
  }
  var CellGroup$Type$BLOCK_instance;
  function CellGroup$Type$BLOCK_getInstance() {
    CellGroup$Type_initFields();
    return CellGroup$Type$BLOCK_instance;
  }
  var CellGroup$Type$DIAGNONAL_instance;
  function CellGroup$Type$DIAGNONAL_getInstance() {
    CellGroup$Type_initFields();
    return CellGroup$Type$DIAGNONAL_instance;
  }
  Object.defineProperty(CellGroup$Type.prototype, 'abbreviation', {
    get: function () {
      switch (this.name) {
        case 'ROW':
          return 'R';
        case 'COLUMN':
          return 'C';
        case 'BLOCK':
          return 'Block';
        case 'DIAGNONAL':
          return 'Diag';
        default:return Kotlin.noWhenBranchMatched();
      }
    }
  });
  CellGroup$Type.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'Type',
    interfaces: [Enum]
  };
  function CellGroup$Type$values() {
    return [CellGroup$Type$ROW_getInstance(), CellGroup$Type$COLUMN_getInstance(), CellGroup$Type$BLOCK_getInstance(), CellGroup$Type$DIAGNONAL_getInstance()];
  }
  CellGroup$Type.values = CellGroup$Type$values;
  function CellGroup$Type$valueOf(name) {
    switch (name) {
      case 'ROW':
        return CellGroup$Type$ROW_getInstance();
      case 'COLUMN':
        return CellGroup$Type$COLUMN_getInstance();
      case 'BLOCK':
        return CellGroup$Type$BLOCK_getInstance();
      case 'DIAGNONAL':
        return CellGroup$Type$DIAGNONAL_getInstance();
      default:throwISE('No enum constant js.katydid.samples.sudokusolver.CellGroup.Type.' + name);
    }
  }
  CellGroup$Type.valueOf_61zpoe$ = CellGroup$Type$valueOf;
  Object.defineProperty(CellGroup.prototype, 'name', {
    get: function () {
      return this.type.abbreviation + (this.index + 1 | 0);
    }
  });
  CellGroup.prototype.removeCellCandidate_k3imf0$ = function (cell, candidate) {
    this.cellsWithCandidate.get_za3lpa$(candidate).remove_11rb$(cell);
  };
  CellGroup.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'CellGroup',
    interfaces: []
  };
  function Board(isXSudoku) {
    this.isXSudoku = isXSudoku;
    this.c_0 = listOf_0([listOf_0([new Cell(), new Cell(), new Cell(), new Cell(), new Cell(), new Cell(), new Cell(), new Cell(), new Cell()]), listOf_0([new Cell(), new Cell(), new Cell(), new Cell(), new Cell(), new Cell(), new Cell(), new Cell(), new Cell()]), listOf_0([new Cell(), new Cell(), new Cell(), new Cell(), new Cell(), new Cell(), new Cell(), new Cell(), new Cell()]), listOf_0([new Cell(), new Cell(), new Cell(), new Cell(), new Cell(), new Cell(), new Cell(), new Cell(), new Cell()]), listOf_0([new Cell(), new Cell(), new Cell(), new Cell(), new Cell(), new Cell(), new Cell(), new Cell(), new Cell()]), listOf_0([new Cell(), new Cell(), new Cell(), new Cell(), new Cell(), new Cell(), new Cell(), new Cell(), new Cell()]), listOf_0([new Cell(), new Cell(), new Cell(), new Cell(), new Cell(), new Cell(), new Cell(), new Cell(), new Cell()]), listOf_0([new Cell(), new Cell(), new Cell(), new Cell(), new Cell(), new Cell(), new Cell(), new Cell(), new Cell()]), listOf_0([new Cell(), new Cell(), new Cell(), new Cell(), new Cell(), new Cell(), new Cell(), new Cell(), new Cell()])]);
    this.rows = listOf_0([new CellGroup(CellGroup$Type$ROW_getInstance(), 0, listOf_0([this.c_0.get_za3lpa$(0).get_za3lpa$(0), this.c_0.get_za3lpa$(0).get_za3lpa$(1), this.c_0.get_za3lpa$(0).get_za3lpa$(2), this.c_0.get_za3lpa$(0).get_za3lpa$(3), this.c_0.get_za3lpa$(0).get_za3lpa$(4), this.c_0.get_za3lpa$(0).get_za3lpa$(5), this.c_0.get_za3lpa$(0).get_za3lpa$(6), this.c_0.get_za3lpa$(0).get_za3lpa$(7), this.c_0.get_za3lpa$(0).get_za3lpa$(8)])), new CellGroup(CellGroup$Type$ROW_getInstance(), 1, listOf_0([this.c_0.get_za3lpa$(1).get_za3lpa$(0), this.c_0.get_za3lpa$(1).get_za3lpa$(1), this.c_0.get_za3lpa$(1).get_za3lpa$(2), this.c_0.get_za3lpa$(1).get_za3lpa$(3), this.c_0.get_za3lpa$(1).get_za3lpa$(4), this.c_0.get_za3lpa$(1).get_za3lpa$(5), this.c_0.get_za3lpa$(1).get_za3lpa$(6), this.c_0.get_za3lpa$(1).get_za3lpa$(7), this.c_0.get_za3lpa$(1).get_za3lpa$(8)])), new CellGroup(CellGroup$Type$ROW_getInstance(), 2, listOf_0([this.c_0.get_za3lpa$(2).get_za3lpa$(0), this.c_0.get_za3lpa$(2).get_za3lpa$(1), this.c_0.get_za3lpa$(2).get_za3lpa$(2), this.c_0.get_za3lpa$(2).get_za3lpa$(3), this.c_0.get_za3lpa$(2).get_za3lpa$(4), this.c_0.get_za3lpa$(2).get_za3lpa$(5), this.c_0.get_za3lpa$(2).get_za3lpa$(6), this.c_0.get_za3lpa$(2).get_za3lpa$(7), this.c_0.get_za3lpa$(2).get_za3lpa$(8)])), new CellGroup(CellGroup$Type$ROW_getInstance(), 3, listOf_0([this.c_0.get_za3lpa$(3).get_za3lpa$(0), this.c_0.get_za3lpa$(3).get_za3lpa$(1), this.c_0.get_za3lpa$(3).get_za3lpa$(2), this.c_0.get_za3lpa$(3).get_za3lpa$(3), this.c_0.get_za3lpa$(3).get_za3lpa$(4), this.c_0.get_za3lpa$(3).get_za3lpa$(5), this.c_0.get_za3lpa$(3).get_za3lpa$(6), this.c_0.get_za3lpa$(3).get_za3lpa$(7), this.c_0.get_za3lpa$(3).get_za3lpa$(8)])), new CellGroup(CellGroup$Type$ROW_getInstance(), 4, listOf_0([this.c_0.get_za3lpa$(4).get_za3lpa$(0), this.c_0.get_za3lpa$(4).get_za3lpa$(1), this.c_0.get_za3lpa$(4).get_za3lpa$(2), this.c_0.get_za3lpa$(4).get_za3lpa$(3), this.c_0.get_za3lpa$(4).get_za3lpa$(4), this.c_0.get_za3lpa$(4).get_za3lpa$(5), this.c_0.get_za3lpa$(4).get_za3lpa$(6), this.c_0.get_za3lpa$(4).get_za3lpa$(7), this.c_0.get_za3lpa$(4).get_za3lpa$(8)])), new CellGroup(CellGroup$Type$ROW_getInstance(), 5, listOf_0([this.c_0.get_za3lpa$(5).get_za3lpa$(0), this.c_0.get_za3lpa$(5).get_za3lpa$(1), this.c_0.get_za3lpa$(5).get_za3lpa$(2), this.c_0.get_za3lpa$(5).get_za3lpa$(3), this.c_0.get_za3lpa$(5).get_za3lpa$(4), this.c_0.get_za3lpa$(5).get_za3lpa$(5), this.c_0.get_za3lpa$(5).get_za3lpa$(6), this.c_0.get_za3lpa$(5).get_za3lpa$(7), this.c_0.get_za3lpa$(5).get_za3lpa$(8)])), new CellGroup(CellGroup$Type$ROW_getInstance(), 6, listOf_0([this.c_0.get_za3lpa$(6).get_za3lpa$(0), this.c_0.get_za3lpa$(6).get_za3lpa$(1), this.c_0.get_za3lpa$(6).get_za3lpa$(2), this.c_0.get_za3lpa$(6).get_za3lpa$(3), this.c_0.get_za3lpa$(6).get_za3lpa$(4), this.c_0.get_za3lpa$(6).get_za3lpa$(5), this.c_0.get_za3lpa$(6).get_za3lpa$(6), this.c_0.get_za3lpa$(6).get_za3lpa$(7), this.c_0.get_za3lpa$(6).get_za3lpa$(8)])), new CellGroup(CellGroup$Type$ROW_getInstance(), 7, listOf_0([this.c_0.get_za3lpa$(7).get_za3lpa$(0), this.c_0.get_za3lpa$(7).get_za3lpa$(1), this.c_0.get_za3lpa$(7).get_za3lpa$(2), this.c_0.get_za3lpa$(7).get_za3lpa$(3), this.c_0.get_za3lpa$(7).get_za3lpa$(4), this.c_0.get_za3lpa$(7).get_za3lpa$(5), this.c_0.get_za3lpa$(7).get_za3lpa$(6), this.c_0.get_za3lpa$(7).get_za3lpa$(7), this.c_0.get_za3lpa$(7).get_za3lpa$(8)])), new CellGroup(CellGroup$Type$ROW_getInstance(), 8, listOf_0([this.c_0.get_za3lpa$(8).get_za3lpa$(0), this.c_0.get_za3lpa$(8).get_za3lpa$(1), this.c_0.get_za3lpa$(8).get_za3lpa$(2), this.c_0.get_za3lpa$(8).get_za3lpa$(3), this.c_0.get_za3lpa$(8).get_za3lpa$(4), this.c_0.get_za3lpa$(8).get_za3lpa$(5), this.c_0.get_za3lpa$(8).get_za3lpa$(6), this.c_0.get_za3lpa$(8).get_za3lpa$(7), this.c_0.get_za3lpa$(8).get_za3lpa$(8)]))]);
    this.columns = listOf_0([new CellGroup(CellGroup$Type$COLUMN_getInstance(), 0, listOf_0([this.c_0.get_za3lpa$(0).get_za3lpa$(0), this.c_0.get_za3lpa$(1).get_za3lpa$(0), this.c_0.get_za3lpa$(2).get_za3lpa$(0), this.c_0.get_za3lpa$(3).get_za3lpa$(0), this.c_0.get_za3lpa$(4).get_za3lpa$(0), this.c_0.get_za3lpa$(5).get_za3lpa$(0), this.c_0.get_za3lpa$(6).get_za3lpa$(0), this.c_0.get_za3lpa$(7).get_za3lpa$(0), this.c_0.get_za3lpa$(8).get_za3lpa$(0)])), new CellGroup(CellGroup$Type$COLUMN_getInstance(), 1, listOf_0([this.c_0.get_za3lpa$(0).get_za3lpa$(1), this.c_0.get_za3lpa$(1).get_za3lpa$(1), this.c_0.get_za3lpa$(2).get_za3lpa$(1), this.c_0.get_za3lpa$(3).get_za3lpa$(1), this.c_0.get_za3lpa$(4).get_za3lpa$(1), this.c_0.get_za3lpa$(5).get_za3lpa$(1), this.c_0.get_za3lpa$(6).get_za3lpa$(1), this.c_0.get_za3lpa$(7).get_za3lpa$(1), this.c_0.get_za3lpa$(8).get_za3lpa$(1)])), new CellGroup(CellGroup$Type$COLUMN_getInstance(), 2, listOf_0([this.c_0.get_za3lpa$(0).get_za3lpa$(2), this.c_0.get_za3lpa$(1).get_za3lpa$(2), this.c_0.get_za3lpa$(2).get_za3lpa$(2), this.c_0.get_za3lpa$(3).get_za3lpa$(2), this.c_0.get_za3lpa$(4).get_za3lpa$(2), this.c_0.get_za3lpa$(5).get_za3lpa$(2), this.c_0.get_za3lpa$(6).get_za3lpa$(2), this.c_0.get_za3lpa$(7).get_za3lpa$(2), this.c_0.get_za3lpa$(8).get_za3lpa$(2)])), new CellGroup(CellGroup$Type$COLUMN_getInstance(), 3, listOf_0([this.c_0.get_za3lpa$(0).get_za3lpa$(3), this.c_0.get_za3lpa$(1).get_za3lpa$(3), this.c_0.get_za3lpa$(2).get_za3lpa$(3), this.c_0.get_za3lpa$(3).get_za3lpa$(3), this.c_0.get_za3lpa$(4).get_za3lpa$(3), this.c_0.get_za3lpa$(5).get_za3lpa$(3), this.c_0.get_za3lpa$(6).get_za3lpa$(3), this.c_0.get_za3lpa$(7).get_za3lpa$(3), this.c_0.get_za3lpa$(8).get_za3lpa$(3)])), new CellGroup(CellGroup$Type$COLUMN_getInstance(), 4, listOf_0([this.c_0.get_za3lpa$(0).get_za3lpa$(4), this.c_0.get_za3lpa$(1).get_za3lpa$(4), this.c_0.get_za3lpa$(2).get_za3lpa$(4), this.c_0.get_za3lpa$(3).get_za3lpa$(4), this.c_0.get_za3lpa$(4).get_za3lpa$(4), this.c_0.get_za3lpa$(5).get_za3lpa$(4), this.c_0.get_za3lpa$(6).get_za3lpa$(4), this.c_0.get_za3lpa$(7).get_za3lpa$(4), this.c_0.get_za3lpa$(8).get_za3lpa$(4)])), new CellGroup(CellGroup$Type$COLUMN_getInstance(), 5, listOf_0([this.c_0.get_za3lpa$(0).get_za3lpa$(5), this.c_0.get_za3lpa$(1).get_za3lpa$(5), this.c_0.get_za3lpa$(2).get_za3lpa$(5), this.c_0.get_za3lpa$(3).get_za3lpa$(5), this.c_0.get_za3lpa$(4).get_za3lpa$(5), this.c_0.get_za3lpa$(5).get_za3lpa$(5), this.c_0.get_za3lpa$(6).get_za3lpa$(5), this.c_0.get_za3lpa$(7).get_za3lpa$(5), this.c_0.get_za3lpa$(8).get_za3lpa$(5)])), new CellGroup(CellGroup$Type$COLUMN_getInstance(), 6, listOf_0([this.c_0.get_za3lpa$(0).get_za3lpa$(6), this.c_0.get_za3lpa$(1).get_za3lpa$(6), this.c_0.get_za3lpa$(2).get_za3lpa$(6), this.c_0.get_za3lpa$(3).get_za3lpa$(6), this.c_0.get_za3lpa$(4).get_za3lpa$(6), this.c_0.get_za3lpa$(5).get_za3lpa$(6), this.c_0.get_za3lpa$(6).get_za3lpa$(6), this.c_0.get_za3lpa$(7).get_za3lpa$(6), this.c_0.get_za3lpa$(8).get_za3lpa$(6)])), new CellGroup(CellGroup$Type$COLUMN_getInstance(), 7, listOf_0([this.c_0.get_za3lpa$(0).get_za3lpa$(7), this.c_0.get_za3lpa$(1).get_za3lpa$(7), this.c_0.get_za3lpa$(2).get_za3lpa$(7), this.c_0.get_za3lpa$(3).get_za3lpa$(7), this.c_0.get_za3lpa$(4).get_za3lpa$(7), this.c_0.get_za3lpa$(5).get_za3lpa$(7), this.c_0.get_za3lpa$(6).get_za3lpa$(7), this.c_0.get_za3lpa$(7).get_za3lpa$(7), this.c_0.get_za3lpa$(8).get_za3lpa$(7)])), new CellGroup(CellGroup$Type$COLUMN_getInstance(), 8, listOf_0([this.c_0.get_za3lpa$(0).get_za3lpa$(8), this.c_0.get_za3lpa$(1).get_za3lpa$(8), this.c_0.get_za3lpa$(2).get_za3lpa$(8), this.c_0.get_za3lpa$(3).get_za3lpa$(8), this.c_0.get_za3lpa$(4).get_za3lpa$(8), this.c_0.get_za3lpa$(5).get_za3lpa$(8), this.c_0.get_za3lpa$(6).get_za3lpa$(8), this.c_0.get_za3lpa$(7).get_za3lpa$(8), this.c_0.get_za3lpa$(8).get_za3lpa$(8)]))]);
    this.blocks = listOf_0([new CellGroup(CellGroup$Type$BLOCK_getInstance(), 0, listOf_0([this.c_0.get_za3lpa$(0).get_za3lpa$(0), this.c_0.get_za3lpa$(0).get_za3lpa$(1), this.c_0.get_za3lpa$(0).get_za3lpa$(2), this.c_0.get_za3lpa$(1).get_za3lpa$(0), this.c_0.get_za3lpa$(1).get_za3lpa$(1), this.c_0.get_za3lpa$(1).get_za3lpa$(2), this.c_0.get_za3lpa$(2).get_za3lpa$(0), this.c_0.get_za3lpa$(2).get_za3lpa$(1), this.c_0.get_za3lpa$(2).get_za3lpa$(2)])), new CellGroup(CellGroup$Type$BLOCK_getInstance(), 1, listOf_0([this.c_0.get_za3lpa$(0).get_za3lpa$(3), this.c_0.get_za3lpa$(0).get_za3lpa$(4), this.c_0.get_za3lpa$(0).get_za3lpa$(5), this.c_0.get_za3lpa$(1).get_za3lpa$(3), this.c_0.get_za3lpa$(1).get_za3lpa$(4), this.c_0.get_za3lpa$(1).get_za3lpa$(5), this.c_0.get_za3lpa$(2).get_za3lpa$(3), this.c_0.get_za3lpa$(2).get_za3lpa$(4), this.c_0.get_za3lpa$(2).get_za3lpa$(5)])), new CellGroup(CellGroup$Type$BLOCK_getInstance(), 2, listOf_0([this.c_0.get_za3lpa$(0).get_za3lpa$(6), this.c_0.get_za3lpa$(0).get_za3lpa$(7), this.c_0.get_za3lpa$(0).get_za3lpa$(8), this.c_0.get_za3lpa$(1).get_za3lpa$(6), this.c_0.get_za3lpa$(1).get_za3lpa$(7), this.c_0.get_za3lpa$(1).get_za3lpa$(8), this.c_0.get_za3lpa$(2).get_za3lpa$(6), this.c_0.get_za3lpa$(2).get_za3lpa$(7), this.c_0.get_za3lpa$(2).get_za3lpa$(8)])), new CellGroup(CellGroup$Type$BLOCK_getInstance(), 3, listOf_0([this.c_0.get_za3lpa$(3).get_za3lpa$(0), this.c_0.get_za3lpa$(3).get_za3lpa$(1), this.c_0.get_za3lpa$(3).get_za3lpa$(2), this.c_0.get_za3lpa$(4).get_za3lpa$(0), this.c_0.get_za3lpa$(4).get_za3lpa$(1), this.c_0.get_za3lpa$(4).get_za3lpa$(2), this.c_0.get_za3lpa$(5).get_za3lpa$(0), this.c_0.get_za3lpa$(5).get_za3lpa$(1), this.c_0.get_za3lpa$(5).get_za3lpa$(2)])), new CellGroup(CellGroup$Type$BLOCK_getInstance(), 4, listOf_0([this.c_0.get_za3lpa$(3).get_za3lpa$(3), this.c_0.get_za3lpa$(3).get_za3lpa$(4), this.c_0.get_za3lpa$(3).get_za3lpa$(5), this.c_0.get_za3lpa$(4).get_za3lpa$(3), this.c_0.get_za3lpa$(4).get_za3lpa$(4), this.c_0.get_za3lpa$(4).get_za3lpa$(5), this.c_0.get_za3lpa$(5).get_za3lpa$(3), this.c_0.get_za3lpa$(5).get_za3lpa$(4), this.c_0.get_za3lpa$(5).get_za3lpa$(5)])), new CellGroup(CellGroup$Type$BLOCK_getInstance(), 5, listOf_0([this.c_0.get_za3lpa$(3).get_za3lpa$(6), this.c_0.get_za3lpa$(3).get_za3lpa$(7), this.c_0.get_za3lpa$(3).get_za3lpa$(8), this.c_0.get_za3lpa$(4).get_za3lpa$(6), this.c_0.get_za3lpa$(4).get_za3lpa$(7), this.c_0.get_za3lpa$(4).get_za3lpa$(8), this.c_0.get_za3lpa$(5).get_za3lpa$(6), this.c_0.get_za3lpa$(5).get_za3lpa$(7), this.c_0.get_za3lpa$(5).get_za3lpa$(8)])), new CellGroup(CellGroup$Type$BLOCK_getInstance(), 6, listOf_0([this.c_0.get_za3lpa$(6).get_za3lpa$(0), this.c_0.get_za3lpa$(6).get_za3lpa$(1), this.c_0.get_za3lpa$(6).get_za3lpa$(2), this.c_0.get_za3lpa$(7).get_za3lpa$(0), this.c_0.get_za3lpa$(7).get_za3lpa$(1), this.c_0.get_za3lpa$(7).get_za3lpa$(2), this.c_0.get_za3lpa$(8).get_za3lpa$(0), this.c_0.get_za3lpa$(8).get_za3lpa$(1), this.c_0.get_za3lpa$(8).get_za3lpa$(2)])), new CellGroup(CellGroup$Type$BLOCK_getInstance(), 7, listOf_0([this.c_0.get_za3lpa$(6).get_za3lpa$(3), this.c_0.get_za3lpa$(6).get_za3lpa$(4), this.c_0.get_za3lpa$(6).get_za3lpa$(5), this.c_0.get_za3lpa$(7).get_za3lpa$(3), this.c_0.get_za3lpa$(7).get_za3lpa$(4), this.c_0.get_za3lpa$(7).get_za3lpa$(5), this.c_0.get_za3lpa$(8).get_za3lpa$(3), this.c_0.get_za3lpa$(8).get_za3lpa$(4), this.c_0.get_za3lpa$(8).get_za3lpa$(5)])), new CellGroup(CellGroup$Type$BLOCK_getInstance(), 8, listOf_0([this.c_0.get_za3lpa$(6).get_za3lpa$(6), this.c_0.get_za3lpa$(6).get_za3lpa$(7), this.c_0.get_za3lpa$(6).get_za3lpa$(8), this.c_0.get_za3lpa$(7).get_za3lpa$(6), this.c_0.get_za3lpa$(7).get_za3lpa$(7), this.c_0.get_za3lpa$(7).get_za3lpa$(8), this.c_0.get_za3lpa$(8).get_za3lpa$(6), this.c_0.get_za3lpa$(8).get_za3lpa$(7), this.c_0.get_za3lpa$(8).get_za3lpa$(8)]))]);
    this.diagonals = this.isXSudoku ? listOf_0([new CellGroup(CellGroup$Type$DIAGNONAL_getInstance(), 0, listOf_0([this.c_0.get_za3lpa$(0).get_za3lpa$(0), this.c_0.get_za3lpa$(1).get_za3lpa$(1), this.c_0.get_za3lpa$(2).get_za3lpa$(2), this.c_0.get_za3lpa$(3).get_za3lpa$(3), this.c_0.get_za3lpa$(4).get_za3lpa$(4), this.c_0.get_za3lpa$(5).get_za3lpa$(5), this.c_0.get_za3lpa$(6).get_za3lpa$(6), this.c_0.get_za3lpa$(7).get_za3lpa$(7), this.c_0.get_za3lpa$(8).get_za3lpa$(8)])), new CellGroup(CellGroup$Type$DIAGNONAL_getInstance(), 1, listOf_0([this.c_0.get_za3lpa$(8).get_za3lpa$(0), this.c_0.get_za3lpa$(7).get_za3lpa$(1), this.c_0.get_za3lpa$(6).get_za3lpa$(2), this.c_0.get_za3lpa$(5).get_za3lpa$(3), this.c_0.get_za3lpa$(4).get_za3lpa$(4), this.c_0.get_za3lpa$(3).get_za3lpa$(5), this.c_0.get_za3lpa$(2).get_za3lpa$(6), this.c_0.get_za3lpa$(1).get_za3lpa$(7), this.c_0.get_za3lpa$(0).get_za3lpa$(8)]))]) : emptyList();
    this.units = this.isXSudoku ? listOf_0([this.rows.get_za3lpa$(0), this.rows.get_za3lpa$(1), this.rows.get_za3lpa$(2), this.rows.get_za3lpa$(3), this.rows.get_za3lpa$(4), this.rows.get_za3lpa$(5), this.rows.get_za3lpa$(6), this.rows.get_za3lpa$(7), this.rows.get_za3lpa$(8), this.columns.get_za3lpa$(0), this.columns.get_za3lpa$(1), this.columns.get_za3lpa$(2), this.columns.get_za3lpa$(3), this.columns.get_za3lpa$(4), this.columns.get_za3lpa$(5), this.columns.get_za3lpa$(6), this.columns.get_za3lpa$(7), this.columns.get_za3lpa$(8), this.blocks.get_za3lpa$(0), this.blocks.get_za3lpa$(1), this.blocks.get_za3lpa$(2), this.blocks.get_za3lpa$(3), this.blocks.get_za3lpa$(4), this.blocks.get_za3lpa$(5), this.blocks.get_za3lpa$(6), this.blocks.get_za3lpa$(7), this.blocks.get_za3lpa$(8), this.diagonals.get_za3lpa$(0), this.diagonals.get_za3lpa$(1)]) : listOf_0([this.rows.get_za3lpa$(0), this.rows.get_za3lpa$(1), this.rows.get_za3lpa$(2), this.rows.get_za3lpa$(3), this.rows.get_za3lpa$(4), this.rows.get_za3lpa$(5), this.rows.get_za3lpa$(6), this.rows.get_za3lpa$(7), this.rows.get_za3lpa$(8), this.columns.get_za3lpa$(0), this.columns.get_za3lpa$(1), this.columns.get_za3lpa$(2), this.columns.get_za3lpa$(3), this.columns.get_za3lpa$(4), this.columns.get_za3lpa$(5), this.columns.get_za3lpa$(6), this.columns.get_za3lpa$(7), this.columns.get_za3lpa$(8), this.blocks.get_za3lpa$(0), this.blocks.get_za3lpa$(1), this.blocks.get_za3lpa$(2), this.blocks.get_za3lpa$(3), this.blocks.get_za3lpa$(4), this.blocks.get_za3lpa$(5), this.blocks.get_za3lpa$(6), this.blocks.get_za3lpa$(7), this.blocks.get_za3lpa$(8)]);
    var tmp$, tmp$_0, tmp$_1, tmp$_2, tmp$_3, tmp$_4, tmp$_5, tmp$_6;
    tmp$ = this.rows.iterator();
    while (tmp$.hasNext()) {
      var row = tmp$.next();
      tmp$_0 = row.cells.iterator();
      while (tmp$_0.hasNext()) {
        var cell = tmp$_0.next();
        cell.row = row;
      }
    }
    tmp$_1 = this.columns.iterator();
    while (tmp$_1.hasNext()) {
      var column = tmp$_1.next();
      tmp$_2 = column.cells.iterator();
      while (tmp$_2.hasNext()) {
        var cell_0 = tmp$_2.next();
        cell_0.column = column;
      }
    }
    tmp$_3 = this.blocks.iterator();
    while (tmp$_3.hasNext()) {
      var block = tmp$_3.next();
      tmp$_4 = block.cells.iterator();
      while (tmp$_4.hasNext()) {
        var cell_1 = tmp$_4.next();
        cell_1.block = block;
      }
    }
    if (!this.diagonals.isEmpty()) {
      tmp$_5 = this.diagonals.get_za3lpa$(0).cells.iterator();
      while (tmp$_5.hasNext()) {
        var cell_2 = tmp$_5.next();
        cell_2.diagonal0 = this.diagonals.get_za3lpa$(0);
      }
      tmp$_6 = this.diagonals.get_za3lpa$(1).cells.iterator();
      while (tmp$_6.hasNext()) {
        var cell_3 = tmp$_6.next();
        cell_3.diagonal1 = this.diagonals.get_za3lpa$(1);
      }
    }
  }
  Board.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'Board',
    interfaces: []
  };
  function SudokuSolverSettings(isXSudoku, isSolvedAutomatically, isUserSolving) {
    if (isXSudoku === void 0)
      isXSudoku = false;
    if (isSolvedAutomatically === void 0)
      isSolvedAutomatically = true;
    if (isUserSolving === void 0)
      isUserSolving = false;
    this.isXSudoku = isXSudoku;
    this.isSolvedAutomatically = isSolvedAutomatically;
    this.isUserSolving = isUserSolving;
  }
  SudokuSolverSettings.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'SudokuSolverSettings',
    interfaces: []
  };
  SudokuSolverSettings.prototype.component1 = function () {
    return this.isXSudoku;
  };
  SudokuSolverSettings.prototype.component2 = function () {
    return this.isSolvedAutomatically;
  };
  SudokuSolverSettings.prototype.component3 = function () {
    return this.isUserSolving;
  };
  SudokuSolverSettings.prototype.copy_ws0pad$ = function (isXSudoku, isSolvedAutomatically, isUserSolving) {
    return new SudokuSolverSettings(isXSudoku === void 0 ? this.isXSudoku : isXSudoku, isSolvedAutomatically === void 0 ? this.isSolvedAutomatically : isSolvedAutomatically, isUserSolving === void 0 ? this.isUserSolving : isUserSolving);
  };
  SudokuSolverSettings.prototype.toString = function () {
    return 'SudokuSolverSettings(isXSudoku=' + Kotlin.toString(this.isXSudoku) + (', isSolvedAutomatically=' + Kotlin.toString(this.isSolvedAutomatically)) + (', isUserSolving=' + Kotlin.toString(this.isUserSolving)) + ')';
  };
  SudokuSolverSettings.prototype.hashCode = function () {
    var result = 0;
    result = result * 31 + Kotlin.hashCode(this.isXSudoku) | 0;
    result = result * 31 + Kotlin.hashCode(this.isSolvedAutomatically) | 0;
    result = result * 31 + Kotlin.hashCode(this.isUserSolving) | 0;
    return result;
  };
  SudokuSolverSettings.prototype.equals = function (other) {
    return this === other || (other !== null && (typeof other === 'object' && (Object.getPrototypeOf(this) === Object.getPrototypeOf(other) && (Kotlin.equals(this.isXSudoku, other.isXSudoku) && Kotlin.equals(this.isSolvedAutomatically, other.isSolvedAutomatically) && Kotlin.equals(this.isUserSolving, other.isUserSolving)))));
  };
  function SudokuSolverAppState(board, changes, settings) {
    if (board === void 0)
      board = new Board(false);
    if (changes === void 0) {
      changes = emptyList();
    }
    if (settings === void 0)
      settings = new SudokuSolverSettings();
    this.board = board;
    this.changes = changes;
    this.settings = settings;
  }
  SudokuSolverAppState.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'SudokuSolverAppState',
    interfaces: []
  };
  SudokuSolverAppState.prototype.component1 = function () {
    return this.board;
  };
  SudokuSolverAppState.prototype.component2 = function () {
    return this.changes;
  };
  SudokuSolverAppState.prototype.component3 = function () {
    return this.settings;
  };
  SudokuSolverAppState.prototype.copy_akxyjw$ = function (board, changes, settings) {
    return new SudokuSolverAppState(board === void 0 ? this.board : board, changes === void 0 ? this.changes : changes, settings === void 0 ? this.settings : settings);
  };
  SudokuSolverAppState.prototype.toString = function () {
    return 'SudokuSolverAppState(board=' + Kotlin.toString(this.board) + (', changes=' + Kotlin.toString(this.changes)) + (', settings=' + Kotlin.toString(this.settings)) + ')';
  };
  SudokuSolverAppState.prototype.hashCode = function () {
    var result = 0;
    result = result * 31 + Kotlin.hashCode(this.board) | 0;
    result = result * 31 + Kotlin.hashCode(this.changes) | 0;
    result = result * 31 + Kotlin.hashCode(this.settings) | 0;
    return result;
  };
  SudokuSolverAppState.prototype.equals = function (other) {
    return this === other || (other !== null && (typeof other === 'object' && (Object.getPrototypeOf(this) === Object.getPrototypeOf(other) && (Kotlin.equals(this.board, other.board) && Kotlin.equals(this.changes, other.changes) && Kotlin.equals(this.settings, other.settings)))));
  };
  function SudokuSolverMsg() {
  }
  SudokuSolverMsg.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'SudokuSolverMsg',
    interfaces: []
  };
  function PlaceValueMsg(rowIndex, columnIndex, newValue) {
    SudokuSolverMsg.call(this);
    this.rowIndex = rowIndex;
    this.columnIndex = columnIndex;
    this.newValue = newValue;
  }
  PlaceValueMsg.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'PlaceValueMsg',
    interfaces: [SudokuSolverMsg]
  };
  PlaceValueMsg.prototype.component1 = function () {
    return this.rowIndex;
  };
  PlaceValueMsg.prototype.component2 = function () {
    return this.columnIndex;
  };
  PlaceValueMsg.prototype.component3 = function () {
    return this.newValue;
  };
  PlaceValueMsg.prototype.copy_qt1dr2$ = function (rowIndex, columnIndex, newValue) {
    return new PlaceValueMsg(rowIndex === void 0 ? this.rowIndex : rowIndex, columnIndex === void 0 ? this.columnIndex : columnIndex, newValue === void 0 ? this.newValue : newValue);
  };
  PlaceValueMsg.prototype.toString = function () {
    return 'PlaceValueMsg(rowIndex=' + Kotlin.toString(this.rowIndex) + (', columnIndex=' + Kotlin.toString(this.columnIndex)) + (', newValue=' + Kotlin.toString(this.newValue)) + ')';
  };
  PlaceValueMsg.prototype.hashCode = function () {
    var result = 0;
    result = result * 31 + Kotlin.hashCode(this.rowIndex) | 0;
    result = result * 31 + Kotlin.hashCode(this.columnIndex) | 0;
    result = result * 31 + Kotlin.hashCode(this.newValue) | 0;
    return result;
  };
  PlaceValueMsg.prototype.equals = function (other) {
    return this === other || (other !== null && (typeof other === 'object' && (Object.getPrototypeOf(this) === Object.getPrototypeOf(other) && (Kotlin.equals(this.rowIndex, other.rowIndex) && Kotlin.equals(this.columnIndex, other.columnIndex) && Kotlin.equals(this.newValue, other.newValue)))));
  };
  function RemoveValueMsg(rowIndex, columnIndex) {
    SudokuSolverMsg.call(this);
    this.rowIndex = rowIndex;
    this.columnIndex = columnIndex;
  }
  RemoveValueMsg.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'RemoveValueMsg',
    interfaces: [SudokuSolverMsg]
  };
  RemoveValueMsg.prototype.component1 = function () {
    return this.rowIndex;
  };
  RemoveValueMsg.prototype.component2 = function () {
    return this.columnIndex;
  };
  RemoveValueMsg.prototype.copy_vux9f0$ = function (rowIndex, columnIndex) {
    return new RemoveValueMsg(rowIndex === void 0 ? this.rowIndex : rowIndex, columnIndex === void 0 ? this.columnIndex : columnIndex);
  };
  RemoveValueMsg.prototype.toString = function () {
    return 'RemoveValueMsg(rowIndex=' + Kotlin.toString(this.rowIndex) + (', columnIndex=' + Kotlin.toString(this.columnIndex)) + ')';
  };
  RemoveValueMsg.prototype.hashCode = function () {
    var result = 0;
    result = result * 31 + Kotlin.hashCode(this.rowIndex) | 0;
    result = result * 31 + Kotlin.hashCode(this.columnIndex) | 0;
    return result;
  };
  RemoveValueMsg.prototype.equals = function (other) {
    return this === other || (other !== null && (typeof other === 'object' && (Object.getPrototypeOf(this) === Object.getPrototypeOf(other) && (Kotlin.equals(this.rowIndex, other.rowIndex) && Kotlin.equals(this.columnIndex, other.columnIndex)))));
  };
  function ChangeSettingsMsg(settingsChange) {
    SudokuSolverMsg.call(this);
    this.settingsChange = settingsChange;
  }
  ChangeSettingsMsg.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'ChangeSettingsMsg',
    interfaces: [SudokuSolverMsg]
  };
  ChangeSettingsMsg.prototype.component1 = function () {
    return this.settingsChange;
  };
  ChangeSettingsMsg.prototype.copy_nv0i3n$ = function (settingsChange) {
    return new ChangeSettingsMsg(settingsChange === void 0 ? this.settingsChange : settingsChange);
  };
  ChangeSettingsMsg.prototype.toString = function () {
    return 'ChangeSettingsMsg(settingsChange=' + Kotlin.toString(this.settingsChange) + ')';
  };
  ChangeSettingsMsg.prototype.hashCode = function () {
    var result = 0;
    result = result * 31 + Kotlin.hashCode(this.settingsChange) | 0;
    return result;
  };
  ChangeSettingsMsg.prototype.equals = function (other) {
    return this === other || (other !== null && (typeof other === 'object' && (Object.getPrototypeOf(this) === Object.getPrototypeOf(other) && Kotlin.equals(this.settingsChange, other.settingsChange))));
  };
  function SettingsChange() {
  }
  SettingsChange.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'SettingsChange',
    interfaces: []
  };
  function ChangeIsXSudoku(newIsXSudoku) {
    SettingsChange.call(this);
    this.newIsXSudoku = newIsXSudoku;
  }
  ChangeIsXSudoku.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'ChangeIsXSudoku',
    interfaces: [SettingsChange]
  };
  ChangeIsXSudoku.prototype.component1 = function () {
    return this.newIsXSudoku;
  };
  ChangeIsXSudoku.prototype.copy_6taknv$ = function (newIsXSudoku) {
    return new ChangeIsXSudoku(newIsXSudoku === void 0 ? this.newIsXSudoku : newIsXSudoku);
  };
  ChangeIsXSudoku.prototype.toString = function () {
    return 'ChangeIsXSudoku(newIsXSudoku=' + Kotlin.toString(this.newIsXSudoku) + ')';
  };
  ChangeIsXSudoku.prototype.hashCode = function () {
    var result = 0;
    result = result * 31 + Kotlin.hashCode(this.newIsXSudoku) | 0;
    return result;
  };
  ChangeIsXSudoku.prototype.equals = function (other) {
    return this === other || (other !== null && (typeof other === 'object' && (Object.getPrototypeOf(this) === Object.getPrototypeOf(other) && Kotlin.equals(this.newIsXSudoku, other.newIsXSudoku))));
  };
  function ChangeIsSolvedAutomatically(newIsSolvedAutomatically) {
    SettingsChange.call(this);
    this.newIsSolvedAutomatically = newIsSolvedAutomatically;
  }
  ChangeIsSolvedAutomatically.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'ChangeIsSolvedAutomatically',
    interfaces: [SettingsChange]
  };
  ChangeIsSolvedAutomatically.prototype.component1 = function () {
    return this.newIsSolvedAutomatically;
  };
  ChangeIsSolvedAutomatically.prototype.copy_6taknv$ = function (newIsSolvedAutomatically) {
    return new ChangeIsSolvedAutomatically(newIsSolvedAutomatically === void 0 ? this.newIsSolvedAutomatically : newIsSolvedAutomatically);
  };
  ChangeIsSolvedAutomatically.prototype.toString = function () {
    return 'ChangeIsSolvedAutomatically(newIsSolvedAutomatically=' + Kotlin.toString(this.newIsSolvedAutomatically) + ')';
  };
  ChangeIsSolvedAutomatically.prototype.hashCode = function () {
    var result = 0;
    result = result * 31 + Kotlin.hashCode(this.newIsSolvedAutomatically) | 0;
    return result;
  };
  ChangeIsSolvedAutomatically.prototype.equals = function (other) {
    return this === other || (other !== null && (typeof other === 'object' && (Object.getPrototypeOf(this) === Object.getPrototypeOf(other) && Kotlin.equals(this.newIsSolvedAutomatically, other.newIsSolvedAutomatically))));
  };
  function ChangeIsUserSolving(newIsUserSolving) {
    SettingsChange.call(this);
    this.newIsUserSolving = newIsUserSolving;
  }
  ChangeIsUserSolving.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'ChangeIsUserSolving',
    interfaces: [SettingsChange]
  };
  ChangeIsUserSolving.prototype.component1 = function () {
    return this.newIsUserSolving;
  };
  ChangeIsUserSolving.prototype.copy_6taknv$ = function (newIsUserSolving) {
    return new ChangeIsUserSolving(newIsUserSolving === void 0 ? this.newIsUserSolving : newIsUserSolving);
  };
  ChangeIsUserSolving.prototype.toString = function () {
    return 'ChangeIsUserSolving(newIsUserSolving=' + Kotlin.toString(this.newIsUserSolving) + ')';
  };
  ChangeIsUserSolving.prototype.hashCode = function () {
    var result = 0;
    result = result * 31 + Kotlin.hashCode(this.newIsUserSolving) | 0;
    return result;
  };
  ChangeIsUserSolving.prototype.equals = function (other) {
    return this === other || (other !== null && (typeof other === 'object' && (Object.getPrototypeOf(this) === Object.getPrototypeOf(other) && Kotlin.equals(this.newIsUserSolving, other.newIsUserSolving))));
  };
  function updateSudokuSolver(applicationState, message) {
    var tmp$, tmp$_0;
    var commandsToExecute = emptyList();
    if (Kotlin.isType(message, PlaceValueMsg))
      tmp$_0 = withCellValueSet(applicationState, message.rowIndex, message.columnIndex, message.newValue);
    else if (Kotlin.isType(message, RemoveValueMsg))
      tmp$_0 = withCellValueRemoved(applicationState, message.rowIndex, message.columnIndex);
    else if (Kotlin.isType(message, ChangeSettingsMsg)) {
      tmp$ = message.settingsChange;
      if (Kotlin.isType(tmp$, ChangeIsSolvedAutomatically))
        tmp$_0 = withSettingsChanged(applicationState, applicationState.settings.isXSudoku, message.settingsChange.newIsSolvedAutomatically, false);
      else if (Kotlin.isType(tmp$, ChangeIsUserSolving))
        tmp$_0 = withSettingsChanged(applicationState, applicationState.settings.isXSudoku, applicationState.settings.isSolvedAutomatically, message.settingsChange.newIsUserSolving);
      else if (Kotlin.isType(tmp$, ChangeIsXSudoku))
        tmp$_0 = withSettingsChanged(applicationState, message.settingsChange.newIsXSudoku, applicationState.settings.isSolvedAutomatically, applicationState.settings.isUserSolving);
      else
        tmp$_0 = Kotlin.noWhenBranchMatched();
    }
     else
      tmp$_0 = Kotlin.noWhenBranchMatched();
    var newApplicationState = tmp$_0;
    return new KatydidApplicationCycle(newApplicationState, commandsToExecute);
  }
  function withCellValueRemoved($receiver, rowIndex, colIndex) {
    var newBoard = new Board($receiver.settings.isXSudoku);
    var newChanges = ArrayList_init_0();
    for (var i = 0; i <= 8; i++) {
      for (var j = 0; j <= 8; j++) {
        var cell = $receiver.board.rows.get_za3lpa$(i).cells.get_za3lpa$(j);
        if (cell.row.index === rowIndex && cell.column.index === colIndex) {
          continue;
        }
        var newCell = newBoard.rows.get_za3lpa$(i).cells.get_za3lpa$(j);
        var oldValue = cell.value;
        var candidatesRemoved;
        if (oldValue != null && cell.state === Cell$State$DEFINED_getInstance()) {
          candidatesRemoved = newCell.setValue_ajq5b3$(oldValue, cell.state);
        }
         else {
          continue;
        }
        newChanges.add_11rb$(new BoardChange('Cell Value Defined', newCell.name, candidatesRemoved == null ? throwUPAE('candidatesRemoved') : candidatesRemoved));
      }
    }
    if ($receiver.settings.isUserSolving) {
      for (var i_0 = 0; i_0 <= 8; i_0++) {
        for (var j_0 = 0; j_0 <= 8; j_0++) {
          var cell_0 = $receiver.board.rows.get_za3lpa$(i_0).cells.get_za3lpa$(j_0);
          if (cell_0.row.index === rowIndex && cell_0.column.index === colIndex) {
            continue;
          }
          var newCell_0 = newBoard.rows.get_za3lpa$(i_0).cells.get_za3lpa$(j_0);
          var oldValue_0 = cell_0.value;
          var candidatesRemoved_0;
          if (oldValue_0 != null && cell_0.state === Cell$State$GUESSED_getInstance()) {
            candidatesRemoved_0 = newCell_0.setValue_ajq5b3$(oldValue_0, cell_0.state);
          }
           else {
            continue;
          }
          newChanges.add_11rb$(new BoardChange('Solved by User', newCell_0.name, candidatesRemoved_0 == null ? throwUPAE('candidatesRemoved') : candidatesRemoved_0));
        }
      }
    }
    if ($receiver.settings.isSolvedAutomatically) {
      newChanges.addAll_brywnq$(solve(newBoard));
    }
    return new SudokuSolverAppState(newBoard, newChanges, $receiver.settings);
  }
  function withCellValueSet($receiver, rowIndex, colIndex, value) {
    var tmp$, tmp$_0;
    var newBoard = new Board($receiver.settings.isXSudoku);
    var newChanges = ArrayList_init_0();
    for (var i = 0; i <= 8; i++) {
      for (var j = 0; j <= 8; j++) {
        var cell = $receiver.board.rows.get_za3lpa$(i).cells.get_za3lpa$(j);
        var newCell = newBoard.rows.get_za3lpa$(i).cells.get_za3lpa$(j);
        var oldValue = cell.value;
        if (oldValue != null && cell.state === Cell$State$DEFINED_getInstance()) {
          tmp$ = newCell.setValue_ajq5b3$(oldValue, Cell$State$DEFINED_getInstance());
        }
         else if (cell.row.index === rowIndex && cell.column.index === colIndex && !$receiver.settings.isUserSolving) {
          tmp$ = newCell.setValue_ajq5b3$(value, Cell$State$DEFINED_getInstance());
        }
         else {
          continue;
        }
        var candidatesRemoved = tmp$;
        newChanges.add_11rb$(new BoardChange('Cell Value Defined', newCell.name, candidatesRemoved));
      }
    }
    if ($receiver.settings.isUserSolving) {
      for (var i_0 = 0; i_0 <= 8; i_0++) {
        for (var j_0 = 0; j_0 <= 8; j_0++) {
          var cell_0 = $receiver.board.rows.get_za3lpa$(i_0).cells.get_za3lpa$(j_0);
          var newCell_0 = newBoard.rows.get_za3lpa$(i_0).cells.get_za3lpa$(j_0);
          var oldValue_0 = cell_0.value;
          if (oldValue_0 != null && cell_0.state === Cell$State$GUESSED_getInstance()) {
            tmp$_0 = newCell_0.setValue_ajq5b3$(oldValue_0, Cell$State$GUESSED_getInstance());
          }
           else if (cell_0.row.index === rowIndex && cell_0.column.index === colIndex) {
            tmp$_0 = newCell_0.setValue_ajq5b3$(value, Cell$State$GUESSED_getInstance());
          }
           else {
            continue;
          }
          var candidatesRemoved_0 = tmp$_0;
          newChanges.add_11rb$(new BoardChange('Solved by User', newCell_0.name, candidatesRemoved_0));
        }
      }
    }
    if ($receiver.settings.isSolvedAutomatically) {
      newChanges.addAll_brywnq$(solve(newBoard));
    }
    return new SudokuSolverAppState(newBoard, newChanges, $receiver.settings);
  }
  function withSettingsChanged($receiver, newIsXSudoku, newIsSolvedAutomatically, newIsUserSolving) {
    var newSettings = new SudokuSolverSettings(newIsXSudoku, newIsSolvedAutomatically, newIsUserSolving);
    var newBoard = new Board(newIsXSudoku);
    var newChanges = ArrayList_init_0();
    for (var i = 0; i <= 8; i++) {
      for (var j = 0; j <= 8; j++) {
        var cell = $receiver.board.rows.get_za3lpa$(i).cells.get_za3lpa$(j);
        var newCell = newBoard.rows.get_za3lpa$(i).cells.get_za3lpa$(j);
        var oldValue = cell.value;
        if (oldValue != null && newCell.candidates.contains_11rb$(oldValue) && cell.state === Cell$State$DEFINED_getInstance()) {
          var candidatesRemoved = newCell.setValue_ajq5b3$(oldValue, cell.state);
          newChanges.add_11rb$(new BoardChange('Cell Value Defined', newCell.name, candidatesRemoved));
        }
      }
    }
    if (newIsUserSolving) {
      for (var i_0 = 0; i_0 <= 8; i_0++) {
        for (var j_0 = 0; j_0 <= 8; j_0++) {
          var cell_0 = $receiver.board.rows.get_za3lpa$(i_0).cells.get_za3lpa$(j_0);
          var newCell_0 = newBoard.rows.get_za3lpa$(i_0).cells.get_za3lpa$(j_0);
          var oldValue_0 = cell_0.value;
          if (oldValue_0 != null && newCell_0.candidates.contains_11rb$(oldValue_0) && cell_0.state === Cell$State$GUESSED_getInstance()) {
            var candidatesRemoved_0 = newCell_0.setValue_ajq5b3$(oldValue_0, cell_0.state);
            newChanges.add_11rb$(new BoardChange('Solved by User', newCell_0.name, candidatesRemoved_0));
          }
        }
      }
    }
    if (newIsSolvedAutomatically) {
      newChanges.addAll_brywnq$(solve(newBoard));
    }
    return new SudokuSolverAppState(newBoard, newChanges, newSettings);
  }
  function solve(board) {
    var result = ArrayList_init_0();
    while (true) {
      var changes = solveNakedSingles(board);
      if (!changes.isEmpty()) {
        result.addAll_brywnq$(changes);
        continue;
      }
      changes = solveHiddenSingles(board);
      if (!changes.isEmpty()) {
        result.addAll_brywnq$(changes);
        continue;
      }
      changes = solveNakedPairs(board);
      if (!changes.isEmpty()) {
        result.addAll_brywnq$(changes);
        continue;
      }
      break;
    }
    return result;
  }
  function solveNakedSingles(board) {
    var tmp$, tmp$_0;
    var result = ArrayList_init_0();
    tmp$ = board.rows.iterator();
    while (tmp$.hasNext()) {
      var row = tmp$.next();
      tmp$_0 = row.cells.iterator();
      while (tmp$_0.hasNext()) {
        var cell = tmp$_0.next();
        if (cell.candidates.size === 1) {
          var c = elementAt(cell.candidates, 0);
          var candidatesRemoved = cell.setValue_ajq5b3$(c, Cell$State$SOLVED_getInstance());
          result.add_11rb$(new BoardChange('Naked Single', cell.name, candidatesRemoved));
        }
      }
    }
    return result;
  }
  function solveHiddenSingles(board) {
    var tmp$;
    var result = ArrayList_init_0();
    tmp$ = board.units.iterator();
    while (tmp$.hasNext()) {
      var unit = tmp$.next();
      for (var c = 0; c <= 8; c++) {
        if (unit.cellsWithCandidate.get_za3lpa$(c).size === 1) {
          var cell = unit.cellsWithCandidate.get_za3lpa$(c).get_za3lpa$(0);
          var candidatesRemoved = cell.setValue_ajq5b3$(c, Cell$State$SOLVED_getInstance());
          result.add_11rb$(new BoardChange('Hidden Single in ' + unit.name, cell.name, candidatesRemoved));
        }
      }
    }
    return result;
  }
  function solveNakedPairs(board) {
    var tmp$;
    var result = ArrayList_init_0();
    tmp$ = board.units.iterator();
    while (tmp$.hasNext()) {
      var unit = tmp$.next();
      for (var u1 = 0; u1 <= 8; u1++) {
        var cell1 = unit.cells.get_za3lpa$(u1);
        for (var u2 = u1 + 1 | 0; u2 <= 8; u2++) {
          var cell2 = unit.cells.get_za3lpa$(u2);
          if (cell1.candidates.size === 2 && equals(cell1.candidates, cell2.candidates)) {
            var c1 = elementAt(cell1.candidates, 0);
            var c2 = elementAt(cell1.candidates, 1);
            var candidatesRemoved = ArrayList_init_0();
            for (var u = 0; u <= 8; u++) {
              if (u !== u1 && u !== u2) {
                var cell = unit.cells.get_za3lpa$(u);
                if (cell.removeCandidate_za3lpa$(c1)) {
                  candidatesRemoved.add_11rb$(cell.name + '#' + (c1 + 1 | 0));
                }
                if (cell.removeCandidate_za3lpa$(c2)) {
                  candidatesRemoved.add_11rb$(cell.name + '#' + (c2 + 1 | 0));
                }
              }
            }
            if (!candidatesRemoved.isEmpty()) {
              result.add_11rb$(new BoardChange('Naked Pair: ' + cell1.name + '/' + cell2.name + ' in ' + unit.name, '', candidatesRemoved));
            }
          }
        }
      }
    }
    return result;
  }
  function viewSudokuSolver$lambda$lambda$lambda($receiver) {
    marginLeft($receiver, get_px(30));
    return Unit;
  }
  function viewSudokuSolver$lambda$lambda$lambda_0($receiver) {
    $receiver.text_4w9ihe$('Sudoku Solver');
    return Unit;
  }
  function viewSudokuSolver$lambda$lambda$lambda_1(closure$applicationState) {
    return function ($receiver) {
      board($receiver, closure$applicationState);
      settings($receiver, closure$applicationState);
      notes($receiver);
      return Unit;
    };
  }
  function viewSudokuSolver$lambda$lambda(closure$applicationState) {
    return function ($receiver) {
      style($receiver, viewSudokuSolver$lambda$lambda$lambda);
      $receiver.h1_qckjfy$(void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, viewSudokuSolver$lambda$lambda$lambda_0);
      $receiver.section_6zr3om$(void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, viewSudokuSolver$lambda$lambda$lambda_1(closure$applicationState));
      changes($receiver, closure$applicationState);
      return Unit;
    };
  }
  function viewSudokuSolver$lambda(closure$applicationState) {
    return function ($receiver) {
      $receiver.main_6zr3om$('#sudoku-solver-app', void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, viewSudokuSolver$lambda$lambda(closure$applicationState));
      return Unit;
    };
  }
  function viewSudokuSolver(applicationState) {
    return viewSudokuSolver$lambda(applicationState);
  }
  function block$lambda$lambda$lambda$lambda(closure$cell) {
    return function (it) {
      return listOf(new RemoveValueMsg(closure$cell.row.index, closure$cell.column.index));
    };
  }
  function block$lambda$lambda$lambda(closure$cellGroup, closure$k, closure$m) {
    return function ($receiver) {
      var cell = closure$cellGroup.cells.get_za3lpa$((3 * closure$k | 0) + closure$m | 0);
      var v = cell.value;
      $receiver.classes_n2nruh$([to('solved', cell.state === Cell$State$SOLVED_getInstance()), to('defined', cell.state === Cell$State$DEFINED_getInstance()), to('guessed', cell.state === Cell$State$GUESSED_getInstance())]);
      if (v != null) {
        if (cell.state !== Cell$State$SOLVED_getInstance()) {
          onclick($receiver, block$lambda$lambda$lambda$lambda(cell));
        }
        $receiver.text_4w9ihe$((v + 1 | 0).toString());
      }
       else {
        if (!cell.candidates.isEmpty()) {
          candidates($receiver, cell);
        }
         else {
          $receiver.classes_n2nruh$([to('unfillable', true)]);
        }
      }
      return Unit;
    };
  }
  function block$lambda$lambda(closure$cellGroup, closure$k) {
    return function ($receiver) {
      for (var m = 0; m <= 2; m++) {
        $receiver.td_iemoux$('.cell', m, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, block$lambda$lambda$lambda(closure$cellGroup, closure$k, m));
      }
      return Unit;
    };
  }
  function block$lambda(closure$cellGroup) {
    return function ($receiver) {
      for (var k = 0; k <= 2; k++) {
        $receiver.tr_n8e5b5$(void 0, k, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, block$lambda$lambda(closure$cellGroup, k));
      }
      return Unit;
    };
  }
  function block($receiver, cellGroup) {
    $receiver.table_55vzb3$('.block', void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, block$lambda(cellGroup));
  }
  function board$lambda$lambda$lambda($receiver) {
    fontWeight($receiver, EFontWeight.bold);
    return Unit;
  }
  function board$lambda$lambda($receiver) {
    style($receiver, board$lambda$lambda$lambda);
    $receiver.text_4w9ihe$('Board');
    return Unit;
  }
  function board$lambda$lambda$lambda$lambda($receiver) {
    return Unit;
  }
  function board$lambda$lambda$lambda$lambda_0(closure$columnIndex) {
    return function ($receiver) {
      $receiver.text_4w9ihe$('C' + closure$columnIndex);
      return Unit;
    };
  }
  function board$lambda$lambda$lambda_0($receiver) {
    $receiver.th_f4d2jq$(void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, board$lambda$lambda$lambda$lambda);
    for (var columnIndex = 1; columnIndex <= 9; columnIndex++) {
      $receiver.th_f4d2jq$(void 0, columnIndex, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, board$lambda$lambda$lambda$lambda_0(columnIndex));
    }
    return Unit;
  }
  function board$lambda$lambda$lambda$lambda_1(closure$i) {
    return function ($receiver) {
      $receiver.text_4w9ihe$('R' + ((3 * closure$i | 0) + 1 | 0));
      return Unit;
    };
  }
  function board$lambda$lambda$lambda$lambda_2(closure$cellGroup) {
    return function ($receiver) {
      block($receiver, closure$cellGroup);
      return Unit;
    };
  }
  function board$lambda$lambda$lambda_1(closure$i, closure$applicationState) {
    return function ($receiver) {
      $receiver.th_f4d2jq$(void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, board$lambda$lambda$lambda$lambda_1(closure$i));
      for (var j = 0; j <= 2; j++) {
        var cellGroup = closure$applicationState.board.blocks.get_za3lpa$((3 * closure$i | 0) + j | 0);
        $receiver.td_iemoux$('.block', j, void 0, 3, void 0, void 0, void 0, void 0, void 0, void 0, 3, void 0, void 0, void 0, void 0, void 0, board$lambda$lambda$lambda$lambda_2(cellGroup));
      }
      return Unit;
    };
  }
  function board$lambda$lambda$lambda$lambda_3(closure$i, closure$j) {
    return function ($receiver) {
      $receiver.text_4w9ihe$('R' + ((3 * closure$i | 0) + closure$j | 0));
      return Unit;
    };
  }
  function board$lambda$lambda$lambda_2(closure$i, closure$j) {
    return function ($receiver) {
      $receiver.th_f4d2jq$(void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, board$lambda$lambda$lambda$lambda_3(closure$i, closure$j));
      return Unit;
    };
  }
  function board$lambda$lambda_0(closure$applicationState) {
    return function ($receiver) {
      $receiver.tr_n8e5b5$(void 0, 'headings', void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, board$lambda$lambda$lambda_0);
      for (var i = 0; i <= 2; i++) {
        $receiver.tr_n8e5b5$(void 0, (3 * i | 0) + 1 | 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, board$lambda$lambda$lambda_1(i, closure$applicationState));
        for (var j = 2; j <= 3; j++) {
          $receiver.tr_n8e5b5$(void 0, (3 * i | 0) + j | 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, board$lambda$lambda$lambda_2(i, j));
        }
      }
      return Unit;
    };
  }
  function board$lambda(closure$applicationState) {
    return function ($receiver) {
      $receiver.span_qckjfy$(void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, board$lambda$lambda);
      $receiver.table_55vzb3$('.board', void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, board$lambda$lambda_0(closure$applicationState));
      return Unit;
    };
  }
  function board($receiver, applicationState) {
    $receiver.section_6zr3om$('#board', void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, board$lambda(applicationState));
  }
  function candidates$lambda$lambda$lambda$lambda(closure$cell, closure$c) {
    return function (it) {
      return listOf(new PlaceValueMsg(closure$cell.row.index, closure$cell.column.index, closure$c));
    };
  }
  function candidates$lambda$lambda$lambda(closure$cell, closure$c) {
    return function ($receiver) {
      if (closure$cell.candidates.contains_11rb$(closure$c)) {
        $receiver.classes_n2nruh$([to('candidate', true)]);
        onclick($receiver, candidates$lambda$lambda$lambda$lambda(closure$cell, closure$c));
        $receiver.text_4w9ihe$((closure$c + 1 | 0).toString());
      }
      return Unit;
    };
  }
  function candidates$lambda$lambda(closure$p, closure$cell) {
    return function ($receiver) {
      for (var q = 0; q <= 2; q++) {
        var c = (3 * closure$p | 0) + q | 0;
        $receiver.td_iemoux$(void 0, q, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, candidates$lambda$lambda$lambda(closure$cell, c));
      }
      return Unit;
    };
  }
  function candidates$lambda(closure$cell) {
    return function ($receiver) {
      for (var p = 0; p <= 2; p++) {
        $receiver.tr_n8e5b5$(void 0, p, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, candidates$lambda$lambda(p, closure$cell));
      }
      return Unit;
    };
  }
  function candidates($receiver, cell) {
    $receiver.table_55vzb3$('.candidates', void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, candidates$lambda(cell));
  }
  function changes$lambda$lambda($receiver) {
    marginLeft($receiver, get_px(30));
    return Unit;
  }
  function changes$lambda$lambda$lambda$lambda($receiver) {
    $receiver.text_4w9ihe$('Action');
    return Unit;
  }
  function changes$lambda$lambda$lambda$lambda_0($receiver) {
    $receiver.text_4w9ihe$('Value Set');
    return Unit;
  }
  function changes$lambda$lambda$lambda$lambda_1($receiver) {
    $receiver.text_4w9ihe$('Candidates Removed');
    return Unit;
  }
  function changes$lambda$lambda$lambda($receiver) {
    $receiver.th_f4d2jq$('.change-description', 1, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, changes$lambda$lambda$lambda$lambda);
    $receiver.th_f4d2jq$('.cell-value-set', 2, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, changes$lambda$lambda$lambda$lambda_0);
    $receiver.th_f4d2jq$('.candidates-removed', 3, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, changes$lambda$lambda$lambda$lambda_1);
    return Unit;
  }
  function changes$lambda$lambda$lambda$lambda_2(closure$change) {
    return function ($receiver) {
      $receiver.text_4w9ihe$(closure$change.description);
      return Unit;
    };
  }
  function changes$lambda$lambda$lambda$lambda_3(closure$change) {
    return function ($receiver) {
      $receiver.text_4w9ihe$(closure$change.cellValueSet);
      return Unit;
    };
  }
  function changes$lambda$lambda$lambda$lambda_4(closure$change) {
    return function ($receiver) {
      $receiver.text_4w9ihe$(joinToString(sorted(closure$change.candidatesRemoved), ', '));
      return Unit;
    };
  }
  function changes$lambda$lambda$lambda_0(closure$change) {
    return function ($receiver) {
      $receiver.td_iemoux$('.change-description', 1, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, changes$lambda$lambda$lambda$lambda_2(closure$change));
      $receiver.td_iemoux$('.cell-value-set', 2, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, changes$lambda$lambda$lambda$lambda_3(closure$change));
      $receiver.td_iemoux$('.candidates-removed', 3, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, changes$lambda$lambda$lambda$lambda_4(closure$change));
      return Unit;
    };
  }
  function changes$lambda$lambda$lambda$lambda_5($receiver) {
    $receiver.text_4w9ihe$('Click any small candidate number in the board to begin defining a puzzle.');
    return Unit;
  }
  function changes$lambda$lambda$lambda_1($receiver) {
    $receiver.td_iemoux$(void 0, void 0, void 0, 3, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, changes$lambda$lambda$lambda$lambda_5);
    return Unit;
  }
  function changes$lambda$lambda_0(closure$applicationState) {
    return function ($receiver) {
      var tmp$, tmp$_0;
      $receiver.tr_n8e5b5$(void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, changes$lambda$lambda$lambda);
      var row = 1;
      tmp$ = closure$applicationState.changes.iterator();
      while (tmp$.hasNext()) {
        var change = tmp$.next();
        $receiver.tr_n8e5b5$(void 0, (tmp$_0 = row, row = tmp$_0 + 1 | 0, tmp$_0), void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, changes$lambda$lambda$lambda_0(change));
      }
      if (closure$applicationState.changes.isEmpty()) {
        $receiver.tr_n8e5b5$(void 0, row, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, changes$lambda$lambda$lambda_1);
      }
      return Unit;
    };
  }
  function changes$lambda(closure$applicationState) {
    return function ($receiver) {
      style($receiver, changes$lambda$lambda);
      $receiver.table_55vzb3$('.changes', void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, changes$lambda$lambda_0(closure$applicationState));
      return Unit;
    };
  }
  function changes($receiver, applicationState) {
    $receiver.section_6zr3om$('#changes', void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, changes$lambda(applicationState));
  }
  function notes$lambda$lambda$lambda($receiver) {
    fontWeight($receiver, EFontWeight.bold);
    return Unit;
  }
  function notes$lambda$lambda($receiver) {
    style($receiver, notes$lambda$lambda$lambda);
    $receiver.text_4w9ihe$('Notes');
    return Unit;
  }
  function notes$lambda$lambda_0($receiver) {
    return Unit;
  }
  function notes$lambda$lambda_1($receiver) {
    $receiver.text_4w9ihe$('SudokuWiki.org');
    return Unit;
  }
  function notes$lambda($receiver) {
    $receiver.span_qckjfy$(void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, notes$lambda$lambda);
    $receiver.br_9mj9vz$(void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, notes$lambda$lambda_0);
    $receiver.text_4w9ihe$('This solver can handle modest Sudoku puzzles. ' + 'Inspiration and terminology for this sample come from ', 1);
    $receiver.a_ncyfe7$(void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, 'http://www.sudokuwiki.org/', void 0, void 0, void 0, void 0, void 0, void 0, void 0, '_blank', void 0, void 0, void 0, notes$lambda$lambda_1);
    $receiver.text_4w9ihe$(', which is highly recommended for more serious Sudoku solving.', 2);
    return Unit;
  }
  function notes($receiver) {
    $receiver.section_6zr3om$('#notes', void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, notes$lambda);
  }
  function settings$lambda$lambda$lambda($receiver) {
    fontWeight($receiver, EFontWeight.bold);
    return Unit;
  }
  function settings$lambda$lambda($receiver) {
    style($receiver, settings$lambda$lambda$lambda);
    $receiver.text_4w9ihe$('Settings');
    return Unit;
  }
  function settings$lambda$lambda$lambda$lambda$lambda(event) {
    var newValue = toBoolean(event.getTargetAttribute_ytbaoo$('value'));
    console.log('RADIO: ', newValue);
    return listOf(new ChangeSettingsMsg(new ChangeIsXSudoku(newValue)));
  }
  function settings$lambda$lambda$lambda$lambda($receiver) {
    onchange($receiver, settings$lambda$lambda$lambda$lambda$lambda);
    return Unit;
  }
  function settings$lambda$lambda$lambda$lambda_0($receiver) {
    $receiver.text_4w9ihe$('Regular Sudoku');
    return Unit;
  }
  function settings$lambda$lambda$lambda$lambda$lambda_0($receiver) {
    marginLeft($receiver, get_px(15));
    return Unit;
  }
  function settings$lambda$lambda$lambda$lambda$lambda_1(event) {
    var newValue = toBoolean(event.getTargetAttribute_ytbaoo$('value'));
    console.log('RADIO: ', newValue);
    return listOf(new ChangeSettingsMsg(new ChangeIsXSudoku(newValue)));
  }
  function settings$lambda$lambda$lambda$lambda_1($receiver) {
    style($receiver, settings$lambda$lambda$lambda$lambda$lambda_0);
    onchange($receiver, settings$lambda$lambda$lambda$lambda$lambda_1);
    return Unit;
  }
  function settings$lambda$lambda$lambda$lambda_2($receiver) {
    $receiver.text_4w9ihe$('X-Sudoku (unique values on diagonals)');
    return Unit;
  }
  function settings$lambda$lambda$lambda_0(closure$applicationState) {
    return function ($receiver) {
      $receiver.inputRadioButton_5idhkk$('#is-not-x-sudoku', void 0, void 0, void 0, !closure$applicationState.settings.isXSudoku, void 0, void 0, void 0, void 0, void 0, void 0, void 0, 'is-x-sudoku', void 0, void 0, void 0, void 0, void 0, void 0, 'false', settings$lambda$lambda$lambda$lambda);
      $receiver.label_va30u7$(void 0, void 0, void 0, void 0, void 0, void 0, 'is-not-x-sudoku', void 0, void 0, void 0, void 0, void 0, void 0, void 0, settings$lambda$lambda$lambda$lambda_0);
      $receiver.inputRadioButton_5idhkk$('#is-x-sudoku', void 0, void 0, void 0, closure$applicationState.settings.isXSudoku, void 0, void 0, void 0, void 0, void 0, void 0, void 0, 'is-x-sudoku', void 0, void 0, void 0, void 0, void 0, void 0, 'true', settings$lambda$lambda$lambda$lambda_1);
      $receiver.label_va30u7$(void 0, void 0, void 0, void 0, void 0, void 0, 'is-x-sudoku', void 0, void 0, void 0, void 0, void 0, void 0, void 0, settings$lambda$lambda$lambda$lambda_2);
      return Unit;
    };
  }
  function settings$lambda$lambda$lambda$lambda$lambda_2(event) {
    var newValue = event.getTargetAttribute_ytbaoo$('checked');
    return listOf(new ChangeSettingsMsg(new ChangeIsSolvedAutomatically(newValue)));
  }
  function settings$lambda$lambda$lambda$lambda_3($receiver) {
    onchange($receiver, settings$lambda$lambda$lambda$lambda$lambda_2);
    return Unit;
  }
  function settings$lambda$lambda$lambda$lambda_4($receiver) {
    $receiver.text_4w9ihe$('Solve automatically');
    return Unit;
  }
  function settings$lambda$lambda$lambda_1(closure$applicationState) {
    return function ($receiver) {
      $receiver.inputCheckbox_5idhkk$('#is-solved-automatically', void 0, void 0, void 0, closure$applicationState.settings.isSolvedAutomatically, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, settings$lambda$lambda$lambda$lambda_3);
      $receiver.label_va30u7$(void 0, void 0, void 0, void 0, void 0, void 0, 'is-solved-automatically', void 0, void 0, void 0, void 0, void 0, void 0, void 0, settings$lambda$lambda$lambda$lambda_4);
      return Unit;
    };
  }
  function settings$lambda$lambda$lambda$lambda_5($receiver) {
    $receiver.text_4w9ihe$('I am currently ');
    return Unit;
  }
  function settings$lambda$lambda$lambda$lambda$lambda_3(event) {
    var newValue = toBoolean(event.getTargetAttribute_ytbaoo$('value'));
    return listOf(new ChangeSettingsMsg(new ChangeIsUserSolving(newValue)));
  }
  function settings$lambda$lambda$lambda$lambda$lambda_4($receiver) {
    return Unit;
  }
  function settings$lambda$lambda$lambda$lambda$lambda_5($receiver) {
    return Unit;
  }
  function settings$lambda$lambda$lambda$lambda_6($receiver) {
    onchange($receiver, settings$lambda$lambda$lambda$lambda$lambda_3);
    $receiver.option_uvs23e$(void 0, false, void 0, void 0, void 0, void 0, void 0, void 0, 'defining', void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, 'false', settings$lambda$lambda$lambda$lambda$lambda_4);
    $receiver.option_uvs23e$(void 0, true, void 0, void 0, void 0, void 0, void 0, void 0, 'solving', void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, 'true', settings$lambda$lambda$lambda$lambda$lambda_5);
    return Unit;
  }
  function settings$lambda$lambda$lambda$lambda_7($receiver) {
    $receiver.text_4w9ihe$(' the puzzle.');
    return Unit;
  }
  function settings$lambda$lambda$lambda_2($receiver) {
    $receiver.span_qckjfy$(void 0, 1, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, settings$lambda$lambda$lambda$lambda_5);
    $receiver.select_7efmz3$('#is-solving', void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, settings$lambda$lambda$lambda$lambda_6);
    $receiver.span_qckjfy$(void 0, 2, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, settings$lambda$lambda$lambda$lambda_7);
    return Unit;
  }
  function settings$lambda$lambda_0(closure$applicationState) {
    return function ($receiver) {
      $receiver.fieldset_wkcbaa$(void 0, 'is-x-sudoku', void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, settings$lambda$lambda$lambda_0(closure$applicationState));
      $receiver.fieldset_wkcbaa$(void 0, 'is-solved-automatically', void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, settings$lambda$lambda$lambda_1(closure$applicationState));
      if (!closure$applicationState.settings.isSolvedAutomatically) {
        $receiver.fieldset_wkcbaa$(void 0, 'is-solving', void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, settings$lambda$lambda$lambda_2);
      }
      return Unit;
    };
  }
  function settings$lambda(closure$applicationState) {
    return function ($receiver) {
      $receiver.span_qckjfy$(void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, settings$lambda$lambda);
      $receiver.form_roosm5$(void 0, 'settings', void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, settings$lambda$lambda_0(closure$applicationState));
      return Unit;
    };
  }
  function settings($receiver, applicationState) {
    $receiver.section_6zr3om$('#settings', void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, settings$lambda(applicationState));
  }
  function BoardNameViewModel(isEditButtonShown, isEditingInProgress, domain, boardUuid) {
    if (isEditButtonShown === void 0)
      isEditButtonShown = false;
    if (isEditingInProgress === void 0)
      isEditingInProgress = false;
    this.isEditButtonShown = isEditButtonShown;
    this.isEditingInProgress = isEditingInProgress;
    this.domain = domain;
    this.boardUuid = boardUuid;
    var tmp$, tmp$_0;
    this.name = (tmp$_0 = (tmp$ = this.domain.boardWithUuid_vhpctj$(this.boardUuid)) != null ? tmp$.name : null) != null ? tmp$_0 : '';
  }
  BoardNameViewModel.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'BoardNameViewModel',
    interfaces: []
  };
  BoardNameViewModel.prototype.component1 = function () {
    return this.isEditButtonShown;
  };
  BoardNameViewModel.prototype.component2 = function () {
    return this.isEditingInProgress;
  };
  BoardNameViewModel.prototype.component3 = function () {
    return this.domain;
  };
  BoardNameViewModel.prototype.component4 = function () {
    return this.boardUuid;
  };
  BoardNameViewModel.prototype.copy_ycka3m$ = function (isEditButtonShown, isEditingInProgress, domain, boardUuid) {
    return new BoardNameViewModel(isEditButtonShown === void 0 ? this.isEditButtonShown : isEditButtonShown, isEditingInProgress === void 0 ? this.isEditingInProgress : isEditingInProgress, domain === void 0 ? this.domain : domain, boardUuid === void 0 ? this.boardUuid : boardUuid);
  };
  BoardNameViewModel.prototype.toString = function () {
    return 'BoardNameViewModel(isEditButtonShown=' + Kotlin.toString(this.isEditButtonShown) + (', isEditingInProgress=' + Kotlin.toString(this.isEditingInProgress)) + (', domain=' + Kotlin.toString(this.domain)) + (', boardUuid=' + Kotlin.toString(this.boardUuid)) + ')';
  };
  BoardNameViewModel.prototype.hashCode = function () {
    var result = 0;
    result = result * 31 + Kotlin.hashCode(this.isEditButtonShown) | 0;
    result = result * 31 + Kotlin.hashCode(this.isEditingInProgress) | 0;
    result = result * 31 + Kotlin.hashCode(this.domain) | 0;
    result = result * 31 + Kotlin.hashCode(this.boardUuid) | 0;
    return result;
  };
  BoardNameViewModel.prototype.equals = function (other) {
    return this === other || (other !== null && (typeof other === 'object' && (Object.getPrototypeOf(this) === Object.getPrototypeOf(other) && (Kotlin.equals(this.isEditButtonShown, other.isEditButtonShown) && Kotlin.equals(this.isEditingInProgress, other.isEditingInProgress) && Kotlin.equals(this.domain, other.domain) && Kotlin.equals(this.boardUuid, other.boardUuid)))));
  };
  function BoardNameMsg() {
  }
  BoardNameMsg.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'BoardNameMsg',
    interfaces: []
  };
  function BoardNameRenameMsg(boardUuid, oldName, newName) {
    BoardNameMsg.call(this);
    this.action = new RenameBoardAction(boardUuid, newName, oldName);
  }
  BoardNameRenameMsg.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'BoardNameRenameMsg',
    interfaces: [BoardNameMsg]
  };
  function BoardNameStartEditingMsg() {
    BoardNameStartEditingMsg_instance = this;
    BoardNameMsg.call(this);
  }
  BoardNameStartEditingMsg.$metadata$ = {
    kind: Kind_OBJECT,
    simpleName: 'BoardNameStartEditingMsg',
    interfaces: [BoardNameMsg]
  };
  var BoardNameStartEditingMsg_instance = null;
  function BoardNameStartEditingMsg_getInstance() {
    if (BoardNameStartEditingMsg_instance === null) {
      new BoardNameStartEditingMsg();
    }
    return BoardNameStartEditingMsg_instance;
  }
  function BoardNameStartHoveringMsg() {
    BoardNameStartHoveringMsg_instance = this;
    BoardNameMsg.call(this);
  }
  BoardNameStartHoveringMsg.$metadata$ = {
    kind: Kind_OBJECT,
    simpleName: 'BoardNameStartHoveringMsg',
    interfaces: [BoardNameMsg]
  };
  var BoardNameStartHoveringMsg_instance = null;
  function BoardNameStartHoveringMsg_getInstance() {
    if (BoardNameStartHoveringMsg_instance === null) {
      new BoardNameStartHoveringMsg();
    }
    return BoardNameStartHoveringMsg_instance;
  }
  function BoardNameStopEditingMsg() {
    BoardNameStopEditingMsg_instance = this;
    BoardNameMsg.call(this);
  }
  BoardNameStopEditingMsg.$metadata$ = {
    kind: Kind_OBJECT,
    simpleName: 'BoardNameStopEditingMsg',
    interfaces: [BoardNameMsg]
  };
  var BoardNameStopEditingMsg_instance = null;
  function BoardNameStopEditingMsg_getInstance() {
    if (BoardNameStopEditingMsg_instance === null) {
      new BoardNameStopEditingMsg();
    }
    return BoardNameStopEditingMsg_instance;
  }
  function BoardNameStopHoveringMsg() {
    BoardNameStopHoveringMsg_instance = this;
    BoardNameMsg.call(this);
  }
  BoardNameStopHoveringMsg.$metadata$ = {
    kind: Kind_OBJECT,
    simpleName: 'BoardNameStopHoveringMsg',
    interfaces: [BoardNameMsg]
  };
  var BoardNameStopHoveringMsg_instance = null;
  function BoardNameStopHoveringMsg_getInstance() {
    if (BoardNameStopHoveringMsg_instance === null) {
      new BoardNameStopHoveringMsg();
    }
    return BoardNameStopHoveringMsg_instance;
  }
  function updateBoardName(boardName, message) {
    var tmp$;
    if (Kotlin.isType(message, BoardNameRenameMsg))
      tmp$ = boardName.copy_ycka3m$(void 0, void 0, message.action.apply_11rb$(boardName.domain));
    else if (Kotlin.isType(message, BoardNameStartEditingMsg))
      tmp$ = boardName.copy_ycka3m$(false, true);
    else if (Kotlin.isType(message, BoardNameStartHoveringMsg))
      tmp$ = boardName.copy_ycka3m$(true);
    else if (Kotlin.isType(message, BoardNameStopEditingMsg))
      tmp$ = boardName.copy_ycka3m$(void 0, false);
    else if (Kotlin.isType(message, BoardNameStopHoveringMsg))
      tmp$ = boardName.copy_ycka3m$(false);
    else
      tmp$ = Kotlin.noWhenBranchMatched();
    return tmp$;
  }
  var cssClassName;
  function viewBoardName$lambda$lambda$lambda(closure$makeMsg) {
    return function (it) {
      return listOf(closure$makeMsg(BoardNameStopEditingMsg_getInstance()));
    };
  }
  function viewBoardName$lambda$lambda$lambda_0(closure$makeMsg, closure$boardName) {
    return function (event) {
      var newValue = event.getTargetAttribute_ytbaoo$('value').toString();
      return listOf_0([closure$makeMsg(BoardNameStopEditingMsg_getInstance()), closure$makeMsg(new BoardNameRenameMsg(closure$boardName.boardUuid, closure$boardName.name, newValue))]);
    };
  }
  function viewBoardName$lambda$lambda(closure$makeMsg, closure$boardName) {
    return function ($receiver) {
      onblur($receiver, viewBoardName$lambda$lambda$lambda(closure$makeMsg));
      onchange($receiver, viewBoardName$lambda$lambda$lambda_0(closure$makeMsg, closure$boardName));
      return Unit;
    };
  }
  function viewBoardName$lambda(closure$boardName, closure$makeMsg) {
    return function ($receiver) {
      $receiver.inputText_y74p72$(void 0, void 0, void 0, void 0, true, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, closure$boardName.name, viewBoardName$lambda$lambda(closure$makeMsg, closure$boardName));
      return Unit;
    };
  }
  function viewBoardName$lambda_0(closure$makeMsg) {
    return function (it) {
      return listOf(closure$makeMsg(BoardNameStartHoveringMsg_getInstance()));
    };
  }
  function viewBoardName$lambda_1(closure$makeMsg) {
    return function (it) {
      return listOf(closure$makeMsg(BoardNameStopHoveringMsg_getInstance()));
    };
  }
  function viewBoardName$lambda$lambda$lambda_1(closure$makeMsg) {
    return function (it) {
      return listOf(closure$makeMsg(BoardNameStartEditingMsg_getInstance()));
    };
  }
  function viewBoardName$lambda$lambda_0(closure$makeMsg) {
    return function ($receiver) {
      onclick($receiver, viewBoardName$lambda$lambda$lambda_1(closure$makeMsg));
      $receiver.unaryPlus_pdl1vz$('Edit');
      return Unit;
    };
  }
  function viewBoardName$lambda_2(closure$boardName, closure$makeMsg) {
    return function ($receiver) {
      $receiver.unaryPlus_pdl1vz$(closure$boardName.name);
      if (closure$boardName.isEditButtonShown) {
        $receiver.button_2lxa1r$(void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, viewBoardName$lambda$lambda_0(closure$makeMsg));
      }
      return Unit;
    };
  }
  function viewBoardName($receiver, boardName, makeMsg) {
    if (boardName.isEditingInProgress) {
      $receiver.dialog_rmrn7i$('.wipcards-board-name', void 0, void 0, void 0, void 0, void 0, void 0, void 0, true, void 0, void 0, void 0, void 0, void 0, viewBoardName$lambda(boardName, makeMsg));
    }
     else {
      onmouseenter($receiver, viewBoardName$lambda_0(makeMsg));
      onmouseleave($receiver, viewBoardName$lambda_1(makeMsg));
      $receiver.h1_qckjfy$('.wipcards-board-name', void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, viewBoardName$lambda_2(boardName, makeMsg));
    }
  }
  function boardNameStyles$lambda$lambda($receiver) {
    borderColor($receiver, colors.lightseagreen);
    fontSize($receiver, get_px(22));
    fontWeight($receiver, EFontWeight.bold);
    return Unit;
  }
  function boardNameStyles$lambda($receiver) {
    backgroundColor($receiver, colors.lightseagreen);
    borderColor($receiver, colors.lightseagreen);
    display($receiver, EDisplay.inlineTable);
    padding($receiver, get_px(2));
    position($receiver, EPosition.relative);
    $receiver.invoke_k851pc$('input', boardNameStyles$lambda$lambda);
    return Unit;
  }
  function boardNameStyles$lambda_0($receiver) {
    fontSize($receiver, get_px(25));
    margin($receiver, get_px(5), get_px(0), get_px(5), get_px(5));
    return Unit;
  }
  function boardNameStyles($receiver) {
    $receiver.invoke_k851pc$('dialog.wipcards-board-name', boardNameStyles$lambda);
    $receiver.invoke_k851pc$('h1.wipcards-board-name', boardNameStyles$lambda_0);
  }
  function Board_0(uuid, name) {
    this.uuid = uuid;
    this.name = name;
  }
  function Board$problems$lambda$lambda() {
    return 'Board name must not be empty.';
  }
  function Board$problems$lambda$lambda_0() {
    return 'Board name must not be blank.';
  }
  function Board$problems$lambda$lambda_1() {
    return 'Board name limited to 100 characters.';
  }
  function Board$problems$lambda$lambda_2() {
    return 'Board must have at least two columns.';
  }
  function Board$problems$lambda$lambda_3() {
    return 'Columns must have unique headings within their board.';
  }
  Board_0.prototype.problems_ek6tvh$ = function (domain) {
    var columns = domain.columns_3yv1mr$(this);
    var tmp$ = addIf(addIf(addIf(addIf(emptyList(), this.name.length === 0, Board$problems$lambda$lambda), isBlank(this.name), Board$problems$lambda$lambda_0), this.name.length > 100, Board$problems$lambda$lambda_1), columns.size < 2, Board$problems$lambda$lambda_2);
    var destination = ArrayList_init_1(collectionSizeOrDefault(columns, 10));
    var tmp$_0;
    tmp$_0 = columns.iterator();
    while (tmp$_0.hasNext()) {
      var item = tmp$_0.next();
      destination.add_11rb$(item.heading);
    }
    return addIf(tmp$, toSet(destination).size < columns.size, Board$problems$lambda$lambda_3);
  };
  Board_0.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'Board',
    interfaces: []
  };
  Board_0.prototype.component1 = function () {
    return this.uuid;
  };
  Board_0.prototype.component2 = function () {
    return this.name;
  };
  Board_0.prototype.copy_omkg7$ = function (uuid, name) {
    return new Board_0(uuid === void 0 ? this.uuid : uuid, name === void 0 ? this.name : name);
  };
  Board_0.prototype.toString = function () {
    return 'Board(uuid=' + Kotlin.toString(this.uuid) + (', name=' + Kotlin.toString(this.name)) + ')';
  };
  Board_0.prototype.hashCode = function () {
    var result = 0;
    result = result * 31 + Kotlin.hashCode(this.uuid) | 0;
    result = result * 31 + Kotlin.hashCode(this.name) | 0;
    return result;
  };
  Board_0.prototype.equals = function (other) {
    return this === other || (other !== null && (typeof other === 'object' && (Object.getPrototypeOf(this) === Object.getPrototypeOf(other) && (Kotlin.equals(this.uuid, other.uuid) && Kotlin.equals(this.name, other.name)))));
  };
  function Card(uuid, title, details) {
    this.uuid = uuid;
    this.title = title;
    this.details = details;
  }
  function Card$problems$lambda$lambda() {
    return 'Card title name must not be empty.';
  }
  function Card$problems$lambda$lambda_0() {
    return 'Card title must not be blank.';
  }
  function Card$problems$lambda$lambda_1() {
    return 'Card title limited to 100 characters.';
  }
  Card.prototype.problems_ek6tvh$ = function (domain) {
    return addIf(addIf(addIf(emptyList(), this.title.length === 0, Card$problems$lambda$lambda), isBlank(this.title), Card$problems$lambda$lambda_0), this.title.length > 100, Card$problems$lambda$lambda_1);
  };
  Card.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'Card',
    interfaces: []
  };
  Card.prototype.component1 = function () {
    return this.uuid;
  };
  Card.prototype.component2 = function () {
    return this.title;
  };
  Card.prototype.component3 = function () {
    return this.details;
  };
  Card.prototype.copy_k6w4gt$ = function (uuid, title, details) {
    return new Card(uuid === void 0 ? this.uuid : uuid, title === void 0 ? this.title : title, details === void 0 ? this.details : details);
  };
  Card.prototype.toString = function () {
    return 'Card(uuid=' + Kotlin.toString(this.uuid) + (', title=' + Kotlin.toString(this.title)) + (', details=' + Kotlin.toString(this.details)) + ')';
  };
  Card.prototype.hashCode = function () {
    var result = 0;
    result = result * 31 + Kotlin.hashCode(this.uuid) | 0;
    result = result * 31 + Kotlin.hashCode(this.title) | 0;
    result = result * 31 + Kotlin.hashCode(this.details) | 0;
    return result;
  };
  Card.prototype.equals = function (other) {
    return this === other || (other !== null && (typeof other === 'object' && (Object.getPrototypeOf(this) === Object.getPrototypeOf(other) && (Kotlin.equals(this.uuid, other.uuid) && Kotlin.equals(this.title, other.title) && Kotlin.equals(this.details, other.details)))));
  };
  function Column(uuid, heading) {
    this.uuid = uuid;
    this.heading = heading;
  }
  function Column$problems$lambda$lambda() {
    return 'Column heading name must not be empty.';
  }
  function Column$problems$lambda$lambda_0() {
    return 'Column heading must not be blank.';
  }
  function Column$problems$lambda$lambda_1() {
    return 'Column heading limited to 25 characters.';
  }
  Column.prototype.problems_ek6tvh$ = function (domain) {
    return addIf(addIf(addIf(emptyList(), this.heading.length === 0, Column$problems$lambda$lambda), isBlank(this.heading), Column$problems$lambda$lambda_0), this.heading.length > 25, Column$problems$lambda$lambda_1);
  };
  Column.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'Column',
    interfaces: []
  };
  Column.prototype.component1 = function () {
    return this.uuid;
  };
  Column.prototype.component2 = function () {
    return this.heading;
  };
  Column.prototype.copy_s7bj91$ = function (uuid, heading) {
    return new Column(uuid === void 0 ? this.uuid : uuid, heading === void 0 ? this.heading : heading);
  };
  Column.prototype.toString = function () {
    return 'Column(uuid=' + Kotlin.toString(this.uuid) + (', heading=' + Kotlin.toString(this.heading)) + ')';
  };
  Column.prototype.hashCode = function () {
    var result = 0;
    result = result * 31 + Kotlin.hashCode(this.uuid) | 0;
    result = result * 31 + Kotlin.hashCode(this.heading) | 0;
    return result;
  };
  Column.prototype.equals = function (other) {
    return this === other || (other !== null && (typeof other === 'object' && (Object.getPrototypeOf(this) === Object.getPrototypeOf(other) && (Kotlin.equals(this.uuid, other.uuid) && Kotlin.equals(this.heading, other.heading)))));
  };
  function User(uuid, name) {
    this.uuid = uuid;
    this.name = name;
  }
  function User$problems$lambda$lambda() {
    return 'User name must not be empty.';
  }
  function User$problems$lambda$lambda_0() {
    return 'User name must not be blank.';
  }
  function User$problems$lambda$lambda_1() {
    return 'User name limited to 100 characters.';
  }
  User.prototype.problems_ek6tvh$ = function (domain) {
    return addIf(addIf(addIf(emptyList(), this.name.length === 0, User$problems$lambda$lambda), isBlank(this.name), User$problems$lambda$lambda_0), this.name.length > 100, User$problems$lambda$lambda_1);
  };
  User.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'User',
    interfaces: []
  };
  User.prototype.component1 = function () {
    return this.uuid;
  };
  User.prototype.component2 = function () {
    return this.name;
  };
  User.prototype.copy_zai29i$ = function (uuid, name) {
    return new User(uuid === void 0 ? this.uuid : uuid, name === void 0 ? this.name : name);
  };
  User.prototype.toString = function () {
    return 'User(uuid=' + Kotlin.toString(this.uuid) + (', name=' + Kotlin.toString(this.name)) + ')';
  };
  User.prototype.hashCode = function () {
    var result = 0;
    result = result * 31 + Kotlin.hashCode(this.uuid) | 0;
    result = result * 31 + Kotlin.hashCode(this.name) | 0;
    return result;
  };
  User.prototype.equals = function (other) {
    return this === other || (other !== null && (typeof other === 'object' && (Object.getPrototypeOf(this) === Object.getPrototypeOf(other) && (Kotlin.equals(this.uuid, other.uuid) && Kotlin.equals(this.name, other.name)))));
  };
  function Concepts(boards, cards, columns, users) {
    if (boards === void 0) {
      boards = emptyMap();
    }
    if (cards === void 0) {
      cards = emptyMap();
    }
    if (columns === void 0) {
      columns = emptyMap();
    }
    if (users === void 0) {
      users = emptyMap();
    }
    this.boards = boards;
    this.cards = cards;
    this.columns = columns;
    this.users = users;
  }
  Concepts.prototype.withBoardAdded_702jzg$ = function (board) {
    return this.copy_7hpub0$(plus(this.boards, to(board.uuid, board)));
  };
  Concepts.prototype.withBoardRemoved_vhpctj$ = function (boardUuid) {
    return this.copy_7hpub0$(minus(this.boards, boardUuid));
  };
  Concepts.prototype.withBoardUpdated_702jzg$ = function (board) {
    return this.copy_7hpub0$(plus(this.boards, to(board.uuid, board)));
  };
  Concepts.prototype.withCardAdded_ik1hmy$ = function (card) {
    return this.copy_7hpub0$(void 0, plus(this.cards, to(card.uuid, card)));
  };
  Concepts.prototype.withCardRemoved_852g1t$ = function (cardUuid) {
    return this.copy_7hpub0$(void 0, minus(this.cards, cardUuid));
  };
  Concepts.prototype.withCardUpdated_ik1hmy$ = function (card) {
    return this.copy_7hpub0$(void 0, plus(this.cards, to(card.uuid, card)));
  };
  Concepts.prototype.withColumnAdded_4g3rdc$ = function (column) {
    return this.copy_7hpub0$(void 0, void 0, plus(this.columns, to(column.uuid, column)));
  };
  Concepts.prototype.withColumnRemoved_3c8knb$ = function (columnUuid) {
    return this.copy_7hpub0$(void 0, void 0, minus(this.columns, columnUuid));
  };
  Concepts.prototype.withColumnUpdated_4g3rdc$ = function (column) {
    return this.copy_7hpub0$(void 0, void 0, plus(this.columns, to(column.uuid, column)));
  };
  Concepts.prototype.withUserAdded_ikdcg5$ = function (user) {
    return this.copy_7hpub0$(void 0, void 0, void 0, plus(this.users, to(user.uuid, user)));
  };
  Concepts.prototype.withUserRemoved_7uuwws$ = function (userUuid) {
    return this.copy_7hpub0$(void 0, void 0, void 0, minus(this.users, userUuid));
  };
  Concepts.prototype.withUserUpdated_ikdcg5$ = function (user) {
    return this.copy_7hpub0$(void 0, void 0, void 0, plus(this.users, to(user.uuid, user)));
  };
  Concepts.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'Concepts',
    interfaces: []
  };
  Concepts.prototype.component1 = function () {
    return this.boards;
  };
  Concepts.prototype.component2 = function () {
    return this.cards;
  };
  Concepts.prototype.component3 = function () {
    return this.columns;
  };
  Concepts.prototype.component4 = function () {
    return this.users;
  };
  Concepts.prototype.copy_7hpub0$ = function (boards, cards, columns, users) {
    return new Concepts(boards === void 0 ? this.boards : boards, cards === void 0 ? this.cards : cards, columns === void 0 ? this.columns : columns, users === void 0 ? this.users : users);
  };
  Concepts.prototype.toString = function () {
    return 'Concepts(boards=' + Kotlin.toString(this.boards) + (', cards=' + Kotlin.toString(this.cards)) + (', columns=' + Kotlin.toString(this.columns)) + (', users=' + Kotlin.toString(this.users)) + ')';
  };
  Concepts.prototype.hashCode = function () {
    var result = 0;
    result = result * 31 + Kotlin.hashCode(this.boards) | 0;
    result = result * 31 + Kotlin.hashCode(this.cards) | 0;
    result = result * 31 + Kotlin.hashCode(this.columns) | 0;
    result = result * 31 + Kotlin.hashCode(this.users) | 0;
    return result;
  };
  Concepts.prototype.equals = function (other) {
    return this === other || (other !== null && (typeof other === 'object' && (Object.getPrototypeOf(this) === Object.getPrototypeOf(other) && (Kotlin.equals(this.boards, other.boards) && Kotlin.equals(this.cards, other.cards) && Kotlin.equals(this.columns, other.columns) && Kotlin.equals(this.users, other.users)))));
  };
  function Connections(containedByBoard, containedByColumn, containsCard, containsColumn, ownedByUser, ownsCard) {
    if (containedByBoard === void 0) {
      containedByBoard = emptyMap();
    }
    if (containedByColumn === void 0) {
      containedByColumn = emptyMap();
    }
    if (containsCard === void 0) {
      containsCard = emptyMap();
    }
    if (containsColumn === void 0) {
      containsColumn = emptyMap();
    }
    if (ownedByUser === void 0) {
      ownedByUser = emptyMap();
    }
    if (ownsCard === void 0) {
      ownsCard = emptyMap();
    }
    this.containedByBoard = containedByBoard;
    this.containedByColumn = containedByColumn;
    this.containsCard = containsCard;
    this.containsColumn = containsColumn;
    this.ownedByUser = ownedByUser;
    this.ownsCard = ownsCard;
  }
  Connections.prototype.withBoardContainsColumn_itv2vk$ = function (board, column) {
    var tmp$ = plus(this.containedByBoard, to(column.uuid, board.uuid));
    var tmp$_0 = void 0;
    var tmp$_1 = void 0;
    var tmp$_2 = this.containsColumn;
    var tmp$_3 = board.uuid;
    var $receiver = this.containsColumn;
    var key = board.uuid;
    var tmp$_4;
    return this.copy_2gtvff$(tmp$, tmp$_0, tmp$_1, plus(tmp$_2, to(tmp$_3, plus_0((tmp$_4 = $receiver.get_11rb$(key)) != null ? tmp$_4 : emptyList(), column.uuid))));
  };
  Connections.prototype.withBoardNoLongerContainsColumn_s948da$ = function (boardUuid, columnUuid) {
    var tmp$;
    return this.copy_2gtvff$(minus(this.containedByBoard, columnUuid), void 0, void 0, plus(this.containsColumn, to(boardUuid, minus_0((tmp$ = this.containsColumn.get_11rb$(boardUuid)) != null ? tmp$ : emptyList(), columnUuid))));
  };
  Connections.prototype.withColumnContainsCard_leauoi$ = function (column, card) {
    var tmp$ = void 0;
    var tmp$_0 = plus(this.containedByColumn, to(card.uuid, column.uuid));
    var tmp$_1 = this.containsCard;
    var tmp$_2 = column.uuid;
    var $receiver = this.containsCard;
    var key = column.uuid;
    var tmp$_3;
    return this.copy_2gtvff$(tmp$, tmp$_0, plus(tmp$_1, to(tmp$_2, plus_0((tmp$_3 = $receiver.get_11rb$(key)) != null ? tmp$_3 : emptyList(), card.uuid))));
  };
  Connections.prototype.withColumnNoLongerContainsCard_5p3oku$ = function (columnUuid, cardUuid) {
    var tmp$;
    return this.copy_2gtvff$(void 0, minus(this.containedByColumn, cardUuid), plus(this.containsCard, to(columnUuid, minus_0((tmp$ = this.containsCard.get_11rb$(columnUuid)) != null ? tmp$ : emptyList(), cardUuid))));
  };
  Connections.prototype.withUserOwnsCard_dd8iot$ = function (user, card) {
    var tmp$ = void 0;
    var tmp$_0 = void 0;
    var tmp$_1 = void 0;
    var tmp$_2 = void 0;
    var tmp$_3 = plus(this.ownedByUser, to(card.uuid, user.uuid));
    var tmp$_4 = this.ownsCard;
    var tmp$_5 = user.uuid;
    var $receiver = this.ownsCard;
    var key = user.uuid;
    var tmp$_6;
    return this.copy_2gtvff$(tmp$, tmp$_0, tmp$_1, tmp$_2, tmp$_3, plus(tmp$_4, to(tmp$_5, plus_0((tmp$_6 = $receiver.get_11rb$(key)) != null ? tmp$_6 : emptyList(), card.uuid))));
  };
  Connections.prototype.withUserNoLongerOwnsCard_1cf56h$ = function (userUuid, cardUuid) {
    var tmp$;
    return this.copy_2gtvff$(void 0, void 0, void 0, void 0, minus(this.ownedByUser, cardUuid), plus(this.ownsCard, to(userUuid, minus_0((tmp$ = this.ownsCard.get_11rb$(userUuid)) != null ? tmp$ : emptyList(), cardUuid))));
  };
  Connections.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'Connections',
    interfaces: []
  };
  Connections.prototype.component1 = function () {
    return this.containedByBoard;
  };
  Connections.prototype.component2 = function () {
    return this.containedByColumn;
  };
  Connections.prototype.component3 = function () {
    return this.containsCard;
  };
  Connections.prototype.component4 = function () {
    return this.containsColumn;
  };
  Connections.prototype.component5 = function () {
    return this.ownedByUser;
  };
  Connections.prototype.component6 = function () {
    return this.ownsCard;
  };
  Connections.prototype.copy_2gtvff$ = function (containedByBoard, containedByColumn, containsCard, containsColumn, ownedByUser, ownsCard) {
    return new Connections(containedByBoard === void 0 ? this.containedByBoard : containedByBoard, containedByColumn === void 0 ? this.containedByColumn : containedByColumn, containsCard === void 0 ? this.containsCard : containsCard, containsColumn === void 0 ? this.containsColumn : containsColumn, ownedByUser === void 0 ? this.ownedByUser : ownedByUser, ownsCard === void 0 ? this.ownsCard : ownsCard);
  };
  Connections.prototype.toString = function () {
    return 'Connections(containedByBoard=' + Kotlin.toString(this.containedByBoard) + (', containedByColumn=' + Kotlin.toString(this.containedByColumn)) + (', containsCard=' + Kotlin.toString(this.containsCard)) + (', containsColumn=' + Kotlin.toString(this.containsColumn)) + (', ownedByUser=' + Kotlin.toString(this.ownedByUser)) + (', ownsCard=' + Kotlin.toString(this.ownsCard)) + ')';
  };
  Connections.prototype.hashCode = function () {
    var result = 0;
    result = result * 31 + Kotlin.hashCode(this.containedByBoard) | 0;
    result = result * 31 + Kotlin.hashCode(this.containedByColumn) | 0;
    result = result * 31 + Kotlin.hashCode(this.containsCard) | 0;
    result = result * 31 + Kotlin.hashCode(this.containsColumn) | 0;
    result = result * 31 + Kotlin.hashCode(this.ownedByUser) | 0;
    result = result * 31 + Kotlin.hashCode(this.ownsCard) | 0;
    return result;
  };
  Connections.prototype.equals = function (other) {
    return this === other || (other !== null && (typeof other === 'object' && (Object.getPrototypeOf(this) === Object.getPrototypeOf(other) && (Kotlin.equals(this.containedByBoard, other.containedByBoard) && Kotlin.equals(this.containedByColumn, other.containedByColumn) && Kotlin.equals(this.containsCard, other.containsCard) && Kotlin.equals(this.containsColumn, other.containsColumn) && Kotlin.equals(this.ownedByUser, other.ownedByUser) && Kotlin.equals(this.ownsCard, other.ownsCard)))));
  };
  function WipCardsDomain(concepts, connections) {
    if (concepts === void 0)
      concepts = new Concepts();
    if (connections === void 0)
      connections = new Connections();
    this.concepts = concepts;
    this.connections = connections;
    this.problems = addIf(emptyList(), this.concepts.boards.isEmpty(), WipCardsDomain$problems$lambda);
  }
  function WipCardsDomain$BoardChange($outer, board) {
    this.$outer = $outer;
    this.board_0 = board;
  }
  WipCardsDomain$BoardChange.prototype.added = function () {
    return this.$outer.copy_83r80y$(this.$outer.concepts.withBoardAdded_702jzg$(this.board_0));
  };
  WipCardsDomain$BoardChange.prototype.contains_4g3rdc$ = function (column) {
    return this.$outer.copy_83r80y$(void 0, this.$outer.connections.withBoardContainsColumn_itv2vk$(this.board_0, column));
  };
  WipCardsDomain$BoardChange.prototype.noLongerContains_4g3rdc$ = function (column) {
    return this.$outer.copy_83r80y$(void 0, this.$outer.connections.withBoardNoLongerContainsColumn_s948da$(this.board_0.uuid, column.uuid));
  };
  WipCardsDomain$BoardChange.prototype.removed = function () {
    return this.$outer.copy_83r80y$(this.$outer.concepts.withBoardRemoved_vhpctj$(this.board_0.uuid));
  };
  WipCardsDomain$BoardChange.prototype.updated = function () {
    return this.$outer.copy_83r80y$(this.$outer.concepts.withBoardUpdated_702jzg$(this.board_0));
  };
  WipCardsDomain$BoardChange.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'BoardChange',
    interfaces: []
  };
  function WipCardsDomain$CardChange($outer, card) {
    this.$outer = $outer;
    this.card_0 = card;
  }
  WipCardsDomain$CardChange.prototype.added = function () {
    return this.$outer.copy_83r80y$(this.$outer.concepts.withCardAdded_ik1hmy$(this.card_0));
  };
  WipCardsDomain$CardChange.prototype.removed = function () {
    return this.$outer.copy_83r80y$(this.$outer.concepts.withCardRemoved_852g1t$(this.card_0.uuid));
  };
  WipCardsDomain$CardChange.prototype.updated = function () {
    return this.$outer.copy_83r80y$(this.$outer.concepts.withCardUpdated_ik1hmy$(this.card_0));
  };
  WipCardsDomain$CardChange.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'CardChange',
    interfaces: []
  };
  function WipCardsDomain$ColumnChange($outer, column) {
    this.$outer = $outer;
    this.column_0 = column;
  }
  WipCardsDomain$ColumnChange.prototype.added = function () {
    return this.$outer.copy_83r80y$(this.$outer.concepts.withColumnAdded_4g3rdc$(this.column_0));
  };
  WipCardsDomain$ColumnChange.prototype.contains_ik1hmy$ = function (card) {
    return this.$outer.copy_83r80y$(void 0, this.$outer.connections.withColumnContainsCard_leauoi$(this.column_0, card));
  };
  WipCardsDomain$ColumnChange.prototype.noLongerContains_ik1hmy$ = function (card) {
    return this.$outer.copy_83r80y$(void 0, this.$outer.connections.withColumnNoLongerContainsCard_5p3oku$(this.column_0.uuid, card.uuid));
  };
  WipCardsDomain$ColumnChange.prototype.removed = function () {
    return this.$outer.copy_83r80y$(this.$outer.concepts.withColumnRemoved_3c8knb$(this.column_0.uuid));
  };
  WipCardsDomain$ColumnChange.prototype.updated = function () {
    return this.$outer.copy_83r80y$(this.$outer.concepts.withColumnUpdated_4g3rdc$(this.column_0));
  };
  WipCardsDomain$ColumnChange.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'ColumnChange',
    interfaces: []
  };
  function WipCardsDomain$UserChange($outer, user) {
    this.$outer = $outer;
    this.user_0 = user;
  }
  WipCardsDomain$UserChange.prototype.added = function () {
    return this.$outer.copy_83r80y$(this.$outer.concepts.withUserAdded_ikdcg5$(this.user_0));
  };
  WipCardsDomain$UserChange.prototype.owns_ik1hmy$ = function (card) {
    return this.$outer.copy_83r80y$(void 0, this.$outer.connections.withUserOwnsCard_dd8iot$(this.user_0, card));
  };
  WipCardsDomain$UserChange.prototype.noLongerOwns_ik1hmy$ = function (card) {
    return this.$outer.copy_83r80y$(void 0, this.$outer.connections.withUserNoLongerOwnsCard_1cf56h$(this.user_0.uuid, card.uuid));
  };
  WipCardsDomain$UserChange.prototype.removed = function () {
    return this.$outer.copy_83r80y$(this.$outer.concepts.withUserRemoved_7uuwws$(this.user_0.uuid));
  };
  WipCardsDomain$UserChange.prototype.updated = function () {
    return this.$outer.copy_83r80y$(this.$outer.concepts.withUserUpdated_ikdcg5$(this.user_0));
  };
  WipCardsDomain$UserChange.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'UserChange',
    interfaces: []
  };
  WipCardsDomain.prototype.boardWithUuid_vhpctj$ = function (boardUuid) {
    return this.concepts.boards.get_11rb$(boardUuid);
  };
  WipCardsDomain.prototype.cardWithUuid_852g1t$ = function (cardUuid) {
    return this.concepts.cards.get_11rb$(cardUuid);
  };
  WipCardsDomain.prototype.columnWithUuid_3c8knb$ = function (columnUuid) {
    return this.concepts.columns.get_11rb$(columnUuid);
  };
  WipCardsDomain.prototype.columns_3yv1mr$ = function ($receiver) {
    var $receiver_0 = this.connections.containsColumn;
    var key = $receiver.uuid;
    var tmp$;
    var $receiver_1 = (tmp$ = $receiver_0.get_11rb$(key)) != null ? tmp$ : emptyList();
    var destination = ArrayList_init_1(collectionSizeOrDefault($receiver_1, 10));
    var tmp$_0;
    tmp$_0 = $receiver_1.iterator();
    while (tmp$_0.hasNext()) {
      var item = tmp$_0.next();
      var tmp$_1 = destination.add_11rb$;
      var tmp$_2;
      tmp$_2 = this.concepts.columns.get_11rb$(item);
      if (tmp$_2 == null) {
        throw IllegalStateException_init('Column not found');
      }
      tmp$_1.call(destination, tmp$_2);
    }
    return destination;
  };
  WipCardsDomain.prototype.cards_46zjfl$ = function ($receiver) {
    var $receiver_0 = this.connections.containsCard;
    var key = $receiver.uuid;
    var tmp$;
    var $receiver_1 = (tmp$ = $receiver_0.get_11rb$(key)) != null ? tmp$ : emptyList();
    var destination = ArrayList_init_1(collectionSizeOrDefault($receiver_1, 10));
    var tmp$_0;
    tmp$_0 = $receiver_1.iterator();
    while (tmp$_0.hasNext()) {
      var item = tmp$_0.next();
      var tmp$_1 = destination.add_11rb$;
      var tmp$_2;
      tmp$_2 = this.concepts.cards.get_11rb$(item);
      if (tmp$_2 == null) {
        throw IllegalStateException_init('Card not found');
      }
      tmp$_1.call(destination, tmp$_2);
    }
    return destination;
  };
  WipCardsDomain.prototype.cards_7ala4q$ = function ($receiver) {
    var $receiver_0 = this.connections.ownsCard;
    var key = $receiver.uuid;
    var tmp$;
    var $receiver_1 = (tmp$ = $receiver_0.get_11rb$(key)) != null ? tmp$ : emptyList();
    var destination = ArrayList_init_1(collectionSizeOrDefault($receiver_1, 10));
    var tmp$_0;
    tmp$_0 = $receiver_1.iterator();
    while (tmp$_0.hasNext()) {
      var item = tmp$_0.next();
      var tmp$_1 = destination.add_11rb$;
      var tmp$_2;
      tmp$_2 = this.concepts.cards.get_11rb$(item);
      if (tmp$_2 == null) {
        throw IllegalStateException_init('Card not found');
      }
      tmp$_1.call(destination, tmp$_2);
    }
    return destination;
  };
  WipCardsDomain.prototype.with_702jzg$ = function (board) {
    return new WipCardsDomain$BoardChange(this, board);
  };
  WipCardsDomain.prototype.with_ik1hmy$ = function (card) {
    return new WipCardsDomain$CardChange(this, card);
  };
  WipCardsDomain.prototype.with_4g3rdc$ = function (column) {
    return new WipCardsDomain$ColumnChange(this, column);
  };
  WipCardsDomain.prototype.with_ikdcg5$ = function (user) {
    return new WipCardsDomain$UserChange(this, user);
  };
  function WipCardsDomain$problems$lambda() {
    return 'No boards have been defined.';
  }
  WipCardsDomain.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'WipCardsDomain',
    interfaces: []
  };
  WipCardsDomain.prototype.component1 = function () {
    return this.concepts;
  };
  WipCardsDomain.prototype.component2 = function () {
    return this.connections;
  };
  WipCardsDomain.prototype.copy_83r80y$ = function (concepts, connections) {
    return new WipCardsDomain(concepts === void 0 ? this.concepts : concepts, connections === void 0 ? this.connections : connections);
  };
  WipCardsDomain.prototype.toString = function () {
    return 'WipCardsDomain(concepts=' + Kotlin.toString(this.concepts) + (', connections=' + Kotlin.toString(this.connections)) + ')';
  };
  WipCardsDomain.prototype.hashCode = function () {
    var result = 0;
    result = result * 31 + Kotlin.hashCode(this.concepts) | 0;
    result = result * 31 + Kotlin.hashCode(this.connections) | 0;
    return result;
  };
  WipCardsDomain.prototype.equals = function (other) {
    return this === other || (other !== null && (typeof other === 'object' && (Object.getPrototypeOf(this) === Object.getPrototypeOf(other) && (Kotlin.equals(this.concepts, other.concepts) && Kotlin.equals(this.connections, other.connections)))));
  };
  function CreateBoardAction(boardUuid, name) {
    Action.call(this);
    this.boardUuid = boardUuid;
    this.name = name;
  }
  CreateBoardAction.prototype.apply_11rb$ = function (state) {
    var board = new Board_0(this.boardUuid, this.name);
    return state.with_702jzg$(board).added();
  };
  CreateBoardAction.prototype.compensatingAction = function () {
    return new DeleteBoardAction(this.boardUuid);
  };
  CreateBoardAction.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'CreateBoardAction',
    interfaces: [Action]
  };
  CreateBoardAction.prototype.component1 = function () {
    return this.boardUuid;
  };
  CreateBoardAction.prototype.component2 = function () {
    return this.name;
  };
  CreateBoardAction.prototype.copy_omkg7$ = function (boardUuid, name) {
    return new CreateBoardAction(boardUuid === void 0 ? this.boardUuid : boardUuid, name === void 0 ? this.name : name);
  };
  CreateBoardAction.prototype.toString = function () {
    return 'CreateBoardAction(boardUuid=' + Kotlin.toString(this.boardUuid) + (', name=' + Kotlin.toString(this.name)) + ')';
  };
  CreateBoardAction.prototype.hashCode = function () {
    var result = 0;
    result = result * 31 + Kotlin.hashCode(this.boardUuid) | 0;
    result = result * 31 + Kotlin.hashCode(this.name) | 0;
    return result;
  };
  CreateBoardAction.prototype.equals = function (other) {
    return this === other || (other !== null && (typeof other === 'object' && (Object.getPrototypeOf(this) === Object.getPrototypeOf(other) && (Kotlin.equals(this.boardUuid, other.boardUuid) && Kotlin.equals(this.name, other.name)))));
  };
  function RenameBoardAction(boardUuid, newName, oldName) {
    Action.call(this);
    this.boardUuid = boardUuid;
    this.newName = newName;
    this.oldName = oldName;
  }
  RenameBoardAction.prototype.apply_11rb$ = function (state) {
    var oldBoard = state.boardWithUuid_vhpctj$(this.boardUuid);
    if (!(oldBoard != null)) {
      var message = 'Board not found.';
      throw IllegalStateException_init(message.toString());
    }
    if (!equals(this.oldName, oldBoard.name)) {
      var message_0 = 'Board has already been renamed.';
      throw IllegalStateException_init(message_0.toString());
    }
    var newBoard = oldBoard.copy_omkg7$(void 0, this.newName);
    return state.with_702jzg$(newBoard).updated();
  };
  RenameBoardAction.prototype.compensatingAction = function () {
    return this.copy_t1xr2j$(void 0, this.oldName, this.newName);
  };
  RenameBoardAction.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'RenameBoardAction',
    interfaces: [Action]
  };
  RenameBoardAction.prototype.component1 = function () {
    return this.boardUuid;
  };
  RenameBoardAction.prototype.component2 = function () {
    return this.newName;
  };
  RenameBoardAction.prototype.component3 = function () {
    return this.oldName;
  };
  RenameBoardAction.prototype.copy_t1xr2j$ = function (boardUuid, newName, oldName) {
    return new RenameBoardAction(boardUuid === void 0 ? this.boardUuid : boardUuid, newName === void 0 ? this.newName : newName, oldName === void 0 ? this.oldName : oldName);
  };
  RenameBoardAction.prototype.toString = function () {
    return 'RenameBoardAction(boardUuid=' + Kotlin.toString(this.boardUuid) + (', newName=' + Kotlin.toString(this.newName)) + (', oldName=' + Kotlin.toString(this.oldName)) + ')';
  };
  RenameBoardAction.prototype.hashCode = function () {
    var result = 0;
    result = result * 31 + Kotlin.hashCode(this.boardUuid) | 0;
    result = result * 31 + Kotlin.hashCode(this.newName) | 0;
    result = result * 31 + Kotlin.hashCode(this.oldName) | 0;
    return result;
  };
  RenameBoardAction.prototype.equals = function (other) {
    return this === other || (other !== null && (typeof other === 'object' && (Object.getPrototypeOf(this) === Object.getPrototypeOf(other) && (Kotlin.equals(this.boardUuid, other.boardUuid) && Kotlin.equals(this.newName, other.newName) && Kotlin.equals(this.oldName, other.oldName)))));
  };
  function DeleteBoardAction(boardUuid) {
    Action.call(this);
    this.boardUuid = boardUuid;
  }
  DeleteBoardAction.prototype.apply_11rb$ = function (state) {
    var board = state.boardWithUuid_vhpctj$(this.boardUuid);
    if (!(board != null)) {
      var message = 'Board not found.';
      throw IllegalStateException_init(message.toString());
    }
    return state.with_702jzg$(board).removed();
  };
  DeleteBoardAction.prototype.compensatingAction = function () {
    throw UnsupportedOperationException_init('TODO');
  };
  DeleteBoardAction.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'DeleteBoardAction',
    interfaces: [Action]
  };
  DeleteBoardAction.prototype.component1 = function () {
    return this.boardUuid;
  };
  DeleteBoardAction.prototype.copy_vhpctj$ = function (boardUuid) {
    return new DeleteBoardAction(boardUuid === void 0 ? this.boardUuid : boardUuid);
  };
  DeleteBoardAction.prototype.toString = function () {
    return 'DeleteBoardAction(boardUuid=' + Kotlin.toString(this.boardUuid) + ')';
  };
  DeleteBoardAction.prototype.hashCode = function () {
    var result = 0;
    result = result * 31 + Kotlin.hashCode(this.boardUuid) | 0;
    return result;
  };
  DeleteBoardAction.prototype.equals = function (other) {
    return this === other || (other !== null && (typeof other === 'object' && (Object.getPrototypeOf(this) === Object.getPrototypeOf(other) && Kotlin.equals(this.boardUuid, other.boardUuid))));
  };
  function DeleteColumnAction(boardUuid, columnUuid) {
    Action.call(this);
    this.boardUuid = boardUuid;
    this.columnUuid = columnUuid;
  }
  DeleteColumnAction.prototype.apply_11rb$ = function (state) {
    var board = state.boardWithUuid_vhpctj$(this.boardUuid);
    var column = state.columnWithUuid_3c8knb$(this.columnUuid);
    if (!(board != null)) {
      var message = 'Board not found.';
      throw IllegalStateException_init(message.toString());
    }
    if (!(column != null)) {
      var message_0 = 'Column has already been deleted.';
      throw IllegalStateException_init(message_0.toString());
    }
    var tmp$;
    var accumulator = state;
    tmp$ = state.cards_46zjfl$(column).iterator();
    while (tmp$.hasNext()) {
      var element = tmp$.next();
      accumulator = accumulator.with_4g3rdc$(column).noLongerContains_ik1hmy$(element);
    }
    return accumulator.with_702jzg$(board).noLongerContains_4g3rdc$(column).with_4g3rdc$(column).removed();
  };
  DeleteColumnAction.prototype.compensatingAction = function () {
    throw UnsupportedOperationException_init('TODO');
  };
  DeleteColumnAction.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'DeleteColumnAction',
    interfaces: [Action]
  };
  DeleteColumnAction.prototype.component1 = function () {
    return this.boardUuid;
  };
  DeleteColumnAction.prototype.component2 = function () {
    return this.columnUuid;
  };
  DeleteColumnAction.prototype.copy_s948da$ = function (boardUuid, columnUuid) {
    return new DeleteColumnAction(boardUuid === void 0 ? this.boardUuid : boardUuid, columnUuid === void 0 ? this.columnUuid : columnUuid);
  };
  DeleteColumnAction.prototype.toString = function () {
    return 'DeleteColumnAction(boardUuid=' + Kotlin.toString(this.boardUuid) + (', columnUuid=' + Kotlin.toString(this.columnUuid)) + ')';
  };
  DeleteColumnAction.prototype.hashCode = function () {
    var result = 0;
    result = result * 31 + Kotlin.hashCode(this.boardUuid) | 0;
    result = result * 31 + Kotlin.hashCode(this.columnUuid) | 0;
    return result;
  };
  DeleteColumnAction.prototype.equals = function (other) {
    return this === other || (other !== null && (typeof other === 'object' && (Object.getPrototypeOf(this) === Object.getPrototypeOf(other) && (Kotlin.equals(this.boardUuid, other.boardUuid) && Kotlin.equals(this.columnUuid, other.columnUuid)))));
  };
  function ChangeCardDetailsAction(cardUuid, newDetails, oldDetails) {
    Action.call(this);
    this.cardUuid = cardUuid;
    this.newDetails = newDetails;
    this.oldDetails = oldDetails;
  }
  ChangeCardDetailsAction.prototype.apply_11rb$ = function (state) {
    var oldCard = state.cardWithUuid_852g1t$(this.cardUuid);
    if (!(oldCard != null)) {
      var message = 'Card not found.';
      throw IllegalStateException_init(message.toString());
    }
    if (!equals(this.oldDetails, oldCard.details)) {
      var message_0 = 'Card details have already been changed.';
      throw IllegalStateException_init(message_0.toString());
    }
    var newCard = oldCard.copy_k6w4gt$(void 0, void 0, this.newDetails);
    return state.with_ik1hmy$(newCard).updated();
  };
  ChangeCardDetailsAction.prototype.compensatingAction = function () {
    return this.copy_k6w4gt$(void 0, this.oldDetails, this.newDetails);
  };
  ChangeCardDetailsAction.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'ChangeCardDetailsAction',
    interfaces: [Action]
  };
  ChangeCardDetailsAction.prototype.component1 = function () {
    return this.cardUuid;
  };
  ChangeCardDetailsAction.prototype.component2 = function () {
    return this.newDetails;
  };
  ChangeCardDetailsAction.prototype.component3 = function () {
    return this.oldDetails;
  };
  ChangeCardDetailsAction.prototype.copy_k6w4gt$ = function (cardUuid, newDetails, oldDetails) {
    return new ChangeCardDetailsAction(cardUuid === void 0 ? this.cardUuid : cardUuid, newDetails === void 0 ? this.newDetails : newDetails, oldDetails === void 0 ? this.oldDetails : oldDetails);
  };
  ChangeCardDetailsAction.prototype.toString = function () {
    return 'ChangeCardDetailsAction(cardUuid=' + Kotlin.toString(this.cardUuid) + (', newDetails=' + Kotlin.toString(this.newDetails)) + (', oldDetails=' + Kotlin.toString(this.oldDetails)) + ')';
  };
  ChangeCardDetailsAction.prototype.hashCode = function () {
    var result = 0;
    result = result * 31 + Kotlin.hashCode(this.cardUuid) | 0;
    result = result * 31 + Kotlin.hashCode(this.newDetails) | 0;
    result = result * 31 + Kotlin.hashCode(this.oldDetails) | 0;
    return result;
  };
  ChangeCardDetailsAction.prototype.equals = function (other) {
    return this === other || (other !== null && (typeof other === 'object' && (Object.getPrototypeOf(this) === Object.getPrototypeOf(other) && (Kotlin.equals(this.cardUuid, other.cardUuid) && Kotlin.equals(this.newDetails, other.newDetails) && Kotlin.equals(this.oldDetails, other.oldDetails)))));
  };
  function ChangeCardTitleAction(cardUuid, newTitle, oldTitle) {
    Action.call(this);
    this.cardUuid = cardUuid;
    this.newTitle = newTitle;
    this.oldTitle = oldTitle;
  }
  ChangeCardTitleAction.prototype.apply_11rb$ = function (state) {
    var oldCard = state.cardWithUuid_852g1t$(this.cardUuid);
    if (!(oldCard != null)) {
      var message = 'Card not found.';
      throw IllegalStateException_init(message.toString());
    }
    if (!equals(this.oldTitle, oldCard.title)) {
      var message_0 = 'Card title has already been changed.';
      throw IllegalStateException_init(message_0.toString());
    }
    var newCard = oldCard.copy_k6w4gt$(void 0, this.newTitle);
    return state.with_ik1hmy$(newCard).updated();
  };
  ChangeCardTitleAction.prototype.compensatingAction = function () {
    return this.copy_k6w4gt$(void 0, this.oldTitle, this.newTitle);
  };
  ChangeCardTitleAction.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'ChangeCardTitleAction',
    interfaces: [Action]
  };
  ChangeCardTitleAction.prototype.component1 = function () {
    return this.cardUuid;
  };
  ChangeCardTitleAction.prototype.component2 = function () {
    return this.newTitle;
  };
  ChangeCardTitleAction.prototype.component3 = function () {
    return this.oldTitle;
  };
  ChangeCardTitleAction.prototype.copy_k6w4gt$ = function (cardUuid, newTitle, oldTitle) {
    return new ChangeCardTitleAction(cardUuid === void 0 ? this.cardUuid : cardUuid, newTitle === void 0 ? this.newTitle : newTitle, oldTitle === void 0 ? this.oldTitle : oldTitle);
  };
  ChangeCardTitleAction.prototype.toString = function () {
    return 'ChangeCardTitleAction(cardUuid=' + Kotlin.toString(this.cardUuid) + (', newTitle=' + Kotlin.toString(this.newTitle)) + (', oldTitle=' + Kotlin.toString(this.oldTitle)) + ')';
  };
  ChangeCardTitleAction.prototype.hashCode = function () {
    var result = 0;
    result = result * 31 + Kotlin.hashCode(this.cardUuid) | 0;
    result = result * 31 + Kotlin.hashCode(this.newTitle) | 0;
    result = result * 31 + Kotlin.hashCode(this.oldTitle) | 0;
    return result;
  };
  ChangeCardTitleAction.prototype.equals = function (other) {
    return this === other || (other !== null && (typeof other === 'object' && (Object.getPrototypeOf(this) === Object.getPrototypeOf(other) && (Kotlin.equals(this.cardUuid, other.cardUuid) && Kotlin.equals(this.newTitle, other.newTitle) && Kotlin.equals(this.oldTitle, other.oldTitle)))));
  };
  function ChangeColumnHeadingAction(columnUuid, newHeading, oldHeading) {
    Action.call(this);
    this.columnUuid = columnUuid;
    this.newHeading = newHeading;
    this.oldHeading = oldHeading;
  }
  ChangeColumnHeadingAction.prototype.apply_11rb$ = function (state) {
    var column = state.columnWithUuid_3c8knb$(this.columnUuid);
    if (!(column != null)) {
      var message = 'Column not found.';
      throw IllegalStateException_init(message.toString());
    }
    if (!equals(this.oldHeading, column.heading)) {
      var message_0 = 'Column heading has already been changed.';
      throw IllegalStateException_init(message_0.toString());
    }
    return state.with_4g3rdc$(column).updated();
  };
  ChangeColumnHeadingAction.prototype.compensatingAction = function () {
    return this.copy_n22h0d$(void 0, this.oldHeading, this.newHeading);
  };
  ChangeColumnHeadingAction.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'ChangeColumnHeadingAction',
    interfaces: [Action]
  };
  ChangeColumnHeadingAction.prototype.component1 = function () {
    return this.columnUuid;
  };
  ChangeColumnHeadingAction.prototype.component2 = function () {
    return this.newHeading;
  };
  ChangeColumnHeadingAction.prototype.component3 = function () {
    return this.oldHeading;
  };
  ChangeColumnHeadingAction.prototype.copy_n22h0d$ = function (columnUuid, newHeading, oldHeading) {
    return new ChangeColumnHeadingAction(columnUuid === void 0 ? this.columnUuid : columnUuid, newHeading === void 0 ? this.newHeading : newHeading, oldHeading === void 0 ? this.oldHeading : oldHeading);
  };
  ChangeColumnHeadingAction.prototype.toString = function () {
    return 'ChangeColumnHeadingAction(columnUuid=' + Kotlin.toString(this.columnUuid) + (', newHeading=' + Kotlin.toString(this.newHeading)) + (', oldHeading=' + Kotlin.toString(this.oldHeading)) + ')';
  };
  ChangeColumnHeadingAction.prototype.hashCode = function () {
    var result = 0;
    result = result * 31 + Kotlin.hashCode(this.columnUuid) | 0;
    result = result * 31 + Kotlin.hashCode(this.newHeading) | 0;
    result = result * 31 + Kotlin.hashCode(this.oldHeading) | 0;
    return result;
  };
  ChangeColumnHeadingAction.prototype.equals = function (other) {
    return this === other || (other !== null && (typeof other === 'object' && (Object.getPrototypeOf(this) === Object.getPrototypeOf(other) && (Kotlin.equals(this.columnUuid, other.columnUuid) && Kotlin.equals(this.newHeading, other.newHeading) && Kotlin.equals(this.oldHeading, other.oldHeading)))));
  };
  function DeleteCardAction(columnUuid, cardUuid, originalDetails, originalTitle) {
    Action.call(this);
    this.columnUuid = columnUuid;
    this.cardUuid = cardUuid;
    this.originalDetails = originalDetails;
    this.originalTitle = originalTitle;
  }
  DeleteCardAction.prototype.apply_11rb$ = function (state) {
    var column = state.columnWithUuid_3c8knb$(this.columnUuid);
    var card = state.cardWithUuid_852g1t$(this.cardUuid);
    if (!(column != null)) {
      var message = 'Column not found.';
      throw IllegalStateException_init(message.toString());
    }
    if (!(card != null)) {
      var message_0 = 'Card not found.';
      throw IllegalStateException_init(message_0.toString());
    }
    return state.with_4g3rdc$(column).noLongerContains_ik1hmy$(card).with_ik1hmy$(card).removed();
  };
  DeleteCardAction.prototype.compensatingAction = function () {
    throw UnsupportedOperationException_init('TODO');
  };
  DeleteCardAction.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'DeleteCardAction',
    interfaces: [Action]
  };
  DeleteCardAction.prototype.component1 = function () {
    return this.columnUuid;
  };
  DeleteCardAction.prototype.component2 = function () {
    return this.cardUuid;
  };
  DeleteCardAction.prototype.component3 = function () {
    return this.originalDetails;
  };
  DeleteCardAction.prototype.component4 = function () {
    return this.originalTitle;
  };
  DeleteCardAction.prototype.copy_bzv4hi$ = function (columnUuid, cardUuid, originalDetails, originalTitle) {
    return new DeleteCardAction(columnUuid === void 0 ? this.columnUuid : columnUuid, cardUuid === void 0 ? this.cardUuid : cardUuid, originalDetails === void 0 ? this.originalDetails : originalDetails, originalTitle === void 0 ? this.originalTitle : originalTitle);
  };
  DeleteCardAction.prototype.toString = function () {
    return 'DeleteCardAction(columnUuid=' + Kotlin.toString(this.columnUuid) + (', cardUuid=' + Kotlin.toString(this.cardUuid)) + (', originalDetails=' + Kotlin.toString(this.originalDetails)) + (', originalTitle=' + Kotlin.toString(this.originalTitle)) + ')';
  };
  DeleteCardAction.prototype.hashCode = function () {
    var result = 0;
    result = result * 31 + Kotlin.hashCode(this.columnUuid) | 0;
    result = result * 31 + Kotlin.hashCode(this.cardUuid) | 0;
    result = result * 31 + Kotlin.hashCode(this.originalDetails) | 0;
    result = result * 31 + Kotlin.hashCode(this.originalTitle) | 0;
    return result;
  };
  DeleteCardAction.prototype.equals = function (other) {
    return this === other || (other !== null && (typeof other === 'object' && (Object.getPrototypeOf(this) === Object.getPrototypeOf(other) && (Kotlin.equals(this.columnUuid, other.columnUuid) && Kotlin.equals(this.cardUuid, other.cardUuid) && Kotlin.equals(this.originalDetails, other.originalDetails) && Kotlin.equals(this.originalTitle, other.originalTitle)))));
  };
  function Action() {
  }
  Action.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'Action',
    interfaces: []
  };
  function addIf($receiver, condition, getElement) {
    return condition ? plus_0($receiver, getElement()) : $receiver;
  }
  function Uuid(uuid) {
    this.uuid = uuid;
  }
  Uuid.prototype.toString = function () {
    return this.uuid;
  };
  Uuid.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'Uuid',
    interfaces: []
  };
  Uuid.prototype.component1 = function () {
    return this.uuid;
  };
  Uuid.prototype.copy_61zpoe$ = function (uuid) {
    return new Uuid(uuid === void 0 ? this.uuid : uuid);
  };
  Uuid.prototype.hashCode = function () {
    var result = 0;
    result = result * 31 + Kotlin.hashCode(this.uuid) | 0;
    return result;
  };
  Uuid.prototype.equals = function (other) {
    return this === other || (other !== null && (typeof other === 'object' && (Object.getPrototypeOf(this) === Object.getPrototypeOf(other) && Kotlin.equals(this.uuid, other.uuid))));
  };
  function WipCardsMsg() {
  }
  WipCardsMsg.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'WipCardsMsg',
    interfaces: []
  };
  function RenameColumnMsg(columnIndex, newName) {
    WipCardsMsg.call(this);
    this.columnIndex = columnIndex;
    this.newName = newName;
  }
  RenameColumnMsg.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'RenameColumnMsg',
    interfaces: [WipCardsMsg]
  };
  RenameColumnMsg.prototype.component1 = function () {
    return this.columnIndex;
  };
  RenameColumnMsg.prototype.component2 = function () {
    return this.newName;
  };
  RenameColumnMsg.prototype.copy_19mbxw$ = function (columnIndex, newName) {
    return new RenameColumnMsg(columnIndex === void 0 ? this.columnIndex : columnIndex, newName === void 0 ? this.newName : newName);
  };
  RenameColumnMsg.prototype.toString = function () {
    return 'RenameColumnMsg(columnIndex=' + Kotlin.toString(this.columnIndex) + (', newName=' + Kotlin.toString(this.newName)) + ')';
  };
  RenameColumnMsg.prototype.hashCode = function () {
    var result = 0;
    result = result * 31 + Kotlin.hashCode(this.columnIndex) | 0;
    result = result * 31 + Kotlin.hashCode(this.newName) | 0;
    return result;
  };
  RenameColumnMsg.prototype.equals = function (other) {
    return this === other || (other !== null && (typeof other === 'object' && (Object.getPrototypeOf(this) === Object.getPrototypeOf(other) && (Kotlin.equals(this.columnIndex, other.columnIndex) && Kotlin.equals(this.newName, other.newName)))));
  };
  function WipCardsBoardNameMsg(boardNameMsg) {
    WipCardsMsg.call(this);
    this.boardNameMsg = boardNameMsg;
  }
  WipCardsBoardNameMsg.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'WipCardsBoardNameMsg',
    interfaces: [WipCardsMsg]
  };
  WipCardsBoardNameMsg.prototype.component1 = function () {
    return this.boardNameMsg;
  };
  WipCardsBoardNameMsg.prototype.copy_cdz9t9$ = function (boardNameMsg) {
    return new WipCardsBoardNameMsg(boardNameMsg === void 0 ? this.boardNameMsg : boardNameMsg);
  };
  WipCardsBoardNameMsg.prototype.toString = function () {
    return 'WipCardsBoardNameMsg(boardNameMsg=' + Kotlin.toString(this.boardNameMsg) + ')';
  };
  WipCardsBoardNameMsg.prototype.hashCode = function () {
    var result = 0;
    result = result * 31 + Kotlin.hashCode(this.boardNameMsg) | 0;
    return result;
  };
  WipCardsBoardNameMsg.prototype.equals = function (other) {
    return this === other || (other !== null && (typeof other === 'object' && (Object.getPrototypeOf(this) === Object.getPrototypeOf(other) && Kotlin.equals(this.boardNameMsg, other.boardNameMsg))));
  };
  function WipCardsUiState() {
  }
  WipCardsUiState.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'WipCardsUiState',
    interfaces: []
  };
  function WipCardsBoardUiState(boardUuid, boardName) {
    WipCardsUiState.call(this);
    this.boardUuid = boardUuid;
    this.boardName = boardName;
  }
  WipCardsBoardUiState.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'WipCardsBoardUiState',
    interfaces: [WipCardsUiState]
  };
  WipCardsBoardUiState.prototype.component1 = function () {
    return this.boardUuid;
  };
  WipCardsBoardUiState.prototype.component2 = function () {
    return this.boardName;
  };
  WipCardsBoardUiState.prototype.copy_bpj1ed$ = function (boardUuid, boardName) {
    return new WipCardsBoardUiState(boardUuid === void 0 ? this.boardUuid : boardUuid, boardName === void 0 ? this.boardName : boardName);
  };
  WipCardsBoardUiState.prototype.toString = function () {
    return 'WipCardsBoardUiState(boardUuid=' + Kotlin.toString(this.boardUuid) + (', boardName=' + Kotlin.toString(this.boardName)) + ')';
  };
  WipCardsBoardUiState.prototype.hashCode = function () {
    var result = 0;
    result = result * 31 + Kotlin.hashCode(this.boardUuid) | 0;
    result = result * 31 + Kotlin.hashCode(this.boardName) | 0;
    return result;
  };
  WipCardsBoardUiState.prototype.equals = function (other) {
    return this === other || (other !== null && (typeof other === 'object' && (Object.getPrototypeOf(this) === Object.getPrototypeOf(other) && (Kotlin.equals(this.boardUuid, other.boardUuid) && Kotlin.equals(this.boardName, other.boardName)))));
  };
  function WipCardsAppState(domain, uiState) {
    this.domain = domain;
    this.uiState = uiState;
  }
  WipCardsAppState.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'WipCardsAppState',
    interfaces: []
  };
  WipCardsAppState.prototype.component1 = function () {
    return this.domain;
  };
  WipCardsAppState.prototype.component2 = function () {
    return this.uiState;
  };
  WipCardsAppState.prototype.copy_ni87cl$ = function (domain, uiState) {
    return new WipCardsAppState(domain === void 0 ? this.domain : domain, uiState === void 0 ? this.uiState : uiState);
  };
  WipCardsAppState.prototype.toString = function () {
    return 'WipCardsAppState(domain=' + Kotlin.toString(this.domain) + (', uiState=' + Kotlin.toString(this.uiState)) + ')';
  };
  WipCardsAppState.prototype.hashCode = function () {
    var result = 0;
    result = result * 31 + Kotlin.hashCode(this.domain) | 0;
    result = result * 31 + Kotlin.hashCode(this.uiState) | 0;
    return result;
  };
  WipCardsAppState.prototype.equals = function (other) {
    return this === other || (other !== null && (typeof other === 'object' && (Object.getPrototypeOf(this) === Object.getPrototypeOf(other) && (Kotlin.equals(this.domain, other.domain) && Kotlin.equals(this.uiState, other.uiState)))));
  };
  function updateWipCards(applicationState, message) {
    var tmp$, tmp$_0;
    var commandsToExecute = emptyList();
    if (Kotlin.isType(message, RenameColumnMsg))
      tmp$_0 = withColumnRenamed(applicationState, message.columnIndex, message.newName);
    else if (Kotlin.isType(message, WipCardsBoardNameMsg)) {
      var oldUiState = Kotlin.isType(tmp$ = applicationState.uiState, WipCardsBoardUiState) ? tmp$ : throwCCE();
      var newBoardName = updateBoardName(oldUiState.boardName, message.boardNameMsg);
      tmp$_0 = applicationState.copy_ni87cl$(newBoardName.domain, oldUiState.copy_bpj1ed$(void 0, newBoardName));
    }
     else
      tmp$_0 = Kotlin.noWhenBranchMatched();
    var newApplicationState = tmp$_0;
    return new KatydidApplicationCycle(newApplicationState, commandsToExecute);
  }
  function withColumnRenamed($receiver, columnIndex, newName) {
    return $receiver;
  }
  function viewWipCards$lambda$lambda$lambda$lambda(msg) {
    return new WipCardsBoardNameMsg(msg);
  }
  function viewWipCards$lambda$lambda$lambda$lambda_0(closure$applicationState, this$) {
    return function ($receiver) {
      var board = this$.boardWithUuid_vhpctj$(closure$applicationState.uiState.boardUuid);
      if (board != null) {
        viewColumnHeadings($receiver, this$.columns_3yv1mr$(board));
        viewColumnContent($receiver, this$.columns_3yv1mr$(board));
      }
      return Unit;
    };
  }
  function viewWipCards$lambda$lambda(closure$applicationState) {
    return function ($receiver) {
      if (Kotlin.isType(closure$applicationState.uiState, WipCardsBoardUiState)) {
        var receiver = closure$applicationState.domain;
        var closure$applicationState_0 = closure$applicationState;
        viewBoardName($receiver, closure$applicationState_0.uiState.boardName, viewWipCards$lambda$lambda$lambda$lambda);
        $receiver.table_55vzb3$('.board', void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, viewWipCards$lambda$lambda$lambda$lambda_0(closure$applicationState_0, receiver));
      }
      return Unit;
    };
  }
  function viewWipCards$lambda(closure$applicationState) {
    return function ($receiver) {
      $receiver.main_6zr3om$('#wip-cards-app', void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, viewWipCards$lambda$lambda(closure$applicationState));
      return Unit;
    };
  }
  function viewWipCards(applicationState) {
    return viewWipCards$lambda(applicationState);
  }
  function viewColumnHeadings$lambda$lambda$lambda(closure$columns) {
    return function ($receiver) {
      width_0($receiver, get_percent(100 / closure$columns.size | 0));
      return Unit;
    };
  }
  function viewColumnHeadings$lambda$lambda(closure$columns, closure$column) {
    return function ($receiver) {
      style($receiver, viewColumnHeadings$lambda$lambda$lambda(closure$columns));
      $receiver.unaryPlus_pdl1vz$(closure$column.heading);
      return Unit;
    };
  }
  function viewColumnHeadings$lambda(closure$columns) {
    return function ($receiver) {
      var tmp$;
      var colIndex = 1;
      tmp$ = closure$columns.iterator();
      while (tmp$.hasNext()) {
        var column = tmp$.next();
        $receiver.th_f4d2jq$('.column-heading', colIndex, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, viewColumnHeadings$lambda$lambda(closure$columns, column));
        colIndex = colIndex + 1 | 0;
      }
      return Unit;
    };
  }
  function viewColumnHeadings($receiver, columns) {
    $receiver.tr_n8e5b5$('#headings', void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, viewColumnHeadings$lambda(columns));
  }
  function viewColumnContent$lambda$lambda($receiver) {
    $receiver.unaryPlus_pdl1vz$('Place cards here');
    return Unit;
  }
  function viewColumnContent$lambda(closure$columns) {
    return function ($receiver) {
      var tmp$;
      var colIndex = 1;
      tmp$ = closure$columns.iterator();
      while (tmp$.hasNext()) {
        var column = tmp$.next();
        $receiver.td_iemoux$('.column-content', colIndex, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, viewColumnContent$lambda$lambda);
        colIndex = colIndex + 1 | 0;
      }
      return Unit;
    };
  }
  function viewColumnContent($receiver, columns) {
    $receiver.tr_n8e5b5$('#content', void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, viewColumnContent$lambda(columns));
  }
  function WipCardsApplication() {
  }
  WipCardsApplication.prototype.initialize = function () {
    var boardUuid = new Uuid('theBoard');
    var board = new Board_0(boardUuid, 'Sample');
    var col1Uuid = new Uuid('col1');
    var col1 = new Column(col1Uuid, 'To Do');
    var col2Uuid = new Uuid('col2');
    var col2 = new Column(col2Uuid, 'Analyze');
    var col3Uuid = new Uuid('col3');
    var col3 = new Column(col3Uuid, 'Implement');
    var col4Uuid = new Uuid('col4');
    var col4 = new Column(col4Uuid, 'Test');
    var col5Uuid = new Uuid('col5');
    var col5 = new Column(col5Uuid, 'Deploy');
    var domain = (new WipCardsDomain()).with_702jzg$(board).added().with_4g3rdc$(col1).added().with_702jzg$(board).contains_4g3rdc$(col1).with_4g3rdc$(col2).added().with_702jzg$(board).contains_4g3rdc$(col2).with_4g3rdc$(col3).added().with_702jzg$(board).contains_4g3rdc$(col3).with_4g3rdc$(col4).added().with_702jzg$(board).contains_4g3rdc$(col4).with_4g3rdc$(col5).added().with_702jzg$(board).contains_4g3rdc$(col5);
    return new KatydidApplicationCycle(new WipCardsAppState(domain, new WipCardsBoardUiState(boardUuid, new BoardNameViewModel(void 0, void 0, domain, boardUuid))));
  };
  WipCardsApplication.prototype.update_xwzc9p$ = function (applicationState, message) {
    return updateWipCards(applicationState, message);
  };
  WipCardsApplication.prototype.view_11rb$ = function (applicationState) {
    return viewWipCards(applicationState);
  };
  WipCardsApplication.$metadata$ = {
    kind: Kind_CLASS,
    simpleName: 'WipCardsApplication',
    interfaces: [KatydidApplication]
  };
  function wipCardsMain(args) {
    buildStyleElement(ensureNotNull(document.getElementById('appStyleElement')), makeWipCardsStyleSheet());
    runApplication('app', new WipCardsApplication());
  }
  function makeWipCardsStyleSheet$lambda$lambda($receiver) {
    fontFamily($receiver, ['Arial', 'Helvetica Neue', 'Helvetica', 'sans-serif']);
    return Unit;
  }
  function makeWipCardsStyleSheet$lambda$lambda$lambda$lambda($receiver) {
    border($receiver, get_px(1), ELineStyle.solid, colors.black);
    fontWeight($receiver, EFontWeight.bold);
    padding($receiver, get_px(5), get_px(0));
    return Unit;
  }
  function makeWipCardsStyleSheet$lambda$lambda$lambda$lambda_0($receiver) {
    textAlign($receiver, ETextAlign.center);
    return Unit;
  }
  function makeWipCardsStyleSheet$lambda$lambda$lambda($receiver) {
    width_0($receiver, get_percent(100));
    $receiver.invoke_k851pc$('th.column-heading', makeWipCardsStyleSheet$lambda$lambda$lambda$lambda);
    $receiver.invoke_k851pc$('td.column-content', makeWipCardsStyleSheet$lambda$lambda$lambda$lambda_0);
    return Unit;
  }
  function makeWipCardsStyleSheet$lambda$lambda_0($receiver) {
    padding($receiver, get_px(0));
    $receiver.invoke_k851pc$('&.board', makeWipCardsStyleSheet$lambda$lambda$lambda);
    return Unit;
  }
  function makeWipCardsStyleSheet$lambda($receiver) {
    $receiver.invoke_k851pc$('body', makeWipCardsStyleSheet$lambda$lambda);
    boardNameStyles($receiver);
    $receiver.invoke_k851pc$('table', makeWipCardsStyleSheet$lambda$lambda_0);
    return Unit;
  }
  function makeWipCardsStyleSheet() {
    return makeStyleSheet(makeWipCardsStyleSheet$lambda);
  }
  function main(args) {
    var appName = window['appName'];
    console.log('Starting application: ', appName);
    switch (appName) {
      case 'Hello World':
        helloWorldMain(args);
        break;
      case 'Greet Me':
        greetMeMain(args);
        break;
      case 'Sudoku Solver':
        sudokuSolverMain(args);
        break;
      case 'Digital Clock':
        digitalClockMain(args);
        break;
      case 'WIP Cards':
        wipCardsMain(args);
        break;
      default:console.log('ERROR: Unknown application: ', appName);
        break;
    }
    console.log('DONE');
  }
  var package$js = _.js || (_.js = {});
  var package$katydid = package$js.katydid || (package$js.katydid = {});
  var package$samples = package$katydid.samples || (package$katydid.samples = {});
  var package$digitalclock = package$samples.digitalclock || (package$samples.digitalclock = {});
  package$digitalclock.DigitalClockApplication = DigitalClockApplication;
  package$digitalclock.digitalClockMain_kand9s$ = digitalClockMain;
  package$digitalclock.makeDigitalClockStyleSheet = makeDigitalClockStyleSheet;
  package$digitalclock.DigitalClockAppState = DigitalClockAppState;
  package$digitalclock.DigitalClockMsg = DigitalClockMsg;
  Object.defineProperty(package$digitalclock, 'ClockTickMsg', {
    get: ClockTickMsg_getInstance
  });
  package$digitalclock.updateTime_pqgv7x$ = updateTime;
  package$digitalclock.updateDigitalClock_i1j43p$ = updateDigitalClock;
  package$digitalclock.viewDigitalClock_saiywm$ = viewDigitalClock;
  var package$greetme = package$samples.greetme || (package$samples.greetme = {});
  package$greetme.GreetMeAppState = GreetMeAppState;
  package$greetme.GreetMeMsg = GreetMeMsg;
  package$greetme.GreetMeApplication = GreetMeApplication;
  package$greetme.greetMeMain_kand9s$ = greetMeMain;
  var package$helloworld = package$samples.helloworld || (package$samples.helloworld = {});
  Object.defineProperty(package$helloworld, 'helloWorldView', {
    get: function () {
      return helloWorldView;
    }
  });
  package$helloworld.helloWorldMain_kand9s$ = helloWorldMain;
  var package$sudokusolver = package$samples.sudokusolver || (package$samples.sudokusolver = {});
  package$sudokusolver.SudokuSolverApplication = SudokuSolverApplication;
  package$sudokusolver.sudokuSolverMain_kand9s$ = sudokuSolverMain;
  package$sudokusolver.makeSudokuStyleSheet = makeSudokuStyleSheet;
  package$sudokusolver.BoardChange = BoardChange;
  Object.defineProperty(Cell$State, 'UNSET', {
    get: Cell$State$UNSET_getInstance
  });
  Object.defineProperty(Cell$State, 'DEFINED', {
    get: Cell$State$DEFINED_getInstance
  });
  Object.defineProperty(Cell$State, 'GUESSED', {
    get: Cell$State$GUESSED_getInstance
  });
  Object.defineProperty(Cell$State, 'SOLVED', {
    get: Cell$State$SOLVED_getInstance
  });
  Cell.State = Cell$State;
  package$sudokusolver.Cell = Cell;
  Object.defineProperty(CellGroup$Type, 'ROW', {
    get: CellGroup$Type$ROW_getInstance
  });
  Object.defineProperty(CellGroup$Type, 'COLUMN', {
    get: CellGroup$Type$COLUMN_getInstance
  });
  Object.defineProperty(CellGroup$Type, 'BLOCK', {
    get: CellGroup$Type$BLOCK_getInstance
  });
  Object.defineProperty(CellGroup$Type, 'DIAGNONAL', {
    get: CellGroup$Type$DIAGNONAL_getInstance
  });
  CellGroup.Type = CellGroup$Type;
  package$sudokusolver.CellGroup = CellGroup;
  package$sudokusolver.Board = Board;
  package$sudokusolver.SudokuSolverSettings = SudokuSolverSettings;
  package$sudokusolver.SudokuSolverAppState = SudokuSolverAppState;
  package$sudokusolver.SudokuSolverMsg = SudokuSolverMsg;
  package$sudokusolver.PlaceValueMsg = PlaceValueMsg;
  package$sudokusolver.RemoveValueMsg = RemoveValueMsg;
  package$sudokusolver.ChangeSettingsMsg = ChangeSettingsMsg;
  package$sudokusolver.SettingsChange = SettingsChange;
  package$sudokusolver.ChangeIsXSudoku = ChangeIsXSudoku;
  package$sudokusolver.ChangeIsSolvedAutomatically = ChangeIsSolvedAutomatically;
  package$sudokusolver.ChangeIsUserSolving = ChangeIsUserSolving;
  package$sudokusolver.updateSudokuSolver_iwq1rv$ = updateSudokuSolver;
  package$sudokusolver.withCellValueRemoved_9uej89$ = withCellValueRemoved;
  package$sudokusolver.withCellValueSet_kr6ltz$ = withCellValueSet;
  package$sudokusolver.withSettingsChanged_qvw7ds$ = withSettingsChanged;
  package$sudokusolver.viewSudokuSolver_azcqru$ = viewSudokuSolver;
  var package$wipcards = package$samples.wipcards || (package$samples.wipcards = {});
  var package$board = package$wipcards.board || (package$wipcards.board = {});
  package$board.BoardNameViewModel = BoardNameViewModel;
  package$board.BoardNameMsg = BoardNameMsg;
  package$board.updateBoardName_khb8pj$ = updateBoardName;
  package$board.viewBoardName_e361ln$ = viewBoardName;
  package$board.boardNameStyles_um522i$ = boardNameStyles;
  var package$domain = package$wipcards.domain || (package$wipcards.domain = {});
  var package$model = package$domain.model || (package$domain.model = {});
  package$model.Board = Board_0;
  package$model.Card = Card;
  package$model.Column = Column;
  package$model.User = User;
  package$model.Concepts = Concepts;
  package$model.Connections = Connections;
  WipCardsDomain.BoardChange = WipCardsDomain$BoardChange;
  WipCardsDomain.CardChange = WipCardsDomain$CardChange;
  WipCardsDomain.ColumnChange = WipCardsDomain$ColumnChange;
  WipCardsDomain.UserChange = WipCardsDomain$UserChange;
  package$model.WipCardsDomain = WipCardsDomain;
  var package$update = package$domain.update || (package$domain.update = {});
  package$update.CreateBoardAction = CreateBoardAction;
  package$update.RenameBoardAction = RenameBoardAction;
  package$update.DeleteBoardAction = DeleteBoardAction;
  package$update.DeleteColumnAction = DeleteColumnAction;
  package$update.ChangeCardDetailsAction = ChangeCardDetailsAction;
  package$update.ChangeCardTitleAction = ChangeCardTitleAction;
  package$update.ChangeColumnHeadingAction = ChangeColumnHeadingAction;
  package$update.DeleteCardAction = DeleteCardAction;
  var package$infrastructure = package$wipcards.infrastructure || (package$wipcards.infrastructure = {});
  package$infrastructure.Action = Action;
  package$infrastructure.addIf_qc2i7d$ = addIf;
  package$infrastructure.Uuid = Uuid;
  var package$messages = package$wipcards.messages || (package$wipcards.messages = {});
  package$messages.WipCardsMsg = WipCardsMsg;
  package$messages.RenameColumnMsg = RenameColumnMsg;
  package$messages.WipCardsBoardNameMsg = WipCardsBoardNameMsg;
  var package$model_0 = package$wipcards.model || (package$wipcards.model = {});
  package$model_0.WipCardsUiState = WipCardsUiState;
  package$model_0.WipCardsBoardUiState = WipCardsBoardUiState;
  package$model_0.WipCardsAppState = WipCardsAppState;
  var package$update_0 = package$wipcards.update || (package$wipcards.update = {});
  package$update_0.updateWipCards_c0meac$ = updateWipCards;
  package$update_0.withColumnRenamed_31roqc$ = withColumnRenamed;
  var package$view = package$wipcards.view || (package$wipcards.view = {});
  package$view.viewWipCards_8yzj75$ = viewWipCards;
  package$wipcards.WipCardsApplication = WipCardsApplication;
  package$wipcards.wipCardsMain_kand9s$ = wipCardsMain;
  package$wipcards.makeWipCardsStyleSheet = makeWipCardsStyleSheet;
  _.main_kand9s$ = main;
  helloWorldView = katydid(void 0, helloWorldView$lambda);
  cssClassName = 'wipcards-board-name';
  main([]);
  Kotlin.defineModule('Katydid-Samples', _);
  return _;
}(typeof this['Katydid-Samples'] === 'undefined' ? {} : this['Katydid-Samples'], kotlin, this['Katydid-VDOM-JS'], this['Katydid-CSS-JS'], this['Katydid-Events-JS']);

//# sourceMappingURL=Katydid-Samples.js.map
